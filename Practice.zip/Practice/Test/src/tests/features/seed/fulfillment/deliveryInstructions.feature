Feature: Managing delivery instructions for seed fulfillment
User should be able to create, update and delete delivery instructions in a seed fulfillment dealer release order

    Background:
        Given User navigates to the application
        * successfully logs-in as "json://LOGIN_USER_DATA#appAdminUser"
        * user sets single account context for seed fulfillment operation
        * user is on seed-fulfillment page

    Scenario: Enabling delivery instructions option
    User should be able to manage delivery instructions when ship-to and branch information details are provided (ship-to account must be eligible for delivery instructions)
        When user starts a new order release request
        * selects ship-to account eligible for delivery instructions
        * selects branch option
        Then Delivery Instructions option must be enabled

    Scenario: Add new delivery instructions
    User should be able to add new delivery instructions when the option is enabled
        Given Delivery Instructions option is enabled
        When user opens delivery instructions page
        * adds a new row for delivery instructions
        * provides all the details for a new delivery instructions record
        * saves the details
        Then a new Delivery Instructions record must be created

    Scenario: Update existing delivery instructions
    User should be able to modify existing delivery instructions when the option is enabled
        Given Delivery Instructions option is enabled
        When user opens delivery instructions page
        * selects an existing delivery instructions record for edit
        * modifies contact-type
        * saves the details
        Then the selected Delivery Instructions record must be updated

    Scenario: Delete existing delivery instructions
    User should be able to delete existing delivery instructions when the option is enabled
        Given Delivery Instructions option is enabled
        When user opens delivery instructions page
        # * selects an existing delivery instructions record
        * deletes the top record
        Then the selected Delivery Instructions record must be deleted