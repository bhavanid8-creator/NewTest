Feature: Seed fulfillment
User should be able to make seed fulfillment i.e., release dealer orders. Released orders information will flow to JDE.

    Background:
        Given User navigates to the application
        And successfully logs-in as "json://LOGIN_USER_DATA#appAdminUser"
        * user sets single account context for seed fulfillment operation
        
    Scenario: Create and save a draft release order with default pallet info
    User can create a new release order with default pallet info and save the order as a draft 
        Given user is on seed-fulfillment new release order page
        When user provides all the delivery details
        * sets product release quantities after inventory computing
        * computes default pallet charges
        * saves the release order
        Then a new release order must be available as unsubmitted request

    @jde
    Scenario: Open and submit draft release order with default pallet info
    User can open a draft release order and place the ERP order with default pallet info.
        Given scenario uses JDE log-in as "json://LOGIN_USER_DATA#jdeUser"
        * user is on seed-fulfillment's Unsubmitted-Drafts section
        When user opens a saved draft release order
        * places the ERP order
        Then a new release order must be available as submitted request
        * product available release quantity must be decremented accordingly
        * order information must be available in the JDE

    @jde
    Scenario: Create a new ERP order with custom pallet info
    User can create a new release order by overriding pallet info and place the ERP order directly. User can view fulfillment breakdown information for a product.
        Given scenario uses JDE log-in as "json://LOGIN_USER_DATA#jdeUser"
        * user is on seed-fulfillment new release order page
        When user creates an order with all the details
        * views product lot information
        * overrides Pallet Non-Stock quantity
        * places the ERP order
        Then a new release order must be available as submitted request
        * product available release quantity must be decremented accordingly
        * order information must be available in the JDE