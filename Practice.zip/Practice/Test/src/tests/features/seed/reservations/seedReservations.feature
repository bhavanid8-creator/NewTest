Feature: Seed Reservations tests

    Background: 
        Given User navigates to the application
        And successfully logs-in as "json://LOGIN_USER_DATA#appAdminUser"
        
        Scenario: Create new seed reservation
        Seed reservation should be successfully created
            Given user selects single account that does not have any existing reservation and navigates to the seed reservations page
            When user navigates to the new seed reservation page
            * fills reservation header details
            * adds new line item to the reservation
            * user clicks on Submit-Reservation
            Then a new reservation must be created

        Scenario: Update seed reservation by changing quantity of line item
        Seed reservation should be successfully updated
            Given user selects single account that has an existing reservation with multiple line items and navigates to the seed reservations page
            When user navigates to the existing seed reservation page
            * modifies reservation line quantity
            * user clicks on Update-Reservation
            Then the reservation must be updated
        
        Scenario: Update seed reservation by adding a new line item
        Seed reservation should be successfully updated
            Given user selects single account that has an existing reservation with one line item and navigates to the seed reservations page
            When user navigates to the existing seed reservation page
            * adds new line item to the existing reservation
            * user clicks on Update-Reservation
            Then the reservation must be updated

        Scenario: User should not be allowed to remove a seed reservation containing only one line item
        Seed reservation should not be allowed to be updated
            Given user selects single account that has an existing reservation with one line item and navigates to the seed reservations page
            When user navigates to the existing seed reservation page
            * attempts to remove the line item from the reservation
            Then Update-Reservation button should be disabled
        
        Scenario: Delete seed reservation
        Seed reservation should be successfully deleted even if it has only one line item
            Given user selects single account that has an existing reservation with one line item and navigates to the seed reservations page
            When user clicks on Delete-Reservation
            Then the reservation must be deleted