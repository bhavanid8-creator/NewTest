Feature: Seed Replant Module on Evolve

    Background:
        Given User navigates to the application
        And successfully logs-in as "json://LOGIN_USER_DATA#appAdminUser"
        #And user sets single account context for seed replant "Active" request

    Scenario: To verify that User can view Seed Replant page via Seed menu navigation
        When User navigates to "Seed" menu and selects "Seed Replant"
        Then The user should be able to view "Seed Replant" page

    Scenario: To verify Seed Replant screen consist of below elements
                1. Header Filter.
                2. Export.
                3. Create New Request.
                4. Active Replant Request tab.
                5. Replant Request Draft.
        Given User is on seed replant page
        And Status Notice message saved in DataBag from DataBase
        Then User should be able to see all the elements mentioned in scenario on seed replant page

    Scenario: To verify Create New Seed Replant Draft Request successfully
        Given user sets single account context for seed replant "Create" request
        And User is on seed replant page
        When The user clicks on Create New Request from Seed Replant page
        Then Seed Replant Create Request page should be open
        When User enters the data in header fields "<growerType>" and select failed and Replant product then click on Save Draft button
        Then Order should be created as draft for "<growerType>" and user should redirect to draft order page
        Examples: 
        | growerType        |
        | Licensed Grower   |
        | UnLicensed Grower |

     Scenario: To verify Create New Seed Replant Request Successfully for Licensed Grower
         Given user sets single account context for seed replant "Create" request
         And User is on seed replant page
         When The user clicks on Create New Request from Seed Replant page
         Then Seed Replant Create Request page should be open
         When User enters the data in header fields "Licensed Grower" and select failed and Replant product then click on Review Request button
         Then Request should be created for "Licensed Grower" and user should redirect to Review Request page
         When User clicks on agrrement check box and then click on Submit for Approval
         Then Order should be created and user should redirect to active seed replant request tab

     Scenario: To verify Create New Seed Replant Request throws error or not for unlicensed grower
         Given user sets single account context for seed replant "Create" request
         And User is on seed replant page
         When The user clicks on Create New Request from Seed Replant page
         Then Seed Replant Create Request page should be open
         When User enters the data in header fields "UnLicensed Grower" and select failed and Replant product then click on Review Request button
         Then Request should not be created for UnLicensed Grower and user should stay on same page with validation error message

    Scenario: To verify user is able to use Header Filters on Seed Replant Screen
        Given User is on seed replant page
        When User clicks on filter option verify the list of header filters available on seed replant page

    Scenario: To verify Active and Draft Replant Request tab for the logged in User
        Given user sets single account context for seed replant "<tabName>" request
        And User is on seed replant page
        When User navigates to "<tabName>" tab
        Then User should be able to see the expected columns on "<tabName>" tab
        And User should be able to see the correct list of replant request in "<tabName>" tab based on the status of the request
        Examples:
        | tabName  |
        | Active   |
        | Draft    |

    Scenario: To verify Export to Excel downloads seed replant data
        Given user sets single account context for seed replant "Active" request
        And User is on seed replant page
        When User clicks on Export to Excel on seed replant page
        Then Excel file should be downloaded with data on seed replant page

    # Scenario: To verify Seed Replant Request details by clicking on request id from respective tab
    #     Given User is on seed replant page
    #     When User navigates to "<tabName>" tab and clicks on first request id from the list
    #     And Get replant request details based on request and store in DataBag
    #     Then Seed Replant Request details page should be open
    #     And "<tabName>" seed replant request details should be correct and mapped to corresponding fields with expected action buttons
    #     Examples: 
    #     | tabName |
    #     | Active  |
    #     | Draft   |

    # Scenario: To verify Seed Replant Request edit functionality by clicking on request id for drafted request
    #     Given User is on seed replant page
    #     When The user clicks on Create New Request from Seed Replant page
    #     Then Seed Replant Create Request page should be open
    #     When User enters the data in header fields "Licensed Grower" and select failed and Replant product then click on Save Draft button
    #     Then Order should be created as draft for "Licensed Grower" and user should redirect to draft order page
    #     When User clicks on request id from "Draft" tab
    #     Then Seed Replant Request details page should be open
    #     When User updates drafted seed replant request and clicks on Review Request button
    #     Then Request should be created for "Licensed Grower" and user should redirect to Review Request page
    #     When User clicks on agrrement check box and then click on Submit for Approval
    #     Then Order should be created and user should redirect to active seed replant request tab

    Scenario: To verify View as PDF added with Treatment for Replant and Failed Products
        Given user sets single account context for seed replant "Create" request
        And User is on seed replant page
        When The user clicks on Create New Request from Seed Replant page
        Then Seed Replant Create Request page should be open
        When User enters the data in header fields "Licensed Grower" and select failed and Replant product then click on Review Request button
        Then Request should be created for "Licensed Grower" and user should redirect to Review Request page
        And Treatment details should be displayed for failed and replant products on review request page
        When User clicks on View as PDF on seed replant review page
        Then PDF should be generated with treatment details for failed and replant products
        When User clicks on agrrement check box and then click on Submit for Approval
        Then Order should be created and user should redirect to active seed replant request tab