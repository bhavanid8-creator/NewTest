Feature: Dealer Order product transfer - multiple accounts context

    Background: 
        Given User navigates to the application
        And successfully logs-in as "json://LOGIN_USER_DATA#appAdminUser"
        
    Scenario: Successful product transfer - new order
    Product(s) should be successfully transferred to another dealer's new order
        And user sets multiple account context for product transfer when "target-dealer-has-no-order"
        And user navigates to the dealer order for product transfer
        And user transfers products to another dealer having no existing order
        Then the transfer must succeed with the message "Your order has been saved"
        And order page must display source dealer order id
    
    Scenario: Successful product transfer - existing order
    Product(s) should be successfully transferred to another dealer's existing order
        And user sets multiple account context for product transfer when "target-dealer-has-an-order"
        And user navigates to the dealer order for product transfer
        And user transfers products to another dealer having an existing order
        Then the transfer must succeed with the message "Your order has been saved"
        And order page must display source dealer order id