# Feature: Dealer Order Updation - EA - single account context

#     Background: 
#         Given User navigates to the application
#         * successfully logs-in as "json://LOGIN_USER_DATA#appAdminUser"
    
#     Scenario: Successfully add EA product to a dealer order
#     Dealer order should be successfully updated with an EA product
#         When user sets single account context for update dealer operation with EA operation type "AddProduct"
#         * user navigates to the dealer order for updating EA order
#         * user opens Add-EA-Products-to-the-order page
#         * adds EA products with quantities to the order
#         Then the dealer order must be updated with the EA products

#     Scenario: Modify EA Units by increasing product quantity
#     EA units must be incremented on the dealer order
#         When user sets single account context for update dealer operation with EA operation type "IncreaseQty"
#         * user navigates to the dealer order for updating EA order
#         * user selects an EA product on the order
#         * opens Modify-EA-Products-Quantity page
#         * modifies quantity using "+" button and updates the order
#         Then EA units on the dealer order must be incremented
    
#     Scenario: Modify EA Units by decreasing product quantity
#     EA units must be decremented on the dealer order
#         When user sets single account context for update dealer operation with EA operation type "DecreaseQty"
#         * user navigates to the dealer order for updating order
#         * user selects an EA product on the order
#         * opens Modify-EA-Products-Quantity page
#         * modifies quantity using "-" button and updates the order
#         Then EA units on the dealer order must be decremented
    
#     Scenario: Modify EA Units by updating product quantity in the textbox
#     EA units must be updated on the dealer order
#         When user sets single account context for update dealer operation with EA operation type "IncreaseQty"
#         * user navigates to the dealer order for updating EA order
#         * user selects an EA product on the order
#         * opens Modify-EA-Products-Quantity page
#         * increases quantity using quantity textbox and updates the order
#         Then EA units on the dealer order must be incremented

#     Scenario: Decrease EA Units
#     EA units must be decremented on the dealer order
#         When user sets single account context for update dealer operation with EA operation type "DecreaseQty"
#         * user navigates to the dealer order for updating order
#         * user selects an EA product on the order
#         * opens Decrease-EA-Units page
#         * modifies quantity using "-" button and updates the order
#         Then EA units on the dealer order must be decremented

#     Scenario: Decrease EA Units - error checking
#     EA units must NOT be incremented on the dealer order using 'Decrease EA Units' option
#         When user sets single account context for update dealer operation with EA operation type "IncreaseQty"
#         * user navigates to the dealer order for updating order
#         * user selects an EA product on the order
#         * opens Decrease-EA-Units page
#         * increases quantity using quantity textbox
#         Then user should not be allowed to increment the quantity and update the order
    
#     Scenario: Swap EA Product
#     Selected EA product units must be replaced by another product units on the dealer order
#         When user sets single account context for update dealer operation to swap EA product
#         * user navigates to the dealer order for updating order
#         * user selects an EA product on the order for swapping
#         * opens Swap-EA-Product page
#         * enters EA units value using quantity textbox of the target product and updates the order
#         Then the dealer order must be updated with the original and swapped EA products