# Feature: Dealer Order product transfer ( with emulated user credentials and multiple dealer account context )

#     Background: 
#         Given User navigates to the application
#         And successfully logs-in as "json://LOGIN_USER_DATA#appAdminUser"
    
#     Scenario: Successful product transfer - new order
#     Product(s) should be successfully transferred to another dealer's new order
#         And user sets multiple accounts context as "json://DEALER_PRODUCT_TRANSFER_NEW_ORDER_EMULATION#multiDealerAccountContext" with emulated account background as "json://ACCOUNT_CONTEXT_DATA#emulatedAccount"
#         And user navigates to the dealer order "json://DEALER_PRODUCT_TRANSFER_NEW_ORDER_EMULATION#orderAccount"
#         And user transfers products to another dealer having no existing order
#         |   products                | json://DEALER_PRODUCT_TRANSFER_NEW_ORDER_EMULATION#productsToTransfer     |
#         |   destinationDealer       | json://DEALER_PRODUCT_TRANSFER_NEW_ORDER_EMULATION#destinationOrderAccount      |
#         |   transferModifications   | json://DEALER_PRODUCT_TRANSFER_NEW_ORDER_EMULATION#transferModifications  |
#         Then the transfer must succeed with the message "Your order has been saved"
#         And order page must display target dealer's new order id
    
#     Scenario: Successful product transfer - existing order
#     Product(s) should be successfully transferred to another dealer's existing order
#         And user sets multiple accounts context as "json://DEALER_PRODUCT_TRANSFER_OLD_ORDER_EMULATION#multiDealerAccountContext" with emulated account background as "json://ACCOUNT_CONTEXT_DATA#emulatedAccount"
#         And user navigates to the dealer order "json://DEALER_PRODUCT_TRANSFER_OLD_ORDER_EMULATION#orderAccount"
#         And user transfers products to another dealer having an existing order
#         |   existingOrderID         | json://DEALER_PRODUCT_TRANSFER_OLD_ORDER_EMULATION#destinationOrderAccount.orderIdToUpdate  |
#         |   products                | json://DEALER_PRODUCT_TRANSFER_OLD_ORDER_EMULATION#productsToTransfer        |
#         |   destinationDealer       | json://DEALER_PRODUCT_TRANSFER_OLD_ORDER_EMULATION#destinationOrderAccount   |
#         |   transferModifications   | json://DEALER_PRODUCT_TRANSFER_OLD_ORDER_EMULATION#transferModifications     |
#         Then the transfer must succeed with the message "Your order has been saved"
#         And order page must display target dealer's existing order id