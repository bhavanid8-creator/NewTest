# Feature: Dealer Order Updation ( with emulated user credentials and multiple dealer account context )

#     Background: 
#         Given feature uses the data file "json://DEALER_OLD_ORDER_EMULATION"
#         * User navigates to the application
#         * successfully logs-in as "json://LOGIN_USER_DATA#appAdminUser"
#         * user sets multiple accounts context as "json://DEALER_OLD_ORDER_EMULATION#multiDealerAccountContext" with emulated account background as "json://ACCOUNT_CONTEXT_DATA#emulatedAccount"
#         * user selects Account details and navigates to the existing dealer order
    
#     Scenario: Successful dealer order update - change existing product quantity
#     Dealer order should be successfully modified when user changes an existing product quanity in the existing order
#         When user modifies quantity for an existing line item on Dealer-order page
#         * completes the dealer order modifications
#         Then the existing order must be updated
    
#     Scenario: Successful dealer order update - delete existing product
#     Dealer order should be successfully modified when user deletes an existing product from the existing order
#         When user deletes an existing line item on Dealer-order page
#         * completes the dealer order modifications
#         Then the existing order must be updated