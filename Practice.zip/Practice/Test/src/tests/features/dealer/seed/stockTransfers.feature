Feature: Stock transfer from one dealer to another dealer

    Background:
        Given User navigates to the application
        And successfully logs-in as "json://LOGIN_USER_DATA#appAdminUser"
        And user sets multiple account context for stock transfer
        And user is on stock-transfers page

    Scenario: Sending dealer creates a stock transfer and submits
    Stock transfer request should be successfully created and submitted to the receiving dealer
        When user starts a new stock transfer request
        * selects transfer-from and transfer-to accounts
        * selects delivery option
        * provides pickup information
        * adds products to the transfer request
        * submits the request
        Then sending dealer should view a new request with SUBMITTED status
        * receiving dealer should view the same request with PENDING status

    Scenario: Receiving dealer approves the trasfer request without updating delivery instructions
    Stock transfer request should be successfully approved without delivery instructions
        And sending dealer has already submitted a stock transfer request
        When user opens the submitted stock transfer request as receiving dealer
        * approves the request
        Then receiving dealer should view the same request with APPROVED status
        * sending dealer should view the same request with APPROVED status

    Scenario: Receiving dealer rejects the trasfer request
    Stock transfer request should be successfully rejected by the receiving dealer
        And sending dealer has already submitted a stock transfer request
        When user opens the submitted stock transfer request as receiving dealer
        * rejects the request
        Then receiving dealer should view the same request with REJECTED status
        * sending dealer should view the same request with REJECTED status
        * sending dealer should be able to view the receiving dealer comments

    Scenario: Sending dealer submits again a rejected stock transfer
    Rejected stock transfer request should be successfully submitted again
        And receiving dealer has rejected a stock transfer request
        When user opens the rejected stock transfer request as sending dealer
        * submits the updated request again
        Then sending dealer should view a new request with SUBMITTED status
        * receiving dealer should view the same request with PENDING status

    Scenario: Receiving dealer approves resubmitted trasfer request that was rejected earlier
    Resubmitted stock transfer request should be successfully approved by the receiving dealer
        And sending dealer has already resubmitted a stock transfer request
        When user opens the submitted stock transfer request as receiving dealer
        * approves the request
        Then receiving dealer should view the same request with APPROVED status
        * sending dealer should view the same request with APPROVED status
