# Feature: Dealer Order product transfer outside territory ( with emulated user credentials and multiple dealer account context )

#     Background: 
#         Given User navigates to the application
#         And successfully logs-in as "json://LOGIN_USER_DATA#appAdminUser"
    
#     Scenario: Successful product transfer between dealers that do not share same parent account
#     Product(s) should be successfully transferred between dealers that are not in the same territory
#         And user sets multiple accounts context as "json://DEALER_PRODUCT_TRANSFER_OUTSIDE_TERRITORY_EMULATION#multiDealerAccountContext" with emulated account background as "json://ACCOUNT_CONTEXT_DATA#emulatedAccount"
#         And user navigates to the dealer order "json://DEALER_PRODUCT_TRANSFER_OUTSIDE_TERRITORY_EMULATION#orderAccount"
#         And user transfers products to another dealer from another territory
#         |   products                | json://DEALER_PRODUCT_TRANSFER_OUTSIDE_TERRITORY_EMULATION#productsToTransfer     |
#         |   destinationDealer       | json://DEALER_PRODUCT_TRANSFER_OUTSIDE_TERRITORY_EMULATION#destinationOrderAccount      |
#         |   transferModifications   | json://DEALER_PRODUCT_TRANSFER_OUTSIDE_TERRITORY_EMULATION#transferModifications  |
#         Then the transfer must succeed with the message "Your order has been saved"