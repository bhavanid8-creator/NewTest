Feature: Dealer Order product transfer outside territory ( with admin user credentials and single dealer account context )

    Background: 
        Given User navigates to the application
        And successfully logs-in as "json://LOGIN_USER_DATA#appAdminUser"
    
    Scenario: Successful product transfer to a dealer with different parent
    Product(s) should be successfully transferred between dealers that are not in the same territory
        And user sets single account context for outside territory product transfer when "target-dealer-has-no-order"
        And user navigates to the dealer order for product transfer
        And user transfers products to another dealer from another territory
        Then the transfer must succeed with the message "Your order has been saved"