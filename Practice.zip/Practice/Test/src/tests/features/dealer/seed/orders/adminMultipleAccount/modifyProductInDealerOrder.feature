Feature: Dealer Order Product Modification - multiple accounts context

     Background: 
         Given feature uses the data file "json://DEALER_OLD_ORDER_MODIFY_MULTI_AC_CONTEXT"
         * User navigates to the application
         * successfully logs-in as "json://LOGIN_USER_DATA#appAdminUser"
         * user sets multiple dealer account context as "json://DEALER_OLD_ORDER_MODIFY_MULTI_AC_CONTEXT#multiDealerAccountContext"
         * user selects Account details and navigates to the existing dealer order
   
     Scenario Outline: Successful dealer order product modification - product replacement
     Selected product in the dealer order should be successfully replaced by another product with the specified package size 
         When user selects a product line item on the order page that can be modified by "<modificationOption>"
         * navigates to product modification page by "<modificationOption>"
         * specifies units for the replacing product and previews changes
         * completes the dealer order modifications
         Then the existing order must be updated
     Examples: 
         | modificationOption | 
         | Treatment          |              
       #  | Package Size       |
       #  | Seed Size          |