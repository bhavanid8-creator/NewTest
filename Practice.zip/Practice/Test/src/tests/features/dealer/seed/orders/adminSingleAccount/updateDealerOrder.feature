Feature: Dealer Order Updation - single account context

    Background: 
        Given User navigates to the application
        * successfully logs-in as "json://LOGIN_USER_DATA#appAdminUser"
    
    Scenario: Successful dealer order update - add new product
    Dealer order should be successfully modified when user adds a new product to the existing order
        When user sets single account context for update dealer operation with operation type "AddProduct"
        * user navigates to the dealer order for updating order
        * user opens Add-Products-to-the-order page
        * adds products to the dealer order
        * sets various properties for each new line item on Dealer-order page
        * completes the dealer order modifications
        Then the existing order must be updated
    
    Scenario: Successful dealer order update - increase product quantity
    Dealer order should be successfully modified when user changes an existing product quantity by clicking the plus button
        When user sets single account context for update dealer operation with operation type "IncreaseQty"
        * user navigates to the dealer order for updating order
        * user increments quantity for an existing line item on order page
        * completes the dealer order modifications
        Then the existing order must be updated
    
    Scenario: Successful dealer order update - decrease product quantity
    Dealer order should be successfully modified when user changes an existing product quantity by clicking the minus button
        When user sets single account context for update dealer operation with operation type "DecreaseQty"
        * user navigates to the dealer order for updating order
        * user decrements quantity for an existing line item on order page
        * completes the dealer order modifications
        Then the existing order must be updated

    Scenario: Successful dealer order update - delete existing product
    Dealer order should be successfully modified when user deletes an existing product from the existing order
        When user sets single account context for update dealer operation with operation type "DeleteProduct"
        * user navigates to the dealer order for updating order
        * user deletes an existing line item on order page
        * completes the dealer order modifications
        Then the existing order must be updated