# Feature: Dealer Order Creation - multiple accounts context

#     Background: 
#         Given feature uses the data file "json://DEALER_NEW_ORDER_MULTI_AC_CONTEXT"
#         * User navigates to the application
#         * successfully logs-in as "json://LOGIN_USER_DATA#appAdminUser"
#         * user sets multiple dealer account context as "json://DEALER_NEW_ORDER_MULTI_AC_CONTEXT#multiDealerAccountContext"
#         * dealer order does not exist
#         * user selects Account details and navigates to the new dealer order
    
#     Scenario: Successful dealer order creation - dealer account selection on dealer-orders page
#     Dealer order should be successfully created
#         When user opens Add-Products-to-the-order page
#         * adds products to the dealer order
#         * sets various properties for each new line item on Dealer-order page
#         * places the dealer order
#         Then a new dealer order must be created