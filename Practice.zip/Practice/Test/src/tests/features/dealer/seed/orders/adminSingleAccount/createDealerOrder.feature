Feature: Dealer Order Creation - single account context

    Background: 
        Given User navigates to the application
        * successfully logs-in as "json://LOGIN_USER_DATA#appAdminUser"
        * user sets single account context for create dealer operation
        * user navigates to the dealer order
    
    Scenario: Successful dealer order creation - dealer account selection on dealer-orders page
    Dealer order should be successfully created
        When user opens Add-Products-to-the-order page
        * adds products to the dealer order
        * sets various properties for each new line item on Dealer-order page
        * places the dealer order
        Then a new dealer order must be created