# Feature: Dealer Order Updation - multiple accounts context

#     Background: 
#         Given feature uses the data file "json://DEALER_OLD_ORDER_MULTI_AC_CONTEXT"
#         * User navigates to the application
#         * successfully logs-in as "json://LOGIN_USER_DATA#appAdminUser"
#         * user sets multiple dealer account context as "json://DEALER_OLD_ORDER_MULTI_AC_CONTEXT#multiDealerAccountContext"
#         * user selects Account details and navigates to the existing dealer order
    
#     Scenario: Successful dealer order update - add new product
#     Dealer order should be successfully modified when user adds a new product to the existing order
#         When user opens Add-Products-to-the-order page
#         * adds products to the dealer order
#         * sets various properties for each new line item on Dealer-order page
#         * completes the dealer order modifications
#         Then the existing order must be updated

#     Scenario: Successful dealer order update - change existing product quantity
#     Dealer order should be successfully modified when user changes an existing product quanity in the existing order
#         When user modifies quantity for an existing line item on Dealer-order page
#         * completes the dealer order modifications
#         Then the existing order must be updated
    
#     Scenario: Successful dealer order update - delete existing product
#     Dealer order should be successfully modified when user deletes an existing product from the existing order
#         When user deletes an existing line item on Dealer-order page
#         * completes the dealer order modifications
#         Then the existing order must be updated