Feature: Dealer Order Product Modification - single account context

    Background: 
        Given User navigates to the application
        * successfully logs-in as "json://LOGIN_USER_DATA#appAdminUser"
    
    Scenario Outline: Successful dealer order product modification
    Selected product in the dealer order should be successfully replaced by another product with the specified package size 
        * user sets single account context with dealer order prerequisite data for product modification with option "<modificationOption>"
        * user navigates to the dealer order
        When user selects a product line item on the order page
        * navigates to product modification page
        * specifies units for the replacing product and previews changes
        * completes the dealer order modifications
        Then the existing order must be updated
    Examples: 
        | modificationOption |                         
      #  | Package Size       |
      #  | Seed Size          |
        | Treatment          |