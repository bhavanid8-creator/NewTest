Feature: Order Split for the Bulk Proprietary products
Ship-To account does not have any existing draft order.

    Background: 
        Given User navigates to the application
        * successfully logs-in as "json://LOGIN_USER_DATA#appAdminUser"
        * user sets single account context for create cpp order operation with package type as "bulk" and supplier type as "proprietary" with multiple delivery dates
        * user navigates to the cpp 'Orders' menu
        * user does not have existing draft orders
        * user navigates to the new cpp order
        
        Scenario: Order must contain multiple sub-orders based on requested arrival date and item number
        Products must be ordered in separate sub-orders based on requested arrival date and item numbers
            When user adds new line items to the cpp order with necessary details along with line items requested arrival dates multiple times
            * user clicks on place order button
            Then a new cpp order must be created
            * products must be ordered in separate sub-orders based on requested arrival date and item number
