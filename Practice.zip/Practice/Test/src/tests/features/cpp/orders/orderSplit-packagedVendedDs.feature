Feature: Order Split for the products with Packaged, Vended and Direct Ship category
Ship-To account does not have any existing draft order.

    Background: 
        Given User navigates to the application
        * successfully logs-in as "json://LOGIN_USER_DATA#appAdminUser"
        * user sets single account context for create cpp order operation with PACKAGED VENDED DS products
        * user navigates to the cpp 'Orders' menu
        * user does not have existing draft orders
        * user navigates to the new cpp order

        Scenario: Order must be split based on supplier number
        Product must be ordered in separate sub-orders based on supplier number.
            When user adds new line items to the cpp order with necessary details
            * user clicks on place order button
            Then a new cpp order must be created
            * order must be split into multiple sub-orders based on supplier number

        