Feature: Marking order items favorite

    Background: 
        Given User navigates to the application
        And successfully logs-in as "json://LOGIN_USER_DATA#appAdminUser"
        * user sets single account context for create cpp order operation with PACKAGED product
        * user navigates to the cpp 'Orders' menu
        * user opens either a new order or existing draft order
        * deletes all existing line items from the draft order

        Scenario: Mark a product as favorite from product selection screen
        Product must be marked as favorite.
            Given navigates to product selection screen and searches for a product
            * a favorite product does not exist
            When user clicks on favorite button of a search result
            Then product must be available in favorites section

        Scenario: Remove a product from favorite list
        Product must be removed from favorite products list.
            Given navigates to product selection screen and searches for a product
            * a favorite product exists
            When user clicks on favorite button of a search result
            Then product must be removed as a favorite
        
        Scenario: Mark a product as favorite from order line item
        Product must be marked as favorite.
            Given navigates to product selection screen and adds a product
            * a favorite product does not exist in the line item
            When user clicks on favorite button of a line item
            Then product must be available in favorites section
        
        Scenario: Remove a product's favorite mark from order line item
        Product must be removed from favorite products list.
            Given navigates to product selection screen and adds a product
            * a favorite product exists in the line item
            When user clicks on favorite button of a line item
            Then product must be removed as a favorite