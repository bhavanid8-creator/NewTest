Feature: Creating new CPP order (both draft and submitting order types)

    Background: 
        Given User navigates to the application
        And successfully logs-in as "json://LOGIN_USER_DATA#appAdminUser"
        * user sets single account context for create cpp order operation with PACKAGED product
        * user navigates to the cpp 'Orders' menu

        Scenario: New draft CPP order without existing draft order
        New draft cpp order with minimum details should be successfully created. Ship-To account does not have any existing draft order.
            Given user does not have existing draft orders
            * user navigates to the new cpp order
            When user adds new line item to the cpp order with minimum details
            And user clicks on save draft button
            Then a new draft cpp order must be created
        
        Scenario: New draft CPP order with existing draft order
        New draft cpp order with minimum details should be successfully created. Ship-To account already has an existing draft order.
            Given user has an existing draft order
            * user navigates to the new cpp order
            When user adds new line item to the cpp order with minimum details
            And user clicks on save draft button
            Then a new draft cpp order must be created

        Scenario: Open draft CPP order with create-new-order feature
        Existing draft cpp order should be successfully updated.
            Given user has an existing draft order
            * user navigates to the new cpp order to open existing draft order
            When user updates customer PO of existing draft order
            And user clicks on save draft button
            Then existing draft cpp order must be updated
        
        Scenario: New CPP order without existing draft order
        New cpp order with minimum details should be successfully created. Ship-To account does not have any existing draft order.
            Given user does not have existing draft orders
            * user navigates to the new cpp order
            When user adds new line item to the cpp order with minimum details
            And user clicks on place order button
            Then a new cpp order must be created
        
        Scenario: Place an existing draft order after updating customer PO
        New cpp order with minimum details should be successfully created. Ship-To account should have an existing draft order.
            Given user has an existing draft order
            * user navigates to the new cpp order to open existing draft order
            When user updates customer PO of existing draft order
            And user clicks on place order button
            Then a new cpp order must be created