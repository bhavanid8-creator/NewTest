Feature: SDM - Requested Arrival Date
Ship-To account does not have any existing draft order.

    Background: 
        Given User navigates to the application
        * successfully logs-in as "json://LOGIN_USER_DATA#appAdminUser"
        * user sets single account context for create cpp order operation with PACKAGED product and SDM
        * user navigates to the cpp 'Orders' menu
        * user does not have existing draft orders
        * user navigates to the new cpp order
        * user adds new line items to the order

        Scenario: New draft CPP-SDM order -unscheduled delivery day with a reason
        New draft cpp order with SDM info (unscheduled delivery day with reason as "B2B Order Placed") should be successfully created. 
            When user updates SDM eligible line item delivery date to "unscheduled-day" and selects reason as "B2B Order Placed"
            And user clicks on save draft button
            Then a new draft cpp order must be created

        Scenario: New draft CPP-SDM order -scheduled delivery day
        New draft cpp order with SDM info (scheduled delivery day) should be successfully created.
            When user updates SDM eligible line item delivery date to "scheduled-day"
            And user clicks on save draft button
            Then a new draft cpp order must be created

        Scenario: New draft CPP-SDM order -next scheduled delivery day
        New draft cpp order with SDM info (next scheduled delivery day) should be successfully created.
            When user updates SDM eligible line item delivery date to "next-scheduled-day"
            And user clicks on save draft button
            Then a new draft cpp order must be created

        Scenario: New draft CPP-SDM order - reason code not applicable for non-SDM item
        New draft cpp order with SDM and non-SDM products should be successfully created.
            When user updates non-SDM line item delivery date
            And user clicks on save draft button
            Then a new draft cpp order must be created

        Scenario Outline: New draft CPP-SDM order - multiple items with same unscheduled delivery date
        Two line items having same unscheduled delivery date should have same arrival date reason change code.
            When user updates SDM eligible line item delivery date to "unscheduled-day" and selects reason as "<reasonOption>"
            * user updates another SDM eligible line item delivery date to same "unscheduled-day"
            Then "<reasonOption>" must be automatically selected as the reason for the other line item
        Examples: 
        | reasonOption                 |                         
        | B2B Order Placed             |
        | Expedite Request             |
        | Vendor Program Date          |
        | WinField United Program Date |

        Scenario: New draft CPP-SDM order - multiple items with different unscheduled delivery dates
        Two line items having different unscheduled delivery date can have different arrival date reason change code.
            When user updates SDM eligible line item delivery date to "unscheduled-day" and selects reason as "B2B Order Placed"
            * user updates another SDM eligible line item delivery date to "unscheduled-day" and selects reason as "Expedite Request"
            * user clicks on save draft button
            Then a new draft cpp order must be created

        Scenario: New CPP-SDM order
        New cpp order with SDM info should be successfully created. 
            When user updates SDM eligible line item delivery date to "unscheduled-day" and selects reason as "B2B Order Placed"
            And user clicks on place order button
            Then a new cpp order must be created