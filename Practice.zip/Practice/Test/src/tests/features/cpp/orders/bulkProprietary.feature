Feature: Bulk Proprietary Order
Ship-To account does not have any existing draft order.

    Background: 
        Given User navigates to the application
        * successfully logs-in as "json://LOGIN_USER_DATA#appAdminUser"
        * user sets single account context for create cpp order operation with package type as "bulk" and supplier type as "proprietary"
        * user navigates to the cpp 'Orders' menu
        * user does not have existing draft orders
        * user navigates to the new cpp order
        * user adds new line item to the cpp order with minimum details

        # Scenario: New draft CPP order - customer PO verification
        # New draft cpp order should not be created if customer PO is required but not provided in the order details.
        #    When user clicks on save draft button without filling customer PO
        #    Then customer PO requirement message must be displayed
        #    * draft order must not be saved

        Scenario: New draft CPP order - min-max qty message
        For a new draft cpp order, application should show min-max qty warning message
            When user clicks on view-product-details link
            Then application should show min-max qty warning message
        
        Scenario: New CPP order - min-max qty error message
        If min-max qty rules are not followed, then placing a new cpp order should fail.
            When sets quantity lesser than min qty
            * sets delivery day to today
            * user clicks on place order button
            Then application should show min-max qty error message
            * order must not be placed
        
        Scenario: New CPP order - min qty - 1 line item
        New cpp order with 1 line item should be successfully created when the quantity is set to minimum. 
            When user updates the quantity of the line item to "min-qty"
            * sets delivery day to today
            * user clicks on place order button
            Then a new cpp order must be created
            * order must have single line item with quantity equal to "min-qty"
        
        Scenario: New CPP order - max qty - 1 line item
        New cpp order with 1 line item should be successfully created when the quantity is set to maximum. 
            When user updates the quantity of the line item to "max-qty"
            * sets delivery day to today
            * user clicks on place order button
            Then a new cpp order must be created
            * order must have single line item with quantity equal to "max-qty"
        
        Scenario Outline: New CPP order - greater than max qty - multiple line items
        New cpp order with multiple line items should be successfully created when the quantity is set to greater than maximum.
            When user updates the quantity of the line item to "<qtyOption>"
            * sets delivery day to today
            * user clicks on place order button
            Then a new cpp order must be created
            * order must have multiple line items
        Examples: 
        | qtyOption                  |
        | min-plus-max-qty           |
        | double-max-qty             |
        | one-plus-double-max-qty    |