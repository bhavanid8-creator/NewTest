Feature: Order Split for the Packaged products with requested arrival date
Ship-To account does not have any existing draft order.

    Background: 
        Given User navigates to the application
        * successfully logs-in as "json://LOGIN_USER_DATA#appAdminUser"

        Scenario Outline: Order must contain one or more sub-orders based on requested arrival date
        Products must be ordered in the same or separate sub-orders based on requested arrival date.
            Given user sets single account context for create cpp order operation with PACKAGED products and "<reqArrivalDateCondition>" requested arrival date
            * user navigates to the cpp 'Orders' menu
            * user does not have existing draft orders
            * user navigates to the new cpp order
            When user adds new line items to the cpp order with necessary details along with line items requested arrival dates
            * user clicks on place order button
            Then a new cpp order must be created
            * products must be ordered in the same or separate sub-orders based on requested arrival date
        Examples: 
        | reqArrivalDateCondition |
        | DIFFERENT               |
        | SAME                    |