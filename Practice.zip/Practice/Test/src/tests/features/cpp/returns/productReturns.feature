Feature: Return CPP Products
  Return CPP Products

  Background:
    Given User navigates to the application
    And successfully logs-in as "json://LOGIN_USER_DATA#appAdminUser"
    * user sets single account context for create cpp 'Product Returns' request
    * user navigates to the cpp 'Product Returns' menu

  Scenario: New draft CPP Product Return request without existing draft request
    New draft cpp product return request should be successfully created. Ship-To account does not have any existing draft return requests.
    Given user does not have existing draft requests
    * user navigates to the new cpp request
    When user adds new line items to the cpp request
    And user clicks on save draft request
    Then a new draft cpp request must be created

  Scenario: New draft CPP Product Return request with existing draft request
    New draft cpp product return request should be successfully created. Ship-To account has an existing draft return requests.
    Given user has an existing draft request
    * user navigates to the new cpp request
    When user adds new line items to the cpp request
    And user clicks on save draft request
    Then a new draft cpp request must be created

  Scenario: Open draft CPP Product Return request with new-request feature
    Existing draft cpp product return request should be successfully updated.
    Given user has an existing draft request
    * user navigates to the new cpp request to open existing draft request
    When user updates customer PO of existing draft request
    And user clicks on save draft request
    Then existing draft cpp request must be updated

  Scenario: New CPP Product Return request without existing draft request
    New cpp Product Return request should be successfully created. Ship-To account does not have any existing draft request.
    Given user does not have existing draft requests
    * user navigates to the new cpp request
    When user adds new line items to the cpp request
    And user places the cpp request
    Then a new cpp return request must be created

  Scenario: New CPP Product Return request without existing draft request including non-returnable products
    New cpp Product Return request should be successfully created with non-returnable products. Ship-To account does not have any existing draft request.
    Given user does not have existing draft requests
    * user navigates to the new cpp request
    When user adds new line items to the cpp request including non-returnable products
    And user places the cpp request
    Then a new cpp return request must be created
    
  Scenario: New CPP Product Return request without existing draft request using pickup location
    New cpp Product Return request should be successfully created using pickup location. Ship-To account does not have any existing draft request.
    Given user does not have existing draft requests
    * user navigates to the new cpp request
    When user adds new line items to the cpp request with pickup location
    And user places the cpp request
    Then a new cpp return request must be created

  Scenario: New CPP Product Return request without existing draft request and more than eligible qty
    New cpp Product Return request should be successfully created with more than eligible qty. Ship-To account does not have any existing draft request.
    Given user does not have existing draft requests
    * user navigates to the new cpp request
    When user adds new line items to the cpp request with more than eligible qty
    And user places the cpp request
    Then a new cpp return request must be created

  Scenario: New CPP Product Return request with an existing draft request
    New cpp Product Return request should be successfully created. Ship-To account has an existing draft request.
    Given user has an existing draft request
    * user navigates to the new cpp request to open existing draft request
    When user adds new line items to the cpp request
    * user places the cpp request
    Then a new cpp return request must be created
  
  