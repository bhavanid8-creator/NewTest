Feature: Return CPP Inoculants
  Return CPP Inoculants

  Background:
    Given User navigates to the application
    And successfully logs-in as "json://LOGIN_USER_DATA#appAdminUser"
    * user sets single account context for create cpp 'Inoculant Returns' request
    * user navigates to the cpp 'Inoculant Returns' menu
    # CPP Inoculant Returns draft requests hold old data (eligible return units) and working on such requests for scenarios needing a draft request can fail.
    # Hence, we delete all draft requests before starting a scenario
    * user does not have existing draft requests

  Scenario: New draft CPP Inoculant Return request without existing draft request
    New draft cpp inoculant return request should be successfully created. Ship-To account does not have any existing draft return requests.
    Given user navigates to the new cpp request
    When user adds new line items to the cpp request
    And user clicks on save draft request
    Then a new draft cpp request must be created
  
  Scenario: New draft CPP Inoculant Return request with existing draft request
    New draft cpp inoculant return request should be successfully created. Ship-To account has an existing draft return requests.
    Given user has an existing draft request
    * user navigates to the new cpp request
    When user adds new line items to the cpp request
    And user clicks on save draft request
    Then a new draft cpp request must be created

  Scenario: Open draft CPP Inoculant Return request with new-request feature
    Existing draft cpp inoculant return request should be successfully updated.
    Given user has an existing draft request
    * user navigates to the new cpp request to open existing draft request
    When user updates customer PO of existing draft request
    And user clicks on save draft request
    Then existing draft cpp request must be updated

  Scenario: New CPP Inoculant Return request without existing draft request
    New cpp Inoculant Return request should be successfully created. Ship-To account does not have any existing draft request.
    Given user navigates to the new cpp request
    When user adds new line items to the cpp request
    And user places the cpp request
    Then a new cpp return request must be created

  Scenario: New CPP Inoculant Return request without existing draft request using pickup location
    New cpp Product Return request should be successfully created using pickup location. Ship-To account does not have any existing draft request.
    Given user navigates to the new cpp request
    When user adds new line items to the cpp request with pickup location
    And user places the cpp request
    Then a new cpp return request must be created

  Scenario: New CPP Inoculant Return request with an existing draft request
    New cpp Inoculant Return request should be successfully created. Ship-To account has an existing draft request.
    Given user has an existing draft request
    * user navigates to the new cpp request to open existing draft request
    When user adds new line items to the cpp request
    * user places the cpp request
    Then a new cpp return request must be created

  Scenario: IP limit exceeded warning for a New draft CPP Inoculant Return request without existing draft request
    New draft cpp inoculant return request should display an appropriate warning message before saving the draft request. Ship-To account does not have any existing draft return requests.
    Given user navigates to the new cpp request
    When user adds new line items to the cpp request with more than eligible qty
    Then IP limit exceeded warning must be displayed

  Scenario: IP limit exceeded error for an existing draft CPP Inoculant Return request
    Existing draft cpp inoculant return request should display an appropriate error message before saving the draft request. Ship-To account has an existing draft return request.
    Given user has an existing draft request with IP limit exceeded warning
    * user navigates to the new cpp request to open existing draft request
    When user updates customer PO of existing draft request
    * user clicks on save draft request
    Then IP limit exceeded error must be displayed