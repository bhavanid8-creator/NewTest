Feature: Grower Order Creation tests

    Background: 
        Given User navigates to the application
        And successfully logs-in as "json://LOGIN_USER_DATA#appAdminUser"
        * user sets single account context for create grower operation
        * user navigates to the new grower order
        When user adds new line item to the order and sets order info at line item level

        Scenario: New grower order - line item properties
        Grower order should be successfully created when user selects dealer and grower accounts on grower-order page and order line item properties are set for each line item separately
            And user clicks on Place-Order or Update-Order button
            Then a new order must be created

        Scenario: New grower order - order level properties
        Grower order should be successfully created when user selects dealer and grower accounts on grower-order page and order line item properties are set at order level
            And user sets various properties with order level controls on Grower-order screen
            And user clicks on Place-Order or Update-Order button
            Then a new order must be created