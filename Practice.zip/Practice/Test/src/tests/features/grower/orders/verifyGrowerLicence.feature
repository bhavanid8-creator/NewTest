Feature: Grower licence check tests

    Background: 
        Given User navigates to the application
        And successfully logs-in as "json://LOGIN_USER_DATA#appAdminUser"
        
   Scenario: Verify License Status values on Grower Orders screen
   When user navigates to Grower Orders
     Then the Grower Orders screen should be displayed 
     And the License Status column should be displayed
     And the Grower Orders should contain a grower with License Status "Unlicensed"
     And the Grower Orders should contain a grower with License Status "Licensed"
     And the Grower Orders should contain a grower with License Status "Not Applicable"
     And the Order ID should be displayed
     And the Equiv Units (BG) should be displayed
     And the Last Updated date should be displayed

    Scenario: Verify Grower Licence link for Unlicenced grower
    When user navigates to Grower orders
     And user selects a grower account with license status "Unlicensed" 
     Then a yellow "Action Required" message should be displayed 
     And the message should contain "An active license is missing" 
     And the message should contain a "Grower License" link 
     When user clicks on the "Grower License" link 
     Then the Grower License page should open in the same tab 
     And the Grower Order Number should be displayed
     And the Grower order number should match the captured Grower Order ID

    Scenario: Verify AgCelerate link for unlicensed grower 
    When user navigates to Grower Orders 
     And user selects a grower account with license status "Unlicensed" 
     When user clicks on the "AgCelerate" link 
     Then the user should be redirected to the AgCelerate page And "Welcome to AgCelerate!" should be displayed 