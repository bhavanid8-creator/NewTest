# Feature: Grower Order Creation ( with emulated user credentials and multiple dealer account context )

#     Background: 
#         Given User navigates to the application
#         And successfully logs-in as "json://LOGIN_USER_DATA#appAdminUser"
        
#         Scenario: Grower order creation - line item properties
#         Grower order should be successfully created when user selects dealer and grower accounts on grower-order page and order line item properties are set for each line item separately
#             Given user sets multiple accounts context as "json://CREATE_GROWER_ORDER_WITH_LINE_ITEM_PROPERTIES_EMULATION#multiDealerAccountContext" with emulated account background as "json://ACCOUNT_CONTEXT_DATA#emulatedAccount"
#             And grower order does not exist for "json://CREATE_GROWER_ORDER_WITH_LINE_ITEM_PROPERTIES_EMULATION#singleAccount"
#             And user selects Account and Grower details from "json://CREATE_GROWER_ORDER_WITH_LINE_ITEM_PROPERTIES_EMULATION#singleAccount" and navigates to Add-Products-to-the-order page
#             And user adds products to the order on Add-Products-to-the-order page
#             | filterCategory                                            | searchKey                                          | onlyShowProductOnDealerOrder                                  | onlyShowProductWithAvailability                             | productsToSelect                               |
#             | json://PRODUCT_CATALOG_DATA#0.filters[0].filterCategory   | json://PRODUCT_CATALOG_DATA#0.filters[0].searchKey | json://PRODUCT_CATALOG_DATA#0.onlyShowProductOnDealerOrder | json://PRODUCT_CATALOG_DATA#0.onlyShowProductWithAvailability  | json://PRODUCT_CATALOG_DATA#0.expectedProducts |
#             | json://PRODUCT_CATALOG_DATA#1.filters[0].filterCategory   | json://PRODUCT_CATALOG_DATA#1.filters[0].searchKey | json://PRODUCT_CATALOG_DATA#1.onlyShowProductOnDealerOrder | json://PRODUCT_CATALOG_DATA#1.onlyShowProductWithAvailability  | json://PRODUCT_CATALOG_DATA#1.expectedProducts |
#             And user sets various properties for each line item on Grower-order screen
#             | productName                                                   | units                                                               | deliveryDate                                                               | seller                                                               | customerPO                                                              |
#             | json://PRODUCT_ORDER_DATA#productsToOrder[0].productInfo.name | json://PRODUCT_ORDER_DATA#productsToOrder[0].productOrderInfo.units | json://PRODUCT_ORDER_DATA#productsToOrder[0].productOrderInfo.deliveryDate | json://PRODUCT_ORDER_DATA#productsToOrder[0].productOrderInfo.seller | json://PRODUCT_ORDER_DATA#productsToOrder[0].productOrderInfo.customerPO|
#             | json://PRODUCT_ORDER_DATA#productsToOrder[1].productInfo.name | json://PRODUCT_ORDER_DATA#productsToOrder[1].productOrderInfo.units | json://PRODUCT_ORDER_DATA#productsToOrder[1].productOrderInfo.deliveryDate | json://PRODUCT_ORDER_DATA#productsToOrder[1].productOrderInfo.seller | json://PRODUCT_ORDER_DATA#productsToOrder[1].productOrderInfo.customerPO|
#             And user clicks on Place-Order or Update-Order button
#             Then a new order must be created

#         Scenario: Grower order creation - order level line item properties
#         Grower order should be successfully created when user selects dealer and grower accounts on grower-order page and order line item properties are set at order level
#             Given user sets multiple accounts context as "json://CREATE_GROWER_ORDER_WITH_ORDER_PROPERTIES_EMULATION#multiDealerAccountContext" with emulated account background as "json://ACCOUNT_CONTEXT_DATA#emulatedAccount"
#             And grower order does not exist for "json://CREATE_GROWER_ORDER_WITH_ORDER_PROPERTIES_EMULATION#singleAccount"
#             And user selects Account and Grower details from "json://CREATE_GROWER_ORDER_WITH_ORDER_PROPERTIES_EMULATION#singleAccount" and navigates to Add-Products-to-the-order page
#             And user adds products to the order on Add-Products-to-the-order page
#             | filterCategory                                            | searchKey                                          | onlyShowProductOnDealerOrder                                  | onlyShowProductWithAvailability                             | productsToSelect                               |
#             | json://PRODUCT_CATALOG_DATA#0.filters[0].filterCategory   | json://PRODUCT_CATALOG_DATA#0.filters[0].searchKey | json://PRODUCT_CATALOG_DATA#0.onlyShowProductOnDealerOrder | json://PRODUCT_CATALOG_DATA#0.onlyShowProductWithAvailability  | json://PRODUCT_CATALOG_DATA#0.expectedProducts |
#             | json://PRODUCT_CATALOG_DATA#2.filters[0].filterCategory   | json://PRODUCT_CATALOG_DATA#2.filters[0].searchKey | json://PRODUCT_CATALOG_DATA#2.onlyShowProductOnDealerOrder | json://PRODUCT_CATALOG_DATA#2.onlyShowProductWithAvailability  | json://PRODUCT_CATALOG_DATA#2.expectedProducts |
#             And user sets various properties for each line item on Grower-order screen
#             | productName                                                   | units                                                               | deliveryDate                                                               | seller                                                               | customerPO                                                              |
#             | json://PRODUCT_ORDER_DATA#productsToOrder[0].productInfo.name | json://PRODUCT_ORDER_DATA#productsToOrder[0].productOrderInfo.units | json://PRODUCT_ORDER_DATA#productsToOrder[0].productOrderInfo.deliveryDate | json://PRODUCT_ORDER_DATA#productsToOrder[0].productOrderInfo.seller | json://PRODUCT_ORDER_DATA#productsToOrder[0].productOrderInfo.customerPO|
#             | json://PRODUCT_ORDER_DATA#productsToOrder[1].productInfo.name | json://PRODUCT_ORDER_DATA#productsToOrder[1].productOrderInfo.units | json://PRODUCT_ORDER_DATA#productsToOrder[1].productOrderInfo.deliveryDate | json://PRODUCT_ORDER_DATA#productsToOrder[1].productOrderInfo.seller | json://PRODUCT_ORDER_DATA#productsToOrder[1].productOrderInfo.customerPO|
#             And user must be able to set various properties for all line items with order level controls on Grower-order screen
#             | units                                           | deliveryDate                                           | seller                                           | customerPO                                          |
#             | json://PRODUCT_ORDER_DATA#globalOrderInfo.units | json://PRODUCT_ORDER_DATA#globalOrderInfo.deliveryDate | json://PRODUCT_ORDER_DATA#globalOrderInfo.seller | json://PRODUCT_ORDER_DATA#globalOrderInfo.customerPO|
#             And user clicks on Place-Order or Update-Order button
#             Then a new order must be created