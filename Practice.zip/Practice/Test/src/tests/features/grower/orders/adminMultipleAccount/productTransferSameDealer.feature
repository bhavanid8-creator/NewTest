# Feature: Grower Order product transfer to same dealer ( with admin user credentials and multiple dealer account context )

#     Background: 
#         Given User navigates to the application
#         And successfully logs-in as "json://LOGIN_USER_DATA#appAdminUser"

#     Scenario: Successful product transfer - same dealer - another grower - new order
#     Product(s) should be successfully transferred to same dealer's another grower's new order
#         And user sets multiple accounts context as "json://PRODUCT_TRANSFER_SAME_DEALER_NEW_ORDER_MULTI_AC_CONTEXT#multiDealerAccountContext"
#         And user navigates to the order "json://PRODUCT_TRANSFER_SAME_DEALER_NEW_ORDER_MULTI_AC_CONTEXT#orderAccount" for product transfer
#         And user transfers products to another grower having no existing order
#         |   products                | json://PRODUCT_TRANSFER_SAME_DEALER_NEW_ORDER_MULTI_AC_CONTEXT#productsToTransfer     |
#         |   destinationGrower       | json://PRODUCT_TRANSFER_SAME_DEALER_NEW_ORDER_MULTI_AC_CONTEXT#destinationGrower      |
#         |   seller                  | json://PRODUCT_TRANSFER_SAME_DEALER_NEW_ORDER_MULTI_AC_CONTEXT#updatedSeller          |
#         |   transferModifications   | json://PRODUCT_TRANSFER_SAME_DEALER_NEW_ORDER_MULTI_AC_CONTEXT#transferModifications  |
#         Then the transfer must succeed with the message "Your order has been saved"
#         And order page must display target grower's new order id
    
#     Scenario: Successful product transfer - same dealer - another grower - existing order
#     Product(s) should be successfully transferred to same dealer's another grower's existing order
#         And user sets multiple accounts context as "json://PRODUCT_TRANSFER_SAME_DEALER_OLD_ORDER_MULTI_AC_CONTEXT#multiDealerAccountContext"
#         And user navigates to the order "json://PRODUCT_TRANSFER_SAME_DEALER_OLD_ORDER_MULTI_AC_CONTEXT#orderAccount" for product transfer
#         And user transfers products to another grower having an existing order
#         |   existingOrderID         | json://PRODUCT_TRANSFER_SAME_DEALER_OLD_ORDER_MULTI_AC_CONTEXT#destinationGrowerOrderId  |
#         |   products                | json://PRODUCT_TRANSFER_SAME_DEALER_OLD_ORDER_MULTI_AC_CONTEXT#productsToTransfer        |
#         |   destinationGrower       | json://PRODUCT_TRANSFER_SAME_DEALER_OLD_ORDER_MULTI_AC_CONTEXT#destinationGrower         |
#         |   seller                  | json://PRODUCT_TRANSFER_SAME_DEALER_OLD_ORDER_MULTI_AC_CONTEXT#updatedSeller             |
#         |   transferModifications   | json://PRODUCT_TRANSFER_SAME_DEALER_OLD_ORDER_MULTI_AC_CONTEXT#transferModifications     |
#         Then the transfer must succeed with the message "Your order has been saved"
#         And order page must display target grower's existing order id