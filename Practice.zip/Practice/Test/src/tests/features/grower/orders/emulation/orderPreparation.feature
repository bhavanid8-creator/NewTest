# Feature: Grower Order UI verification - Line items properties update ( emulated credentials and multiple dealer account)
# Verifies if user can set various properties like Delivery Date, Quantity, Customer PO, etc., for the selected products in Grower-Order-Creation flow

#     Background: 
#         Given User navigates to the application
#         And successfully logs-in as "json://LOGIN_USER_DATA#appAdminUser"
#         And user sets multiple accounts context as "json://UPDATE_ORDER_EMULATION#multiDealerAccountContext" with emulated account background as "json://ACCOUNT_CONTEXT_DATA#emulatedAccount"
#         And user selects Account and Grower details from "json://UPDATE_ORDER_EMULATION#singleAccount" and navigates to Add-Products-to-the-order page
#         And user adds products to the order on Add-Products-to-the-order page
#         | filterCategory                                            | searchKey                                          | onlyShowProductOnDealerOrder                                  | onlyShowProductWithAvailability                             | productsToSelect                               |
#         | json://PRODUCT_CATALOG_DATA#0.filters[0].filterCategory   | json://PRODUCT_CATALOG_DATA#0.filters[0].searchKey | json://PRODUCT_CATALOG_DATA#0.onlyShowProductOnDealerOrder | json://PRODUCT_CATALOG_DATA#0.onlyShowProductWithAvailability  | json://PRODUCT_CATALOG_DATA#0.expectedProducts |
#         | json://PRODUCT_CATALOG_DATA#1.filters[0].filterCategory   | json://PRODUCT_CATALOG_DATA#1.filters[0].searchKey | json://PRODUCT_CATALOG_DATA#1.onlyShowProductOnDealerOrder | json://PRODUCT_CATALOG_DATA#1.onlyShowProductWithAvailability  | json://PRODUCT_CATALOG_DATA#1.expectedProducts |
            
#     Scenario: User updates order line item properties on 'Grower-order' page
#     Updating line item properties should help user to finalize the order
#         Then user must be able to set various properties for each line item on Grower-order screen
#         | productName                                                   | units                                                               | deliveryDate                                                               | seller                                                               | customerPO                                                              |
#         | json://PRODUCT_ORDER_DATA#productsToOrder[0].productInfo.name | json://PRODUCT_ORDER_DATA#productsToOrder[0].productOrderInfo.units | json://PRODUCT_ORDER_DATA#productsToOrder[0].productOrderInfo.deliveryDate | json://PRODUCT_ORDER_DATA#productsToOrder[0].productOrderInfo.seller | json://PRODUCT_ORDER_DATA#productsToOrder[0].productOrderInfo.customerPO|
#         | json://PRODUCT_ORDER_DATA#productsToOrder[1].productInfo.name | json://PRODUCT_ORDER_DATA#productsToOrder[1].productOrderInfo.units | json://PRODUCT_ORDER_DATA#productsToOrder[1].productOrderInfo.deliveryDate | json://PRODUCT_ORDER_DATA#productsToOrder[1].productOrderInfo.seller | json://PRODUCT_ORDER_DATA#productsToOrder[1].productOrderInfo.customerPO|

#         And user must be able to set various properties for all line items with order level controls on Grower-order screen
#         | units                                           | deliveryDate                                           | seller                                           | customerPO                                          |
#         | json://PRODUCT_ORDER_DATA#globalOrderInfo.units | json://PRODUCT_ORDER_DATA#globalOrderInfo.deliveryDate | json://PRODUCT_ORDER_DATA#globalOrderInfo.seller | json://PRODUCT_ORDER_DATA#globalOrderInfo.customerPO|

#         And Place-Order or Update-Order button must be enabled on Grower-order screen