Feature: Grower Order product transfer to another dealer( with admin user credentials and multiple dealer account context )

    Background: 
        Given User navigates to the application
        And successfully logs-in as "json://LOGIN_USER_DATA#appAdminUser"

    Scenario: Successful product transfer-another dealer-another grower-new order
    Product(s) should be successfully transferred to another dealer's another grower's new order
        And user sets multiple account context for product transfer when "target-grower-has-no-order"
        And user navigates to the order for product transfer
        And user transfers products to another dealer-grower having no existing order
        Then the transfer must succeed with the message "Your order has been saved"
        And order page must display target grower's new order id
    
    Scenario: Successful product transfer-another dealer-another grower-existing order
    Product(s) should be successfully transferred to another dealer's another grower's existing order
        And user sets multiple account context for product transfer when "target-grower-has-an-order"
        And user navigates to the order for product transfer
        And user transfers products to another dealer-grower having an existing order
        Then the transfer must succeed with the message "Your order has been saved"
        And order page must display target grower's existing order id