# Feature: Grower Order screens verification - Account setup
# Verifies Account setup related screens in Grower-Order-Creation flow

#     Background: 
#         Given User navigates to the application
#         And successfully logs-in as "json://LOGIN_USER_DATA#appAdminUser"
    
#     Scenario: User sets the account context on Emulation page
#     Setting an emulated account context should help user in selecting this account and related grower information for a new grower order creation
#         And user sets emulated accounts context as "json://ACCOUNT_CONTEXT_DATA#emulatedAccount"
#         Then user must be able to use context specific emulated accounts from "json://ACCOUNT_CONTEXT_DATA#emulatedAccount" along with related grower details on Seed-Orders screen
#         And user must be able to select context specific emulated accounts from "json://ACCOUNT_CONTEXT_DATA#emulatedAccount" along with related grower details on Create-New-Grower-Order screen