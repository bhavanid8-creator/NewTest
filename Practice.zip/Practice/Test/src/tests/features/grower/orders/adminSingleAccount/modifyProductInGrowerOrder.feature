Feature: Grower Order Product Modification - single account context

    Background: 
        Given User navigates to the application
        * successfully logs-in as "json://LOGIN_USER_DATA#appAdminUser"

    Scenario Outline: Successful grower order update - product replacement
    Grower order should be successfully updated when user replaces existing line items of the existing order
        And user sets single account context with grower order prerequisite data for product modification with option "<modificationOption>"
        And user navigates to the order for the product modification
        And user modifies a product
        And user clicks on Update-Order button
        Then the existing order must be updated
    Examples: 
        | modificationOption |
     #   | Treatment          |
        | Package Size       |
        | Seed Size          |