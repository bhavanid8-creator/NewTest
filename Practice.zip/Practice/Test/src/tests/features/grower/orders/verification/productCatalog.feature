# Feature: Grower Order screens verification - Product selection
# Verifies Product selection related screens in Grower-Order-Creation flow

#     Background: 
#         Given User navigates to the application
#         And successfully logs-in as "json://LOGIN_USER_DATA#appAdminUser"
#         And user sets single account context as "json://ACCOUNT_CONTEXT_DATA#singleAccount"
#         And user selects Account and Grower details from "json://ACCOUNT_CONTEXT_DATA#singleAccount" and navigates to Add-Products-to-the-order page
    
#     Scenario Outline: User searches for products on 'Add-Products-to-the-order' page
#     Searching for products should help user to add right products to the order
#         And user searches for products with "<filterCategory>", "<searchKey>", "<onlyShowProductOnDealerOrder>", "<onlyShowProductWithAvailability>"
#         Then user must be able to select products as "<products>" on Add-Product-to-the-order screen
#         And Add-to-Order button must be enabled on Add-Product-to-the-order screen

#         Examples: 
#         | filterCategory                                            | searchKey                                          | onlyShowProductOnDealerOrder                                  | onlyShowProductWithAvailability                             | products                               |
#         | json://PRODUCT_CATALOG_DATA#0.filters[0].filterCategory   | json://PRODUCT_CATALOG_DATA#0.filters[0].searchKey | json://PRODUCT_CATALOG_DATA#0.onlyShowProductOnDealerOrder | json://PRODUCT_CATALOG_DATA#0.onlyShowProductWithAvailability  | json://PRODUCT_CATALOG_DATA#0.expectedProducts |
#         | json://PRODUCT_CATALOG_DATA#1.filters[0].filterCategory   | json://PRODUCT_CATALOG_DATA#1.filters[0].searchKey | json://PRODUCT_CATALOG_DATA#1.onlyShowProductOnDealerOrder | json://PRODUCT_CATALOG_DATA#1.onlyShowProductWithAvailability  | json://PRODUCT_CATALOG_DATA#1.expectedProducts |
            