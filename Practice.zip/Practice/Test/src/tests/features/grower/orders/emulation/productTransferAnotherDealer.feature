# Feature: Grower Order product transfer to another dealer ( with emulated user credentials and multiple dealer account context )

#     Background: 
#         Given User navigates to the application
#         And successfully logs-in as "json://LOGIN_USER_DATA#appAdminUser"

#     Scenario: Successful product transfer - another dealer - another grower - new order
#     Product(s) should be successfully transferred to another dealer's another grower's new order
#         And user sets multiple accounts context as "json://PRODUCT_TRANSFER_ANOTHER_DEALER_NEW_ORDER_EMULATION#multiDealerAccountContext" with emulated account background as "json://ACCOUNT_CONTEXT_DATA#emulatedAccount"
#         And user navigates to the order "json://PRODUCT_TRANSFER_ANOTHER_DEALER_NEW_ORDER_EMULATION#orderAccount" for product transfer to another dealer
#         And user transfers products to another dealer-grower having no existing order
#         |   products                | json://PRODUCT_TRANSFER_ANOTHER_DEALER_NEW_ORDER_EMULATION#productsToTransfer     |
#         |   destinationDealer       | json://PRODUCT_TRANSFER_ANOTHER_DEALER_NEW_ORDER_EMULATION#destinationOrderAccount      |
#         |   seller                  | json://PRODUCT_TRANSFER_ANOTHER_DEALER_NEW_ORDER_EMULATION#updatedSeller          |
#         |   transferModifications   | json://PRODUCT_TRANSFER_ANOTHER_DEALER_NEW_ORDER_EMULATION#transferModifications  |
#         Then the transfer must succeed with the message "Your order has been saved"
#         And order page must display target grower's new order id
    
#     Scenario: Successful product transfer - another dealer - another grower - existing order
#     Product(s) should be successfully transferred to another dealer's another grower's existing order
#         And user sets multiple accounts context as "json://PRODUCT_TRANSFER_ANOTHER_DEALER_OLD_ORDER_EMULATION#multiDealerAccountContext" with emulated account background as "json://ACCOUNT_CONTEXT_DATA#emulatedAccount"
#         And user navigates to the order "json://PRODUCT_TRANSFER_ANOTHER_DEALER_OLD_ORDER_EMULATION#orderAccount" for product transfer to another dealer
#         And user transfers products to another dealer-grower having an existing order
#         |   existingOrderID         | json://PRODUCT_TRANSFER_ANOTHER_DEALER_OLD_ORDER_EMULATION#destinationOrderAccount.orderIdToUpdate  |
#         |   products                | json://PRODUCT_TRANSFER_ANOTHER_DEALER_OLD_ORDER_EMULATION#productsToTransfer        |
#         |   destinationDealer       | json://PRODUCT_TRANSFER_ANOTHER_DEALER_OLD_ORDER_EMULATION#destinationOrderAccount   |
#         |   seller                  | json://PRODUCT_TRANSFER_ANOTHER_DEALER_OLD_ORDER_EMULATION#updatedSeller             |
#         |   transferModifications   | json://PRODUCT_TRANSFER_ANOTHER_DEALER_OLD_ORDER_EMULATION#transferModifications     |
#         Then the transfer must succeed with the message "Your order has been saved"
#         And order page must display target grower's existing order id

#     # Scenario: Product transfer validations_emul-diff-dealer-diff-grower-existing-order
#     # Page must allow user to transfer product(s)
#     #     And user sets multiple accounts context as "json://PRODUCT_TRANSFER_ANOTHER_DEALER_OLD_ORDER_EMULATION#multiDealerAccountContext" with emulated account background as "json://ACCOUNT_CONTEXT_DATA#emulatedAccount"
#     #     And user navigates to the order "json://PRODUCT_TRANSFER_ANOTHER_DEALER_OLD_ORDER_EMULATION#orderAccount" for product transfer to another dealer
#     #     Then user should be able to transfers products to another dealer-grower having an existing order
#     #     |   existingOrderID         | json://PRODUCT_TRANSFER_ANOTHER_DEALER_OLD_ORDER_EMULATION#destinationOrderAccount.orderIdToUpdate  |
#     #     |   products                | json://PRODUCT_TRANSFER_ANOTHER_DEALER_OLD_ORDER_EMULATION#productsToTransfer        |
#     #     |   destinationDealer       | json://PRODUCT_TRANSFER_ANOTHER_DEALER_OLD_ORDER_EMULATION#destinationOrderAccount   |
#     #     |   seller                  | json://PRODUCT_TRANSFER_ANOTHER_DEALER_OLD_ORDER_EMULATION#updatedSeller             |
#     #     |   transferModifications   | json://PRODUCT_TRANSFER_ANOTHER_DEALER_OLD_ORDER_EMULATION#transferModifications     |