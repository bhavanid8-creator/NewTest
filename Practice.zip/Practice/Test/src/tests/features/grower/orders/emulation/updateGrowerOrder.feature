# Feature: Grower Order Modification ( with emulated user credentials and multiple dealer account context )

#     Background: 
#         Given User navigates to the application
#         And successfully logs-in as "json://LOGIN_USER_DATA#appAdminUser"
#         And user sets multiple accounts context as "json://UPDATE_ORDER_EMULATION#multiDealerAccountContext" with emulated account background as "json://ACCOUNT_CONTEXT_DATA#emulatedAccount"
    
#     Scenario: Successful grower order update - adding new line item
#     Grower order should be successfully updated when user adds a new line item to the existing order
#         And user navigates to the order "json://UPDATE_ORDER_EMULATION#newLineItemToAdd.orderAccount"
#         And user adds new line item "json://UPDATE_ORDER_EMULATION#newLineItemToAdd.productToAdd" to the order and sets line item order info
#         And user clicks on Update-Order button
#         Then the existing order must be updated
        
#     Scenario: Successful grower order update - modifying existing first line item
#     Grower order should be successfully updated when user modifies existing line item of the existing order
#         And user navigates to the order "json://UPDATE_ORDER_EMULATION#existingLineItemToUpdate.orderAccount"
#         And user modifies first line item
#         And user clicks on Update-Order button
#         Then the existing order must be updated

#     Scenario: Successful grower order update - deleting existing first line item
#     Grower order should be successfully updated when user deletes existing line item of the existing order
#         And user navigates to the order "json://UPDATE_ORDER_EMULATION#existingLineItemToDelete.orderAccount"
#         And user deletes first line item
#         And user clicks on Update-Order button
#         Then the existing order must be updated

#     Scenario: Successful grower order update - product replacement by Package-Size option
#     Grower order should be successfully updated when user replaces existing line items of the existing order
#         And user navigates to the order "json://UPDATE_ORDER_EMULATION#modifyProducts.orderAccount" for the product modification with the option "Package Size"
#         And user modifies products
#         And user clicks on Update-Order button
#         Then the existing order must be updated