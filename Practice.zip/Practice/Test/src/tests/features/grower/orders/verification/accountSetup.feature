# Feature: Grower Order screens verification - Account setup
# Verifies Account setup related screens in Grower-Order-Creation flow

#     Background: 
#         Given User navigates to the application
#         And successfully logs-in as "json://LOGIN_USER_DATA#appAdminUser"
    
#     Scenario: User sets the account context on Account page - single account selection
#     Setting one or more accounts context should help user in selecting those accounts and related grower information for a new grower order creation
#         And user sets single account context as "json://ACCOUNT_CONTEXT_DATA#singleAccount"
#         Then user must be able to use context specific accounts from "json://ACCOUNT_CONTEXT_DATA#singleAccount" along with related grower details on Seed-Orders screen
#         And user must be able to select context specific accounts from "json://ACCOUNT_CONTEXT_DATA#singleAccount" along with related grower details on Create-New-Grower-Order screen