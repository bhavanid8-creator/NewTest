# Feature: Grower Order product transfer to another dealer ( with admin user credentials and single dealer account context )

#     Background: 
#         Given User navigates to the application
#         And successfully logs-in as "json://LOGIN_USER_DATA#appAdminUser"
    
#     Scenario: Successful product transfer - another dealer - another grower - new order
#     Product(s) should be successfully transferred to another dealer's another grower's new order
        # And user sets single account context with order account as "json://PRODUCT_TRANSFER_ANOTHER_DEALER_NEW_ORDER#orderAccount"
        # And user navigates to the order "json://PRODUCT_TRANSFER_ANOTHER_DEALER_NEW_ORDER#orderAccount" for product transfer
        # And user transfers products to another dealer-grower having no existing order
        # |   products                | json://PRODUCT_TRANSFER_ANOTHER_DEALER_NEW_ORDER#productsToTransfer     |
        # |   destinationDealer       | json://PRODUCT_TRANSFER_ANOTHER_DEALER_NEW_ORDER#destinationOrderAccount      |
        # |   seller                  | json://PRODUCT_TRANSFER_ANOTHER_DEALER_NEW_ORDER#updatedSeller          |
        # |   transferModifications   | json://PRODUCT_TRANSFER_ANOTHER_DEALER_NEW_ORDER#transferModifications  |
        # Then the transfer must succeed with the message "Your order has been saved"
        # And order page must display target grower's new order id
    
    # Scenario: Successful product transfer - another dealer - another grower - existing order
    # Product(s) should be successfully transferred to another dealer's another grower's existing order
        # And user sets single account context with order account as "json://PRODUCT_TRANSFER_ANOTHER_DEALER_OLD_ORDER#orderAccount"
        # And user navigates to the order "json://PRODUCT_TRANSFER_ANOTHER_DEALER_OLD_ORDER#orderAccount" for product transfer
        # And user transfers products to another dealer-grower having an existing order
        # |   existingOrderID         | json://PRODUCT_TRANSFER_ANOTHER_DEALER_OLD_ORDER#destinationOrderAccount.orderIdToUpdate  |
        # |   products                | json://PRODUCT_TRANSFER_ANOTHER_DEALER_OLD_ORDER#productsToTransfer        |
        # |   destinationDealer       | json://PRODUCT_TRANSFER_ANOTHER_DEALER_OLD_ORDER#destinationOrderAccount   |
        # |   seller                  | json://PRODUCT_TRANSFER_ANOTHER_DEALER_OLD_ORDER#updatedSeller             |
        # |   transferModifications   | json://PRODUCT_TRANSFER_ANOTHER_DEALER_OLD_ORDER#transferModifications     |
        # Then the transfer must succeed with the message "Your order has been saved"
        # And order page must display target grower's existing order id