Feature: Grower Order Modification tests

    Background: 
        Given User navigates to the application
        And successfully logs-in as "json://LOGIN_USER_DATA#appAdminUser"
        
    Scenario: Successful grower order update - adding new line item
    Grower order should be successfully updated when user adds a new line item to the existing order
        And user sets single account context for update grower operation with operation type "AddProduct"
        And user navigates to the grower order for updating order
        And user adds new line item to the order and sets line item order info
        And user clicks on Update-Order button
        Then the existing order must be updated
    
    Scenario: Successful grower order update - increase product quantity
    Grower order should be successfully modified when user changes an existing product quantity by clicking the plus button
        When user sets single account context for update grower operation with operation type "IncreaseQty"
        * user navigates to the grower order for updating order
        * user increments quantity for an existing line item on order page
        * completes the order modifications
        Then the existing order must be updated
    
    Scenario: Successful grower order update - decrease product quantity
    Grower order should be successfully modified when user changes an existing product quantity by clicking the minus button
        When user sets single account context for update grower operation with operation type "DecreaseQty"
        * user navigates to the grower order for updating order
        * user decrements quantity for an existing line item on order page
        * completes the order modifications
        Then the existing order must be updated

    Scenario: Successful grower order update - delete existing product
    Grower order should be successfully modified when user deletes an existing product from the existing order
        When user sets single account context for update grower operation with operation type "DeleteProduct"
        * user navigates to the grower order for updating order
        * user deletes an existing line item on order page
        * completes the order modifications
        Then the existing order must be updated