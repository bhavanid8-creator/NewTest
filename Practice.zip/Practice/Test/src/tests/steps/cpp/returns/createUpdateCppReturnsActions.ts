export default interface ICreateUpdateCppReturnsActions {
    addNewProductReturnsLineItems(options: {
        addProductToTheReturnRequest?: boolean;
        isCustomerPickup?: boolean;
    }): Promise<void>;
}