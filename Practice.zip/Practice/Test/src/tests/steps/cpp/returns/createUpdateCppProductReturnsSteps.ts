import { expect } from "playwright/test";
import LineItemInfo from "../../../../helpers/util/db/resultSets/cpp/lineItemInfo";
import { fixture } from "../../../../hooks/fixture";
import DataBagKeys from "../../dataBagKeys";
import StepPageHelper from "../../stepPageHelper";
import { selectShipToAccount } from "./createUpdateCppReturnsSteps";
import CppNewReturnPage from "../../../../pages/cpp/returns/cppNewReturnPage";
import AddProductsToTheCppReturnPage from "../../../../pages/cpp/returns/addProductsToTheCppReturnPage";
import ICreateUpdateCppReturnsActions from "./createUpdateCppReturnsActions";

export default class CreateUpdateCppProductReturnsSteps implements ICreateUpdateCppReturnsActions {

    async addNewProductReturnsLineItems({
        addProductToTheReturnRequest = true,
        isCustomerPickup = true
    }: {
        addProductToTheReturnRequest?: boolean;
        isCustomerPickup?: boolean;
    } = {}): Promise<void> {
        const cppNewProductReturnPage = await StepPageHelper.getCppNewProductReturnPage();

        await selectShipToAccount(cppNewProductReturnPage);
        const soldToAccountNumber = fixture.dataBag.getData(DataBagKeys.SOLD_TO_DEALER_NUMBER) as string;
        const displayedSoldToName = await cppNewProductReturnPage.getSoldToName(soldToAccountNumber);
        fixture.logger.info(`Displayed SoldTo account name is - ${displayedSoldToName}`);
        expect(displayedSoldToName.trim().length).toBeGreaterThan(0);
        const pickupFromNumber = fixture.dataBag.getData(DataBagKeys.PICKUP_FROM_NUMBER) as number;
        const customerPO = await cppNewProductReturnPage.fillReturnHeaderDetails(true, isCustomerPickup, true, null, pickupFromNumber.toString()); // we always fill customer PO because we need it to identify the return request later
        fixture.dataBag.saveData(DataBagKeys.CUSTOMER_PO, customerPO);

        await this.selectProductsForAddingToTheRequest(cppNewProductReturnPage, addProductToTheReturnRequest);
    }

    private async selectProductsForAddingToTheRequest(cppNewReturnPage: CppNewReturnPage, addProductToTheReturnRequest: boolean) {
        fixture.logger.info(`started searching products for the request`);
        let lineItemsInfo: LineItemInfo[] = fixture.dataBag.getData(DataBagKeys.CPP_LINE_ITEM_DATA) as LineItemInfo[];
        if (lineItemsInfo == undefined || lineItemsInfo.length == 0) {
            const errMsg = 'No line items found in the data bag. Please ensure that the line items are set in the data bag before proceeding.';
            fixture.logger.error(errMsg);
            throw new Error(errMsg);
        }
        let filteredLineItemsInfo: LineItemInfo[] = [];

        const includeNonReturnableProducts = fixture.dataBag.getData(DataBagKeys.INCLUDE_NON_RETURNABLE_PRODUCTS) as boolean;
        
        if(includeNonReturnableProducts === true) {
            //Own account returnable and non-returnable products
            filteredLineItemsInfo = lineItemsInfo.filter(item => item.ProductType === CppNewReturnPage.RETURNING_PRODUCT_TYPE_ACCOUNT_RETURNABLE || item.ProductType === CppNewReturnPage.RETURNING_PRODUCT_TYPE_ACCOUNT_NON_RETURNABLE);
            await this.validateAndSelectProductsForAddingToTheRequest(filteredLineItemsInfo, "No line items found for own account returnable & non-returnable products.",
                cppNewReturnPage, addProductToTheReturnRequest, AddProductsToTheCppReturnPage.YOUR_ACCOUNT_INVOICED_PRODUCTS_TAB_INDEX);

            //Parent account returnable and non-returnable products
            filteredLineItemsInfo = lineItemsInfo.filter(item => item.ProductType === CppNewReturnPage.RETURNING_PRODUCT_TYPE_PARENT_ACCOUNT_RETURNABLE || item.ProductType === CppNewReturnPage.RETURNING_PRODUCT_TYPE_PARENT_ACCOUNT_NON_RETURNABLE);
            await this.validateAndSelectProductsForAddingToTheRequest(filteredLineItemsInfo, "No line items found for parent account returnable & non-returnable products.",
                cppNewReturnPage, addProductToTheReturnRequest, AddProductsToTheCppReturnPage.PARENT_COMPANY_INVOICED_PRODUCTS_TAB_INDEX);

        }else{
            //Own account returnable products
            filteredLineItemsInfo = lineItemsInfo.filter(item => item.ProductType === CppNewReturnPage.RETURNING_PRODUCT_TYPE_ACCOUNT_RETURNABLE);
            await this.validateAndSelectProductsForAddingToTheRequest(filteredLineItemsInfo, "No line items found for own account returnable products.",
                cppNewReturnPage, addProductToTheReturnRequest, AddProductsToTheCppReturnPage.YOUR_ACCOUNT_INVOICED_PRODUCTS_TAB_INDEX);

            //Parent account returnable
            filteredLineItemsInfo = lineItemsInfo.filter(item => item.ProductType === CppNewReturnPage.RETURNING_PRODUCT_TYPE_PARENT_ACCOUNT_RETURNABLE);
            await this.validateAndSelectProductsForAddingToTheRequest(filteredLineItemsInfo, "No line items found for parent account returnable products.",
                cppNewReturnPage, addProductToTheReturnRequest, AddProductsToTheCppReturnPage.PARENT_COMPANY_INVOICED_PRODUCTS_TAB_INDEX);
        }

            
        //Manual entry products
        filteredLineItemsInfo = lineItemsInfo.filter(item => item.ProductType === CppNewReturnPage.RETURNING_PRODUCT_TYPE_MANUAL_RETURNABLE);
        for(let i = 0; i < filteredLineItemsInfo.length; i++) {
            filteredLineItemsInfo[i].EligibleUnits = 1; // For manual entry products, we set the eligible units to 1 as per the business requirement
        }
        
        await this.validateAndSelectProductsForAddingToTheRequest(filteredLineItemsInfo, "No line items found for manual entry products.",
            cppNewReturnPage, addProductToTheReturnRequest, AddProductsToTheCppReturnPage.MANUALLY_ENTER_PRODUCTS_TAB_INDEX);
    }

    private async validateAndSelectProductsForAddingToTheRequest(filteredLineItemsInfo: LineItemInfo[], errorMessage: string,
        cppNewReturnPage: CppNewReturnPage, addProductToTheReturnRequest: boolean, tabIndex: number): Promise<void> {
        if (filteredLineItemsInfo.length === 0) {
            fixture.logger.error(errorMessage);
            throw new Error(errorMessage);
        }else{
            await this.performSearchAndAddProducts(cppNewReturnPage, addProductToTheReturnRequest, filteredLineItemsInfo, tabIndex)
        }
    }

    private async performSearchAndAddProducts(cppNewReturnPage: CppNewReturnPage, addProductToTheReturnRequest: boolean, lineItemsInfo: LineItemInfo[], tabIndex: number): Promise<void> {
        await cppNewReturnPage.clickAddProducts();
        const addProductsToProductReturnsRequestPage = await StepPageHelper.getAddProductsToTheCppProductReturnPage();
        await addProductsToProductReturnsRequestPage.clickProductSelectionTab(tabIndex);
        await addProductsToProductReturnsRequestPage.clickSearchFilterDropDown();
        await addProductsToProductReturnsRequestPage.selectSearchFilterItemInTheDropDown(AddProductsToTheCppReturnPage.PRODUCT_SEARCH_FILTER_OPTION_ItemNumber);

        let itemNumbers = [];
        for (let i = 0; i < lineItemsInfo.length; i++) {
            if (!itemNumbers.includes(lineItemsInfo[i].ItemNumber))
                itemNumbers.push(lineItemsInfo[i].ItemNumber);
        }
        fixture.logger.info(`list of item numbers: ${JSON.stringify(itemNumbers)}`);
        await addProductsToProductReturnsRequestPage.searchProduct(itemNumbers);

        fixture.logger.info(`completed searching products for the order`);

        if (addProductToTheReturnRequest) {
            fixture.logger.info(`started selecting and adding products to the order`);
            let tabName = addProductsToProductReturnsRequestPage.getProductSelectionTabName(tabIndex);
            fixture.logger.info(`selecting products from the '${tabName}' tab`);
            const includeNonReturnableProducts = fixture.dataBag.getData(DataBagKeys.INCLUDE_NON_RETURNABLE_PRODUCTS) as boolean;
            //select products
            if (tabIndex == AddProductsToTheCppReturnPage.YOUR_ACCOUNT_INVOICED_PRODUCTS_TAB_INDEX || tabIndex == AddProductsToTheCppReturnPage.PARENT_COMPANY_INVOICED_PRODUCTS_TAB_INDEX) {
                //multiple products are added in the own or parent account tab
                await addProductsToProductReturnsRequestPage.selectProductsFromOwnOrParentAccountTabByItemNumber(itemNumbers, includeNonReturnableProducts);
            } else {
                //only one product is added in the manual entry tab
                await addProductsToProductReturnsRequestPage.selectProductFromManualEntryTab(lineItemsInfo[0].ItemNumber, lineItemsInfo[0].UOM);
            }
            fixture.logger.info(`product selection from the '${tabName}' tab completed`);

            const result = await addProductsToProductReturnsRequestPage.isAddToRequestButtonEnabled();
            expect(result).toBeTruthy();
            await addProductsToProductReturnsRequestPage.clickAddToRequestButton();
            await cppNewReturnPage.dismissProductAddedToastMsg();

            const setQtyMoreThanEligibleQty = fixture.dataBag.getData(DataBagKeys.SET_QTY_MORE_THAN_ELIGIBLE_QTY) as boolean;

            //set quantities and customer notes for the line items
            fixture.logger.info(`starting setting quantities and customer notes for the line items`);
            for (let i = 0; i < lineItemsInfo.length; i++) {
                let qtyToSet = 1;
                if(setQtyMoreThanEligibleQty) {
                    qtyToSet = lineItemsInfo[i].EligibleUnits + 1;
                }
                await cppNewReturnPage.modifyLineItemQty(lineItemsInfo[i].ItemNumber, qtyToSet.toString());
                await cppNewReturnPage.setLineItemCustomerNotes(lineItemsInfo[i].ItemNumber);
            }

            fixture.logger.info(`completed setting quantities and customer notes for the line items`);

            fixture.logger.info(`completed selecting and adding products to the return request`);
        }
    }
}