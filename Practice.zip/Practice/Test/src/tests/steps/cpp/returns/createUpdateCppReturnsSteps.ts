import { Given, Then, When } from "@cucumber/cucumber";
import { fixture } from "../../../../hooks/fixture";
import DataBagKeys from "../../dataBagKeys";
import StepPageHelper from "../../stepPageHelper";
import CppProductReturnsPage from "../../../../pages/cpp/returns/product/productReturnsPage";
import CreateUpdateCppProductReturnsSteps from "./createUpdateCppProductReturnsSteps";
import CppNewReturnPage from "../../../../pages/cpp/returns/cppNewReturnPage";
import CppReturnsPage from "../../../../pages/cpp/returns/cppReturnsPage";
import ICreateUpdateCppReturnsActions from "./createUpdateCppReturnsActions";
import { expect } from "@playwright/test";
import CppInoculantReturnsPage from "../../../../pages/cpp/returns/inoculant/inoculantReturnsPage";
import CreateUpdateCppInoculantReturnsSteps from "./createUpdateCppInoculantReturnsSteps";
import LineItemInfo from "../../../../helpers/util/db/resultSets/cpp/lineItemInfo";

Given('user does not have existing draft requests', async function () {
    const returnType = getReturnTypeFromDataBag();
    await manageDraftReturnRequests(returnType, true);
});

Given('user has an existing draft request', async function () {
    const returnType = getReturnTypeFromDataBag();
    await manageDraftReturnRequests(returnType, false);
});

Given('user has an existing draft request with IP limit exceeded warning', async function () {
    const returnType = getReturnTypeFromDataBag();
    fixture.dataBag.saveData(DataBagKeys.SET_QTY_MORE_THAN_ELIGIBLE_QTY, true);
    await manageDraftReturnRequests(returnType, false);
});

Given('user navigates to the new cpp request', async function () {
    const returnType = getReturnTypeFromDataBag();
    let cppReturnsPage = await getCppReturnsPage(returnType);
    await navigateToNewCppReturnRequest(cppReturnsPage, returnType);
    fixture.dataBag.saveData(DataBagKeys.CREATE_NEW_CPP_ORDER_OR_RETURN_REQUEST, true);
});

Given('user navigates to the new cpp request to open existing draft request', async function () {
    const returnType = getReturnTypeFromDataBag();
    let cppReturnsPage = await getCppReturnsPage(returnType);
    await navigateToNewCppReturnRequest(cppReturnsPage, returnType);
    fixture.dataBag.saveData(DataBagKeys.CREATE_NEW_CPP_ORDER_OR_RETURN_REQUEST, false);
});

When('user adds new line items to the cpp request', async function () {
    const returnType = getReturnTypeFromDataBag();
    fixture.dataBag.saveData(DataBagKeys.INCLUDE_NON_RETURNABLE_PRODUCTS, false);
    fixture.dataBag.saveData(DataBagKeys.USE_PICKUP_LOCATION, false);
    fixture.dataBag.saveData(DataBagKeys.SET_QTY_MORE_THAN_ELIGIBLE_QTY, false)
    await addNewLineItems(returnType);
});

When('user adds new line items to the cpp request with pickup location', async function () {
    const returnType = getReturnTypeFromDataBag();
    fixture.dataBag.saveData(DataBagKeys.INCLUDE_NON_RETURNABLE_PRODUCTS, false);
    fixture.dataBag.saveData(DataBagKeys.USE_PICKUP_LOCATION, true);
    fixture.dataBag.saveData(DataBagKeys.SET_QTY_MORE_THAN_ELIGIBLE_QTY, false)
    await addNewLineItems(returnType);
});

When('user adds new line items to the cpp request including non-returnable products', async function () {
    const returnType = getReturnTypeFromDataBag();
    fixture.dataBag.saveData(DataBagKeys.INCLUDE_NON_RETURNABLE_PRODUCTS, true);
    fixture.dataBag.saveData(DataBagKeys.USE_PICKUP_LOCATION, false);
    fixture.dataBag.saveData(DataBagKeys.SET_QTY_MORE_THAN_ELIGIBLE_QTY, false)
    await addNewLineItems(returnType);
});

When('user adds new line items to the cpp request with more than eligible qty', async function () {
    const returnType = getReturnTypeFromDataBag();
    fixture.dataBag.saveData(DataBagKeys.INCLUDE_NON_RETURNABLE_PRODUCTS, false);
    fixture.dataBag.saveData(DataBagKeys.USE_PICKUP_LOCATION, false);
    fixture.dataBag.saveData(DataBagKeys.SET_QTY_MORE_THAN_ELIGIBLE_QTY, true)
    await addNewLineItems(returnType);
});

When('user clicks on save draft request', async function () {
    const returnType = getReturnTypeFromDataBag();
    const cppNewReturnPage = await getCppNewReturnPage(returnType);
    await saveDraftRequest(cppNewReturnPage, returnType);
});

When('user updates customer PO of existing draft request', async function () {
    const returnType = getReturnTypeFromDataBag();
    const cppNewReturnPage = await getCppNewReturnPage(returnType);
    await selectShipToAccount(cppNewReturnPage);
    fixture.logger.info('setting new customer PO');
    const customerPO = await cppNewReturnPage.setCustomerPO(true);
    fixture.dataBag.saveData(DataBagKeys.CUSTOMER_PO, customerPO);
});

When('user places the cpp request', async function () {
    await placeRequest();
});

Then('a new draft cpp request must be created', async function () {
    const returnType = getReturnTypeFromDataBag();
    await verifyDraftRequestUpdateOperation(returnType);
});

Then('existing draft cpp request must be updated', async function () {
    const returnType = getReturnTypeFromDataBag();
    await verifyDraftRequestUpdateOperation(returnType);
});

Then('a new cpp return request must be created', async function () {
    await submitRequestCompletionVerification()
});

Then('IP limit exceeded warning must be displayed', async function () {
    await checkIPLimitExceededWarningOrErrorDisplayed(true);
});

Then('IP limit exceeded error must be displayed', async function () {
    await checkIPLimitExceededWarningOrErrorDisplayed(false);
});

async function checkIPLimitExceededWarningOrErrorDisplayed(isWarningCheck: boolean): Promise<void> {
    const returnType = getReturnTypeFromDataBag();
    const cppNewReturnPage = await getCppNewReturnPage(returnType);
    const lineItemData = fixture.dataBag.getData(DataBagKeys.CPP_LINE_ITEM_DATA) as LineItemInfo[];
    let isWarningDisplayed = false;
    if(isWarningCheck) {
        isWarningDisplayed = await cppNewReturnPage.isIPLimitExceededWarningDisplayed(lineItemData[0].ItemNumber);
    }else {
        isWarningDisplayed = await cppNewReturnPage.isIPLimitExceededErrorDisplayed(lineItemData[0].ItemNumber);
    }
    
    expect(isWarningDisplayed).toBeTruthy();
}

function getReturnTypeFromDataBag(): string {
    const returnType = fixture.dataBag.getData(DataBagKeys.CPP_RETURN_REQUEST_TYPE) as string;
    return returnType;
}

async function getCppReturnsPage(returnType: string): Promise<CppReturnsPage> {
    let cppReturnsPage: CppReturnsPage;
    switch (returnType) {
        case CppProductReturnsPage.RETURN_TYPE:
            {
                cppReturnsPage = await StepPageHelper.getCppProductReturnsPage();
            }
            break;
        case CppInoculantReturnsPage.RETURN_TYPE:
            {
                cppReturnsPage = await StepPageHelper.getCppInoculantReturnsPage();
            }
            break;
        default:
            {
                fixture.logger.error(`return type '${returnType}' is not supported`);
                throw new Error(`return type '${returnType}' is not supported`);
            }
    }
    return cppReturnsPage;
}

async function getCppNewReturnPage(returnType: string): Promise<CppNewReturnPage> {
    let cppNewReturnPage: CppNewReturnPage;
    switch (returnType) {
        case CppProductReturnsPage.RETURN_TYPE:
            {
                cppNewReturnPage = await StepPageHelper.getCppNewProductReturnPage();
            }
            break;
        case CppInoculantReturnsPage.RETURN_TYPE:
            {
                cppNewReturnPage = await StepPageHelper.getCppNewInoculantReturnPage();
            }
            break;
        default:
            {
                fixture.logger.error(`return type '${returnType}' is not supported`);
                throw new Error(`return type '${returnType}' is not supported`);
            }
    }
    return cppNewReturnPage;
}

async function manageDraftReturnRequests(returnType: string, shouldNotHaveDraftRequests: boolean) {
    let tabName = `Return Request Drafts (of ${returnType})`;
    let cppReturnsPage = await getCppReturnsPage(returnType);
    let cppNewReturnPage: CppNewReturnPage;

    fixture.logger.info(`navigating to ${tabName} tab`);
    await cppReturnsPage.switchToTab(cppReturnsPage.TabName_Return_Request_Drafts);
    fixture.logger.info(`navigated to ${tabName} tab`);
    const accountNumber = fixture.dataBag.getData(DataBagKeys.SOURCE_DEALER_ACCOUNT_NUMBER) as number;
    fixture.logger.info(`deleting draft requests of the account ${accountNumber} if available`);
    const accountNumberStr = accountNumber.toString();
    const existingRequestsCount = await cppReturnsPage.getExistingDraftRequestsCount(accountNumberStr);
    let final_userHasDraftRequest = false;
    if (existingRequestsCount > 0 && shouldNotHaveDraftRequests) {
        await cppReturnsPage.deleteAccountDraftRequests(accountNumberStr, existingRequestsCount);
    }else if (existingRequestsCount > 0 && !shouldNotHaveDraftRequests) {
        final_userHasDraftRequest = true;
    }else if (existingRequestsCount == 0 && !shouldNotHaveDraftRequests) {
        //create a fresh draft request
        await navigateToNewCppReturnRequest(cppReturnsPage, returnType);
        await addNewLineItems(returnType);
        cppNewReturnPage = await getCppNewReturnPage(returnType);
        await selectShipToAccount(cppNewReturnPage);
        await saveDraftRequest(cppNewReturnPage, returnType);
        final_userHasDraftRequest = true;
    }
    fixture.dataBag.saveData(DataBagKeys.USER_HAS_CPP_ORDER_OR_REQUEST, final_userHasDraftRequest);
    fixture.logger.info(`completed checking availability and deleting draft orders of the account ${accountNumber}`);
}

async function navigateToNewCppReturnRequest(cppReturnsPage: CppReturnsPage, returnType: string) {
    fixture.logger.info(`navigating to 'New Return' screen for ${returnType}`);
    await cppReturnsPage.clickCreateNewReturn();
    fixture.logger.info(`navigated to 'New Return' screen for ${returnType}`);
}

function getCppSteps(): ICreateUpdateCppReturnsActions {
    const returnType = getReturnTypeFromDataBag();
    switch (returnType) {
        case CppProductReturnsPage.RETURN_TYPE:
            return new CreateUpdateCppProductReturnsSteps();
        case CppInoculantReturnsPage.RETURN_TYPE:
            return new CreateUpdateCppInoculantReturnsSteps();
        default:
            {
                fixture.logger.error(`return type '${returnType}' is not supported`);
                throw new Error(`return type '${returnType}' is not supported`);
            }
    }
}

async function addNewLineItems(returnType: string, {
    addProductToTheOrder = true,
    isCustomerPickup = true
}: {
    addProductToTheOrder?: boolean;
    isCustomerPickup?: boolean
    } = {}) {
    fixture.logger.info(`adding new line items for ${returnType}`);
    const createUpdateCppReturnsActions = getCppSteps();
    await createUpdateCppReturnsActions.addNewProductReturnsLineItems({
        addProductToTheReturnRequest: addProductToTheOrder,
        isCustomerPickup: isCustomerPickup
    });
    fixture.logger.info(`completed adding new line items for ${returnType}`);
}

export async function selectShipToAccount(cppNewReturnPage: CppNewReturnPage): Promise<boolean> {
    const accountNumber = fixture.dataBag.getData(DataBagKeys.SOURCE_DEALER_ACCOUNT_NUMBER) as number;
    
    const userHasExistingCppReturnRequest = fixture.dataBag.getData(DataBagKeys.USER_HAS_CPP_ORDER_OR_REQUEST) as boolean;
    if (userHasExistingCppReturnRequest) {
        const createNewCppReturnRequest = fixture.dataBag.getData(DataBagKeys.CREATE_NEW_CPP_ORDER_OR_RETURN_REQUEST) as boolean;
        await cppNewReturnPage.selectShipToOfExistingOrder(accountNumber.toString(), createNewCppReturnRequest);
    } else {
        await cppNewReturnPage.selectShipTo(accountNumber.toString());
    }

    return userHasExistingCppReturnRequest;
}

async function saveDraftRequest(cppNewReturnRequestPage: CppNewReturnPage, returnType: string) {
    fixture.logger.info(`saving draft request for ${returnType}`);
    const msg = await cppNewReturnRequestPage.clickSaveDraft();
    fixture.dataBag.saveData(DataBagKeys.OPERATION_COMPLETION_MESSAGE, msg);
    fixture.logger.info(`completed saving draft request for ${returnType}`);
}

async function placeRequest() {
    const returnType = getReturnTypeFromDataBag();
    let cppNewReturnPage: CppNewReturnPage = await getCppNewReturnPage(returnType);
    fixture.logger.info(`placing request for ${returnType}`);
    
    await reviewRequest(cppNewReturnPage);
    await submitRequest(cppNewReturnPage);
    
    fixture.logger.info(`completed placing request for ${returnType}`);
}

async function reviewRequest(cppNewReturnPage: CppNewReturnPage) {
    const msg = await cppNewReturnPage.clickReviewRequest();
    fixture.logger.info(`reviewing return request completed with the message - ${msg}`);
    fixture.dataBag.saveData(DataBagKeys.OPERATION_COMPLETION_MESSAGE, msg);
}

async function submitRequest(cppNewReturnPage: CppNewReturnPage) {
    const msg = await cppNewReturnPage.clickSubmitReturn();
    fixture.logger.info(`submitting return request completed with the message - ${msg}`);
    fixture.dataBag.saveData(DataBagKeys.OPERATION_COMPLETION_MESSAGE, msg);
}

async function verifyDraftRequestUpdateOperation(returnType: string, isReturnRequestDraft: boolean = true) {
    let swithToTabName = ""; //no need to switch tabs for Place-Order scenario because UI navigates to the newly created order summary
    let expectedActiveTabName = "";
    let errorMsg = "failed to verify the 'CPP return request saved successfully.' message on Create-New-Cpp-Return-Request page. Error: "; //corresponds to Place-Request scenario
    const cppReturnsPage = await getCppReturnsPage(returnType);

    if (isReturnRequestDraft) {
        expectedActiveTabName = cppReturnsPage.TabName_Active_Return_Requests;
        swithToTabName = cppReturnsPage.TabName_Return_Request_Drafts;
        errorMsg = "failed to verify 'CPP return request saved successfully.' message on Create-New-Cpp-Return-Request page. Error: "
    }

    await saveDraftRequestCompletionVerification(errorMsg, expectedActiveTabName, swithToTabName);
}

async function saveDraftRequestCompletionVerification(errorMsg: string, expectedActiveTabName: string = "", swithToTabName: string = ""){
    let result = true;
    try {
        const returnType = fixture.dataBag.getData(DataBagKeys.CPP_RETURN_REQUEST_TYPE) as string;
        const cppReturnsPage: CppReturnsPage = await getCppReturnsPage(returnType);
        
        const customerPO = fixture.dataBag.getData(DataBagKeys.CUSTOMER_PO) as string;
        const currentTabName = await cppReturnsPage.getCurrentActiveTabName();
        fixture.logger.info(`current active tab name is - ${currentTabName}`);
        fixture.logger.info(`expected active tab name is - ${expectedActiveTabName}`);
        result = currentTabName.trim() == expectedActiveTabName.trim();
        expect(result).toBeTruthy();

        await cppReturnsPage.switchToTab(swithToTabName);

        let displayedReturnId = await cppReturnsPage.getReturnIdByCustomerPO(customerPO);
        fixture.logger.info(`Displayed Return Id/number is - ${displayedReturnId}`);
        expect(displayedReturnId).not.toBeNull();
        displayedReturnId = displayedReturnId.trim();
        expect(displayedReturnId.length).toBeGreaterThan(0);
        fixture.dataBag.saveData(DataBagKeys.ORDER_ID, displayedReturnId);
        result = true;//set this to true so that the final expect does not fail
    } catch (error) {
        fixture.logger.error(errorMsg + error);
        result = false;
    }
    expect(result).toBeTruthy();
}

async function submitRequestCompletionVerification(){
    let result = true;
    try {
        const cppSubmittedReturnSummaryPage = await StepPageHelper.getSubmittedCppReturnSummaryPage();
        fixture.logger.info(`navigating from summary page to the cpp returns page`);
        await cppSubmittedReturnSummaryPage.clickBackToReturnList();
        
        const returnType = fixture.dataBag.getData(DataBagKeys.CPP_RETURN_REQUEST_TYPE) as string;
        const cppReturnsPage: CppReturnsPage = await getCppReturnsPage(returnType);

        const customerPO = fixture.dataBag.getData(DataBagKeys.CUSTOMER_PO) as string;

        const currentTabName = await cppReturnsPage.getCurrentActiveTabName();
        fixture.logger.info(`current active tab name is - ${currentTabName}`);
        
        result = currentTabName.trim() == cppReturnsPage.TabName_Active_Return_Requests.trim();
        expect(result).toBeTruthy();

        fixture.logger.info(`navigated from summary page to the cpp returns page`);
        
        let displayedReturnId = await cppReturnsPage.getReturnIdByCustomerPO(customerPO);
        
        fixture.logger.info(`Displayed Return Id/number is - ${displayedReturnId}`);
        expect(displayedReturnId).not.toBeNull();
        displayedReturnId = displayedReturnId.trim();
        expect(displayedReturnId.length).toBeGreaterThan(0);
        fixture.dataBag.saveData(DataBagKeys.ORDER_ID, displayedReturnId);
        result = true;//set this to true so that the final expect does not fail
    } catch (error) {
        fixture.logger.error("Failed to verify CPP returns submission request with the error: " + error);
        result = false;
    }
    expect(result).toBeTruthy();
}
