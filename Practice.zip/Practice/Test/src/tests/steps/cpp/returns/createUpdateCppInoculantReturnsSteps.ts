import { expect } from "playwright/test";
import LineItemInfo from "../../../../helpers/util/db/resultSets/cpp/lineItemInfo";
import { fixture } from "../../../../hooks/fixture";
import DataBagKeys from "../../dataBagKeys";
import StepPageHelper from "../../stepPageHelper";
import { selectShipToAccount } from "./createUpdateCppReturnsSteps";
import CppNewReturnPage from "../../../../pages/cpp/returns/cppNewReturnPage";
import AddProductsToTheCppReturnPage from "../../../../pages/cpp/returns/addProductsToTheCppReturnPage";
import ICreateUpdateCppReturnsActions from "./createUpdateCppReturnsActions";

export default class CreateUpdateCppInoculantReturnsSteps implements ICreateUpdateCppReturnsActions {

    async addNewProductReturnsLineItems({
        addProductToTheReturnRequest = true,
        isCustomerPickup = true
    }: {
        addProductToTheReturnRequest?: boolean;
        isCustomerPickup?: boolean;
    } = {}): Promise<void> {
        const cppNewInoculantReturnPage = await StepPageHelper.getCppNewInoculantReturnPage();

        await selectShipToAccount(cppNewInoculantReturnPage);
        const soldToAccountNumber = fixture.dataBag.getData(DataBagKeys.SOLD_TO_DEALER_NUMBER) as string;
        const displayedSoldToName = await cppNewInoculantReturnPage.getSoldToName(soldToAccountNumber);
        fixture.logger.info(`Displayed SoldTo account name is - ${displayedSoldToName}`);
        expect(displayedSoldToName.trim().length).toBeGreaterThan(0);
        const pickupFromNumber = fixture.dataBag.getData(DataBagKeys.PICKUP_FROM_NUMBER) as number;
        const customerPO = await cppNewInoculantReturnPage.fillReturnHeaderDetails(true, isCustomerPickup, true, null, pickupFromNumber.toString()); // we always fill customer PO because we need it to identify the return request later
        fixture.dataBag.saveData(DataBagKeys.CUSTOMER_PO, customerPO);

        await this.selectProductsForAddingToTheRequest(cppNewInoculantReturnPage, addProductToTheReturnRequest);
    }

    private async selectProductsForAddingToTheRequest(cppNewReturnPage: CppNewReturnPage, addProductToTheReturnRequest: boolean) {
        fixture.logger.info(`started searching products for the request`);
        let lineItemsInfo: LineItemInfo[] = fixture.dataBag.getData(DataBagKeys.CPP_LINE_ITEM_DATA) as LineItemInfo[];
        if (lineItemsInfo == undefined || lineItemsInfo.length == 0) {
            const errMsg = 'No line items found in the data bag. Please ensure that the line items are set in the data bag before proceeding.';
            fixture.logger.error(errMsg);
            throw new Error(errMsg);
        }
        
        let filteredLineItemsInfo: LineItemInfo[] = [];
        let atleastOneProductFound = false; //it is observed that Inoculant data setup is complex

        //Own account returnable products
        filteredLineItemsInfo = lineItemsInfo.filter(item => item.ProductType === CppNewReturnPage.RETURNING_PRODUCT_TYPE_ACCOUNT_RETURNABLE);
        if(filteredLineItemsInfo.length !== 0){
            atleastOneProductFound = true;
            await this.validateAndSelectProductsForAddingToTheRequest(filteredLineItemsInfo, "No line items found for own account returnable products.",
            cppNewReturnPage, addProductToTheReturnRequest, AddProductsToTheCppReturnPage.YOUR_ACCOUNT_INVOICED_PRODUCTS_TAB_INDEX);
        }else{
            fixture.logger.warn("No line items found for own account returnable products. Proceeding with parent account returnable products.");            
        }        
        
        //Parent account returnable products
        filteredLineItemsInfo = lineItemsInfo.filter(item => item.ProductType === CppNewReturnPage.RETURNING_PRODUCT_TYPE_PARENT_ACCOUNT_RETURNABLE);
        if(filteredLineItemsInfo.length !== 0){
            await this.validateAndSelectProductsForAddingToTheRequest(filteredLineItemsInfo, "No line items found for parent account returnable products.",
            cppNewReturnPage, addProductToTheReturnRequest, AddProductsToTheCppReturnPage.PARENT_COMPANY_INVOICED_PRODUCTS_TAB_INDEX);
        }else{
            let msg = "No line items found for parent account returnable products.";
            if (atleastOneProductFound) {
                fixture.logger.error(msg + " It is important at least one account has at least one product");
                expect(atleastOneProductFound).toBeTruthy(); //break test here
            }
            fixture.logger.warn(msg);
        }

        //manual entry products are not applicable for the inoculant returns, so we skip them
    }

    private async validateAndSelectProductsForAddingToTheRequest(filteredLineItemsInfo: LineItemInfo[], errorMessage: string,
        cppNewReturnPage: CppNewReturnPage, addProductToTheReturnRequest: boolean, tabIndex: number): Promise<void> {
        if (filteredLineItemsInfo.length === 0) {
            fixture.logger.error(errorMessage);
            throw new Error(errorMessage);
        }else{
            await this.performSearchAndAddProducts(cppNewReturnPage, addProductToTheReturnRequest, filteredLineItemsInfo, tabIndex)
        }
    }

    private async performSearchAndAddProducts(cppNewReturnPage: CppNewReturnPage, addProductToTheReturnRequest: boolean, lineItemsInfo: LineItemInfo[], tabIndex: number): Promise<void> {
        await cppNewReturnPage.clickAddProducts();
        const addProductsToInoculantReturnsRequestPage = await StepPageHelper.getAddProductsToTheCppInoculantReturnPage();
        await addProductsToInoculantReturnsRequestPage.clickProductSelectionTab(tabIndex);
        await addProductsToInoculantReturnsRequestPage.clickSearchFilterDropDown();
        await addProductsToInoculantReturnsRequestPage.selectSearchFilterItemInTheDropDown(AddProductsToTheCppReturnPage.PRODUCT_SEARCH_FILTER_OPTION_ItemNumber);

        let itemNumbers = [];
        for (let i = 0; i < lineItemsInfo.length; i++) {
            if (!itemNumbers.includes(lineItemsInfo[i].ItemNumber))
                itemNumbers.push(lineItemsInfo[i].ItemNumber);
        }
        fixture.logger.info(`list of item numbers: ${JSON.stringify(itemNumbers)}`);
        await addProductsToInoculantReturnsRequestPage.searchProduct(itemNumbers);

        fixture.logger.info(`completed searching products for the order`);

        if (addProductToTheReturnRequest) {
            fixture.logger.info(`started selecting and adding products to the order`);
            let tabName = addProductsToInoculantReturnsRequestPage.getProductSelectionTabName(tabIndex);
            fixture.logger.info(`selecting products from the '${tabName}' tab`);
            //select products
            if (tabIndex == AddProductsToTheCppReturnPage.YOUR_ACCOUNT_INVOICED_PRODUCTS_TAB_INDEX || tabIndex == AddProductsToTheCppReturnPage.PARENT_COMPANY_INVOICED_PRODUCTS_TAB_INDEX) {
                //multiple products are added in the own or parent account tab
                await addProductsToInoculantReturnsRequestPage.selectProductsFromOwnOrParentAccountTabByItemNumber(itemNumbers, false); //non-returnable products are not applicable for the inoculant returns
            } else {
                const errorMsg = `Product selection from the '${tabName}' tab is not supported.`;
                fixture.logger.error(errorMsg);
                throw new Error(errorMsg);
            }
            fixture.logger.info(`product selection from the '${tabName}' tab completed`);

            const result = await addProductsToInoculantReturnsRequestPage.isAddToRequestButtonEnabled();
            expect(result).toBeTruthy();
            await addProductsToInoculantReturnsRequestPage.clickAddToRequestButton();
            await cppNewReturnPage.dismissProductAddedToastMsg();

            const setQtyMoreThanEligibleQty = fixture.dataBag.getData(DataBagKeys.SET_QTY_MORE_THAN_ELIGIBLE_QTY) as boolean;

            //set quantities and customer notes for the line items
            fixture.logger.info(`starting setting quantities and customer notes for the line items`);
            for (let i = 0; i < lineItemsInfo.length; i++) {
                await cppNewReturnPage.modifyLineItemQty(lineItemsInfo[i].ItemNumber, lineItemsInfo[i].EligibleUnits.toString());
                if(setQtyMoreThanEligibleQty) {
                    await cppNewReturnPage.incrementOrDecrementLineItemQty(lineItemsInfo[i].ItemNumber, true);
                }
                await cppNewReturnPage.setLineItemCustomerNotes(lineItemsInfo[i].ItemNumber);
            }

            fixture.logger.info(`completed setting quantities and customer notes for the line items`);

            fixture.logger.info(`completed selecting and adding products to the return request`);
        }
    }
}