import { Given } from "@cucumber/cucumber";
import { fixture } from "../../../../hooks/fixture";
import StepPageHelper from "../../stepPageHelper";
import CppProductReturnsPage from "../../../../pages/cpp/returns/product/productReturnsPage";
import CppInoculantReturnsPage from "../../../../pages/cpp/returns/inoculant/inoculantReturnsPage";

Given('user navigates to the cpp {string} menu', async function (menuName: string) {
    fixture.logger.info(`navigating to 'Crop Protections --> ${menuName}' menu`);
    const headerNavigationPage = await StepPageHelper.getHeaderNavigationPage();
    switch (menuName) {
        case "Orders":
            await headerNavigationPage.navigateToCppOrdersPage();
            break;
        case CppProductReturnsPage.RETURN_TYPE:
        case CppInoculantReturnsPage.RETURN_TYPE:
            await headerNavigationPage.navigateToCppReturnsPage(menuName);
            break;
        default:
            fixture.logger.error(`menu name '${menuName}' is not supported`);
            throw new Error(`menu name '${menuName}' is not supported`);
    }
    fixture.logger.info(`navigated to 'Crop Protections --> ${menuName}' menu`);
});