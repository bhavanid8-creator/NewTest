import { Given, Then, When } from "@cucumber/cucumber";
import { fixture } from "../../../../hooks/fixture";
import DataBagKeys from "../../dataBagKeys";
import { expect } from "playwright/test";
import AccountDetails from "../../../../helpers/util/test-data/dealer/accountDetails";
import StepPageHelper from "../../stepPageHelper";
import AddProductsToTheCppOrderPage from "../../../../pages/cpp/orders/addProductsToTheCppOrderPage";
import CppOrdersPage from "../../../../pages/cpp/orders/cppOrdersPage";
import CppNewOrderPage from "../../../../pages/cpp/orders/cppNewOrderPage";
import LineItemInfo from "../../../../helpers/util/db/resultSets/cpp/lineItemInfo";
import DateHelper from "../../../../helpers/types/dateHelper";
import { de } from "date-fns/locale";

Given('user navigates to the new cpp order', async function () {
    await navigateToNewCppOrder();
    fixture.dataBag.saveData(DataBagKeys.CREATE_NEW_CPP_ORDER_OR_RETURN_REQUEST, true);
});

Given('user navigates to the new cpp order to open existing draft order', async function () {
    await navigateToNewCppOrder();
    fixture.dataBag.saveData(DataBagKeys.CREATE_NEW_CPP_ORDER_OR_RETURN_REQUEST, false);
});

async function navigateToNewCppOrder() {
    fixture.logger.info(`navigating to 'Create New Order' screen`);
    const cppOrdersPage = await StepPageHelper.getCppOrdersPage();
    await cppOrdersPage.clickCreateNewOrder();
    fixture.logger.info(`navigated to 'Create New Order' screen`);
}

Given('user does not have existing draft orders', async function () {
    await manageDraftOrders(true);
});

async function manageDraftOrders(shouldNotHaveDraftOrders: boolean) {
    fixture.logger.info(`navigating to 'Draft Orders' tab`);
    const cppOrdersPage = await StepPageHelper.getCppOrdersPage();
    await cppOrdersPage.switchToTab(CppOrdersPage.TabName_Draft_Orders);
    fixture.logger.info(`navigated to 'Draft Orders' tab`);
    const accountNumber = fixture.dataBag.getData(DataBagKeys.SOURCE_DEALER_ACCOUNT_NUMBER) as number;
    fixture.logger.info(`deleting draft orders of the account ${accountNumber} if available`);
    const accountNumberStr = accountNumber.toString();
    const existingOrdersCount = await cppOrdersPage.getExistingDraftOrdersCount(accountNumberStr);
    let final_userHasDraftOrder = false;
    if (existingOrdersCount > 0 && shouldNotHaveDraftOrders) {
        await cppOrdersPage.deleteAccountDraftOrders(accountNumberStr, existingOrdersCount);
    }else if (existingOrdersCount > 0 && !shouldNotHaveDraftOrders) {
        final_userHasDraftOrder = true;
    }else if (existingOrdersCount == 0 && !shouldNotHaveDraftOrders) {
        //create a fresh draft order
        await navigateToNewCppOrder();
        await addNewLineItemWithMinDetails();
        await saveDraftOrder();
        final_userHasDraftOrder = true;
    }
    fixture.dataBag.saveData(DataBagKeys.USER_HAS_CPP_ORDER_OR_REQUEST, final_userHasDraftOrder);
    fixture.logger.info(`completed checking availability and deleting draft orders of the account ${accountNumber}`);
}

Given('user has an existing draft order', async function () {
    await manageDraftOrders(false);
});

Given('user opens either a new order or existing draft order', async function () {
    const shipToAccountHasDraftOrder = fixture.dataBag.getData(DataBagKeys.DRAFT_CPP_ORDER_AVAILABLE) as boolean;
    if (shipToAccountHasDraftOrder) {
        await openExistingCppDraftOrder();
    } else {
        //start creating a fresh draft order
        await navigateToNewCppOrder();
    }
});

async function openExistingCppDraftOrder() {
    const shipToAccountNumber = (fixture.dataBag.getData(DataBagKeys.SOURCE_DEALER_ACCOUNT_NUMBER) as number).toString();
    const cppOrdersPage = await StepPageHelper.getCppOrdersPage();
    fixture.logger.info(`switching to Draft Orders tab`);
    await cppOrdersPage.switchToTab(CppOrdersPage.TabName_Draft_Orders);
    fixture.logger.info(`opening existing draft order for the account - ${shipToAccountNumber}`);
    await cppOrdersPage.openExistingFirstDraftOrder(shipToAccountNumber);
    fixture.logger.info(`opened existing draft order for the account - ${shipToAccountNumber}`);
}

Given('deletes all existing line items from the draft order', async function () {
    const shipToAccountHasDraftOrder = fixture.dataBag.getData(DataBagKeys.DRAFT_CPP_ORDER_AVAILABLE) as boolean;
    if (shipToAccountHasDraftOrder) {
        const cppNewOrderPage = await StepPageHelper.getCppNewOrderPage();
        await cppNewOrderPage.deleteOrderLineItems();
    
    } else {
        fixture.logger.info(`order is not an existing draft order so not deleting lineitmes`);
    }
});

Given('navigates to product selection screen and searches for a product', async function () {
    await searchProducts(false); //we don't want to add products to the order
});

Given('navigates to product selection screen and adds a product', async function () {
    await searchProducts(true); //we want to add products to the order
});

async function searchProducts(shouldAddToTheOrder: boolean) {
    const shipToAccountHasDraftOrder = fixture.dataBag.getData(DataBagKeys.DRAFT_CPP_ORDER_AVAILABLE) as boolean;
    if (shipToAccountHasDraftOrder) {
        const cppNewOrderPage = await StepPageHelper.getCppNewOrderPage();
        // await selectProductsForAddingToTheOrder_obsolete(cppNewOrderPage, false /* no need to add products to the order */
        //     , false /* irrelevant */);
        await selectProductsForAddingToTheOrder(cppNewOrderPage, shouldAddToTheOrder /* no need to add products to the order */
            , false /* irrelevant */);
    } else {
        //fill details for a fresh draft order but don't complete creating the order
        await addNewLineItemWithMinDetails({addProductToTheOrder:shouldAddToTheOrder //we want to add products to the order
        });
    }
}
Given('a favorite product does not exist', async function () {
    await markOrUnmarkFavStatusFromAllProductsSearchResult(true, `product - item-number - is already marked as favorite. Hence marking it as not-favorite`);
});

Given('a favorite product exists', async function () {
    await markOrUnmarkFavStatusFromAllProductsSearchResult(false, `product - item-number - is not marked as favorite. Hence marking it as favorite`);
});

async function markOrUnmarkFavStatusFromAllProductsSearchResult(changeStatus: boolean, changeMsg: string){
    const addProductsToTheCppOrderPage = await StepPageHelper.getAddProductToTheCppOrderPage();
    const itemNumber = fixture.dataBag.getData(DataBagKeys.SOURCE_PRODUCT_ITEM_NUMBER_TO_USE) as string;
    const result = await addProductsToTheCppOrderPage.isProductMarkedAsFavInAllProducts(itemNumber);
    if(result == changeStatus){
        changeMsg = changeMsg.replace("item-number", itemNumber);
        fixture.logger.info(changeMsg);
        await addProductsToTheCppOrderPage.markOrUnmarkProductAsFav(itemNumber);
    }
}

Given('a favorite product does not exist in the line item', async function () {
    await markOrUnmarkFavStatusFromTheOrder(true, `product - item-number - is already marked as favorite. Hence marking it as not-favorite`);
});

Given('a favorite product exists in the line item', async function () {
    await markOrUnmarkFavStatusFromTheOrder(false, `product - item-number - is not marked as favorite. Hence marking it as favorite`);
});

async function markOrUnmarkFavStatusFromTheOrder(changeStatus: boolean, changeMsg: string){
    const cppNewOrderPage = await StepPageHelper.getCppNewOrderPage();
    const itemNumber = fixture.dataBag.getData(DataBagKeys.SOURCE_PRODUCT_ITEM_NUMBER_TO_USE) as string;
    const lineItemSeqNo = 1;
    const result = await cppNewOrderPage.isProductMarkedAsFavInTheOrder(itemNumber, lineItemSeqNo);
    if(result == changeStatus){
        changeMsg = changeMsg.replace("item-number", itemNumber);
        fixture.logger.info(changeMsg);
        await cppNewOrderPage.markOrUnmarkProductAsFavInTheOrder(itemNumber, lineItemSeqNo);
    }
}

When('user adds new line item to the cpp order with minimum details', async function () {
    await addNewLineItemWithMinDetails();
});

When('user adds new line items to the cpp order with necessary details', async function () {
    await addNewLineItemWithMinDetails();
    await setAllLineItemsMinQty();
});

When('user adds new line items to the cpp order with necessary details along with line items requested arrival dates', async function () {
    await addNewLineItemWithMinDetails();
    await setAllLineItemsMinQty();
    await setLineItemsDeliveryDay();
});

When('user adds new line items to the cpp order with necessary details along with line items requested arrival dates multiple times', async function () {
    await addNewLineItemWithMinDetails({addSameItemNumberMultipleTimes: true}); //here
    await setAllLineItemsMinQty();
    await setLineItemsDeliveryDay();
});

When('user adds new line items to the order', async function () {
    await addNewLineItemsWithSDM();
});

When('user updates SDM eligible line item delivery date to {string} and selects reason as {string}', async function (
    deliveryDayType: string, deliveryDayChangeReason: string) {
    await setLineItemDeliveryDayAndReason(deliveryDayType, deliveryDayChangeReason);
});

When('user updates another SDM eligible line item delivery date to {string} and selects reason as {string}', async function (
    deliveryDayType: string, deliveryDayChangeReason: string) {
    await setLineItemDeliveryDayAndReason(deliveryDayType, deliveryDayChangeReason, 1);
});

async function setLineItemDeliveryDayAndReason(deliveryDayType: string, deliveryDayChangeReason: string, lineItemIndex?: number) {
    await setDeliveryDayDetails({lineItemIndex: lineItemIndex, deliveryDayType: deliveryDayType, deliveryDayChangeReason: deliveryDayChangeReason});
    await checkSelectReasonPresence(true);
}

When('user updates SDM eligible line item delivery date to {string}', async function (
    deliveryDayType: string) {
    await setDeliveryDayDetails({deliveryDayType: deliveryDayType});
    await checkSelectReasonPresence(false);
});

When('user updates another SDM eligible line item delivery date to same {string}', async function (
    deliveryDayType: string) {
    let deliveryDateToUse: Date = fixture.dataBag.getData(DataBagKeys.CPP_LINE_ITEM_DELIVERY_DATE) as Date;
    await setDeliveryDayDetails({ lineItemIndex: 1, deliveryDayType: deliveryDayType, 
        deliveryDateToUse: deliveryDateToUse, ignoreReasonSelectionForUnscheduledDay: true });//reason must be automatically selected
    await checkSelectReasonPresence(true);
});

When('user updates non-SDM line item delivery date', async function () {
    await setDeliveryDayDetails({deliveryDayType : ""});
    await checkSelectReasonPresence(false);
});

async function checkSelectReasonPresence(shouldPresent: boolean) {
    const cppNewOrderPage = await StepPageHelper.getCppNewOrderPage();
    const isReasonDropdownPresent = await cppNewOrderPage.isReasonChangePresent();
    fixture.logger.info(`reason dropdown present - ${isReasonDropdownPresent}`);
    expect(isReasonDropdownPresent).toBe(shouldPresent);
}

async function addNewLineItemsWithSDM() {
    await addNewLineItemWithMinDetails({
        isCustomerPickup: false, //for SDM, customer-pickup must be unchecked
    });
}

async function addNewLineItemWithMinDetails({
    addProductToTheOrder = true,
    isCustomerPickup = true, 
    addSameItemNumberMultipleTimes = false
}: {
    addProductToTheOrder?: boolean;
    isCustomerPickup?: boolean;
    addSameItemNumberMultipleTimes?: boolean;
} = {}) {
    const cppNewOrderPage = await StepPageHelper.getCppNewOrderPage();
    
    const userHasExistingCppOrder = await selectShipToAccount();
    
    const displayedSoldToName = await cppNewOrderPage.getSoldToName();
    fixture.logger.info(`Displayed SoldTo account name is - ${displayedSoldToName}`);
    const expectedSoldToName = fixture.dataBag.getData(DataBagKeys.SOLD_TO_DEALER_NAME) as string;
    fixture.logger.info(`Expected SoldTo account name is - ${expectedSoldToName}`);
    expect(displayedSoldToName.trim()).toBe(expectedSoldToName.trim());
    const deliverToAccountNumber = fixture.dataBag.getData(DataBagKeys.DELIVER_TO_DEALER_ACCOUNT_NUMBER) as number;
    if(deliverToAccountNumber != undefined)
    {
        await cppNewOrderPage.selectDeliverTo(deliverToAccountNumber.toString());
    }else{
        fixture.logger.info(`skipping Deliver To`);
    }
    let fillCustomerPO = fixture.dataBag.getData(DataBagKeys.CUSTOMER_PO_REQUIRED) as boolean;
    if(fillCustomerPO == undefined)
        fillCustomerPO = true;
    const customerPO = await cppNewOrderPage.fillOrderDetails(isCustomerPickup, fillCustomerPO);
    fixture.dataBag.saveData(DataBagKeys.CUSTOMER_PO, customerPO);

    await selectProductsForAddingToTheOrder(cppNewOrderPage, addProductToTheOrder, userHasExistingCppOrder, addSameItemNumberMultipleTimes);
}

function getLineItemsDataOrderedByRequestDeliveryDateAndItemNumber(lineItemsData: LineItemInfo[]): LineItemInfo[] {
    if (lineItemsData == undefined || lineItemsData.length == 0)
        return [];

    const getDateValue = (value: string): number => {
        if (value == undefined || value == null || value.trim().length == 0)
            return Number.MAX_SAFE_INTEGER;

        const parts = value.split("/");
        if (parts.length == 3) {
            const month = Number(parts[0]);
            const day = Number(parts[1]);
            const year = Number(parts[2]);
            if (!Number.isNaN(month) && !Number.isNaN(day) && !Number.isNaN(year))
                return new Date(year, month - 1, day).getTime();
        }

        const parsed = new Date(value).getTime();
        if (Number.isNaN(parsed))
            return Number.MAX_SAFE_INTEGER;
        return parsed;
    };

    const sorted = [...lineItemsData].sort((a, b) => {
        const dateDiff = getDateValue(a.RequestDeliveryDate) - getDateValue(b.RequestDeliveryDate);
        if (dateDiff !== 0)
            return dateDiff;

        const itemNumberDiff = a.ItemNumber.localeCompare(b.ItemNumber);
        if (itemNumberDiff !== 0)
            return itemNumberDiff;

        return a.LineItemSeq - b.LineItemSeq;
    });

    return sorted;
}

async function selectProductsForAddingToTheOrder(cppNewOrderPage: CppNewOrderPage, addProductToTheOrder: boolean, 
    userHasExistingCppOrder: boolean, addSameItemNumberMultipleTimes: boolean = false) {
    fixture.logger.info(`started searching products for the order`);
    await cppNewOrderPage.clickAddProducts();
    const addProductsToOrderPage = await StepPageHelper.getAddProductToTheCppOrderPage();
    await addProductsToOrderPage.clickSearchFilterDropDown();
    await addProductsToOrderPage.selectSearchFilterItemInTheDropDown(AddProductsToTheCppOrderPage.PRODUCT_SEARCH_FILTER_OPTION_ItemNumber);
    let itemNumber = fixture.dataBag.getData(DataBagKeys.SOURCE_PRODUCT_ITEM_NUMBER_TO_USE) as string;
    let lineItemsInfo: LineItemInfo[] = [];
    let itemNumbers: string[] = [];
    if(itemNumber == undefined || itemNumber.length == 0){
        lineItemsInfo = fixture.dataBag.getData(DataBagKeys.CPP_LINE_ITEM_DATA) as LineItemInfo[];

        for(let i=0; i<lineItemsInfo.length; i++){
            if(!itemNumbers.includes(lineItemsInfo[i].ItemNumber))
                itemNumbers.push(lineItemsInfo[i].ItemNumber);
        }
        fixture.logger.info(`list of item numbers: ${JSON.stringify(itemNumbers)}`);
    }
    else{
        itemNumbers.push(itemNumber);
    }
    await addProductsToOrderPage.searchProduct(itemNumbers);

    fixture.logger.info(`completed searching products for the order`);

    if (addProductToTheOrder) {
        fixture.logger.info(`started selecting and adding products to the order`);
        await addProductsToOrderPage.selectProductsFromAllProductsTabByItemNumber(itemNumbers);
        const result = await addProductsToOrderPage.isAddToOrderButtonEnabled();
        expect(result).toBeTruthy();
        await addProductsToOrderPage.clickAddToOrderButton();
        await cppNewOrderPage.dismissProductAddedToastMsg();
        
        //set quantities
        fixture.logger.info(`starting setting quantities for the line items`);
        const lineItemsData = fixture.dataBag.getData(DataBagKeys.CPP_LINE_ITEM_DATA) as LineItemInfo[];
        if (lineItemsData == undefined || lineItemsData.length == 0) {
            const minQty = fixture.dataBag.getData(DataBagKeys.PRODUCT_CONVERSION_OR_MIN_TRANSFERRABLE_QTY_OR_ORDER_QTY) as number;
            await cppNewOrderPage.modifyLineItemQty(itemNumber, 1, minQty.toString());
        } else { 
            if (!addSameItemNumberMultipleTimes) {
                //each item number will be added only once
                for (let i = 0; i < lineItemsData.length; i++) {
                    await cppNewOrderPage.modifyLineItemQty(lineItemsData[i].ItemNumber, lineItemsData[i].LineItemSeq, lineItemsData[i].MinQty.toString());
                }
            } else {
                //sort by requested delivery date and item number; preserve original line item sequence for UI locators
                const orderedLineItemsData = getLineItemsDataOrderedByRequestDeliveryDateAndItemNumber(lineItemsData);
                //count occurrences per same item number (not total line-item count in response)
                const sameItemNumberCountByItem: Record<string, number> = {};
                for (let i = 0; i < orderedLineItemsData.length; i++) {
                    const key = orderedLineItemsData[i].ItemNumber;
                    sameItemNumberCountByItem[key] = (sameItemNumberCountByItem[key] ?? 0) + 1;
                }
                const itemOccurrenceCount: Record<string, number> = {};
                for (let i = 0; i < orderedLineItemsData.length; i++) {
                    const currentLineItem = orderedLineItemsData[i];
                    const occurrence = (itemOccurrenceCount[currentLineItem.ItemNumber] ?? 0) + 1;
                    itemOccurrenceCount[currentLineItem.ItemNumber] = occurrence;
                    const sameItemNumberCount = sameItemNumberCountByItem[currentLineItem.ItemNumber] ?? 0;
                    if (sameItemNumberCount > 1 && occurrence > 1) {
                        const result = await cppNewOrderPage.addNewLineItemForTheItemNumber(currentLineItem.ItemNumber);
                        expect(result).toBeTruthy();
                    }
                    
                    await cppNewOrderPage.modifyLineItemQty(currentLineItem.ItemNumber, currentLineItem.LineItemSeq, currentLineItem.MinQty.toString());
                }
            }
        }
        fixture.logger.info(`completed setting quantities for the line items`);

        if (!userHasExistingCppOrder) {
            let contactName = fixture.dataBag.getData(DataBagKeys.CPP_ORDER_CONTACT) as string;
            if(contactName == undefined || contactName == null)
                contactName = "";
            await cppNewOrderPage.fillOrderContactAndDeliveryDetails(contactName);//these details are needed only when the Ship-To dealer does not have any existing order
        }
        fixture.logger.info(`completed selecting and adding products to the order`);
    }
}

async function setDeliveryDayDetails({ lineItemIndex = -1, deliveryDayType, deliveryDayChangeReason = "", ignoreReasonSelectionForUnscheduledDay = false, deliveryDateToUse = null}:
    {
        lineItemIndex?: number;
        deliveryDayType: string;
        deliveryDayChangeReason?: string;
        ignoreReasonSelectionForUnscheduledDay?: boolean;
        deliveryDateToUse?: Date | null;
    }) {
    const cppNewOrderPage = await StepPageHelper.getCppNewOrderPage();
    const lineItemsData = fixture.dataBag.getData(DataBagKeys.CPP_LINE_ITEM_DATA) as LineItemInfo[];
    let lineItem: LineItemInfo;
    let deliveryDate: Date;
    let selectReason = false;

    if(deliveryDayType.length == 0){
        const nonSdmItem = lineItemsData.find(item => !item.IsItemSDM);
        lineItem = nonSdmItem as LineItemInfo;//there will be only one non-SDM product
        const sdmLineItem = lineItemsData.find(item => item.IsItemSDM);
        deliveryDate = new Date(sdmLineItem!.EarliestUnscheduledDeliveryDate); //any date should work
    } else {
        if(lineItemIndex == -1) {
            const sdmItem = lineItemsData.find(item => item.IsItemSDM);
            lineItem = sdmItem as LineItemInfo;
        } else{
            fixture.dataBag.saveData(DataBagKeys.CPP_ANOTHER_SDM_LINE_ITEM_INDEX, lineItemIndex);
            const sdmItem = lineItemsData.filter(item => item.IsItemSDM).at(lineItemIndex);
            lineItem = sdmItem as LineItemInfo;
        }
        if (deliveryDayType == "unscheduled-day") {
            if(deliveryDateToUse != null)
                deliveryDate = deliveryDateToUse;
        //    else if(lineItemIndex == -1)
        //        deliveryDate = new Date(lineItem.EarliestUnscheduledDeliveryDate);
            else
                deliveryDate = new Date(lineItem.NextEarliestUnScheduleDeliveryDate);
            if (!ignoreReasonSelectionForUnscheduledDay) {
                selectReason = true; //applicable only for unscheduled days
                if (deliveryDayChangeReason.length == 0) {
                    fixture.logger.error(`for unscheduled-delivery-day, reason change must be specified`);
                    expect(false).toBeTruthy();//fail the test
                }
            }
        } else if (deliveryDayType == "scheduled-day") {
            deliveryDate = new Date(lineItem.EarliestScheduledDeliveryDate);
        } else if (deliveryDayType == "next-scheduled-day") {
            deliveryDate = new Date(lineItem.NextEarliestScheduledDeliveryDate);
        } else {
            fixture.logger.error(`unsupported delivery day/date type - ${deliveryDayType} - mentioned`);
            expect(false).toBeTruthy();//fail the test
            deliveryDate = new Date(); // Initialize to avoid unassigned variable error
        }
        fixture.logger.info(`deliveryDate type: ${typeof deliveryDate}, value: ${deliveryDate}`);
    }
    await cppNewOrderPage.fillDeliveryDate(lineItem.ItemNumber, deliveryDate, lineItem.LineItemSeq);
    fixture.dataBag.saveData(DataBagKeys.CPP_LINE_ITEM_DELIVERY_DATE, deliveryDate);

    if (selectReason)
        await cppNewOrderPage.selectArrivalDateChangeReason(lineItem.ItemNumber, deliveryDayChangeReason, lineItem.LineItemSeq);
}

async function setDeliveryDayAsToday() {
    const cppNewOrderPage = await StepPageHelper.getCppNewOrderPage();
    const lineItemsData = fixture.dataBag.getData(DataBagKeys.CPP_LINE_ITEM_DATA) as LineItemInfo[];
    await cppNewOrderPage.fillDeliveryDate(lineItemsData[0].ItemNumber, new Date(), lineItemsData[0].LineItemSeq);
}

async function setLineItemsDeliveryDay() {
    fixture.logger.info(`started setting requested arrival date for all line items`);
    const cppNewOrderPage = await StepPageHelper.getCppNewOrderPage();
    const lineItemsData = fixture.dataBag.getData(DataBagKeys.CPP_LINE_ITEM_DATA) as LineItemInfo[];
    const orderedLineItemsData = getLineItemsDataOrderedByRequestDeliveryDateAndItemNumber(lineItemsData);
    for(let index=0; index<orderedLineItemsData.length; index++){
        await cppNewOrderPage.fillDeliveryDate(orderedLineItemsData[index].ItemNumber, new Date(orderedLineItemsData[index].RequestDeliveryDate), orderedLineItemsData[index].LineItemSeq);
    }
    fixture.logger.info(`completed setting requested arrival date for all line items`);
}

async function setQty(qtyType: string) {
    const cppNewOrderPage = await StepPageHelper.getCppNewOrderPage();
    const lineItemsData = fixture.dataBag.getData(DataBagKeys.CPP_LINE_ITEM_DATA) as LineItemInfo[];
    let qty = 0;
    switch(qtyType){
        case "lesser-than-min-qty":
            qty = lineItemsData[0].MinQty - 1;
            break;
        case "min-qty":
            qty = lineItemsData[0].MinQty;
            break;
        case "max-qty":
            qty = lineItemsData[0].MaxQty;
            break;
        case "min-plus-max-qty":
            qty = lineItemsData[0].MinQty + lineItemsData[0].MaxQty;
            break;
        case "double-max-qty":
            qty = lineItemsData[0].MaxQty + lineItemsData[0].MaxQty;
            break;
        case "one-plus-double-max-qty":
            qty = lineItemsData[0].MaxQty + lineItemsData[0].MaxQty + 1;
            break;
        default:
            fixture.logger.error(`unsupported qty type - ${qtyType} - mentioned`);
            expect(false).toBeTruthy();//fail the test
            break;
    }
    fixture.dataBag.saveData(DataBagKeys.PRODUCT_CONVERSION_OR_MIN_TRANSFERRABLE_QTY_OR_ORDER_QTY, qty);
    await cppNewOrderPage.modifyLineItemQty(lineItemsData[0].ItemNumber, lineItemsData[0].LineItemSeq, qty.toString());
}

async function setAllLineItemsMinQty() {
    fixture.logger.info(`setting all line items to min qty started`);
    const cppNewOrderPage = await StepPageHelper.getCppNewOrderPage();
    const lineItemsData = fixture.dataBag.getData(DataBagKeys.CPP_LINE_ITEM_DATA) as LineItemInfo[];
    const orderedLineItemsData = getLineItemsDataOrderedByRequestDeliveryDateAndItemNumber(lineItemsData);
    for(let i=0; i<orderedLineItemsData.length; i++){
        await cppNewOrderPage.modifyLineItemQty(orderedLineItemsData[i].ItemNumber, orderedLineItemsData[i].LineItemSeq, orderedLineItemsData[i].MinQty.toString());
    }
    fixture.logger.info(`setting all line items to min qty completed`);
}

async function selectShipToAccount(): Promise<boolean> {
    const cppNewOrderPage = await StepPageHelper.getCppNewOrderPage();
    const accountNumber = fixture.dataBag.getData(DataBagKeys.SOURCE_DEALER_ACCOUNT_NUMBER) as number;
    
    const userHasExistingCppOrder = fixture.dataBag.getData(DataBagKeys.USER_HAS_CPP_ORDER_OR_REQUEST) as boolean;
    if (userHasExistingCppOrder) {
        const createNewCppOrder = fixture.dataBag.getData(DataBagKeys.CREATE_NEW_CPP_ORDER_OR_RETURN_REQUEST) as boolean;
        await cppNewOrderPage.selectShipToOfExistingOrder(accountNumber.toString(), createNewCppOrder);
    } else {
        await cppNewOrderPage.selectShipTo(accountNumber.toString());
    }

    return userHasExistingCppOrder;
}
When('user updates customer PO of existing draft order', async function () {
    await selectShipToAccount();
    const cppNewOrderPage = await StepPageHelper.getCppNewOrderPage();
    fixture.logger.info('setting new customer PO');
    const customerPO = await cppNewOrderPage.setCustomerPO(true);
    fixture.dataBag.saveData(DataBagKeys.CUSTOMER_PO, customerPO);
});

When('user clicks on save draft button without filling customer PO', async function () {
    const cppNewOrderPage = await StepPageHelper.getCppNewOrderPage();
    await cppNewOrderPage.clearCustomerPO();
    await saveDraftOrder();
});

When('user clicks on save draft button', async function () {
    await saveDraftOrder();
});

When('user clicks on place order button', async function () {
    await placeOrder();
});

When('user clicks on view-product-details link', async function () {
    const lineItemsData = fixture.dataBag.getData(DataBagKeys.CPP_LINE_ITEM_DATA) as LineItemInfo[];
    
    const cppNewOrderPage = await StepPageHelper.getCppNewOrderPage();
    await cppNewOrderPage.clickViewProductDetails(lineItemsData[0].ItemNumber, 1);
});

When('sets delivery day to today', async function () {
    await setDeliveryDayAsToday();
});

When('sets quantity lesser than min qty', async function () {
    await setQty("lesser-than-min-qty");
});

When('user updates the quantity of the line item to {string}', async function (qtyType: string) {
    await setQty(qtyType);
});

async function saveDraftOrder() {
    const cppNewOrderPage = await StepPageHelper.getCppNewOrderPage();
    const msg = await cppNewOrderPage.clickSaveDraft();
    fixture.dataBag.saveData(DataBagKeys.OPERATION_COMPLETION_MESSAGE, msg);
}

async function placeOrder() {
    const cppNewOrderPage = await StepPageHelper.getCppNewOrderPage();
    const msg = await cppNewOrderPage.clickPlaceOrder();
    fixture.dataBag.saveData(DataBagKeys.OPERATION_COMPLETION_MESSAGE, msg);
}

When('user clicks on favorite button of a search result', async function () {
    const addProductsToTheCppOrderPage = await StepPageHelper.getAddProductToTheCppOrderPage();
    const itemNumber = fixture.dataBag.getData(DataBagKeys.SOURCE_PRODUCT_ITEM_NUMBER_TO_USE) as string;
    await addProductsToTheCppOrderPage.markOrUnmarkProductAsFav(itemNumber);
    fixture.dataBag.saveData(DataBagKeys.SHOULD_NAVIGATE_TO_ADD_PRODUCTS_PAGE, false);
});

When('user clicks on favorite button of a line item', async function () {
    const cppNewOrderPage = await StepPageHelper.getCppNewOrderPage();
    const itemNumber = fixture.dataBag.getData(DataBagKeys.SOURCE_PRODUCT_ITEM_NUMBER_TO_USE) as string;
    await cppNewOrderPage.markOrUnmarkProductAsFavInTheOrder(itemNumber, 1);
    fixture.dataBag.saveData(DataBagKeys.SHOULD_NAVIGATE_TO_ADD_PRODUCTS_PAGE, true);
});

Then('a new draft cpp order must be created', async function () {
    await verifyDraftOrderUpdateOperation("a new draft CPP order has been saved with the order id - ");
});

Then('existing draft cpp order must be updated', async function () {
    await verifyDraftOrderUpdateOperation("an existing draft CPP order has been updated with the order id - ");
});

Then('a new cpp order must be created', async function () {
    await verifyDraftOrderUpdateOperation("a new CPP order has been saved with the order id - ", false);
});

Then('{string} must be automatically selected as the reason for the other line item', async function (deliveryDayChangeReason: string) {
    const cppNewOrderPage = await StepPageHelper.getCppNewOrderPage();
    const lineItemsData = fixture.dataBag.getData(DataBagKeys.CPP_LINE_ITEM_DATA) as LineItemInfo[];
    const lineItemIndex = fixture.dataBag.getData(DataBagKeys.CPP_ANOTHER_SDM_LINE_ITEM_INDEX) as number;
    const lineItem = lineItemsData.filter(item => item.IsItemSDM).at(lineItemIndex) as LineItemInfo;
    const selectedValue = await cppNewOrderPage.getSelectedDeliveryReasonOptionValue(lineItem.ItemNumber, lineItem.LineItemSeq);
    fixture.logger.info(`selected reason on the UI - ${selectedValue}`);
    fixture.logger.info(`expected reason on the UI - ${deliveryDayChangeReason}`);
    expect(selectedValue == deliveryDayChangeReason).toBeTruthy();
});

Then('customer PO requirement message must be displayed', async function () {
    const cppNewOrderPage = await StepPageHelper.getCppNewOrderPage();
    const customerPOErrorMsgDisplayed = await cppNewOrderPage.isCustomerPOErrorMsgDisplayed();
    //const expectedCustomerPOReqStatus = fixture.dataBag.getData(DataBagKeys.CUSTOMER_PO_REQUIRED) as boolean;
    //fixture.logger.info(`customer PO on the UI - ${customerPOErrorMsgDisplayed}`);
    //fixture.logger.info(`expected customer PO requirement - ${expectedCustomerPOReqStatus}`);
    expect(customerPOErrorMsgDisplayed).toBeTruthy();
});

Then('order must have single line item with quantity equal to {string}', async function (qtyType: string) {
    const cppNewOrderPage = await StepPageHelper.getCppNewOrderPage();
    const lineItemsData = fixture.dataBag.getData(DataBagKeys.CPP_LINE_ITEM_DATA) as LineItemInfo[];
    const lineItemsCount = await cppNewOrderPage.getLineItemsCountInThePlacedOrder(lineItemsData[0].ItemNumber);
    fixture.logger.info(`count of line items in the placed order is ${lineItemsCount}`);
    expect(lineItemsCount).toBe(1);
    const qty = await cppNewOrderPage.getLineItemsOrderQtyInThePlacedOrder(lineItemsData[0].ItemNumber);
    fixture.logger.info(`qty of line item in the placed order is ${qty[0]}`);
    let expectedQty = 0;
    if(qtyType == "min-qty")
        expectedQty = lineItemsData[0].MinQty;
    else if(qtyType == "max-qty")
        expectedQty = lineItemsData[0].MaxQty;
    fixture.logger.info(`expected qty of line item in the placed order is ${expectedQty}`);
    expect(qty[0]).toBe(expectedQty);
});

Then('order must have multiple line items', async function () {
    const cppNewOrderPage = await StepPageHelper.getCppNewOrderPage();
    const lineItemsData = fixture.dataBag.getData(DataBagKeys.CPP_LINE_ITEM_DATA) as LineItemInfo[];
    const lineItemsCount = await cppNewOrderPage.getLineItemsCountInThePlacedOrder(lineItemsData[0].ItemNumber);
    fixture.logger.info(`count of line items in the placed order is ${lineItemsCount}`);
    expect(lineItemsCount).toBeGreaterThan(1);
    const qtyOrdered = fixture.dataBag.getData(DataBagKeys.PRODUCT_CONVERSION_OR_MIN_TRANSFERRABLE_QTY_OR_ORDER_QTY) as number;
    //const expectedDistributions = cppNewOrderPage.getQtyDistributions(lineItemsData[0].MinQty, lineItemsData[0].MaxQty, lineItemsData[0].MinQty + lineItemsData[0].MaxQty);
    const expectedDistributions = cppNewOrderPage.getQtyDistributions(lineItemsData[0].MinQty, lineItemsData[0].MaxQty, qtyOrdered);
    const actualDistributions = await cppNewOrderPage.getLineItemsOrderQtyInThePlacedOrder(lineItemsData[0].ItemNumber);
    fixture.logger.info(`expected qty distributions - ${expectedDistributions}`);
    fixture.logger.info(`actual qty distributions - ${actualDistributions}`);
    expect(expectedDistributions).toEqual(actualDistributions);
});

Then('order must be split into multiple sub-orders based on supplier number', async function () {
    const placedCppOrderSummaryPage = await StepPageHelper.getPlacedCppOrderSummaryPage();
    const lineItemsData = fixture.dataBag.getData(DataBagKeys.CPP_LINE_ITEM_DATA) as LineItemInfo[];
    const result = await placedCppOrderSummaryPage.validateOrderSplit(lineItemsData);
    expect(result).toBeTruthy();
});

Then('products must be ordered in the same or separate sub-orders based on requested arrival date', async function () {
    const placedCppOrderSummaryPage = await StepPageHelper.getPlacedCppOrderSummaryPage();
    const lineItemsData = fixture.dataBag.getData(DataBagKeys.CPP_LINE_ITEM_DATA) as LineItemInfo[];
    const result = await placedCppOrderSummaryPage.validateOrderSplitByRequestedArrivalDate(lineItemsData);
    expect(result).toBeTruthy();
});

Then('products must be ordered in separate sub-orders based on requested arrival date and item number', async function () {
    const placedCppOrderSummaryPage = await StepPageHelper.getPlacedCppOrderSummaryPage();
    const lineItemsData = fixture.dataBag.getData(DataBagKeys.CPP_LINE_ITEM_DATA) as LineItemInfo[];
    const result = await placedCppOrderSummaryPage.validateBulkProductOrderSplitByRequestedArrivalDate(lineItemsData);
    expect(result).toBeTruthy();
});

async function verifyDraftOrderUpdateOperation(successMsg: string, isOrderDraft: boolean = true) {
    let swithToTabName = ""; //no need to switch tabs for Place-Order scenario because UI navigates to the newly created order summary
    let expectedActiveTabName = "";
    let errorMsg = "failed to verify 'Order #number placed successfully' message on Create-New-Cpp-Order page. Error: "; //corresponds to Place-Order scenario

    if (isOrderDraft) {
        expectedActiveTabName = CppOrdersPage.TabName_Draft_Orders;
        swithToTabName = CppOrdersPage.TabName_Draft_Orders;
        errorMsg = "failed to verify 'CPP Order #number saved successfully.' message on Create-New-Cpp-Order page. Error: "
    }

    await placeOrSaveDraftOrderCompletionVerification(successMsg, errorMsg, expectedActiveTabName, swithToTabName);
}

async function placeOrSaveDraftOrderCompletionVerification(successMsg: string, errorMsg: string, expectedActiveTabName: string = "", swithToTabName: string = ""){
    let result = true;
    let orderNumberFromTheMessage ='';
    try {
        const msg = fixture.dataBag.getData(DataBagKeys.OPERATION_COMPLETION_MESSAGE) as string;
        if (msg !== undefined && msg !== null && msg.length > 0) {
            let index = expectedActiveTabName.length > 0 ? 2 : 1;
            orderNumberFromTheMessage = (msg.trim().split(" ")[index]).substring(1);
            expect(orderNumberFromTheMessage).not.toBeNull();
            expect(orderNumberFromTheMessage.length).toBeGreaterThan(1);
            fixture.dataBag.saveData(DataBagKeys.ORDER_ID, orderNumberFromTheMessage);
            fixture.logger.info(successMsg + orderNumberFromTheMessage);
        } else {
            fixture.logger.warn('could not retrieve toast message hence skipping it');
        }
        const cppOrdersPage = await StepPageHelper.getCppOrdersPage();
        
        let displayedOrderId = "";

        if (swithToTabName.length > 0) {
            //below checks are applicable only for draft order
            const customerPO = fixture.dataBag.getData(DataBagKeys.CUSTOMER_PO) as string;
            const currentTabName = await cppOrdersPage.getCurrentActiveTabName();
            fixture.logger.info(`current active tab name is - ${currentTabName}`);
            fixture.logger.info(`expected active tab name is - ${expectedActiveTabName}`);
            result = currentTabName.trim() == expectedActiveTabName.trim();
            expect(result).toBeTruthy();

            await cppOrdersPage.switchToTab(swithToTabName);

            displayedOrderId = await cppOrdersPage.getOrderNumberByCustomerPO(customerPO);
        } else {
            errorMsg = 'failed to very status information on the summary page. ';
            //below checks are applicable only for placed order
            const placedCppOrderSummaryPage = await StepPageHelper.getPlacedCppOrderSummaryPage();
            const displayedStatusNoticeText = await placedCppOrderSummaryPage.getDisplayedOrderSummaryStatusNoticeText();
            fixture.logger.info(`displayed order summary status notice text is - ${displayedStatusNoticeText}`);
            result = displayedStatusNoticeText.includes(CppOrdersPage.Order_Summary_Status_Notice_Txt);
            if(!result)
                result = displayedStatusNoticeText.includes(CppOrdersPage.Order_Summary_Status_Notice_Txt_1);
            expect(result).toBeTruthy();

            displayedOrderId = await placedCppOrderSummaryPage.getDisplayedOrderNumberOnTheSummary();
        }
        fixture.logger.info(`Displayed Order Id/number is - ${displayedOrderId}`);
        expect(displayedOrderId).not.toBeNull();
        displayedOrderId = displayedOrderId.trim();
        expect(displayedOrderId.length).toBeGreaterThan(0);

        if (orderNumberFromTheMessage.length > 0) {
            result = displayedOrderId == orderNumberFromTheMessage;
            fixture.logger.info(`verifying displayed order id value`);
            expect(result).toBeTruthy();
        }
        result = true;//set this to true so that the final expect does not fail
    } catch (error) {
        fixture.logger.error(errorMsg + error);
        result = false;
    }
    expect(result).toBeTruthy();
}

Then('product must be available in favorites section', async function () {
    await navigateToAddProductsScreenIfNeeded(false);
    const addProductsToTheCppOrderPage = await StepPageHelper.getAddProductToTheCppOrderPage();
    const itemNumber = fixture.dataBag.getData(DataBagKeys.SOURCE_PRODUCT_ITEM_NUMBER_TO_USE) as string;
    const result = await addProductsToTheCppOrderPage.isProductMarkedAsFav(itemNumber);    
    expect(result).toBeTruthy();
});

Then('product must be removed as a favorite', async function () {
    await navigateToAddProductsScreenIfNeeded(true);
    const addProductsToTheCppOrderPage = await StepPageHelper.getAddProductToTheCppOrderPage();
    const itemNumber = fixture.dataBag.getData(DataBagKeys.SOURCE_PRODUCT_ITEM_NUMBER_TO_USE) as string;
    const result = await addProductsToTheCppOrderPage.isProductMarkedAsFavInAllProducts(itemNumber);    
    expect(result).toBeFalsy();
});

async function navigateToAddProductsScreenIfNeeded(searchProducts: boolean){
    const navigateToAddProductsPage = fixture.dataBag.getData(DataBagKeys.SHOULD_NAVIGATE_TO_ADD_PRODUCTS_PAGE) as boolean;
    if(navigateToAddProductsPage != undefined && navigateToAddProductsPage)
    {
        const cppNewOrderPage = await StepPageHelper.getCppNewOrderPage();
        if(searchProducts)
            await selectProductsForAddingToTheOrder(cppNewOrderPage, false, false);
        else
            await cppNewOrderPage.clickAddProducts();
    }
}

Then('application should show min-max qty warning message', async function () {
    const lineItemsData = fixture.dataBag.getData(DataBagKeys.CPP_LINE_ITEM_DATA) as LineItemInfo[];
    
    const cppNewOrderPage = await StepPageHelper.getCppNewOrderPage();
    const displayedMsg = await cppNewOrderPage.getDisplayedProductMinMaxQtyWarningMsg(lineItemsData[0].ItemNumber, 1);
    fixture.logger.info(`displayed min-max qty warning message is - ${displayedMsg}`);
    const expectedMsg = cppNewOrderPage.getLineItemMinMaxQtyWarningMessage(lineItemsData[0].MaxQty, lineItemsData[0].MinQty, lineItemsData[0].UOM);
    fixture.logger.info(`expected min-max qty warning message is - ${expectedMsg}`);
    expect(expectedMsg.trim() == displayedMsg.trim()).toBeTruthy();
});

Then('application should show min-max qty error message', async function () {
    const lineItemsData = fixture.dataBag.getData(DataBagKeys.CPP_LINE_ITEM_DATA) as LineItemInfo[];
    
    const cppNewOrderPage = await StepPageHelper.getCppNewOrderPage();
    const displayedMsg = await cppNewOrderPage.getDisplayedProductMinMaxQtyErrorMsg(lineItemsData[0].ItemNumber, 1);
    fixture.logger.info(`displayed min-max qty error message is - ${displayedMsg}`);
    const expectedMsg = cppNewOrderPage.getLineItemMinMaxQtyErrorMessage();
    fixture.logger.info(`expected min-max qty error message is - ${expectedMsg}`);
    expect(expectedMsg.trim() == displayedMsg.trim()).toBeTruthy();
});

Then('order must not be placed', async function () {
    await verifyDraftOrderIsDisplayed();
});

Then('draft order must not be saved', async function () {
    await verifyDraftOrderIsDisplayed();
});

async function verifyDraftOrderIsDisplayed() {
    const cppNewOrderPage = await StepPageHelper.getCppNewOrderPage();
    const saveDraftBtnIsEnabled = await cppNewOrderPage.canClickSaveDraft();
    fixture.logger.info(`Save-Draft button enabled state is - ${saveDraftBtnIsEnabled}`);
    expect(saveDraftBtnIsEnabled).toBeTruthy();
}