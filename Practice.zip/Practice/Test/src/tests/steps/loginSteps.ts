import { Given, When, Then, setDefaultTimeout } from "@cucumber/cucumber";

import { expect } from "@playwright/test";
import { fixture } from "../../hooks/fixture";
import { TestDataType } from "../../helpers/util/test-data/TestDataType";
import AppUser from "../../helpers/util/test-data/account/appUser";
import StepDataHelper from "./stepDataHelper";
import StepPageHelper from "./stepPageHelper";
import DataBagKeys from "./dataBagKeys";
import { navigateToAppLandingPage } from "./commonFeatureSteps";
import EvolveDbManager from "../../helpers/util/db/evolveDbManager";
import DbOperationResult from "../../helpers/util/db/dbOperationResult";
import { config } from 'dotenv';

config();

const fs = require("fs-extra");

setDefaultTimeout(60 * 1000 * 5);

Given('User enters the username as {string}', async function (username: string) {
    const loginPage = await StepPageHelper.getLoginPage();
    try {
        await loginPage.enterUserName(username);
        fixture.logger.info("User entered username");
    }
    catch (error) {
        fixture.logger.error("Failed to enter user name. Error: " + error);
    }
    expect(await loginPage.getUserName()).toBe(username);
});

Given('User enters the password as {string}', async function (password: string) {
    const loginPage = await StepPageHelper.getLoginPage();
    try {
        await loginPage.enterPassword(password);
        fixture.logger.info("User entered password");
    }
    catch (error) {
        fixture.logger.error("Failed to enter password. Error: " + error);
    }
    expect(await loginPage.getPassword()).toBe(password);
});

When('User clicks on the login button', async function () {
    let result = true;
    try {
        const loginPage = await StepPageHelper.getLoginPage();
        await loginPage.clickLoginButton(false);//don't check for homepage navigation
    } catch (error) {
        result = false;
        fixture.logger.error("Failed to click login button. Error: " + error);
    }
    expect(result).toBeTruthy();
});


Then('Login should pass', async function () {
    await checkLoggedInUser();
});

When('Login should fail', async function () {
    const loginPage = await StepPageHelper.getLoginPage();
    const failureMesssage = await loginPage.getErrorMessage();
    await expect(failureMesssage).toBeVisible();
});

Given('User {string} logged-in',  { timeout: 1000 * 1000 }, async function (userDetailDataPath: string) {
    const loginPage = await StepPageHelper.getLoginPage();
    const expectedTitle = await loginPage.getLoggedInPageTitle();
    const isUserLoggedIn = await navigateToAppLandingPage(expectedTitle, false, 1);
    if (!isUserLoggedIn) {
        await loginToApp(userDetailDataPath);
        await checkLoggedInUser();
    }
});

Given('successfully logs-in as {string}',  { timeout: 1000 * 1000 }, async function (userDetailDataPath: string) {
    await loginToApp(userDetailDataPath);
    await checkLoggedInUser();
});

Given('logs-in as {string}', async function (userDetailDataPath: string) {
    await loginToApp(userDetailDataPath);
});

async function loginToApp(userDetailDataPath: string){
    let result = true;
    const loginPage = await StepPageHelper.getLoginPage();
    const userName = process.env.EvolveUserName;
    const password = process.env.EvolvePassword;
    //console.log("evolveusername loaded:",!!userName)
    //console.log("evolvepassword loaded:",!!password)

    if (!userName || !password) {
    throw new Error("Missing USERNAME or PASSWORD in environment variables");
    }
    //const userDetail = StepDataHelper.getSingleTestDataRecordForType(TestDataType.AppUser, userDetailDataPath) as AppUser;
    fixture.logger.info(`User - ${userName} - is about to login to the application`);
    let userRoleSet = false;
    //fixture.logger.info(`JDEReleaseFunctionsKey value is - ${process.env.JDEReleaseFunctionsKey}`);
    try {
        let evolveDbManager = new EvolveDbManager();
        console.log("BEFORE SET USER ROLE");
        let dbResult: DbOperationResult = await evolveDbManager.setUserRole(userName, evolveDbManager.COL_VAL_USER_ROLE_ADMINISTRATOR);
        if (!dbResult.operationResult) {
            throw new Error(`setUserRole failed: ${JSON.stringify(dbResult, null, 2)}`);
        } else {
            fixture.logger.info(`User - ${userName} - role set to Administrator successfully`);
        }
        userRoleSet = true;
        await loginPage.enterUserName(userName);
        await loginPage.enterPassword(password);
        await loginPage.clickLoginButton();
        //const loggedInUserAuthInfoFilePath = fixture.dataBag.getData(DataBagKeys.USER_AUTH_INFO_FILE_PATH);
        //await fixture.browserContext.storageState({ path: loggedInUserAuthInfoFilePath });
        result = await loginPage.initializeOAuthToken();
        //await fixture.page.waitForTimeout(2000);
    } catch (error) {
        console.error("LoginError:" ,error);
        console.error("loginerror details:",JSON.stringify(error,null,2));

        result = false;
        if(userRoleSet){
            fixture.logger.error("User failed to log-in. Error: " + error);
        }else{
            fixture.logger.error(`For the user - ${userName} - failed to set the role to Administrator. Error: ` + error);
        }
    }
    expect(result).toBeTruthy();
}

async function isLoginComplete(): Promise<boolean> {
    /*const loginPage = await StepPageHelper.getLoginPage();
    let text = "";
    try {
        text = await loginPage.getLoggedInUserName();
        //console.log("Username: " + text);
        fixture.logger.info("Username: " + text);
        fixture.logger.info(`User - ${text} - has logged-in to the application`);
        return true;
    } catch (error) {
        fixture.logger.warn("Unable to retrieve logged-in user name. Probably user is not yet logged-in. Error: " + error);
    }
    return false;*/
    const loggedInUserAuthInfoFilePath = fixture.dataBag.getData(DataBagKeys.USER_AUTH_INFO_FILE_PATH) as string;
    return fs.existsSync(loggedInUserAuthInfoFilePath);
}

async function checkLoggedInUser() {
    let result = true;
    const loginPage = await StepPageHelper.getLoginPage();
    let text = "";
    try {
        text = await loginPage.getLoggedInUserName();
        //console.log("Username: " + text);
        fixture.logger.info("Username: " + text);
    } catch (error) {
        result = false;
        console.log("LOGIN ERROR:",error);
        fixture.logger.error("Failed to get logged-in user name. Error: " + error);
    }
    console.log("LOGGED IN USER:",text);
    expect(text.length).toBeGreaterThan(1);
    expect(result).toBeTruthy();
    fixture.logger.info(`User - ${text} - has logged-in to the application`);
}
