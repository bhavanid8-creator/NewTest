import { expect } from "@playwright/test";
import EvolveDbManager from "../../helpers/util/db/evolveDbManager";
import { fixture } from "../../hooks/fixture";
import DataBagKeys from "./dataBagKeys";
import ProductData from "../../helpers/util/test-data/dataRequirements/productData";
import InitializedGrower from "../../helpers/util/test-data/dataRequirements/initializedGrower";
import InitializedDealer from "../../helpers/util/test-data/dataRequirements/initializedDealer";
import CommonData from "../../helpers/util/test-data/dataRequirements/commonData";

export default class DataRequirementsSteps {

    /**
     * Deletes existing orders (if any) of the specified dealer
     * @param accountNumber dealer account number
     */
    static async ensureDealerDoesNotHaveAnOrder(accountNumber: string) {
        fixture.logger.info("checking and deleting (if necessary) dealer order has started");
        let result = true;
        try {
            let evolveDbManager = new EvolveDbManager();
            const dbResult = await evolveDbManager.deleteDealerOrders(accountNumber);
            expect(dbResult.operationResult).toBeTruthy();
        } catch (error) {
            fixture.logger.error("checking and deleting (if necessary) dealer order has failed. Error: " + error);
            result = false;
        }
        expect(result).toBeTruthy();
        
        fixture.logger.info("deleting dealer account reference from internal cache");
        let accountNumbersOfDealerWithNewlyCreatedOrders = fixture.globalDataBag.getData(DataBagKeys.DATA_REQ_DEALER_ACCOUNT_WITH_INITIALIZED_ORDERS) as InitializedDealer[];
        let index = accountNumbersOfDealerWithNewlyCreatedOrders.findIndex(d => d.accountNumber === accountNumber);
        if (index !== -1) {
            accountNumbersOfDealerWithNewlyCreatedOrders.splice(index, 1);//removes only one occrrence but we are sure there will be only one entry
            fixture.globalDataBag.saveData(DataBagKeys.DATA_REQ_DEALER_ACCOUNT_WITH_INITIALIZED_ORDERS, accountNumbersOfDealerWithNewlyCreatedOrders);
        }

        fixture.logger.info("checking and deleting (if necessary) dealer order has completed");
    }

    static async ensureDealerHasAnOrder({accountNumber, itemIds = [], quantities = [], deleteExistingData = true}: 
        {accountNumber: string; itemIds?:number[]; quantities?:number[]; deleteExistingData?: boolean}): Promise<string> {
        let accountNumbersOfDealerWithNewlyCreatedOrders = fixture.globalDataBag.getData(DataBagKeys.DATA_REQ_DEALER_ACCOUNT_WITH_INITIALIZED_ORDERS) as InitializedDealer[];
        let existingDealerIndex = accountNumbersOfDealerWithNewlyCreatedOrders.findIndex(d => d.accountNumber === accountNumber);
        if(existingDealerIndex !== -1)
         {
            fixture.logger.info("dealer order was already created");
            return accountNumbersOfDealerWithNewlyCreatedOrders[existingDealerIndex].newOrderNumber;
         }

        fixture.logger.info("checking and inserting (if necessary) dealer order has started");
        let newDealerOrderNumber:string;
        let result = true;
        
        if(itemIds === undefined)
            itemIds = [];
        
        if(quantities === undefined)
            quantities = [];
        
        let emulatingUserId = fixture.dataBag.getData(DataBagKeys.CURRENT_EMULATED_USER_ID) as string; //this could be undefined too
        if(emulatingUserId === undefined || (emulatingUserId !== null && emulatingUserId.length === 0))
            emulatingUserId = null;
        
        if(deleteExistingData === undefined)
            deleteExistingData = true;

        try {
            let evolveDbManager = new EvolveDbManager();

            if(itemIds.length === 0){
                let productData = evolveDbManager.getDataRequirementObject(DataBagKeys.DATA_REQ_PRODUCTS) as ProductData[];
                for(let i=0; i<productData.length; i++){
                    if(!itemIds.includes(productData[i].itemId))
                        itemIds.push(productData[i].itemId);
                }
            }
            let commonData = evolveDbManager.getDataRequirementObject(DataBagKeys.DATA_REQ_COMMON) as CommonData;
            if(quantities.length === 0){
                for(let i=0; i<itemIds.length; i++){
                    quantities.push(commonData.defaultDealerProductQty);
                }
            }else if(quantities.length < itemIds.length){
                for(let i=0; i<itemIds.length - quantities.length; i++){
                    quantities.push(commonData.defaultDealerProductQty);
                }
            }
            
            const dbResult = await evolveDbManager.insertDealerOrder(accountNumber, itemIds, quantities, emulatingUserId, deleteExistingData);
            expect(dbResult.operationResult).toBeTruthy();
            newDealerOrderNumber = dbResult.operationData.newDealerOrderNumber;
            expect(newDealerOrderNumber).not.toBeNull();
            expect(newDealerOrderNumber.length).toBeGreaterThan(0);
        } catch (error) {
            fixture.logger.error("checking and inserting (if necessary) dealer order has failed. Error: " + error);
            result = false;
        }
        expect(result).toBeTruthy();
        
        fixture.logger.info("updating internal cache with the dealer account for whom a new order has been created");
        let newInitializedDealer = new InitializedDealer();
        newInitializedDealer.accountNumber = accountNumber;
        newInitializedDealer.newOrderNumber = newDealerOrderNumber;
        accountNumbersOfDealerWithNewlyCreatedOrders.push(newInitializedDealer);
        fixture.globalDataBag.saveData(DataBagKeys.DATA_REQ_DEALER_ACCOUNT_WITH_INITIALIZED_ORDERS, accountNumbersOfDealerWithNewlyCreatedOrders);
        fixture.logger.info("checking and inserting (if necessary) dealer order has completed");
        return newDealerOrderNumber;
    }

    static async ensureGrowerDoesNotHaveAnOrder(dealerAccountNumber: string, growerGMK: string) {
        fixture.logger.info("checking and deleting (if necessary) grower order has started");
        let result = true;
        try {
            let evolveDbManager = new EvolveDbManager();
            const dbResult = await evolveDbManager.deleteGrowerOrders(dealerAccountNumber, growerGMK);
            expect(dbResult.operationResult).toBeTruthy();
        } catch (error) {
            fixture.logger.error("checking and deleting (if necessary) grower order has failed. Error: " + error);
            result = false;
        }
        expect(result).toBeTruthy();
        
        fixture.logger.info("deleting grower account reference from internal cache");
        let gmkNumbersOfGrowerWithNewlyCreatedOrders = fixture.globalDataBag.getData(DataBagKeys.DATA_REQ_GROWER_GMK_WITH_INITIALIZED_ORDERS) as InitializedGrower[];
        let index = gmkNumbersOfGrowerWithNewlyCreatedOrders.findIndex(g => g.gmk === growerGMK);
        if (index !== -1) {
            gmkNumbersOfGrowerWithNewlyCreatedOrders.splice(index, 1);//removes only one occrrence but we are sure there will be only one entry
            fixture.globalDataBag.saveData(DataBagKeys.DATA_REQ_GROWER_GMK_WITH_INITIALIZED_ORDERS, gmkNumbersOfGrowerWithNewlyCreatedOrders);
        }

        fixture.logger.info("checking and deleting (if necessary) grower order has completed");
    }

    /**
     * 
     * @param accountNumber shipToAccount value
     * @param growerGMK grower GMK
     * @param itemIds product ItemId list; if not provided all the products mentioned in the products requirements JSON file will be used
     * @param quantities quantity for each of the item; if not provided by default 50 will be used
     * @param deleteExistingData should be used to indicate to delete grower orders that were created before the current scenario set run; by default true.
     * Note: grower order created during current scenario set run will not be deleted even if this parameter value is TRUE.
     * @returns 
     */
    static async ensureGrowerHasAnOrder({accountNumber, growerGMK, itemIds = [], quantities = [], deleteExistingData = true}: 
        {accountNumber: string; growerGMK: string; itemIds?:number[]; quantities?:number[]; deleteExistingData?: boolean}): Promise<string> {
        let gmkNumbersOfGrowerWithNewlyCreatedOrders = fixture.globalDataBag.getData(DataBagKeys.DATA_REQ_GROWER_GMK_WITH_INITIALIZED_ORDERS) as InitializedGrower[];
        let existingGrowerIndex = gmkNumbersOfGrowerWithNewlyCreatedOrders.findIndex(g => g.gmk === growerGMK);
        if(existingGrowerIndex !== -1)
         {
            fixture.logger.info("grower order was already created");
            return gmkNumbersOfGrowerWithNewlyCreatedOrders[existingGrowerIndex].newOrderNumber;
         }

        fixture.logger.info("checking and inserting (if necessary) grower order has started");
        let newGrowerOrderNumber: string;

        let result = true;
        
        if(itemIds === undefined)
            itemIds = [];
        
        if(quantities === undefined)
            quantities = [];
        
        let emulatingUserId = fixture.dataBag.getData(DataBagKeys.CURRENT_EMULATED_USER_ID) as string; //this could be undefined too
        if(emulatingUserId === undefined || (emulatingUserId !== null && emulatingUserId.length === 0))
            emulatingUserId = null;
        
        if(deleteExistingData === undefined)
            deleteExistingData = true;

        try {
            let evolveDbManager = new EvolveDbManager();

            if(itemIds.length === 0){
                let productData = evolveDbManager.getDataRequirementObject(DataBagKeys.DATA_REQ_PRODUCTS) as ProductData[];
                for(let i=0; i<productData.length; i++){
                    if(!itemIds.includes(productData[i].itemId))
                        itemIds.push(productData[i].itemId);
                }
            }
            let commonData = evolveDbManager.getDataRequirementObject(DataBagKeys.DATA_REQ_COMMON) as CommonData;

            if(quantities.length === 0){
                for(let i=0; i<itemIds.length; i++){
                    quantities.push(commonData.defaultGrowerProductQty);
                }
            }else if(quantities.length < itemIds.length){
                for(let i=0; i<itemIds.length - quantities.length; i++){
                    quantities.push(commonData.defaultGrowerProductQty);
                }
            }
            
            const dbResult = await evolveDbManager.insertGrowerOrder(accountNumber, growerGMK, itemIds, quantities, emulatingUserId, deleteExistingData);
            expect(dbResult.operationResult).toBeTruthy();
            newGrowerOrderNumber = dbResult.operationData.newGrowerOrderNumber;
            expect(newGrowerOrderNumber).not.toBeNull();
            expect(newGrowerOrderNumber.length).toBeGreaterThan(0);
        } catch (error) {
            fixture.logger.error("checking and inserting (if necessary) grower order has failed. Error: " + error);
            result = false;
        }
        expect(result).toBeTruthy();
        
        fixture.logger.info("updating internal cache with the grower account for whom a new order has been created");
        let newInitializedGrower = new InitializedGrower();
        newInitializedGrower.gmk = growerGMK;
        newInitializedGrower.newOrderNumber = newGrowerOrderNumber;

        gmkNumbersOfGrowerWithNewlyCreatedOrders.push(newInitializedGrower);
        fixture.globalDataBag.saveData(DataBagKeys.DATA_REQ_GROWER_GMK_WITH_INITIALIZED_ORDERS, gmkNumbersOfGrowerWithNewlyCreatedOrders);
        fixture.logger.info("checking and inserting (if necessary) grower order has completed");

        return newGrowerOrderNumber;
    }
}