import { expect } from "@playwright/test";
import { fixture } from "../../hooks/fixture";
import { ProductSelectionFilters } from "../../helpers/util/test-data/product/productsSelection";
import StepPageHelper from "./stepPageHelper";
import AddProductsToTheOrderPage from "../../pages/seed/orders/addProductsToTheOrderPage";
import AddEAProductsToTheOrderPage from "../../pages/seed/orders/addEAProductsToTheOrderPage";
import ProductInfo from "../../helpers/util/test-data/product/productInfo";
export default class AddProductsToOrderPageSteps {
    private addProductToTheOrderPage: AddProductsToTheOrderPage = null;
    private addEAProductToTheOrderPage: AddEAProductsToTheOrderPage = null;
    async searchForProducts(filterCategory: string, searchKey: string, onlyShowProductOnDealerOrder: string, onlyShowProductWithAvailability: string) : Promise<boolean> {
        /*const pageStability = await this.addProductToTheOrderPage.isPageStable();
        expect(pageStability).toBeTruthy();
        */
        if(this.addProductToTheOrderPage === null){
            this.addProductToTheOrderPage = await StepPageHelper.getAddProductToTheOrderPage();
        }
        await this.addProductToTheOrderPage.clickSearchFilterDropDown();
        await this.addProductToTheOrderPage.selectSearchFilterItemInTheDropDown(filterCategory);
        let isSearchByFreeText: boolean = false;

        if (filterCategory === ProductSelectionFilters.productName
            || filterCategory === ProductSelectionFilters.technology)
            isSearchByFreeText = true;

        fixture.logger.info(`products are searched with following filters`);
        fixture.logger.info(`filterCategory - ${filterCategory}; searchKey - ${searchKey}; onlyShowProductOnDealerOrder - ${onlyShowProductOnDealerOrder}; onlyShowProductWithAvailability - ${onlyShowProductWithAvailability} (in case of dealer order, this needs to be read as ${!onlyShowProductWithAvailability})`);
        const onlyShowProductOnDealerOrder_bool = (/true/i).test(onlyShowProductOnDealerOrder);
        const onlyShowProductWithAvailability_bool = (/true/i).test(onlyShowProductWithAvailability);

        return await this.addProductToTheOrderPage.searchProduct(searchKey, isSearchByFreeText
            , onlyShowProductOnDealerOrder_bool, onlyShowProductWithAvailability_bool);
    }

    private async initializeEAProductsPage(){
        if(this.addEAProductToTheOrderPage === null){
            this.addEAProductToTheOrderPage = await StepPageHelper.getAddEAProductToTheOrderPage();
        }
    }

    async searchForEAProducts(filterCategory: string, searchKey: string, displayDealerOrderEarlyAdvantageUnits:string) : Promise<boolean> {
        await this.initializeEAProductsPage();
        await this.addEAProductToTheOrderPage.clickEASearchFilterDropDown();
        await this.addEAProductToTheOrderPage.selectSearchFilterItemInTheDropDown(filterCategory);
        let isSearchByFreeText: boolean = false;

        if (filterCategory === ProductSelectionFilters.productName)
            isSearchByFreeText = true;
        fixture.logger.info(`products are searched with following filters`);
        fixture.logger.info(`filterCategory - ${filterCategory}; searchKey - ${searchKey}; displayDealerOrderEarlyAdvantageUnits - ${displayDealerOrderEarlyAdvantageUnits}`);
        const displayDealerOrderEarlyAdvantageUnits_bool = (/true/i).test(displayDealerOrderEarlyAdvantageUnits);
        
        return await this.addEAProductToTheOrderPage.searchEAProduct(searchKey, isSearchByFreeText
            , displayDealerOrderEarlyAdvantageUnits_bool);
    }

    async selectProducts(products: string[], clearSearchResults: boolean) {

        if(this.addProductToTheOrderPage === null){
            this.addProductToTheOrderPage = await StepPageHelper.getAddProductToTheOrderPage();
        }

        await this.addProductToTheOrderPage.selectProductsFromSearchResult(products);

        if(clearSearchResults)
            await this.addProductToTheOrderPage.clearProductSearchResults();
    }
    
    async selectProductsByItemNumbers(itemNumbersToSelect: string[], clearSearchResults: boolean) {

        if(this.addProductToTheOrderPage === null){
            this.addProductToTheOrderPage = await StepPageHelper.getAddProductToTheOrderPage();
        }

        await this.addProductToTheOrderPage.selectProductsFromSearchResultByTestId(itemNumbersToSelect);
        if(clearSearchResults)
            await this.addProductToTheOrderPage.clearProductSearchResults();
    }

    async selectEAProducts(products: string[], productQuantites: string[], clearSearchResults: boolean) {
        await this.initializeEAProductsPage();
        await this.addEAProductToTheOrderPage.selectProductsFromSearchResult(products, productQuantites);
        if(clearSearchResults)
            await this.addEAProductToTheOrderPage.clearProductSearchResults();
    }

    async selectEAProductsByItemNumber(products: string[], productQuantites: string[], clearSearchResults: boolean) {
        await this.initializeEAProductsPage();
        await this.addEAProductToTheOrderPage.selectProductsByItemNumberFromSearchResult(products, productQuantites);
        if(clearSearchResults)
            await this.addEAProductToTheOrderPage.clearProductSearchResults();
    }

    async addSelectedProductsToOrder(): Promise<string> {
        const result = await this.addProductToTheOrderPage.isAddToOrderButtonEnabled();
        expect(result).toBeTruthy();

        return await this.addProductToTheOrderPage.clickAddToOrderButton();
    }

    async updateOrderWithEAProducts(): Promise<string> {
        await this.initializeEAProductsPage();
        const result = await this.addEAProductToTheOrderPage.isUpdateOrderButtonEnabled();
        expect(result).toBeTruthy();
        return await this.addEAProductToTheOrderPage.clickUpdateOrderButton();
    }

    async modifyEAUnitsWithButtons(shouldReduceQty: boolean){
        await this.initializeEAProductsPage();
        await this.addEAProductToTheOrderPage.modifyEAUnitsWithButtons(shouldReduceQty);
    }

    async swapEAUnitsWithInput_obsolete(targetProduct: ProductInfo, units: string): Promise<boolean>{
        await this.initializeEAProductsPage();
        return await this.addEAProductToTheOrderPage.swapEAUnitsWithInput_obsolete(targetProduct, units);
    }

    async swapEAUnitsWithInput(swappingProductItemNumber: string, productQty: string): Promise<void>{
        await this.initializeEAProductsPage();
        await this.addEAProductToTheOrderPage.selectProductsByItemNumberFromSearchResult([swappingProductItemNumber], [productQty]);
    }

    async modifyEAUnitsWithInput(qtyToUpdateBy: number){
        await this.initializeEAProductsPage();
        await this.addEAProductToTheOrderPage.modifyEAUnitsWithInput(qtyToUpdateBy);
    }
}