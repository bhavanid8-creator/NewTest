import { fixture } from "../../hooks/fixture";
import DataBagKeys from "./dataBagKeys";
import { expect } from "@playwright/test";
import StepPageHelper from "./stepPageHelper";
import ProductFilter from "../../helpers/util/test-data/product/productFilter";
import { ProductSelectionFilters } from "../../helpers/util/test-data/product/productsSelection";
export default class SharedSteps{
    async updateOrderIfModifiedDuringNavigation(): Promise<boolean>{
        fixture.logger.info(`updating order as either a new line item was added or existing line item was modified during navigation`);
        let orderUpdated = false;
        const lineItemAddedOrModifiedDuringNavigation = fixture.dataBag.getData(DataBagKeys.ORDER_LINE_ITEM_ADDED_OR_MODIFIED_DURING_NAVIGATION) as boolean;
    
        if(lineItemAddedOrModifiedDuringNavigation != null && lineItemAddedOrModifiedDuringNavigation){
            const addGrowerOrderPage = await StepPageHelper.getAddGrowerOrderPage();
            await addGrowerOrderPage.placeOrUpdateOrder(false);
            orderUpdated = true;
        }
        fixture.logger.info(`updating order completed`);
        return orderUpdated;
    }

    validateStepActionResult(actionResult: boolean, errorMsg: string){
        if(!actionResult)
            fixture.logger.error(errorMsg);
    
        expect(actionResult).toBeTruthy();
    }

    async delayForSlowMotion(){
        const slowMotion = parseInt(process.env.SLOW_MOTION_IN_MS.replaceAll(",",""));
        if(slowMotion > 0)
            await fixture.page.waitForTimeout(slowMotion);
    }

    getProductFilterDataByItemNumber(itemNumber: string): ProductFilter {
        const productFilter = new ProductFilter();
        productFilter.filterCategory = ProductSelectionFilters.itemNumber;
        productFilter.searchKey = itemNumber;
        return productFilter;
    }
}