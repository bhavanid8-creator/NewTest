import { DataTable, Given, Then, When, setDefaultTimeout } from "@cucumber/cucumber";

import { expect } from "@playwright/test";
import { fixture } from "../../../../../hooks/fixture";
import AddProductsToOrderPageSteps from "../../../addProductsToOrderPageSteps";
import ProductOrderLineItemInfo from "../../../../../helpers/util/test-data/productOrder/productOrderLineItemInfo";
import ProductInfo from "../../../../../helpers/util/test-data/product/productInfo";
import ProductOrderInfo from "../../../../../helpers/util/test-data/productOrder/productOrderInfo";
import StepDataHelper from "../../../stepDataHelper";
import StepPageHelper from "../../../stepPageHelper";
import DataBagKeys from "../../../dataBagKeys";
import { fillGrowerProductOrderInfo } from "../updateGrowerOrderSteps";

setDefaultTimeout(60 * 1000 * 2)

Given('user adds products to the order on Add-Products-to-the-order page', async function (dataTable: DataTable) {
    fixture.logger.info("Adding products to the order on Add-Products-to-the-order page has started");
    let result = true;
    let productsInfo: ProductInfo[] = [];
    try {
        const records = dataTable.hashes();
        const addProductsToOrderPageSteps = new AddProductsToOrderPageSteps();
        const addGrowerOrderPage = await StepPageHelper.getAddGrowerOrderPage();

        fixture.logger.info("below products will be added to the order");
        const accountNumberStr = fixture.dataBag.getData(DataBagKeys.DEALER_ACCOUNT_NUMBER) as string;
        const accountNumber = parseInt(accountNumberStr);
        let productsFoundAtleastForOneFilter = false;
        for (let i = 0; i < records.length; i++) {
            const r = records[i];

            const filterCategoryInfo: string = StepDataHelper.getSingleStringNodeData(r.filterCategory);
            const searchKeyInfo: string = StepDataHelper.getSingleStringNodeData(r.searchKey);
            const onlyShowProductOnDealerOrderInfo: string = StepDataHelper.getSingleStringNodeData(r.onlyShowProductOnDealerOrder);
            const onlyShowProductWithAvailabilityInfo: string = StepDataHelper.getSingleStringNodeData(r.onlyShowProductWithAvailability);
            //let productsInfo: string[] = StepDataHelper.getStringNodeListData(r.productsToSelect);
           // const productsInfo = StepDataHelper.getMultipleTestDataRecordsForType(TestDataType.ProductInfo, r.productsToSelect) as ProductInfo[];
            fixture.logger.info(`caling product availability API with below payload`);
            fixture.logger.info(`accountNumber = ${accountNumber}; filterCategoryInfo = ${filterCategoryInfo}; searchKeyInfo = ${searchKeyInfo}`);
           const productsInfoTemp = await StepDataHelper.getProductsForGrower(accountNumber,filterCategoryInfo,searchKeyInfo);
            if(productsInfoTemp == null || productsInfoTemp.length == 0)
            {
                if(i === records.length - 1 && !productsFoundAtleastForOneFilter)
                {
                    fixture.logger.error("Could not retrieve products with selected criteria. Hence exiting from the scenario");
                    result = false;
                    break;
                }else{
                    fixture.logger.warn('products are not available from the endpoint');
                    continue;
                }
            }
            productsFoundAtleastForOneFilter = true;
            
            if (i > 0) //when i == 0, navigation to the add-products-page was already done
            {
                await addGrowerOrderPage.navigateToAddProductsPage();
            }
            result = await addProductsToOrderPageSteps.searchForProducts(filterCategoryInfo, searchKeyInfo, onlyShowProductOnDealerOrderInfo, onlyShowProductWithAvailabilityInfo);
            if (result) {
                await addProductsToOrderPageSteps.selectProducts([productsInfoTemp[0].itemDescription], false);
                const msg = await addProductsToOrderPageSteps.addSelectedProductsToOrder();
                //await addGrowerOrderPage.checkProductsAddedMessageDisplay();
                fixture.logger.info(`received message after adding products to the order is...${msg}`);
                expect(msg).not.toBeNull();
                expect(msg.length).toBeGreaterThan(0);
                productsInfo.push(productsInfoTemp[0]);
                // if (i < records.length - 1) {
                //     await addGrowerOrderPage.navigateToAddProductsPage();
                // }
            }
            //productsInfo.push(...productsInfoTemp);
        }
    } catch (error) {
        fixture.logger.error("Adding products to the order on Add-Products-to-the-order page failed. Error: " + error);
        result = false;
    }
    expect(result).toBeTruthy();
    fixture.logger.info("Adding products to the order on Add-Products-to-the-order page has completed");
    fixture.dataBag.saveData(DataBagKeys.PRODUCTS_TO_USE, productsInfo);
    const temp = fixture.dataBag.getData(DataBagKeys.PRODUCTS_TO_USE) as ProductInfo[];
    fixture.logger.info(`saved products length is...${temp.length}`);
    //fixture.logger.info(`first saved product data is...${JSON.stringify(temp[0])}`);
    //fixture.logger.info(`second saved product data is...${JSON.stringify(temp[1])}`);
});

Then('user must be able to set various properties for each line item on Grower-order screen', async function (dataTable: DataTable) {
    await setOrderLineitemProperties(dataTable);
});

Then('user sets various properties for each line item on Grower-order screen', async function (dataTable: DataTable) {
    await setOrderLineitemProperties(dataTable);
});

async function setOrderLineitemProperties(dataTable: DataTable){
    fixture.logger.info("Setting various properties for each line item on Grower-order page has started");
    let result = true;
    try {
        const productsToOrder: ProductOrderLineItemInfo[] = [];

        const records = dataTable.hashes();
        const productsInfo = fixture.dataBag.getData(DataBagKeys.PRODUCTS_TO_USE) as ProductInfo[];
        //for (let i = 0; i < records.length; i++) {
        for (let i = 0; i < productsInfo.length; i++) {
            const r = records[i];
            const orderLineItem = new ProductOrderLineItemInfo();

            orderLineItem.productInfo = new ProductInfo();
            //orderLineItem.productInfo.name = StepDataHelper.getSingleStringNodeData(r.productName);
            orderLineItem.productInfo.name = productsInfo[i].name;

            orderLineItem.productOrderInfo = getProductOrderInfoFromDataTableRecord(r);

            productsToOrder.push(orderLineItem);
            //console.log(orderLineItem);
        }
        const addGrowerOrderPage = await StepPageHelper.getAddGrowerOrderPage();
        await addGrowerOrderPage.fillProductOrderDetails(productsToOrder);
        await addGrowerOrderPage.fillOrderOtherDetails();
    } catch (error) {
        fixture.logger.error("Setting various properties for each line item on Grower-order page failed. Error: " + error);
        result = false;
    }
    expect(result).toBeTruthy();
    fixture.logger.info("Setting various properties for each line item on Grower-order page has completed");
}

When('user sets various properties with order level controls on Grower-order screen', async function () {
    await setOrlierLineitemPropertiesAtOrderLevel();
});

async function setOrlierLineitemPropertiesAtOrderLevel(){
    fixture.logger.info("Setting various properties for all line items with order level controls on Grower-order page has started");
    let result = true;
    try {
        const addGrowerOrderPage = await StepPageHelper.getAddGrowerOrderPage();

        //const globalOrderInfo = getProductOrderInfoFromDataTableRecord(dataTable.hashes()[0]);
        const globalOrderInfo = new ProductOrderInfo();
        await fillGrowerProductOrderInfo(globalOrderInfo);
        // step 1: fill line item details in the same order that products were added
        await addGrowerOrderPage.fillLineItemDetailsWithOrderLevelControls(globalOrderInfo);
    } catch (error) {
        fixture.logger.error("Setting various properties for all line items with order level controls on Grower-order page failed. Error: " + error);
        result = false;
    }
    expect(result).toBeTruthy();
    fixture.logger.info("Setting various properties for all line items with order level controls on Grower-order page has completed");
}
function getProductOrderInfoFromDataTableRecord(r: Record<string, string>): ProductOrderInfo {
    const productOrderInfo = new ProductOrderInfo();

    productOrderInfo.units = StepDataHelper.getSingleStringNodeData(r.units);

    const providedDate = StepDataHelper.getSingleStringNodeData(r.deliveryDate);
    const deliveryDate = new Date(providedDate);
    const today = new Date();
    if (deliveryDate < today) {
        productOrderInfo.deliveryDate = today.toLocaleDateString('en-US', {
            month: 'long',
            day: 'numeric',
            year: 'numeric'
        });
    } else {
        productOrderInfo.deliveryDate = providedDate;
    }

    productOrderInfo.seller = StepDataHelper.getSingleStringNodeData(r.seller);
    productOrderInfo.customerPO = StepDataHelper.getSingleStringNodeData(r.customerPO);

    return productOrderInfo;
}
Then('Place-Order or Update-Order button must be enabled on Grower-order screen', async function () {
    fixture.logger.info("Checking Place-Order or Update-Order button is enabled or not on Grower-order page has started");
    let result = true;
    try {
        const addGrowerOrderPage = await StepPageHelper.getAddGrowerOrderPage();
        result = await addGrowerOrderPage.isPlaceOrUpdateOrderBtnEnabled();
    } catch (error) {
        fixture.logger.error("Checking Place-Order or Update-Order button is enabled or not on Grower-order page failed. Error: " + error);
        result = false;
    }
    expect(result).toBeTruthy();
    fixture.logger.info("Checking Place-Order or Update-Order button is enabled or not on Grower-order page has completed");
});
