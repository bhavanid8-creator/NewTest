import { Given, Then, When, setDefaultTimeout } from "@cucumber/cucumber";

import { expect } from "@playwright/test";
import { fixture } from "../../../../../hooks/fixture";
import VerifyAccounts from "../../../../../helpers/util/test-data/dealer/verifyAccounts";
import { TestDataType } from "../../../../../helpers/util/test-data/TestDataType";
import StepDataHelper from "../../../stepDataHelper";
import VerifyEmulatedAccount from "../../../../../helpers/util/test-data/emulation/verifyEmulatedAccount";
import DataBagKeys from "../../../dataBagKeys";
import HeaderNavigationPage from "../../../../../pages/landing/headerNavigationPage";
import MultiDealerAccountContext from "../../../../../helpers/util/test-data/dealer/multiDealerAccountContext";
import { AccountFilterOption } from "../../../../../pages/account/accountPage";
import EnumValidator from "../../../../../helpers/types/enumValidator";
import AccountDetailsForOrderModification from "../../../../../helpers/util/test-data/grower/accountDetailsForOrderModification";
import AccountsSelectionToVerify from "../../../../../helpers/util/test-data/dealer/accountsSelectionToVerify";
import AccountDetails from "../../../../../helpers/util/test-data/dealer/accountDetails";
import StepPageHelper from "../../../stepPageHelper";
import SingleDealerAccountContext from "../../../../../helpers/util/test-data/dealer/singleDealerAccountContext";
import EmulationPage from "../../../../../pages/emulation/emulationPage";
import EvolveDbManager from "../../../../../helpers/util/db/evolveDbManager";
import DataRequirementsSteps from "../../../dataRequirementsSteps";
import ApiManager from "../../../../../helpers/util/api/apiManager";
import GrowerDetails from "../../../../../helpers/util/test-data/grower/growerDetails";
import DealerAccountContext from "../../../../../helpers/util/test-data/dealer/dealerAccountContext";
import GrowerOrderModifyProdSpResult from "../../../../../helpers/util/db/resultSets/growerOrderModifyProdSpResult";
import GrowerOrderTransferProdSpResult from "../../../../../helpers/util/db/resultSets/growerOrderTransferProdSpResult";
import DealerOrderTransferProdSpResult from "../../../../../helpers/util/db/resultSets/dealerOrderTransferProdSpResult";
import { DealerOrderModifyProdSpResult } from "../../../../../helpers/util/db/resultSets/dealerOrderModifyProdSpResult";
import { DealerStockTransferSpResult } from "../../../../../helpers/util/db/resultSets/dealerStockTransferSpResult";
import { DealerOrderCreateOrUpdateSpResult } from "../../../../../helpers/util/db/resultSets/dealerOrderCreateOrUpdateSpResult";
import DbOperationResult from "../../../../../helpers/util/db/dbOperationResult";
import GrowerOrderCreateOrUpdateSpResult from "../../../../../helpers/util/db/resultSets/growerOrderCreateOrUpdateSpResult";
import DealerOrderSwapEAProdSpResult from "../../../../../helpers/util/db/resultSets/dealerOrderSwapEAProdSpResult";
import SeedFulfillmentInfo from "../../../../../helpers/util/api/models/seedFulfillmentInfo";
import CreateCppOrderSpResult from "../../../../../helpers/util/db/resultSets/cpp/createCppOrderSpResult";
import CppNewOrderPage from "../../../../../pages/cpp/orders/cppNewOrderPage";
import CreateCppReturnRequestSpResult from "../../../../../helpers/util/db/resultSets/cpp/createCppReturnRequestSpResult";
import CppProductReturnsPage from "../../../../../pages/cpp/returns/product/productReturnsPage";
import CppInoculantReturnsPage from "../../../../../pages/cpp/returns/inoculant/inoculantReturnsPage";
import { SkipScenarioError } from "../../../../../helpers/util/errorHandler";
import SeedReservationDataQueryResult from "../../../../../helpers/util/db/resultSets/seed/seedReservationDataQueryResult";
import SingleSeedReservationDataQueryResult from "../../../../../helpers/util/db/resultSets/seed/singleSeedReservationDataQueryResult";

setDefaultTimeout(60 * 1000 * 5)

Given('user sets multiple accounts context as {string} with emulated account background as {string}', async function (multiDealerAccountContext: string, emulatedAccountContext: string) {
    const dealerAccountContext = await setMultiAccountContext_obsolete(multiDealerAccountContext);

    await setEmulationBackground(dealerAccountContext);
});

Given('user sets multiple accounts context as {string}', async function (multiDealerAccountContext: string) {
    await setMultiAccountContext_obsolete(multiDealerAccountContext);
});

Given('user sets single account context with grower order prerequisite data for product modification with option {string}', async function (scenarioName: string) {
    await getDataForGrowerOrderProductModification(scenarioName);
});

async function getDataForGrowerOrderProductModification(scenarioName: string){
    let actionType = "Treatment"; //by default we will use Treatement as the ActionType in the stored proc
    //NOTE: stored proc is designed to provide data for grower-order-product-modification but the same can be used for other 
    //scenarios in this feature
    if (scenarioName == "Package Size" || scenarioName == "Seed Size") {
        actionType = scenarioName;
    }

    fixture.logger.info(`product modification option is - ${actionType}`);
    
    fixture.logger.info("getting data for the scenario using stored procedure");
    let result = true;
    let spResult: GrowerOrderModifyProdSpResult = null;
    try {
        let evolveDbManager = new EvolveDbManager();
        const dbResult = await evolveDbManager.getDataForGrowerOrderProductModification(actionType);
        expect(dbResult.operationResult).toBeTruthy();
        expect(dbResult.operationData).toBeDefined();
        expect(dbResult.operationData).not.toBeNull();
        spResult = dbResult.operationData;

        const accNumber = spResult.AccountNumber.toString();
        await setAccounts(AccountFilterOption.ACCOUNT_NUMBER, accNumber, accNumber, true);
        fixture.dataBag.saveData(DataBagKeys.SOURCE_DEALER_ACCOUNT_NUMBER, spResult.AccountNumber);
        fixture.dataBag.saveData(DataBagKeys.SOURCE_GROWER_GMK, spResult.GMK);
        fixture.dataBag.saveData(DataBagKeys.SOURCE_GROWER_NAME, spResult.GrowerName);
        fixture.dataBag.saveData(DataBagKeys.SOURCE_GROWER_ORDER_NUMBER, spResult.GrowerOrderNumber);
        fixture.dataBag.saveData(DataBagKeys.SOURCE_PRODUCT_ITEM_NUMBER_TO_USE, spResult.FromItemNumber);
        fixture.dataBag.saveData(DataBagKeys.TARGET_PRODUCT_ITEM_NUMBER_TO_USE, spResult.ToItemNumber);
        fixture.dataBag.saveData(DataBagKeys.PRODUCT_CONVERSION_OR_MIN_TRANSFERRABLE_QTY_OR_ORDER_QTY, spResult.ToConv);
        if(scenarioName == "Package Size" || scenarioName == "Seed Size" || scenarioName == "Treatment")
            fixture.dataBag.saveData(DataBagKeys.MODIFICATION_OPTION, scenarioName);
    } catch (error) {
        if (error instanceof SkipScenarioError) {
            fixture.logger.info("Skipping scenario due to No Data from store procedure.");
            this.skip(); // tell Cucumber to skip the scenario
            }
            else {
            fixture.logger.error("Setting account context for grower order modification failed. Error: " + error);
            result = false;
            }
    }
   expect(result).toBeTruthy();
};

Given('user sets single account context for update grower operation with operation type {string}', async function (operationType: string) {
    fixture.dataBag.saveData(DataBagKeys.ORDER_UPDATE_TYPE, operationType);
    if(operationType == "DeleteProduct")
        operationType = "AddProduct"; //SP does not support "DeleteProduct" so we call it for "AddProduct" so that we can add that product to the order and delete it
    await getDataForGrowerOrderCreateOrUpdate("update-order", operationType);
});

async function getDataForGrowerOrderCreateOrUpdate(operationName: string, updateOperationType: string = "") {
    let operationDetails = `grower operation is - ${operationName}`;
    if(updateOperationType.length > 0)
        operationDetails += ` - with operation type - ${updateOperationType}`;

    fixture.logger.info(operationDetails);
    fixture.logger.info("getting data for the scenario using stored procedure");
    let result = true;
    let spResult: GrowerOrderCreateOrUpdateSpResult = null;
    try {
        let evolveDbManager = new EvolveDbManager();
        let dbResult: DbOperationResult;
        if (operationName == "create-new-order") {
            dbResult = await evolveDbManager.getDataForNewGrowerOrder();
        } else if (operationName == "update-order") {
            dbResult = await evolveDbManager.getDataForGrowerOrderUpdation(updateOperationType);            
        }else {
            fixture.logger.error(`invalid grower operation name - ${operationName}`);
            expect(false).toBeTruthy();
        }
        
        expect(dbResult.operationResult).toBeTruthy();
        expect(dbResult.operationData).toBeDefined();
        expect(dbResult.operationData).not.toBeNull();
        spResult = dbResult.operationData;

        /* sample data to bypass SP execution
        spResult = new GrowerOrderCreateOrUpdateSpResult();
        spResult.AccountName = "HARVEY FERTILIZER-KINSTON";
        spResult.AccountNumber = 9883791;
        spResult.GMK = 35228;
        spResult.GrowerOrderNumber = "20241004082835";
        spResult.ItemNumber = "1735827";
        spResult.MinQty = 1;*/

        const accNumber = spResult.AccountNumber.toString();
        await setAccounts(AccountFilterOption.ACCOUNT_NUMBER, accNumber, accNumber, true);
        fixture.dataBag.saveData(DataBagKeys.SOURCE_DEALER_ACCOUNT_NUMBER, spResult.AccountNumber);
        fixture.dataBag.saveData(DataBagKeys.SOURCE_DEALER_NAME, spResult.AccountName);
        fixture.dataBag.saveData(DataBagKeys.SOURCE_GROWER_GMK, spResult.GMK);
        fixture.dataBag.saveData(DataBagKeys.SOURCE_GROWER_ORDER_NUMBER, spResult.GrowerOrderNumber);
        fixture.dataBag.saveData(DataBagKeys.SOURCE_PRODUCT_ITEM_NUMBER_TO_USE, spResult.ItemNumber);
        fixture.dataBag.saveData(DataBagKeys.PRODUCT_CONVERSION_OR_MIN_TRANSFERRABLE_QTY_OR_ORDER_QTY, spResult.MinQty);
        
    } catch (error) {
        fixture.logger.error(`Setting account context for grower order operation - ${operationName}- failed. Error: ` + error);
        result = false;
    }
    expect(result).toBeTruthy();
}

async function setMultiAccountContext_obsolete(multiDealerAccountContext: string): Promise<MultiDealerAccountContext>{
    fixture.logger.info("Setting multiple account context on Account page has started");
    fixture.dataBag.saveData(DataBagKeys.ACCOUNT_CONTEXT_IS_SINGLE, false);
    let result = true;
    let accountsContextData: MultiDealerAccountContext = null;
    try {
        accountsContextData = StepDataHelper.getSingleTestDataRecordForType(TestDataType.MultiDealerAccountContext, multiDealerAccountContext) as MultiDealerAccountContext;
        //console.log("verifyAccountsData is...." + verifyAccountsData);

        const headerNavigationPage = await StepPageHelper.getHeaderNavigationPage();

        await clearEmulationAccountIfExists(headerNavigationPage);

        await headerNavigationPage.navigateToAccountPage();

        const accountPage = await StepPageHelper.getAccountPage();

        const accountNumbersToSelect: string[] = [];

        //step 0: clear existing accounts
        await accountPage.clearExistingAccounts();
        
        //step 1: selecting account filter

        await accountPage.clickAccountFilter();
        
        const isSupportedAccountFilter = EnumValidator.validateEnumStringValue(AccountFilterOption, accountsContextData.filterCategory);
        if(!isSupportedAccountFilter)
            throw new Error(`unsupported filterBy value - ${accountsContextData.filterCategory} - specified for accounts`);
        
        const accountFilter = accountsContextData.filterCategory as unknown as AccountFilterOption;
        await accountPage.setAccountFilter(accountFilter);
                
        fixture.logger.info("following filter category has been selected on Account page: " + accountsContextData.filterCategory);

        //step 2: entering search data
        await accountPage.filterAccount(accountsContextData.searchKey);
        fixture.logger.info("following search key has been entered on Account page: " + accountsContextData.searchKey);

        //step 3: selecting account(s)
        if (accountsContextData.selectAll) {
            await accountPage.selectFilteredAccounts(accountNumbersToSelect, true);
            fixture.logger.info("all accounts have been selected on Account page");
        } else {
            for (let j = 0; j < accountsContextData.accountNumbersToSelect.length; j++) {
                if (!accountNumbersToSelect.includes(accountsContextData.accountNumbersToSelect[j])) {
                    accountNumbersToSelect.push(accountsContextData.accountNumbersToSelect[j]);
                }
            }
            await accountPage.selectFilteredAccounts(accountNumbersToSelect);
            fixture.logger.info(`following accounts have been selected on Account page: ${accountNumbersToSelect.toString()}`);
        }
        //step 4: click on Add-Account button (TODO: need to consider Select-Account button feature as well)
        await accountPage.clickAddAccountButton();
        fixture.logger.info("Add-Account button has been clicked on Account page");

        await accountPage.confirmAccountUpdate();
        fixture.logger.info("User has confirmed account(s) addition on Account page");
    } catch (error) {
        fixture.logger.error("Setting multiple user account context on Account page failed. Error: " + error);
        result = false;
    }
    expect(result).toBeTruthy();
    fixture.logger.info("Setting multiple account context on Account page has completed");
    return accountsContextData;
}
Given('user sets single account context with order account as {string}', async function (accountContextInfo: string) {
    fixture.logger.info("Setting account context with order account data on Account page has started");
    fixture.dataBag.saveData(DataBagKeys.ACCOUNT_CONTEXT_IS_SINGLE, true);
    let result = true;
    try {
        const orderAccountDetails = StepDataHelper.getSingleTestDataRecordForType(TestDataType.AccountDetailsForOrderModification, accountContextInfo) as AccountDetailsForOrderModification;
        await setAccounts(AccountFilterOption.ACCOUNT_NAME, orderAccountDetails.name, orderAccountDetails.number, true);
    } catch (error) {
        fixture.logger.error("Setting user account context with order account data on Account page failed. Error: " + error);
        result = false;
    }
    expect(result).toBeTruthy();
    fixture.logger.info("Setting account context with order account data on Account page has completed");
});

Given('user sets single account context for product transfer when {string}', async function (targetGrowerContext: string) {
    await setAccountContextWithAccountNumbers(targetGrowerContext, true);
});

Given('user sets single account context for outside territory product transfer when {string}', async function (targetGrowerContext: string) {
    await setAccountContextWithAccountNumbers(targetGrowerContext, true, false);
});

Given('user sets multiple account context for product transfer when {string}', async function (targetGrowerContext: string) {
    await setAccountContextWithAccountNumbers(targetGrowerContext, false);
});

Given('user sets multiple account context for stock transfer', async function () {
    await setAccountContextWithAccountNumbersData("stock-transfer", false);
});

async function setAccountContextWithAccountNumbers(targetContext: string, isSingleAccount: boolean
    , areDealersInTheSameParentNetwork:  boolean = true //this means inside territory; this is applicable only for dealer transfer
){
    fixture.logger.info("Setting account context with order account data on Account page has started");
    fixture.dataBag.saveData(DataBagKeys.ACCOUNT_CONTEXT_IS_SINGLE, isSingleAccount);
    let result = true;
    
    let needTargetOrder: boolean;
    let errorMsg = "";
    try {
        if(targetContext == "target-grower-has-no-order" || targetContext == "target-dealer-has-no-order"){
            needTargetOrder = false;
        }else if(targetContext == "target-grower-has-an-order" || targetContext == "target-dealer-has-an-order"){
            needTargetOrder = true;
        }else{
            errorMsg = `invalid scenario type - ${targetContext}`;
            fixture.logger.error(errorMsg);
            expect(false, errorMsg).toBeTruthy();
        }
        
        let orderAccountDetails: AccountDetailsForOrderModification;
        
        if(targetContext == "target-grower-has-no-order" || targetContext == "target-grower-has-an-order"){
            orderAccountDetails = await getOrderAccountDetailsForGrowerProductTransfer(isSingleAccount, needTargetOrder);
        }else{
            orderAccountDetails = await getOrderAccountDetailsForDealerProductTransfer(areDealersInTheSameParentNetwork, needTargetOrder);
        }

        let searchKey = orderAccountDetails.number;
        let accountNumberToSelect = orderAccountDetails.number;
        if(!isSingleAccount)
        {
            const trgtAccountNumber = fixture.dataBag.getData(DataBagKeys.TARGET_DEALER_ACCOUNT_NUMBER) as number;
            searchKey += ", " + trgtAccountNumber.toString();
            accountNumberToSelect += VerifyAccounts.accountNumbersToSelectDelimiter + trgtAccountNumber.toString();
        }
        await setAccounts(AccountFilterOption.ACCOUNT_NUMBER, searchKey, accountNumberToSelect, isSingleAccount);
        
    } catch (error) {
        fixture.logger.error("Setting user account context with order account data on Account page failed. Error: " + error);
        result = false;
    }
    expect(result).toBeTruthy();
    fixture.logger.info("Setting account context with order account data on Account page has completed");
}

async function setAccountContextWithAccountNumbersData(scenario: string, isSingleAccount: boolean){
    fixture.logger.info("Setting account context with order account data on Account page has started");
    fixture.dataBag.saveData(DataBagKeys.ACCOUNT_CONTEXT_IS_SINGLE, isSingleAccount);
    let result = true;
    
    try {
        let orderAccountDetails: AccountDetailsForOrderModification;
        
        if(scenario == "stock-transfer"){
            orderAccountDetails = await getOrderAccountDetailsForDealerStockTransfer();
        }

        let searchKey = orderAccountDetails.number;
        let accountNumberToSelect = orderAccountDetails.number;
        if(!isSingleAccount)
        {
            const trgtAccountNumber = fixture.dataBag.getData(DataBagKeys.TARGET_DEALER_ACCOUNT_NUMBER) as number;
            searchKey += ", " + trgtAccountNumber.toString();
            accountNumberToSelect += VerifyAccounts.accountNumbersToSelectDelimiter + trgtAccountNumber.toString();
        }
        await setAccounts(AccountFilterOption.ACCOUNT_NUMBER, searchKey, accountNumberToSelect, isSingleAccount);
        
    } catch (error) {
        fixture.logger.error("Setting user account context with order account data on Account page failed. Error: " + error);
        result = false;
    }
    expect(result).toBeTruthy();
    fixture.logger.info("Setting account context with order account data on Account page has completed");
}

async function getOrderAccountDetailsForGrowerProductTransfer(isWithinDealerNetwork: boolean, needTargetGrowerOrder: boolean): Promise<AccountDetailsForOrderModification>{
    fixture.logger.info("getting data for the scenario using stored procedure");
    let spResult: GrowerOrderTransferProdSpResult = null;
    let evolveDbManager = new EvolveDbManager();
    const dbResult = await evolveDbManager.getDataForGrowerOrderProductTransfer(isWithinDealerNetwork, needTargetGrowerOrder);
    expect(dbResult.operationResult).toBeTruthy();
    expect(dbResult.operationData).toBeDefined();
    expect(dbResult.operationData).not.toBeNull();
    spResult = dbResult.operationData;
    /*
    //TEMP
    let dbResult = new DbOperationResult();
    dbResult.operationResult = true;
    spResult = new GrowerOrderTransferProdSpResult();
    spResult.SrcAccountNumber = 9946436;
    spResult.FromItemId = 1733450;
    spResult.FromItemNumber = "1733450";
    spResult.SrcGrowerOrderNumber = "20241002082435";
    spResult.SrcGrowerName = "Shane Smith Farm";
    spResult.SrcGMK = 570805;
    spResult.TrgtAccountNumber = 9946436;
    spResult.TrgtGMK = 16202;
    spResult.TrgtGrowerName = "Nash Dairy";
    spResult.TrgtGrowerOrderNumber = "20241119086920";
    spResult.MinTransferrableQty = 40;
    
    dbResult.operationData = spResult;
    //temp
    */
        
    fixture.dataBag.saveData(DataBagKeys.SOURCE_DEALER_ACCOUNT_NUMBER, spResult.SrcAccountNumber);
    fixture.dataBag.saveData(DataBagKeys.SOURCE_GROWER_GMK, spResult.SrcGMK);
    fixture.dataBag.saveData(DataBagKeys.SOURCE_GROWER_NAME, spResult.SrcGrowerName);
    fixture.dataBag.saveData(DataBagKeys.SOURCE_GROWER_ORDER_NUMBER, spResult.SrcGrowerOrderNumber);
    fixture.dataBag.saveData(DataBagKeys.TARGET_GROWER_GMK, spResult.TrgtGMK);
    fixture.dataBag.saveData(DataBagKeys.TARGET_GROWER_NAME, spResult.TrgtGrowerName);
    fixture.dataBag.saveData(DataBagKeys.SOURCE_PRODUCT_ITEM_NUMBER_TO_USE, spResult.FromItemNumber);
    fixture.dataBag.saveData(DataBagKeys.PRODUCT_CONVERSION_OR_MIN_TRANSFERRABLE_QTY_OR_ORDER_QTY, spResult.MinTransferrableQty);
    if(spResult.TrgtAccountNumber != undefined && spResult.TrgtAccountNumber != null){
        fixture.dataBag.saveData(DataBagKeys.TARGET_DEALER_ACCOUNT_NUMBER, spResult.TrgtAccountNumber);
    }
    if(spResult.TrgtGrowerOrderNumber != undefined && spResult.TrgtGrowerOrderNumber != null && spResult.TrgtGrowerOrderNumber.length > 0 ){
        fixture.dataBag.saveData(DataBagKeys.TARGET_GROWER_ORDER_NUMBER, spResult.TrgtGrowerOrderNumber);
    }
    let orderAccountDetails = new AccountDetailsForOrderModification();
    orderAccountDetails.number = spResult.SrcAccountNumber.toString();
    orderAccountDetails.relatedGrower = new GrowerDetails();
    orderAccountDetails.relatedGrower.growerGMK = spResult.SrcGMK.toString();

    return orderAccountDetails;
}

async function getOrderAccountDetailsForDealerProductTransfer(isWithinParentNetwork: boolean, needTargetDealerOrder: boolean): Promise<AccountDetailsForOrderModification>{
    fixture.logger.info("getting data for the scenario using stored procedure");
    let spResult: DealerOrderTransferProdSpResult = null;
    let evolveDbManager = new EvolveDbManager();
    const dbResult = await evolveDbManager.getDataForDealerOrderProductTransfer(isWithinParentNetwork, needTargetDealerOrder);
    expect(dbResult.operationResult).toBeTruthy();
    expect(dbResult.operationData).toBeDefined();
    expect(dbResult.operationData).not.toBeNull();
    spResult = dbResult.operationData;
    
    fixture.dataBag.saveData(DataBagKeys.SOURCE_DEALER_ACCOUNT_NUMBER, spResult.SrcAccountNumber);
    fixture.dataBag.saveData(DataBagKeys.SOURCE_DEALER_NAME, spResult.SrcAccountName);
    fixture.dataBag.saveData(DataBagKeys.SOURCE_DEALER_ORDER_NUMBER, spResult.SrcAccountOrderNumber);
    fixture.dataBag.saveData(DataBagKeys.TARGET_DEALER_NAME, spResult.TrgtAccountName);
    fixture.dataBag.saveData(DataBagKeys.SOURCE_PRODUCT_ITEM_NUMBER_TO_USE, spResult.FromItemNumber);
    fixture.dataBag.saveData(DataBagKeys.PRODUCT_CONVERSION_OR_MIN_TRANSFERRABLE_QTY_OR_ORDER_QTY, spResult.MinTransferrableQty);
    
    if(spResult.TrgtAccountNumber != undefined && spResult.TrgtAccountNumber != null){
        fixture.dataBag.saveData(DataBagKeys.TARGET_DEALER_ACCOUNT_NUMBER, spResult.TrgtAccountNumber);
    }
    if(spResult.TrgtAccountOrderNumber != undefined && spResult.TrgtAccountOrderNumber != null && spResult.TrgtAccountOrderNumber.length > 0 ){
        fixture.dataBag.saveData(DataBagKeys.TARGET_DEALER_ORDER_NUMBER, spResult.TrgtAccountOrderNumber);
    }
    let orderAccountDetails = new AccountDetailsForOrderModification();
    orderAccountDetails.number = spResult.SrcAccountNumber.toString();
    orderAccountDetails.orderIdToUpdate = spResult.SrcAccountOrderNumber;

    return orderAccountDetails;
}

async function getOrderAccountDetailsForDealerStockTransfer(): Promise<AccountDetailsForOrderModification>{
    fixture.logger.info("getting data for the scenario using stored procedure");
    let spResult: DealerStockTransferSpResult = null;
    let evolveDbManager = new EvolveDbManager();
    const dbResult = await evolveDbManager.getDataForDealerStockTransfer();
    expect(dbResult.operationResult).toBeTruthy();
    expect(dbResult.operationData).toBeDefined();
    expect(dbResult.operationData).not.toBeNull();
    spResult = dbResult.operationData;
    
    fixture.dataBag.saveData(DataBagKeys.SOURCE_DEALER_ACCOUNT_NUMBER, spResult.SrcAccountNumber);
    fixture.dataBag.saveData(DataBagKeys.SOURCE_DEALER_NAME, spResult.SrcAccountName);
    fixture.dataBag.saveData(DataBagKeys.TARGET_DEALER_NAME, spResult.TrgtAccountName);
    fixture.dataBag.saveData(DataBagKeys.TARGET_DEALER_ACCOUNT_NUMBER, spResult.TrgtAccountNumber);
    fixture.dataBag.saveData(DataBagKeys.SOURCE_PRODUCT_ITEM_NUMBER_TO_USE, spResult.ItemNumber);
    fixture.dataBag.saveData(DataBagKeys.PRODUCT_CONVERSION_OR_MIN_TRANSFERRABLE_QTY_OR_ORDER_QTY, spResult.MinTransferrableQty);
    fixture.dataBag.saveData(DataBagKeys.LOT_NUMBER, spResult.LotNumber);
    
    let orderAccountDetails = new AccountDetailsForOrderModification();
    orderAccountDetails.number = spResult.SrcAccountNumber.toString();
    return orderAccountDetails;
}

export async function setAccounts(filterCategory: string, searchKey: string, accountNumberToSelect: string, isSingleAccount: boolean){
    fixture.dataBag.saveData(DataBagKeys.ACCOUNT_CONTEXT_IS_SINGLE, isSingleAccount);
    const verifyAccountsData = new VerifyAccounts();

    const accountsSelectionToVerify: AccountsSelectionToVerify[] = [];
    const accountToVerify = new AccountsSelectionToVerify();
    accountToVerify.filterCategory = filterCategory;
    accountToVerify.searchKey = searchKey;
    accountToVerify.accountNumbersToSelect = accountNumberToSelect;

    accountsSelectionToVerify.push(accountToVerify);
    verifyAccountsData.selections = accountsSelectionToVerify;

    await selectAccounts(verifyAccountsData);
}

Given('grower order does not exist for {string}', async function (accountContextInfo: string) {
    const verifyAccountsData = StepDataHelper.getSingleTestDataRecordForType(TestDataType.VerifyAccounts, accountContextInfo) as VerifyAccounts;
    const singleAccountContext = fixture.dataBag.getData(DataBagKeys.ACCOUNT_CONTEXT_IS_SINGLE) as boolean;
    if (!singleAccountContext) {
        //get the right grower and related dealer from the API based on the account context
        const dealerGrowerInfo = await StepDataHelper.getGrowersWithExistingOrder();
        verifyAccountsData.selections[0].accountNumbersToSelect = dealerGrowerInfo[0].shipToAccount.toString();
        verifyAccountsData.expectedAccounts[0].number = dealerGrowerInfo[0].shipToAccount.toString();
        verifyAccountsData.expectedAccounts[0].name = dealerGrowerInfo[0].dealerName;
        verifyAccountsData.expectedAccounts[0].relatedGrowers = [];
        const grower = new GrowerDetails();
        grower.name = dealerGrowerInfo[0].growerName;
        grower.growerGMK = dealerGrowerInfo[0].gmk.toString();
        grower.growerGLN = dealerGrowerInfo[0].gln;
        verifyAccountsData.expectedAccounts[0].relatedGrowers.push(grower);
    }

    let dealerAccountNumber = verifyAccountsData.selections[0].accountNumbersToSelect.split("#")[0];
    await DataRequirementsSteps.ensureGrowerDoesNotHaveAnOrder(dealerAccountNumber, verifyAccountsData.expectedAccounts[0].relatedGrowers[0].growerGMK);
    fixture.dataBag.saveData(DataBagKeys.DEALER_GROWER_INFO_TO_USE, verifyAccountsData);
});

Given('user sets single dealer account context as {string}', async function (accountContextInfo: string) {
    fixture.logger.info("Setting single dealer account context on Account page has started");
    let result = true;
    try {
        const accountsData = StepDataHelper.getSingleTestDataRecordForType(TestDataType.SingleDealerAccountContext, accountContextInfo) as SingleDealerAccountContext;
        let singleDealerAccountContext = new SingleDealerAccountContext();
        singleDealerAccountContext.copy(accountsData);
        await selectAccountsForContext(singleDealerAccountContext);
        
    } catch (error) {
        fixture.logger.error("Setting single dealer account context on Account page failed. Error: " + error);
        result = false;
    }
    expect(result).toBeTruthy();
    fixture.logger.info("Setting single dealer account context on Account page has completed");
});

Given('user sets single account context with dealer order prerequisite data for product modification with option {string}', async function (scenarioName: string) {
    let actionType = "Treatment"; //by default we will use Treatement as the ActionType in the stored proc
    
    if (scenarioName == "Package Size" || scenarioName == "Seed Size") {
        actionType = scenarioName;
    }

    fixture.logger.info(`product modification option is - ${actionType}`);
    fixture.logger.info("getting data for the scenario using stored procedure");
    let result = true;
    let spResult: DealerOrderModifyProdSpResult = null;
    try {
        let evolveDbManager = new EvolveDbManager();
        const dbResult = await evolveDbManager.getDataForDealerOrderProductModification(actionType);
        expect(dbResult.operationResult).toBeTruthy();
        expect(dbResult.operationData).toBeDefined();
        expect(dbResult.operationData).not.toBeNull();
        spResult = dbResult.operationData;

        const accNumber = spResult.AccountNumber.toString();
        await setAccounts(AccountFilterOption.ACCOUNT_NUMBER, accNumber, accNumber, true);
        fixture.dataBag.saveData(DataBagKeys.SOURCE_DEALER_ACCOUNT_NUMBER, spResult.AccountNumber);
        fixture.dataBag.saveData(DataBagKeys.SOURCE_DEALER_NAME, spResult.DealerName);
        fixture.dataBag.saveData(DataBagKeys.SOURCE_DEALER_ORDER_NUMBER, spResult.DealerOrderNumber);
        fixture.dataBag.saveData(DataBagKeys.SOURCE_PRODUCT_ITEM_NUMBER_TO_USE, spResult.FromItemNumber);
        fixture.dataBag.saveData(DataBagKeys.TARGET_PRODUCT_ITEM_NUMBER_TO_USE, spResult.ToItemNumber);
        fixture.dataBag.saveData(DataBagKeys.PRODUCT_CONVERSION_OR_MIN_TRANSFERRABLE_QTY_OR_ORDER_QTY, spResult.ToConv);
        if(scenarioName == "Package Size" || scenarioName == "Seed Size" || scenarioName == "Treatment")
            fixture.dataBag.saveData(DataBagKeys.MODIFICATION_OPTION, scenarioName);
    } catch (error) {
        fixture.logger.error("Setting account context for dealer order modification failed. Error: " + error);
        result = false;
    }
    expect(result).toBeTruthy();
});

Given('user sets single account context for create dealer operation', async function () {
    await getDataForDealerOrderCreateOrUpdate("create-new-order");
});

Given('user sets single account context for create grower operation', async function () {
    await getDataForGrowerOrderCreateOrUpdate("create-new-order");
});

Given('user sets single account context for update dealer operation with operation type {string}', async function (operationType: string) {
    await setSingleAccountContextForDealerOperation(operationType, false);
});

Given('user sets single account context for update dealer operation with EA operation type {string}', async function (operationType: string) {
    await setSingleAccountContextForDealerOperation(operationType, true);
});

Given('user sets single account context for seed fulfillment operation', async function () {
    //call API to get the sedd fulfillment info
    const seedFulfillmentData: SeedFulfillmentInfo = await StepDataHelper.getSeedFulfillmentData();
    // const seedFulfillmentResponse: SeedFulfillmentResponse = await StepDataHelper.getSeedFulfillmentData();
    // const seedFulfillmentData: SeedFulfillmentInfo = seedFulfillmentResponse.getProductByType('Non-Bulk'); 
    const accNumber = seedFulfillmentData.AccountNumber.toString();
    await setAccounts(AccountFilterOption.ACCOUNT_NUMBER, accNumber, accNumber, true);
    fixture.dataBag.saveData(DataBagKeys.SOURCE_DEALER_ACCOUNT_NUMBER, seedFulfillmentData.AccountNumber);
    fixture.dataBag.saveData(DataBagKeys.SOURCE_DEALER_NAME, seedFulfillmentData.AccountName);
    fixture.dataBag.saveData(DataBagKeys.SOURCE_DEALER_ORDER_NUMBER, seedFulfillmentData.DealerOrderNumber);
    fixture.dataBag.saveData(DataBagKeys.SOURCE_PRODUCT_ITEM_NUMBER_TO_USE, seedFulfillmentData.ItemNumber);
    fixture.logger.info(`saving AvailableToShip - ${seedFulfillmentData.AvailableToShip}`);
    fixture.dataBag.saveData(DataBagKeys.PRODUCT_CONVERSION_OR_MIN_TRANSFERRABLE_QTY_OR_ORDER_QTY, seedFulfillmentData.AvailableToShip);
    fixture.dataBag.saveData(DataBagKeys.BRANCH_PLANT, seedFulfillmentData.BranchPlantId);
    fixture.logger.info(`saving seed weight - ${seedFulfillmentData.SeedWeightPerReleaseUnit}`);
    fixture.dataBag.saveData(DataBagKeys.SEED_WEIGHT, seedFulfillmentData.SeedWeightPerReleaseUnit);
    // fixture.logger.info(`saving seed weight - ${seedFulfillmentData.SeedWeight}`);
    // fixture.dataBag.saveData(DataBagKeys.SEED_WEIGHT, seedFulfillmentData.SeedWeight);
    fixture.dataBag.saveData(DataBagKeys.PALLET_TYPE, seedFulfillmentData.PalletType);
    fixture.dataBag.saveData(DataBagKeys.PALLET_WEIGHT, seedFulfillmentData.PalletWeight);
    fixture.dataBag.saveData(DataBagKeys.PALLET_QTY, seedFulfillmentData.PalletQuantity);
});

Given('user selects single account that does not have any existing reservation and navigates to the seed reservations page', async function () {
    await getDataForSeedReservations(false);
    await navigateToSeedReservationsPage();
});

Given('user selects single account that has an existing reservation with multiple line items and navigates to the seed reservations page', async function () {
    await getDataForSeedReservations(true);
    await navigateToSeedReservationsPage();
});

Given('user selects single account that has an existing reservation with one line item and navigates to the seed reservations page', async function () {
    await getDataForSeedReservations(true, true);
    await navigateToSeedReservationsPage();
});

async function getDataForSeedReservations(userShouldHaveReservation: boolean = false, shouldContainOnlyOneLineItem: boolean = false) {
    fixture.logger.info('getting data for seed reservations');
    let result = true;
        
    try {
        let evolveDbManager = new EvolveDbManager();
        let dbResultReservationData: DbOperationResult;
        if (userShouldHaveReservation === true) {
            dbResultReservationData = await evolveDbManager.getExistingSeedReservationData(shouldContainOnlyOneLineItem);
        } else {
            dbResultReservationData = await evolveDbManager.getDataForNewSeedReservation();
        }
        
        expect(dbResultReservationData.operationResult).toBeTruthy();
        expect(dbResultReservationData.operationData).toBeDefined();
        expect(dbResultReservationData.operationData).not.toBeNull();
        if(shouldContainOnlyOneLineItem === true){
            const dataQueryResultForOneLineItem: SingleSeedReservationDataQueryResult = dbResultReservationData.operationData;
            fixture.dataBag.saveData(DataBagKeys.SHIP_TO_DEALER_NUMBER, dataQueryResultForOneLineItem.ShipToAccountNumber);
            fixture.dataBag.saveData(DataBagKeys.GROWER_GMK, dataQueryResultForOneLineItem.GrowerGMK);
            fixture.dataBag.saveData(DataBagKeys.SEED_RESERVATION_ID, dataQueryResultForOneLineItem.ReservationId);
            fixture.dataBag.saveData(DataBagKeys.PRODUCT_LINE_AND_MARKETING_BRAND_INFO, dataQueryResultForOneLineItem.ProductLineAndMarketingBrandInfo);
            fixture.dataBag.saveData(DataBagKeys.GROWER_GMK, dataQueryResultForOneLineItem.GrowerGMK);
            fixture.dataBag.saveData(DataBagKeys.MISSING_PRODUCT_LINE_AND_MARKETING_BRAND_INFO, dataQueryResultForOneLineItem.MissingProductLineAndMarketingBrandInfo);//of ProductLineAndMarketingBrand type
            const accNumber = dataQueryResultForOneLineItem.ShipToAccountNumber.toString();
            await setAccounts(AccountFilterOption.ACCOUNT_NUMBER, accNumber, accNumber, true);
        }else{
            const dataQueryResult: SeedReservationDataQueryResult = dbResultReservationData.operationData;
            fixture.dataBag.saveData(DataBagKeys.SHIP_TO_DEALER_NUMBER, dataQueryResult.ShipToAccountNumber);
            fixture.dataBag.saveData(DataBagKeys.SELLER_NUMBER, dataQueryResult.SellerAccountNumber);
            fixture.dataBag.saveData(DataBagKeys.GROWER_GMK, dataQueryResult.GrowerGMK);
            fixture.dataBag.saveData(DataBagKeys.SEED_RESERVATION_ID, dataQueryResult.ReservationId); //this may be null for new reservation case
            fixture.dataBag.saveData(DataBagKeys.PRODUCT_LINE_AND_MARKETING_BRAND_INFO, dataQueryResult.ProductLineAndMarketingBrandInfo);

            fixture.dataBag.saveData(DataBagKeys.GROWER_GMK, dataQueryResult.GrowerGMK);

            let dbResultProductLineAndBrandConfigData: DbOperationResult = await evolveDbManager.getProductLineAndMarketingBrandDataForSeedReservation();
            expect(dbResultProductLineAndBrandConfigData.operationResult).toBeTruthy();
            expect(dbResultProductLineAndBrandConfigData.operationData).toBeDefined();
            expect(dbResultProductLineAndBrandConfigData.operationData).not.toBeNull();
            
            fixture.dataBag.saveData(DataBagKeys.PRODUCT_LINE_AND_MARKETING_BRAND_INFO_CONFIG, dbResultProductLineAndBrandConfigData.operationData); //of ProductLineAndMarketingBrand[] array type
            const accNumber = dataQueryResult.ShipToAccountNumber.toString();
            await setAccounts(AccountFilterOption.ACCOUNT_NUMBER, accNumber, accNumber, true);
        }
    } catch (error) {
        fixture.logger.error(`Setting account context for seed reservation - failed. Error: ` + error);
        result = false;
    }
    expect(result).toBeTruthy();
}

async function navigateToSeedReservationsPage(){
    fixture.logger.info('navigating to seed reservations list page');
    let result = true;
    try {
        const headerNavigationPage = await StepPageHelper.getHeaderNavigationPage();
        await headerNavigationPage.navigateToSeedReservationPage();

    } catch (error) {
        result = false;
        fixture.logger.error("failed to navigate to seed reservations list page. Error: " + error);
    }
    expect(result).toBeTruthy();
    fixture.logger.info('navigated to seed reservations list page');
}

async function setSingleAccountContextForDealerOperation(operationType: string, isOperationForEA: boolean) {
    fixture.dataBag.saveData(DataBagKeys.ORDER_UPDATE_TYPE, operationType);
    if(operationType == "DeleteProduct")
        operationType = "AddProduct"; //SP does not support "DeleteProduct" so we call it for "AddProduct" so that we can add that product to the order and delete it
    await getDataForDealerOrderCreateOrUpdate("update-order", operationType, isOperationForEA);
}
async function getDataForDealerOrderCreateOrUpdate(operationName: string, updateOperationType: string = "", isOperationForEA: boolean = false) {
    let operationDetails = isOperationForEA ? `dealer EA operation is - ${operationName}` : `dealer operation is - ${operationName}`;
    if(updateOperationType.length > 0)
        operationDetails += ` - with operation type - ${updateOperationType}`;

    fixture.logger.info(operationDetails);
    fixture.logger.info("getting data for the scenario using stored procedure");
    let result = true;
    let spResult: DealerOrderCreateOrUpdateSpResult = null;
    try {
        let evolveDbManager = new EvolveDbManager();
        let dbResult: DbOperationResult;
        if (operationName == "create-new-order") {
            dbResult = await evolveDbManager.getDataForNewDealerOrder();
            /*
            //temp
            dbResult = new DbOperationResult();
            dbResult.operationResult = true;
            let res = new DealerOrderCreateOrUpdateSpResult();
            res.AccountName = "GPAH LLC/TALLADEGA COUNTY EXCH-WEDOWEE";
            res.AccountNumber = 9874803;
            res.ItemId = 1682918;
            res.ItemNumber = "1682918";
            res.MinQty = 1;
            dbResult.operationData = res;*/
        } else if (operationName == "update-order") {
            if(!isOperationForEA){
                dbResult = await evolveDbManager.getDataForDealerOrderUpdation(updateOperationType);
            }else{
                dbResult = await evolveDbManager.getDataForDealerOrderUpdateWithEAProduct(updateOperationType);
            }
        } else {
            fixture.logger.error(`invalid dealer operation name - ${operationName}`);
            expect(false).toBeTruthy();
        }
        
        expect(dbResult.operationResult).toBeTruthy();
        expect(dbResult.operationData).toBeDefined();
        expect(dbResult.operationData).not.toBeNull();
        spResult = dbResult.operationData;

        const accNumber = spResult.AccountNumber.toString();
        await setAccounts(AccountFilterOption.ACCOUNT_NUMBER, accNumber, accNumber, true);
        fixture.dataBag.saveData(DataBagKeys.SOURCE_DEALER_ACCOUNT_NUMBER, spResult.AccountNumber);
        fixture.dataBag.saveData(DataBagKeys.SOURCE_DEALER_NAME, spResult.AccountName);
        fixture.dataBag.saveData(DataBagKeys.SOURCE_DEALER_ORDER_NUMBER, spResult.DealerOrderNumber);
        fixture.dataBag.saveData(DataBagKeys.SOURCE_PRODUCT_ITEM_NUMBER_TO_USE, spResult.ItemNumber);
        fixture.dataBag.saveData(DataBagKeys.PRODUCT_CONVERSION_OR_MIN_TRANSFERRABLE_QTY_OR_ORDER_QTY, spResult.MinQty);
        fixture.dataBag.saveData(DataBagKeys.EA_UNITS, spResult.UpdatedEAUnits);
    } catch (error) {
        fixture.logger.error(`Setting account context for dealer order operation - ${operationName}- failed. Error: ` + error);
        result = false;
    }
    expect(result).toBeTruthy();
}

When('user sets single account context for update dealer operation to swap EA product', async function () {
    fixture.logger.info("getting data for the scenario - EA product swap - using stored procedure");
    let result = true;
    let spResult: DealerOrderSwapEAProdSpResult = null;
    try {
        let evolveDbManager = new EvolveDbManager();
        const dbResult = await evolveDbManager.getDataForDealerOrderEAProductSwap();
        expect(dbResult.operationResult).toBeTruthy();
        expect(dbResult.operationData).toBeDefined();
        expect(dbResult.operationData).not.toBeNull();
        spResult = dbResult.operationData;

        const accNumber = spResult.AccountNumber.toString();
        await setAccounts(AccountFilterOption.ACCOUNT_NUMBER, accNumber, accNumber, true);
        fixture.dataBag.saveData(DataBagKeys.SOURCE_DEALER_ACCOUNT_NUMBER, spResult.AccountNumber);
        fixture.dataBag.saveData(DataBagKeys.SOURCE_DEALER_NAME, spResult.DealerName);
        fixture.dataBag.saveData(DataBagKeys.SOURCE_DEALER_ORDER_NUMBER, spResult.DealerOrderNumber);
        fixture.dataBag.saveData(DataBagKeys.SOURCE_PRODUCT_ITEM_NUMBER_TO_USE, spResult.FromItemNumber);
        fixture.dataBag.saveData(DataBagKeys.TARGET_PRODUCT_ITEM_NUMBER_TO_USE, spResult.ToItemNumber);
        fixture.dataBag.saveData(DataBagKeys.PRODUCT_CONVERSION_OR_MIN_TRANSFERRABLE_QTY_OR_ORDER_QTY, spResult.ToConv);
        fixture.dataBag.saveData(DataBagKeys.EA_UNITS, spResult.FinalFromEAUnits);
        fixture.dataBag.saveData(DataBagKeys.TO_ITEM_EA_UNITS, spResult.FinalToEAUnits);
    } catch (error) {
        fixture.logger.error("Setting account context for dealer order EA product swapping failed. Error: " + error);
        result = false;
    }
    expect(result).toBeTruthy();
});

Given('user sets multiple dealer account context as {string}', async function (accountContextInfo: string) {
    fixture.logger.info("Setting multiple dealer account context on Account page has started");
    let result = true;
    try {
        const accountsData = StepDataHelper.getSingleTestDataRecordForType(TestDataType.SingleDealerAccountContext, accountContextInfo) as MultiDealerAccountContext;
        let multiDealerAccountContext = new MultiDealerAccountContext();
        multiDealerAccountContext.copy(accountsData);
        await selectAccountsForContext(multiDealerAccountContext);
        
    } catch (error) {
        fixture.logger.error("Setting single dealer account context on Account page failed. Error: " + error);
        result = false;
    }
    expect(result).toBeTruthy();
    fixture.logger.info("Setting multiple dealer account context on Account page has completed");
});

async function selectAccountsForContext(accountsData: SingleDealerAccountContext | MultiDealerAccountContext){
    const headerNavigationPage = await StepPageHelper.getHeaderNavigationPage();

    await clearEmulationAccountIfExists(headerNavigationPage);

    await headerNavigationPage.navigateToAccountPage();

    const accountPage = await StepPageHelper.getAccountPage();

    //step 0: clear existing accounts
    await accountPage.clearExistingAccounts();

    //step 1: selecting account filter
    await accountPage.clickAccountFilter();

    const isSupportedAccountFilter = EnumValidator.validateEnumStringValue(AccountFilterOption, accountsData.filterCategory);
    if (!isSupportedAccountFilter)
        throw new Error(`unsupported filterBy value - ${accountsData.filterCategory} - specified for accounts`);

    const accountFilter = accountsData.filterCategory as unknown as AccountFilterOption;
    await accountPage.setAccountFilter(accountFilter);
    fixture.logger.info("following filter category has been selected on Account page: " + accountFilter);

    //step 2: entering search data
    await accountPage.filterAccount(accountsData.searchKey);
    fixture.logger.info("following search key has been entered on Account page: " + accountsData.searchKey);

    let tempAccountNumbersToSelect: string[] = [];
    let selectAllAccounts: boolean = false;
    if(accountsData instanceof SingleDealerAccountContext){
        fixture.logger.info('context is single');
        const singleAccContext = accountsData as SingleDealerAccountContext;
        fixture.logger.info(`single account number is....${singleAccContext.accountNumberToSelect}`);
        tempAccountNumbersToSelect.push(singleAccContext.accountNumberToSelect);
    }else if(accountsData instanceof MultiDealerAccountContext){
        fixture.logger.info('context is multiple');
        const multiAccContext = accountsData as MultiDealerAccountContext;
        selectAllAccounts = multiAccContext.selectAll;
        if(!multiAccContext.selectAll)
            tempAccountNumbersToSelect = multiAccContext.accountNumbersToSelect;
    }else{
        throw new Error(`unsupported context data specified for accounts`);
    }
    
    //step 3: selecting account(s)
    await accountPage.selectFilteredAccounts(tempAccountNumbersToSelect, selectAllAccounts);
    if(!selectAllAccounts)
        fixture.logger.info(`following accounts have been selected on Account page: ${tempAccountNumbersToSelect.toString()}`);
    else
        fixture.logger.info(`all accounts have been selected on Account page`);

    //step 4: click on Add-Account button (TODO: need to consider Select-Account button feature as well)
    await accountPage.clickAddAccountButton();
    fixture.logger.info("Add-Account button has been clicked on Account page");

    await accountPage.confirmAccountUpdate();
    fixture.logger.info("User has confirmed account(s) addition on Account page");
}
async function selectAccounts(verifyAccountsData: VerifyAccounts){
    const headerNavigationPage = await StepPageHelper.getHeaderNavigationPage();

    await clearEmulationAccountIfExists(headerNavigationPage);

    await headerNavigationPage.navigateToAccountPage();

    const accountPage = await StepPageHelper.getAccountPage();

    const accountNumbersToSelect: string[] = [];

    //step 0: clear existing accounts
    await accountPage.clearExistingAccounts();

    for (let i = 0; i < verifyAccountsData.selections.length; i++) {
        //step 1: selecting account filter
        await accountPage.clickAccountFilter();        

        const isSupportedAccountFilter = EnumValidator.validateEnumStringValue(AccountFilterOption, verifyAccountsData.selections[i].filterCategory);
        if (!isSupportedAccountFilter)
            throw new Error(`unsupported filterBy value - ${verifyAccountsData.selections[i].filterCategory} - specified for accounts`);

        const accountFilter = verifyAccountsData.selections[i].filterCategory as unknown as AccountFilterOption;
        //let continueAccountSearch = true;
        let accountSearchRetryCount = 5;
        //while (continueAccountSearch) {
        while (accountSearchRetryCount > 0) {
            //NOTE: IT IS OBSERVED SOME TIMES THE FILTER IS NOT GETTING SELECTED PROPERLY
            //TO ENSURE THE RIGHT SELECTION, WE CHECK THE DISPLAYED CHIP TEXT THAT SHOULD CONTAIN THE SELECTED FILTER
            await accountPage.setAccountFilter(accountFilter);
            fixture.logger.info("following filter category has been selected on Account page: " + verifyAccountsData.selections[i].filterCategory);

            //step 2: entering search data
            if(accountFilter == AccountFilterOption.ACCOUNT_NUMBER){
                const accNumberValidationRes = StepDataHelper.validateAccountNumber(verifyAccountsData.selections[i].searchKey);
                expect(accNumberValidationRes).toBeTruthy();
            }
            await accountPage.filterAccount(verifyAccountsData.selections[i].searchKey);
            fixture.logger.info("following search key has been entered on Account page: " + verifyAccountsData.selections[i].searchKey);

            const chipText = await accountPage.getChipText();
            fixture.logger.info(`displayed chip text - ${chipText}`);

            if(chipText.includes(accountFilter))
                //continueAccountSearch = false;
                accountSearchRetryCount = 0;
            else{
                fixture.logger.error(`account filter was not selected properly hence retrying it again`);
                --accountSearchRetryCount;
            }
        }
        const tempAccountNumbersToSelect: string[] = verifyAccountsData.selections[i].accountNumbersToSelect.split(VerifyAccounts.accountNumbersToSelectDelimiter);

        for (let j = 0; j < tempAccountNumbersToSelect.length; j++) {
            if (!accountNumbersToSelect.includes(tempAccountNumbersToSelect[j])) {
                accountNumbersToSelect.push(tempAccountNumbersToSelect[j]);
            }
        }
    }

    //step 3: selecting account(s)
    const res = await accountPage.selectFilteredAccounts(accountNumbersToSelect, true);
    expect(res).toBeTruthy();
    fixture.logger.info(`following accounts have been selected on Account page: ${accountNumbersToSelect.toString()}`);

    //step 4: click on Add-Account button (TODO: need to consider Select-Account button feature as well)
    await accountPage.clickAddAccountButton();
    fixture.logger.info("Add-Account button has been clicked on Account page");

    await accountPage.confirmAccountUpdate();
    fixture.logger.info("User has confirmed account(s) addition on Account page");
}

async function clearEmulationAccountIfExists(headerNavigationPage: HeaderNavigationPage): Promise<EmulationPage> {
    //check if page already has emulated account; if so clear it first IF AND ONLY IF the emulation was set outside the automation

    const emulationSetByAutomation = fixture.dataBag.getData(DataBagKeys.EMULATION_SET_BY_AUTOMATION) as boolean;
    
    if(emulationSetByAutomation != undefined && emulationSetByAutomation){
        fixture.logger.info('skipping removing emulation details as it was set by automation');
        return;
    }
    
    const loginPage = await StepPageHelper.getLoginPage();
    
    const isEmulationAccountPresent = await loginPage.isEmulationAccountPresent();
    fixture.logger.info(`isEmulationAccountPresent value is ${isEmulationAccountPresent}`);
    if(isEmulationAccountPresent) {
        const existingEmulatedUserId = await loginPage.getEmulatedUserName();
        fixture.logger.info("an Emulation account is already in use : " + existingEmulatedUserId);
        await headerNavigationPage.navigateToEmulationPage();
        
        const emulationPage = await StepPageHelper.getEmulationPage();
        await emulationPage.clickClearEmulationButton();
        fixture.logger.info("existing Emulation account is cleared");

        return emulationPage;
    }
    return null;
}

Then('user must be able to use context specific accounts from {string} along with related grower details on Seed-Orders screen', async function (accountContextInfo: string) {
    const verifyAccountsData = StepDataHelper.getSingleTestDataRecordForType(TestDataType.VerifyAccounts, accountContextInfo) as VerifyAccounts;
    await checkAccountSelectionOnSeedOrdersPage(verifyAccountsData);
});

Then('user must be able to select context specific accounts from {string} along with related grower details on Create-New-Grower-Order screen', async function (accountContextInfo: string) {
    const verifyAccountsData = StepDataHelper.getSingleTestDataRecordForType(TestDataType.VerifyEmulatedAccount, accountContextInfo) as VerifyAccounts;
    await checkAccountSelectionOnCreateNewOrderPage(verifyAccountsData);
});

Given('user sets emulated accounts context as {string}', async function (accountContextInfo: string) {
    const verifyAccountsData = StepDataHelper.getSingleTestDataRecordForType(TestDataType.VerifyEmulatedAccount, accountContextInfo) as VerifyEmulatedAccount;
        
    const dealerAccountContext = new DealerAccountContext();
    dealerAccountContext.filterCategory = verifyAccountsData.selection.filterCategory;
    dealerAccountContext.searchKey = verifyAccountsData.selection.searchKey;

    const newEmulatedAccountInfo = await setEmulationBackground(dealerAccountContext);
    const growersInfo = await StepDataHelper.getGrowersWithExistingOrder(newEmulatedAccountInfo.expectedAccounts[0].number);
    fixture.dataBag.saveData(DataBagKeys.DEALER_ACCOUNT_NUMBER, newEmulatedAccountInfo.expectedAccounts[0].number);
    fixture.dataBag.saveData(DataBagKeys.GROWER_GMK, growersInfo[0].gmk);
});

async function setEmulationBackground(dealerAccountContext: DealerAccountContext): Promise<VerifyEmulatedAccount>{
    fixture.logger.info("Setting emulated account context on Emulation page has started");
    let result = true;
    let verifyAccountsData: VerifyEmulatedAccount = null;
    try {
        verifyAccountsData = await ApiManager.getEmulationDetails(dealerAccountContext);
        expect(verifyAccountsData).not.toBeNull();

        const headerNavigationPage = await StepPageHelper.getHeaderNavigationPage();
        
        fixture.dataBag.saveData(DataBagKeys.EMULATION_SET_BY_AUTOMATION, false); //we just started setting the details so to be on safer side, set this value to FALSE
        let emulationPage = await clearEmulationAccountIfExists(headerNavigationPage);

        if (emulationPage == null) {
            await headerNavigationPage.navigateToEmulationPage();
            emulationPage = await StepPageHelper.getEmulationPage();
        }
        //step 1: selecting account filter

        await emulationPage.clearExistingEmulation();//there is some problem with the UI and hence we try ocne again to clear emulation
        await emulationPage.clickAccountFilter();
        switch (verifyAccountsData.selection.filterCategory) //TODO: support more filters
        {
            case emulationPage.accountFilterOption_accountNumber:
                await emulationPage.setAccountFilterToAccountNumber();
                break;
            default:
                throw new Error(`invalid filterBy value - ${verifyAccountsData.selection.filterCategory} - specified for accounts`);
        }
        fixture.logger.info("following filter category has been selected on Emulation page: " + verifyAccountsData.selection.filterCategory);

        //step 2: entering search data
        await emulationPage.filterAccount(verifyAccountsData.selection.searchKey);
        fixture.logger.info("following search key has been entered on Emulation page: " + verifyAccountsData.selection.searchKey);

        //Step 3: select attached account
        await emulationPage.selectAttachedAccount(verifyAccountsData.selection.attachedAccountNumberToSelect);
        fixture.logger.info("following account has been selected on Emulation page: " + verifyAccountsData.selection.attachedAccountNumberToSelect);

        //Step 4: select attached user
        const attachedUserIdToSelect = verifyAccountsData.selection.attachedUserIdToSelect;
        await emulationPage.selectAttachedUser(attachedUserIdToSelect);
        fixture.logger.info("following user has been selected on Emulation page: " + attachedUserIdToSelect);
        fixture.dataBag.saveData(DataBagKeys.CURRENT_EMULATED_USER_ID, attachedUserIdToSelect);
        fixture.dataBag.saveData(DataBagKeys.EMULATION_SET_BY_AUTOMATION, true);

        //step 5: click on Set-Emulation button
        await emulationPage.clickSetEmulationButton();

        //step 6: check if profile contains the new emulated account
        const loginPage = await StepPageHelper.getLoginPage();
        const newEmulatedUserId = await loginPage.getEmulatedUserName();
        //const newEmulatedUserId = await emulationPage.getEmulatedUserNameInProfile();
        if(newEmulatedUserId.length == 0 || !newEmulatedUserId.includes(attachedUserIdToSelect))
            throw new Error("setting emulation account failed because profile does not have the newly selected emulation account details");
        fixture.logger.info("Set-Emulation button has been clicked on Emulation page");
    } catch (error) {
        fixture.logger.error("Setting emulated account context on Emulation page failed. Error: " + error);
        result = false;
    }
    expect(result).toBeTruthy();
    fixture.logger.info("Setting emulated account context on Emulation page has completed");
    return verifyAccountsData;
}
Then('user must be able to use context specific emulated accounts from {string} along with related grower details on Seed-Orders screen', async function (accountContextInfo: string) {
    //const verifyAccountsData = StepDataHelper.getSingleTestDataRecordForType(TestDataType.VerifyEmulatedAccount, accountContextInfo) as VerifyEmulatedAccount;
    const verifyAccountsData = getEmulatedAccountFromDatabag();
    await checkAccountSelectionOnSeedOrdersPage(verifyAccountsData);
});

function getEmulatedAccountFromDatabag(): VerifyEmulatedAccount{
    const dealerNumber = fixture.dataBag.getData(DataBagKeys.DEALER_ACCOUNT_NUMBER) as string;
    const growerGMK = fixture.dataBag.getData(DataBagKeys.GROWER_GMK) as number;

    const verifyAccountsData = new VerifyEmulatedAccount();
    verifyAccountsData.expectedAccounts = [];
    const accountDetails = new AccountDetails();
    accountDetails.number = dealerNumber;
    accountDetails.relatedGrowers = [];
    const grower = new GrowerDetails();
    grower.growerGMK = growerGMK.toString();
    accountDetails.relatedGrowers.push(grower);
    verifyAccountsData.expectedAccounts.push(accountDetails);
    
    return verifyAccountsData;
}
async function checkAccountSelectionOnSeedOrdersPage(verifyAccountsData: VerifyAccounts | VerifyEmulatedAccount){
    let result = true;
    fixture.logger.info("checking account selection process on Seed-Orders page has started");
    try {
        //step 1: navigating to Seed-Orders page

        const headerNavigationPage = await StepPageHelper.getHeaderNavigationPage();
        await headerNavigationPage.navigateToSeedOrdersPage();

        const seedOrdersPage = await StepPageHelper.getSeedOrdersPage();

        for (let i = 0; i < verifyAccountsData.expectedAccounts.length; i++) {
            //step 1: checking for Accounts data
            result = await seedOrdersPage.isAccountSelectable(verifyAccountsData.expectedAccounts[i]);

            expect(result).toBeTruthy();

            //step 2: checking for Gowers data
            result = await seedOrdersPage.areGrowersSelectable(verifyAccountsData.expectedAccounts[i].relatedGrowers);
            expect(result).toBeTruthy();

            await seedOrdersPage.clearAccountSelection();
        }
    } catch (error) {
        result = false;
        fixture.logger.error("checking account selection process on Seed-Orders page has failed. Error: " + error);
    }
    expect(result).toBeTruthy();
    fixture.logger.info("checking account selection process on Seed-Orders page has completed");
}
Then('user must be able to select context specific emulated accounts from {string} along with related grower details on Create-New-Grower-Order screen', async function (accountContextInfo: string) {
    //const verifyAccountsData = StepDataHelper.getSingleTestDataRecordForType(TestDataType.VerifyEmulatedAccount, accountContextInfo) as VerifyEmulatedAccount;
    const verifyAccountsData = getEmulatedAccountFromDatabag();
    await checkAccountSelectionOnCreateNewOrderPage(verifyAccountsData);
});

async function checkAccountSelectionOnCreateNewOrderPage(verifyAccountsData: VerifyAccounts | VerifyEmulatedAccount){
    let result = true;
    fixture.logger.info("checking account selection process on Create-New-Grower-Order page has started");
    try {
        const headerNavigationPage = await StepPageHelper.getHeaderNavigationPage();
        await headerNavigationPage.navigateToSeedOrdersPage();
        const seedOrdersPage = await StepPageHelper.getSeedOrdersPage();
        await seedOrdersPage.clickCreateNewGrowerOrderButton();
        const addGrowerOrderPage = await StepPageHelper.getAddGrowerOrderPage();
        //let pageStability = addGrowerOrderPage.isPageStable();
        //expect(pageStability).toBeTruthy();

        for (let i = 0; i < verifyAccountsData.expectedAccounts.length; i++) {
            //step 1: checking for Accounts data
            result = await addGrowerOrderPage.isAccountSelectable(verifyAccountsData.expectedAccounts[i]);
            expect(result).toBeTruthy();

            //step 2: checking for Gowers data
            for (let j = 0; j < verifyAccountsData.expectedAccounts[i].relatedGrowers.length; j++) {
                result = await addGrowerOrderPage.isGrowerSelectable(verifyAccountsData.expectedAccounts[i].relatedGrowers[j]);
                expect(result).toBeTruthy();
            }
        }
    }
    catch (error) {
        result = false;
        fixture.logger.error("checking account selection process on Create-New-Grower-Order page has failed. Error: " + error);
    }
    expect(result).toBeTruthy();
    fixture.logger.info("checking account selection process on Create-New-Grower-Order page has completed");
}

/////****** CPP OPERATIONS ******/////
async function getDataForCppOrderCreate(productPackageType: string) {
    let operationDetails = `CPP order creation with the product type - ${productPackageType}`;
    
    fixture.logger.info(operationDetails);
    fixture.logger.info("getting data for the scenario using stored procedure");
    let result = true;
    let spResult: CreateCppOrderSpResult = null;
    try {
        let evolveDbManager = new EvolveDbManager();
        let dbResult: DbOperationResult = await evolveDbManager.getDataForNewCppOrder(productPackageType);
        
        expect(dbResult.operationResult).toBeTruthy();
        expect(dbResult.operationData).toBeDefined();
        expect(dbResult.operationData).not.toBeNull();
        spResult = dbResult.operationData;
        /*    
        //sample data to bypass SP execution
        spResult = new CreateCppOrderSpResult();
        spResult.ShipToAccountName = "GPAH LLC-QUITMAN - QUITMAN, GA";
        spResult.ShipToAccountNumber = 9874773;
        spResult.SoldToAccountName = "GREENPOINT AG HOLDINGS LLC - DECATUR, AL";
        spResult.DeliverToAccountName = null;
        spResult.DeliverToAccountNumber = null;
        spResult.ContactName = "DOC ";
        spResult.ItemNumber = "1667497";
        spResult.MinQty = 1;
        spResult.HasDraftOrder = false; //CHECK THIS AT THE TIME OF TESTING*/
        
        const accNumber = spResult.ShipToAccountNumber.toString();
        await setAccounts(AccountFilterOption.ACCOUNT_NUMBER, accNumber, accNumber, true);
        fixture.dataBag.saveData(DataBagKeys.SOURCE_DEALER_ACCOUNT_NUMBER, spResult.ShipToAccountNumber);
        fixture.dataBag.saveData(DataBagKeys.SOURCE_DEALER_NAME, spResult.ShipToAccountName);
        fixture.dataBag.saveData(DataBagKeys.SOLD_TO_DEALER_NAME, spResult.SoldToAccountName);
        fixture.dataBag.saveData(DataBagKeys.DELIVER_TO_DEALER_ACCOUNT_NUMBER, spResult.DeliverToAccountNumber);
        fixture.dataBag.saveData(DataBagKeys.DELIVER_TO_DEALER_NAME, spResult.DeliverToAccountName);
        fixture.dataBag.saveData(DataBagKeys.SOURCE_PRODUCT_ITEM_NUMBER_TO_USE, spResult.ItemNumber);
        fixture.dataBag.saveData(DataBagKeys.PRODUCT_CONVERSION_OR_MIN_TRANSFERRABLE_QTY_OR_ORDER_QTY, spResult.MinQty);
        fixture.dataBag.saveData(DataBagKeys.DRAFT_CPP_ORDER_AVAILABLE, spResult.HasDraftOrder);
        fixture.dataBag.saveData(DataBagKeys.CPP_ORDER_CONTACT, spResult.ContactName);
        
    } catch (error) {
        fixture.logger.error(`Setting account context for CPP order operation - ${productPackageType}- failed. Error: ` + error);
        result = false;
    }
    expect(result).toBeTruthy();
}

async function getDataForCppOrderCreateWithSDM(productPackageType: string) {
    let operationDetails = `CPP order with SDM - Requested Arrival Date and the product type - ${productPackageType}`;
    
    fixture.logger.info(operationDetails);
    fixture.logger.info("getting data for the scenario using stored procedure");
    let result = true;
    let spResult: CreateCppOrderSpResult = null;
    try {
        let evolveDbManager = new EvolveDbManager();
        let dbResult: DbOperationResult = await evolveDbManager.getDataForNewCppOrderWithSdm();
        
        expect(dbResult.operationResult).toBeTruthy();
        expect(dbResult.operationData).toBeDefined();
        expect(dbResult.operationData).not.toBeNull();
        spResult = dbResult.operationData;
        /*
        //sample data to bypass SP execution
        spResult = new CreateCppOrderSpResult();
        spResult.ShipToAccountName = "GPAH LLC-QUITMAN - QUITMAN, GA";
        spResult.ShipToAccountNumber = 9874773;
        spResult.SoldToAccountName = "GREENPOINT AG HOLDINGS LLC - DECATUR, AL";
        spResult.DeliverToAccountName = null;
        spResult.DeliverToAccountNumber = null;
        spResult.ContactName = "DOC ";
        spResult.LineItemsData = [];
        spResult.LineItemsData[0] = new LineItemInfo();
        spResult.LineItemsData[0].LineItemSeq = 1;
        spResult.LineItemsData[0].ItemNumber = "10016281";
        spResult.LineItemsData[0].MinQty = 1;
        spResult.LineItemsData[0].IsItemSDM = true;
        spResult.LineItemsData[0].EarliestScheduledDeliveryDate = new Date('2025-05-06');
        spResult.LineItemsData[0].EarliestUnscheduledDeliveryDate = new Date('2025-05-03');
        spResult.LineItemsData[0].NextEarliestScheduledDeliveryDate = '2025-05-09';
        spResult.LineItemsData[0].NextEarliestUnScheduleDeliveryDate = new Date('2025-05-04');
        spResult.LineItemsData[0].UOM = "CA";

        spResult.LineItemsData[1] = new LineItemInfo();
        spResult.LineItemsData[1].LineItemSeq = 2;
        spResult.LineItemsData[1].ItemNumber = "10119843";
        spResult.LineItemsData[1].MinQty = 1;
        spResult.LineItemsData[1].IsItemSDM = true;
        spResult.LineItemsData[1].EarliestScheduledDeliveryDate = new Date('2025-05-06');
        spResult.LineItemsData[1].EarliestUnscheduledDeliveryDate = new Date('2025-05-03');
        spResult.LineItemsData[1].NextEarliestScheduledDeliveryDate = '2025-05-09';
        spResult.LineItemsData[1].NextEarliestUnScheduleDeliveryDate = new Date('2025-05-04');
        spResult.LineItemsData[1].UOM = "CA";

        spResult.LineItemsData[2] = new LineItemInfo();
        spResult.LineItemsData[2].LineItemSeq = 3;
        spResult.LineItemsData[2].ItemNumber = "1714171";
        spResult.LineItemsData[2].MinQty = 1;
        spResult.LineItemsData[2].IsItemSDM = true;
        spResult.LineItemsData[2].EarliestScheduledDeliveryDate = new Date('2025-05-06');
        spResult.LineItemsData[2].EarliestUnscheduledDeliveryDate = new Date('2025-05-03');
        spResult.LineItemsData[2].NextEarliestScheduledDeliveryDate = '2025-05-09';
        spResult.LineItemsData[2].NextEarliestUnScheduleDeliveryDate = new Date('2025-05-04');
        spResult.LineItemsData[2].UOM = "IB";

        spResult.LineItemsData[3] = new LineItemInfo();
        spResult.LineItemsData[3].LineItemSeq = 4;
        spResult.LineItemsData[3].ItemNumber = "1682667";
        spResult.LineItemsData[3].MinQty = 180;
        spResult.LineItemsData[3].IsItemSDM = false;
        spResult.LineItemsData[3].UOM = "CA";
        */
        const accNumber = spResult.ShipToAccountNumber.toString();
        await setAccounts(AccountFilterOption.ACCOUNT_NUMBER, accNumber, accNumber, true);
        fixture.dataBag.saveData(DataBagKeys.SOURCE_DEALER_ACCOUNT_NUMBER, spResult.ShipToAccountNumber);
        fixture.dataBag.saveData(DataBagKeys.SOURCE_DEALER_NAME, spResult.ShipToAccountName);
        fixture.dataBag.saveData(DataBagKeys.SOLD_TO_DEALER_NAME, spResult.SoldToAccountName);
        fixture.dataBag.saveData(DataBagKeys.DELIVER_TO_DEALER_ACCOUNT_NUMBER, spResult.DeliverToAccountNumber);
        fixture.dataBag.saveData(DataBagKeys.DELIVER_TO_DEALER_NAME, spResult.DeliverToAccountName);
        //fixture.dataBag.saveData(DataBagKeys.SOURCE_PRODUCT_ITEM_NUMBER_TO_USE, spResult.ItemNumber);
        //fixture.dataBag.saveData(DataBagKeys.PRODUCT_CONVERSION_OR_MIN_TRANSFERRABLE_QTY, spResult.MinQty);
        //fixture.dataBag.saveData(DataBagKeys.DRAFT_CPP_ORDER_AVAILABLE, spResult.HasDraftOrder);
        fixture.dataBag.saveData(DataBagKeys.CPP_ORDER_CONTACT, spResult.ContactName);
        fixture.dataBag.saveData(DataBagKeys.CPP_LINE_ITEM_DATA, spResult.LineItemsData);
        
    } catch (error) {
        fixture.logger.error(`Setting account context for CPP order operation - ${productPackageType}- failed. Error: ` + error);
        result = false;
    }
    expect(result).toBeTruthy();
}

Given('user sets single account context for create cpp order operation with PACKAGED product', async function () {
    await getDataForCppOrderCreate("PACKAGED");
    fixture.dataBag.saveData(DataBagKeys.IS_SDM_ORDER, false);
});

Given('user sets single account context for create cpp order operation with PACKAGED product and SDM', async function () {
    await getDataForCppOrderCreateWithSDM("PACKAGED");
    fixture.dataBag.saveData(DataBagKeys.IS_SDM_ORDER, true);
});

Given('user sets single account context for create cpp order operation with package type as {string} and supplier type as {string}', async function (
    packageType: string, supplierType: string
) {
    await getDataForCppOrderCreateWithPackageAndSupplier(packageType, supplierType);
});

Given('user sets single account context for create cpp order operation with package type as {string} and supplier type as {string} with multiple delivery dates', async function (
    packageType: string, supplierType: string
) {
    await getDataForCppOrderCreateWithPackageAndSupplier(packageType, supplierType, true);
});

Given('user sets single account context for create cpp order operation with PACKAGED VENDED DS products', async function () {
    await getDataForCppOrderCreateWithPackagedVendedDs();
    fixture.dataBag.saveData(DataBagKeys.IS_SDM_ORDER, false);
});

Given('user sets single account context for create cpp order operation with PACKAGED products and {string} requested arrival date', async function (reqArrivalDateCondition: string) {
    await getDataForCppOrderCreateWithPackageAndReqArrivalDate(reqArrivalDateCondition);
    fixture.dataBag.saveData(DataBagKeys.IS_SDM_ORDER, false);
});

Given('user sets single account context for create cpp {string} request', async function (returnType: string) {
    await getDataForCppProductReturnsRequest(returnType);
    fixture.dataBag.saveData(DataBagKeys.CPP_RETURN_REQUEST_TYPE, returnType);
});

async function getDataForCppProductReturnsRequest(returnType: string){
    let operationDetails = `CPP ${returnType}`;
    
    fixture.logger.info('getting data for the scenario - ' + operationDetails);
    let result = true;
    let spResult: CreateCppReturnRequestSpResult = null;
    try {
        if(returnType == CppProductReturnsPage.RETURN_TYPE)
        {
            let evolveDbManager = new EvolveDbManager();
            let dbResult: DbOperationResult = await evolveDbManager.getDataForNewCppReturnRequest('PRODUCT');
            
            expect(dbResult.operationResult).toBeTruthy();
            expect(dbResult.operationData).toBeDefined();
            expect(dbResult.operationData).not.toBeNull();
            spResult = dbResult.operationData;
        }else if(returnType == CppInoculantReturnsPage.RETURN_TYPE){
            let evolveDbManager = new EvolveDbManager();
            let dbResult: DbOperationResult = await evolveDbManager.getDataForNewCppInoculantsReturnRequest();
            
            expect(dbResult.operationResult).toBeTruthy();
            expect(dbResult.operationData).toBeDefined();
            expect(dbResult.operationData).not.toBeNull();
            spResult = dbResult.operationData;
            /*
            //this is temp data arrangement for Inoculant returns; 
            spResult = new CreateCppReturnRequestSpResult();
            spResult.ShipToAccountNumber = 9874789;
            spResult.SoldToAccountNumber = 9871632;
            spResult.PickupFromAccountNumber = 9955406;
            spResult.IsPORequired = true;
            spResult.HasDraftOrder = false;
            spResult.LineItemsData = [];
            let index = 0;
            spResult.LineItemsData[index] = new LineItemInfo();
            spResult.LineItemsData[index].LineItemSeq = index + 1;
            spResult.LineItemsData[index].ItemNumber = "1680877";
            spResult.LineItemsData[index].ProductType = "AccountReturnable";
            spResult.LineItemsData[index].EligibleUnits = 85;
            
            index++;
            spResult.LineItemsData[index] = new LineItemInfo();
            spResult.LineItemsData[index].LineItemSeq = index + 1;
            spResult.LineItemsData[index].ItemNumber = "1694180";
            spResult.LineItemsData[index].ProductType = "ParentAccountReturnable";
            spResult.LineItemsData[index].EligibleUnits = 48;*/            
        }
        const accNumber = spResult.ShipToAccountNumber.toString();
        await setAccounts(AccountFilterOption.ACCOUNT_NUMBER, accNumber, accNumber, true);
        fixture.dataBag.saveData(DataBagKeys.SOURCE_DEALER_ACCOUNT_NUMBER, spResult.ShipToAccountNumber);
        fixture.dataBag.saveData(DataBagKeys.SOURCE_DEALER_NAME, spResult.ShipToAccountName);
        fixture.dataBag.saveData(DataBagKeys.SOLD_TO_DEALER_NUMBER, spResult.SoldToAccountNumber);
        fixture.dataBag.saveData(DataBagKeys.PICKUP_FROM_NUMBER, spResult.PickupFromAccountNumber);
        fixture.dataBag.saveData(DataBagKeys.CUSTOMER_PO_REQUIRED, spResult.IsPORequired);
        fixture.dataBag.saveData(DataBagKeys.DRAFT_CPP_ORDER_AVAILABLE, spResult.HasDraftOrder);
        fixture.dataBag.saveData(DataBagKeys.CPP_LINE_ITEM_DATA, spResult.LineItemsData);
    } catch (error) {
        fixture.logger.error(`Setting account context for - ${operationDetails} - failed. Error: ` + error);
        result = false;
    }
    expect(result).toBeTruthy();
}

async function getDataForCppOrderCreateWithPackageAndReqArrivalDate(reqArrivalDateCondition: string) {
    let operationDetails = `CPP order with packaged products and arrival date condition type - ${reqArrivalDateCondition}`;
    
    fixture.logger.info(operationDetails);
    let result = true;
    let spResult: CreateCppOrderSpResult = null;
    try {
        let evolveDbManager = new EvolveDbManager();
        let dbResult: DbOperationResult = await evolveDbManager.getDataForNewCppOrderWithPackArrivalDate(reqArrivalDateCondition);
        
        expect(dbResult.operationResult).toBeTruthy();
        expect(dbResult.operationData).toBeDefined();
        expect(dbResult.operationData).not.toBeNull();
        spResult = dbResult.operationData;
        
        const accNumber = spResult.ShipToAccountNumber.toString();
        await setAccounts(AccountFilterOption.ACCOUNT_NUMBER, accNumber, accNumber, true);
        fixture.dataBag.saveData(DataBagKeys.SOURCE_DEALER_ACCOUNT_NUMBER, spResult.ShipToAccountNumber);
        fixture.dataBag.saveData(DataBagKeys.SOURCE_DEALER_NAME, spResult.ShipToAccountName);
        fixture.dataBag.saveData(DataBagKeys.SOLD_TO_DEALER_NAME, spResult.SoldToAccountName);
        fixture.dataBag.saveData(DataBagKeys.DELIVER_TO_DEALER_ACCOUNT_NUMBER, spResult.DeliverToAccountNumber);
        fixture.dataBag.saveData(DataBagKeys.DELIVER_TO_DEALER_NAME, spResult.DeliverToAccountName);
        fixture.dataBag.saveData(DataBagKeys.CPP_ORDER_CONTACT, spResult.ContactName);
        fixture.dataBag.saveData(DataBagKeys.CPP_LINE_ITEM_DATA, spResult.LineItemsData);
        fixture.dataBag.saveData(DataBagKeys.CUSTOMER_PO_REQUIRED, spResult.IsPORequired);
        
    } catch (error) {
        fixture.logger.error(`Setting account context for ${operationDetails}- failed. Error: ` + error);
        result = false;
    }
    expect(result).toBeTruthy();
}

async function getDataForCppOrderCreateWithPackageAndSupplier(packageType: string, supplierType: string, dataForMultipleDeliveryDates: boolean = false) {
    let operationDetails = `CPP order with package type - ${packageType} and supplier type - ${supplierType}`;
    
    fixture.logger.info(operationDetails);
    fixture.logger.info("getting data for the scenario using stored procedure");
    let result = true;
    let spResult: CreateCppOrderSpResult = null;
    try {
        
        let evolveDbManager = new EvolveDbManager();
        let dbResult: DbOperationResult = null;
        if(dataForMultipleDeliveryDates)
            dbResult = await evolveDbManager.getDataForNewCppOrderWithBulkProductsHavingDifferentDeliveryDates();
        else
            dbResult = await evolveDbManager.getDataForNewCppOrderWithBulkProduct();
        
        expect(dbResult.operationResult).toBeTruthy();
        expect(dbResult.operationData).toBeDefined();
        expect(dbResult.operationData).not.toBeNull();
        spResult = dbResult.operationData;
        /*
        //sample data to bypass SP execution for evolveDbManager.getDataForNewCppOrderWithBulkProduct
        spResult = new CreateCppOrderSpResult();
        spResult.ShipToAccountName = "HELENA AGRI-ENT LLC-HASKELL - HASKELL, TX";
        spResult.ShipToAccountNumber = 7023048;
        spResult.SoldToAccountName = "HELENA AGRI-ENTERPRISES LLC(MAIN) - COLLIERVILLE, TN";
        spResult.DeliverToAccountName = "HELENA AGRI-ENT LLC-MOSES LAKE - MOSES LAKE, WA";
        spResult.DeliverToAccountNumber = 7018654;
        spResult.ContactName = "automationContact ";
        spResult.HasDraftOrder = false;
        spResult.IsPORequired = true;
        spResult.LineItemsData = [];
        let index = 0;
        spResult.LineItemsData[index] = new LineItemInfo();
        spResult.LineItemsData[index].LineItemSeq = 1;
        spResult.LineItemsData[index].ItemNumber = "10015325";
        spResult.LineItemsData[index].MinQty = 2000;
        spResult.LineItemsData[index].MaxQty = 4200;
        spResult.LineItemsData[index].UOM = 'GA';
        spResult.LineItemsData[index].PackageType = packageType;
        spResult.LineItemsData[index].SupplierType = supplierType;
        spResult.LineItemsData[index].RequestDeliveryDate = new Date(Date.now() + 86400000).toLocaleDateString('en-US', { month: '2-digit', day: '2-digit', year: 'numeric' }); //'05/12/2025'

        index++;
        spResult.LineItemsData[index] = new LineItemInfo();
        spResult.LineItemsData[index].LineItemSeq = 2;
        spResult.LineItemsData[index].ItemNumber = "10130108";
        spResult.LineItemsData[index].MinQty = 1000;
        spResult.LineItemsData[index].MaxQty = 4100;
        spResult.LineItemsData[index].UOM = 'GA';
        spResult.LineItemsData[index].PackageType = packageType;
        spResult.LineItemsData[index].SupplierType = supplierType;
        spResult.LineItemsData[index].RequestDeliveryDate = new Date(Date.now() + 86400000).toLocaleDateString('en-US', { month: '2-digit', day: '2-digit', year: 'numeric' });//'05/12/2025'

        index++;
        spResult.LineItemsData[index] = new LineItemInfo();
        spResult.LineItemsData[index].LineItemSeq = 3;
        spResult.LineItemsData[index].ItemNumber = "10130108";
        spResult.LineItemsData[index].MinQty = 1000;
        spResult.LineItemsData[index].MaxQty = 4100;
        spResult.LineItemsData[index].UOM = 'GA';
        spResult.LineItemsData[index].PackageType = packageType;
        spResult.LineItemsData[index].SupplierType = supplierType;
        spResult.LineItemsData[index].RequestDeliveryDate = new Date(Date.now() + 2 * 86400000).toLocaleDateString('en-US', { month: '2-digit', day: '2-digit', year: 'numeric' });
        
        index++;
        spResult.LineItemsData[index] = new LineItemInfo();
        spResult.LineItemsData[index].LineItemSeq = 4;
        spResult.LineItemsData[index].ItemNumber = "10130108";
        spResult.LineItemsData[index].MinQty = 1000;
        spResult.LineItemsData[index].MaxQty = 4100;
        spResult.LineItemsData[index].UOM = 'GA';
        spResult.LineItemsData[index].PackageType = packageType;
        spResult.LineItemsData[index].SupplierType = supplierType;
        spResult.LineItemsData[index].RequestDeliveryDate = new Date(Date.now() + 3 * 86400000).toLocaleDateString('en-US', { month: '2-digit', day: '2-digit', year: 'numeric' });

        index++;
        spResult.LineItemsData[index] = new LineItemInfo();
        spResult.LineItemsData[index].LineItemSeq = 5;
        spResult.LineItemsData[index].ItemNumber = "10130108";
        spResult.LineItemsData[index].MinQty = 1000;
        spResult.LineItemsData[index].MaxQty = 4100;
        spResult.LineItemsData[index].UOM = 'GA';
        spResult.LineItemsData[index].PackageType = packageType;
        spResult.LineItemsData[index].SupplierType = supplierType;
        spResult.LineItemsData[index].RequestDeliveryDate = new Date(Date.now() + 4 * 86400000).toLocaleDateString('en-US', { month: '2-digit', day: '2-digit', year: 'numeric' });

        index++;
        spResult.LineItemsData[index] = new LineItemInfo();
        spResult.LineItemsData[index].LineItemSeq = 6;
        spResult.LineItemsData[index].ItemNumber = "10130108";
        spResult.LineItemsData[index].MinQty = 1000;
        spResult.LineItemsData[index].MaxQty = 4100;
        spResult.LineItemsData[index].UOM = 'GA';
        spResult.LineItemsData[index].PackageType = packageType;
        spResult.LineItemsData[index].SupplierType = supplierType;
        spResult.LineItemsData[index].RequestDeliveryDate = new Date(Date.now() + 5 * 86400000).toLocaleDateString('en-US', { month: '2-digit', day: '2-digit', year: 'numeric' });
        */
        const accNumber = spResult.ShipToAccountNumber.toString();
        await setAccounts(AccountFilterOption.ACCOUNT_NUMBER, accNumber, accNumber, true);
        fixture.dataBag.saveData(DataBagKeys.CPP_SCENARIO, CppNewOrderPage.CPP_SCENARIO_BULK);
        fixture.dataBag.saveData(DataBagKeys.SOURCE_DEALER_ACCOUNT_NUMBER, spResult.ShipToAccountNumber);
        fixture.dataBag.saveData(DataBagKeys.SOURCE_DEALER_NAME, spResult.ShipToAccountName);
        fixture.dataBag.saveData(DataBagKeys.SOLD_TO_DEALER_NAME, spResult.SoldToAccountName);
        fixture.dataBag.saveData(DataBagKeys.DELIVER_TO_DEALER_ACCOUNT_NUMBER, spResult.DeliverToAccountNumber);
        fixture.dataBag.saveData(DataBagKeys.DELIVER_TO_DEALER_NAME, spResult.DeliverToAccountName);
        fixture.dataBag.saveData(DataBagKeys.CPP_ORDER_CONTACT, spResult.ContactName);
        fixture.dataBag.saveData(DataBagKeys.CPP_LINE_ITEM_DATA, spResult.LineItemsData);
        fixture.dataBag.saveData(DataBagKeys.CUSTOMER_PO_REQUIRED, spResult.IsPORequired);
        
    } catch (error) {
        fixture.logger.error(`Setting account context for ${operationDetails}- failed. Error: ` + error);
        result = false;
    }
    expect(result).toBeTruthy();
}

async function getDataForCppOrderCreateWithPackagedVendedDs() {
    let operationDetails = `CPP order with Pacakeged - Vended - Direct-To-Ship products with mandatory customer PO`;
    
    fixture.logger.info(operationDetails);
    fixture.logger.info("getting data for the scenario using stored procedure");
    let result = true;
    let spResult: CreateCppOrderSpResult = null;
    try {
        let evolveDbManager = new EvolveDbManager();
        let dbResult: DbOperationResult = await evolveDbManager.getDataForNewCppOrderWithPackVenDs("Y");
        
        expect(dbResult.operationResult).toBeTruthy();
        expect(dbResult.operationData).toBeDefined();
        expect(dbResult.operationData).not.toBeNull();
        spResult = dbResult.operationData;
        /*
        //sample data to bypass SP execution
        spResult = new CreateCppOrderSpResult();
        spResult.ShipToAccountName = "GPAH LLC/CENTRAL ALA FARMERS-FAUNSDALE - FAUNSDALE, AL";
        spResult.ShipToAccountNumber = 9945875;
        spResult.SoldToAccountName = "GREENPOINT AG HOLDINGS LLC - DECATUR, AL";
        spResult.DeliverToAccountName = "GPAH LLC/MADISON COUNTY COOP-MERIDIANVIL - MERIDIANVILLE, AL";
        spResult.DeliverToAccountNumber = 9942841;
        spResult.ContactName = "";
        spResult.HasDraftOrder = false;
        spResult.IsPORequired = true;
        let lineItemInfo1 = new LineItemInfo();
        lineItemInfo1.LineItemSeq = 1;
        lineItemInfo1.ItemNumber = "1702948";
        lineItemInfo1.SupplierNumber = "7779725";
        lineItemInfo1.ItemVendorName = "NON-PROPRIETARY";
        lineItemInfo1.MinQty = 5;
        lineItemInfo1.UOM = 'PA';
        lineItemInfo1.PackageSize = "5 GA PAIL(S)";
        lineItemInfo1.GallonsPerQty = 5;

        let lineItemInfo2 = new LineItemInfo();
        lineItemInfo2.LineItemSeq = 2;
        lineItemInfo2.ItemNumber = "1706360";
        lineItemInfo2.SupplierNumber = "7776757";
        lineItemInfo2.ItemVendorName = "NON-PROPRIETARY";
        lineItemInfo2.MinQty = 5;
        lineItemInfo2.UOM = 'CA';
        lineItemInfo2.PackageSize = "2 X 2.5 GA CASE(S)";
        lineItemInfo2.GallonsPerQty = 5;

        let lineItemInfo3 = new LineItemInfo();
        lineItemInfo3.LineItemSeq = 3;
        lineItemInfo3.ItemNumber = "1723751";
        lineItemInfo3.SupplierNumber = "7776757";
        lineItemInfo3.ItemVendorName = "NON-PROPRIETARY";
        lineItemInfo3.MinQty = 36;
        lineItemInfo3.UOM = 'CA';
        lineItemInfo3.PackageSize = "2 X 2.5 GA CASE(S)";
        lineItemInfo3.GallonsPerQty = 5;

        spResult.LineItemsData = [lineItemInfo1, lineItemInfo2, lineItemInfo3];
        */
        const accNumber = spResult.ShipToAccountNumber.toString();
        await setAccounts(AccountFilterOption.ACCOUNT_NUMBER, accNumber, accNumber, true);
        fixture.dataBag.saveData(DataBagKeys.SOURCE_DEALER_ACCOUNT_NUMBER, spResult.ShipToAccountNumber);
        fixture.dataBag.saveData(DataBagKeys.SOURCE_DEALER_NAME, spResult.ShipToAccountName);
        fixture.dataBag.saveData(DataBagKeys.SOLD_TO_DEALER_NAME, spResult.SoldToAccountName);
        fixture.dataBag.saveData(DataBagKeys.DELIVER_TO_DEALER_ACCOUNT_NUMBER, spResult.DeliverToAccountNumber);
        fixture.dataBag.saveData(DataBagKeys.DELIVER_TO_DEALER_NAME, spResult.DeliverToAccountName);
        fixture.dataBag.saveData(DataBagKeys.CPP_ORDER_CONTACT, spResult.ContactName);
        fixture.dataBag.saveData(DataBagKeys.CPP_LINE_ITEM_DATA, spResult.LineItemsData);
        fixture.dataBag.saveData(DataBagKeys.CUSTOMER_PO_REQUIRED, spResult.IsPORequired);
        
    } catch (error) {
        fixture.logger.error(`Setting account context for ${operationDetails}- failed. Error: ` + error);
        result = false;
    }
    expect(result).toBeTruthy();
}