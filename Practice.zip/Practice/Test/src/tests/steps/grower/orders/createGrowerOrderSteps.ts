import { Given, When, Then, setDefaultTimeout } from "@cucumber/cucumber";

import { fixture } from "../../../../hooks/fixture";
import { expect } from "@playwright/test";
import StepPageHelper from "../../stepPageHelper";
import DataBagKeys from "../../dataBagKeys";

setDefaultTimeout(60 * 1000 * 2)

Given('user clicks on Place-Order or Update-Order button', async function () {
    await placeOrUpdateOrder(true, "failed to click on Place/Update Order button on Grower-Order page.");
});

When('places the dealer order', async function () {
    await placeOrUpdateOrder(true, "failed to click on Place-Order button on Dealer-Order page.");
});

When('completes the dealer order modifications', async function () {
    await placeOrUpdateOrder(false, "failed to click on Update-Order button on Dealer-Order page.");
});

When('completes the order modifications', async function () {
    await placeOrUpdateOrder(false, "failed to click on Update-Order button on the order page.");
});

export async function placeOrUpdateOrder(isNewOrder: boolean, errorMsg: string){
    let result = true;
    try {
        const skipUpdateOrder = fixture.dataBag.getData(DataBagKeys.SKIP_ORDER_UPDATE) as boolean;
        if (skipUpdateOrder === undefined || !skipUpdateOrder) {
            const addGrowerOrderPage = await StepPageHelper.getAddGrowerOrderPage();
            const msg = await addGrowerOrderPage.placeOrUpdateOrder(isNewOrder);
            fixture.dataBag.saveData(DataBagKeys.OPERATION_COMPLETION_MESSAGE, msg);
        }else{
            fixture.logger.warn('skipping order update');
        }
    } catch (error) {
        result = false;
        fixture.logger.error(errorMsg + error);
    }
    expect(result).toBeTruthy();
}

Then('a new order must be created', async function () {
    await placeOrUpdateOrderCompletionVerification("a new grower order has been placed with the order id - ",
    "failed to verify 'Grower Order #number updated successfully.' message on Create-New-Grower-Order page. Error: ");
});

Then('a new dealer order must be created', async function () {
    await placeOrUpdateOrderCompletionVerification("dealer order has been placed with the order id - ",
    "failed to verify 'Dealer Order #number saved successfully.' message on New-Dealer-Order page. Error: ");
});

Then('the existing order must be updated', async function () {
    await placeOrUpdateOrderCompletionVerification("an existing grower/dealer order has been updated with the order id - ",
    "failed to verify 'Grower/Dealer Order #number updated/saved successfully.' message on Update-Order page. Error: ");
});

async function placeOrUpdateOrderCompletionVerification(successMsg: string, errorMsg: string){
    let result = true;
    try {
        const skipUpdateOrder = fixture.dataBag.getData(DataBagKeys.SKIP_ORDER_UPDATE) as boolean;
        if (skipUpdateOrder === undefined || !skipUpdateOrder) {
            const msg = fixture.dataBag.getData(DataBagKeys.OPERATION_COMPLETION_MESSAGE) as string;
            if (msg !== undefined && msg !== null && msg.length > 0) {
                const orderId = (msg.trim().split(" ")[2]).substring(1);
                expect(orderId).not.toBeNull();
                expect(orderId.length).toBeGreaterThan(1);
                fixture.dataBag.saveData(DataBagKeys.ORDER_ID, orderId);
                fixture.logger.info(successMsg + orderId);
            }else{
                fixture.logger.warn('could not retrieve toast message hence skipping it and checking for Place/Update Order butoon visibility which must be false');
                const addGrowerOrderPage = await StepPageHelper.getAddGrowerOrderPage();
                result = await addGrowerOrderPage.isPlaceOrUpdateOrderBtnAvailable();
                expect(result).toBeFalsy();
                result = true;//set this to true so that the final expect does not fail
                fixture.logger.warn('Place/Update Order butoon is not present - check completed successfully');
            }
        }else{
            result = false;
        }
    } catch (error) {
        fixture.logger.error(errorMsg + error);
        result = false;
    }
    expect(result).toBeTruthy();
}
