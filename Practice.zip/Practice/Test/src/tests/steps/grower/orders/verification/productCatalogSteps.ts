import { Given, Then, setDefaultTimeout } from "@cucumber/cucumber";

import { expect } from "@playwright/test";
import { fixture } from "../../../../../hooks/fixture";
import VerifyAccounts from "../../../../../helpers/util/test-data/dealer/verifyAccounts";
import AddProductsToOrderPageSteps from "../../../addProductsToOrderPageSteps";
import { TestDataType } from "../../../../../helpers/util/test-data/TestDataType";
import StepDataHelper from "../../../stepDataHelper";
import DataBagKeys from "../../../dataBagKeys";
import ProductInfo from "../../../../../helpers/util/test-data/product/productInfo";
import StepPageHelper from "../../../stepPageHelper";
import DealerGrowerInfo from "../../../../../helpers/util/api/models/dealerGrowerInfo";
import AccountDetails from "../../../../../helpers/util/test-data/dealer/accountDetails";
import GrowerDetails from "../../../../../helpers/util/test-data/grower/growerDetails";

setDefaultTimeout(60 * 1000 * 2)

Given('user selects Account and Grower details from {string} and navigates to Add-Products-to-the-order page', async function (accountContextInfo: string) {
    fixture.logger.info("Selecting Account and Grower details and navigating to Add-Products-to-the-order page has started");
    let result = true;
    try {
        const headerNavigationPage = await StepPageHelper.getHeaderNavigationPage();
        await headerNavigationPage.navigateToSeedOrdersPage();
        const seedOrdersPage = await StepPageHelper.getSeedOrdersPage();

        //const verifyAccountsData = StepDataHelper.getSingleTestDataRecordForType(TestDataType.VerifyAccounts, accountContextInfo) as VerifyAccounts;
        const verifyAccountsData = fixture.dataBag.getData(DataBagKeys.DEALER_GROWER_INFO_TO_USE) as VerifyAccounts;

        //let pageStability = await seedOrdersPage.isPageLoaded();// await seedOrdersPage.isPageStable();
        //expect(pageStability).toBeTruthy();

        const currentGrowerOrdersCount = await seedOrdersPage.getCurrentGrowerOrdersCount();
        fixture.dataBag.saveData(DataBagKeys.CURRENT_GROWER_ORDERS_COUNT, currentGrowerOrdersCount);

        fixture.logger.info(`Grower orders count on Seed-Orders page is :  ${currentGrowerOrdersCount}`);
        await seedOrdersPage.clickCreateNewGrowerOrderButton();
        const addGrowerOrderPage = await StepPageHelper.getAddGrowerOrderPage();
        //pageStability = await addGrowerOrderPage.isPageStable(); //await addGrowerOrderPage.isPageLoaded();
        //expect(pageStability).toBeTruthy();

        await addGrowerOrderPage.selectAccountFromDropDown(verifyAccountsData.expectedAccounts[0]);
        await addGrowerOrderPage.selectGrowerFromDropDown(verifyAccountsData.expectedAccounts[0].relatedGrowers[0]);

        fixture.dataBag.saveData(DataBagKeys.DEALER_ACCOUNT_NUMBER, verifyAccountsData.expectedAccounts[0].number);

        await addGrowerOrderPage.navigateToAddProductsPage();
    } catch (error) {
        fixture.logger.error("Selecting Account and Grower details and navigating to Add-Products-to-the-order page failed. Error: " + error);
        result = false;
    }
    expect(result).toBeTruthy();
    fixture.logger.info("Selecting Account and Grower details and navigating to Add-Products-to-the-order page has completed");
});

/*Given('user searches for products', async function () {
    const addProductToTheOrderPage = pf.getAddProductsToTheOrderPage(fixture.page);

    const verifyProductsData = pf.getTestDataProvider().getTestData(TestDataType.VerifyProductCatalog, "", "") as VerifyProductCatalog;

    const pageStability = await addProductToTheOrderPage.isPageStable();
    expect(pageStability).toBeTruthy();
    console.log("addProductToTheOrderPage loaded..." + pageStability);

    let isFirstSearch = true;
    for(let i=0; i<verifyProductsData.filters.length; i++){
        await addProductToTheOrderPage.clickSearchFilterDropDown();
        await addProductToTheOrderPage.selectSearchFilterItemInTheDropDown(verifyProductsData.filters[i].filterCategory);
        let isSearchByFreeText: boolean = false;
        let productSelectionFilters = new ProductSelectionFilters();

        console.log(verifyProductsData.filters[i].filterCategory);
        console.log(productSelectionFilters.productName);
        console.log(productSelectionFilters.technology);
        if(verifyProductsData.filters[i].filterCategory === productSelectionFilters.productName ||
            verifyProductsData.filters[i].filterCategory === productSelectionFilters.technology)
            isSearchByFreeText = true;
       
        console.log(isSearchByFreeText);
        await addProductToTheOrderPage.searchProduct(isFirstSearch, verifyProductsData.filters[i].searchKey, isSearchByFreeText
        , verifyProductsData.onlyShowProductOnDealerOrder, verifyProductsData.onlyShowProductWithAvailability);

        isFirstSearch = false;
    }
});*/

Given('user searches for products with {string}, {string}, {string}, {string}', async function (filterCategory: string, searchKey: string, onlyShowProductOnDealerOrder: string, onlyShowProductWithAvailability: string) {
    fixture.logger.info("Searching for products on Add-Products-to-the-order page has started");
    let result = true;
    try {
        const filterCategoryInfo: string = StepDataHelper.getSingleStringNodeData(filterCategory);
        const searchKeyInfo: string = StepDataHelper.getSingleStringNodeData(searchKey);
        const onlyShowProductOnDealerOrderInfo: string = StepDataHelper.getSingleStringNodeData(onlyShowProductOnDealerOrder);
        const onlyShowProductWithAvailabilityInfo: string = StepDataHelper.getSingleStringNodeData(onlyShowProductWithAvailability);

        const addProductsToOrderPageSteps = new AddProductsToOrderPageSteps();
        await addProductsToOrderPageSteps.searchForProducts(filterCategoryInfo, searchKeyInfo, onlyShowProductOnDealerOrderInfo, onlyShowProductWithAvailabilityInfo);
    } catch (error) {
        fixture.logger.error("Searching for products on Add-Products-to-the-order page failed. Error: " + error);
        result = false;
    }
    expect(result).toBeTruthy();
    fixture.logger.info("Searching for products on Add-Products-to-the-order page has completed");
});

/*
Then('user must be able to select products as {string} on Add-Product-to-the-order screen', async function (products: string) {
    const addProductToTheOrderPage = pf.getAddProductsToTheOrderPage(fixture.page);
    const verifyProductsData = pf.getTestDataProvider().getTestData(TestDataType.VerifyProductCatalog, "", "") as VerifyProductCatalog;

    await addProductToTheOrderPage.selectProductsFromSearchResult(verifyProductsData.expectedProducts);

    await addProductToTheOrderPage.clearProductSearchResults();
});*/

Then('user must be able to select products as {string} on Add-Product-to-the-order screen', async function (products: string) {
    fixture.logger.info("Selecting products on Add-Products-to-the-order page has started");
    let result = true;
    try {
        const productsInfo = StepDataHelper.getMultipleTestDataRecordsForType(TestDataType.ProductInfo, products) as ProductInfo[];
        if (productsInfo == null || productsInfo.length == 0) {
            fixture.logger.error("source does not have any products to be added info in the product catalog. Hence exiting from the scenario");
            result = false;
        }

        const productNames: string[] = [];
        for (let pIndex = 0; pIndex < productsInfo.length; pIndex++) {
            fixture.logger.info(`product name is...${productsInfo[pIndex].name}`);
            if (!productNames.includes(productsInfo[pIndex].name))
                productNames.push(productsInfo[pIndex].name);
        }
        const addProductsToOrderPageSteps = new AddProductsToOrderPageSteps();
        await addProductsToOrderPageSteps.selectProducts(productNames, true);
    } catch (error) {
        fixture.logger.error("Selecting products on Add-Products-to-the-order page failed. Error: " + error);
        result = false;
    }
    expect(result).toBeTruthy();
    fixture.logger.info("Selecting products on Add-Products-to-the-order page has completed");
});

Then('Add-to-Order button must be enabled on Add-Product-to-the-order screen', async function () {
    fixture.logger.info("Checking if Add-to-Order button is enabled on Add-Product-to-the-order page has started");
    let result = true;
    try {
        const addProductToTheOrderPage = await StepPageHelper.getAddProductToTheOrderPage();
        result = await addProductToTheOrderPage.isAddToOrderButtonEnabled();
        expect(result).toBeTruthy();
    } catch (error) {
        fixture.logger.error("Checking if Add-to-Order button is enabled on Add-Product-to-the-order page failed. Error: " + error);
        result = false;
    }
    expect(result).toBeTruthy();
    fixture.logger.info("Checking if Add-to-Order button is enabled on Add-Product-to-the-order page has completed");
});