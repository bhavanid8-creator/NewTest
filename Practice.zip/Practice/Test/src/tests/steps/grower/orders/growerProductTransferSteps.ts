import { DataTable, Given, Then, setDefaultTimeout } from "@cucumber/cucumber";
import { expect } from "@playwright/test";
import { fixture } from "../../../../hooks/fixture";
import StepDataHelper from "../../stepDataHelper";
import { TestDataType } from "../../../../helpers/util/test-data/TestDataType";
import GrowerDetails from "../../../../helpers/util/test-data/grower/growerDetails";
import ProductInfo from "../../../../helpers/util/test-data/product/productInfo";
import SellerInfo from "../../../../helpers/util/test-data/seller/sellerInfo";
import ProductOrderInfo from "../../../../helpers/util/test-data/productOrder/productOrderInfo";
import DataBagKeys from "../../dataBagKeys";
import SharedSteps from "../../sharedSteps";
import StepPageHelper from "../../stepPageHelper";
import AccountDetailsForOrderModification from "../../../../helpers/util/test-data/grower/accountDetailsForOrderModification";
import ProductTransferSameDealerPage from "../../../../pages/seed/orders/grower/productTransferSameDealerPage";
import ProductTransferAnotherDealerPage from "../../../../pages/seed/orders/grower/productTransferAnotherDealerPage";
import DataRequirementsSteps from "../../dataRequirementsSteps";
import DealerGrowerInfo from "../../../../helpers/util/api/models/dealerGrowerInfo";
import GrowerOrderItemInfo from "../../../../helpers/util/api/models/growerOrderItemInfo";
import DateHelper from "../../../../helpers/types/dateHelper";

setDefaultTimeout(60 * 1000 * 2)

Given('user transfers products to another dealer-grower having no existing order', async function () {
    await transferProducts(false, false);
});

Given('user transfers products to another dealer-grower having an existing order', async function () {
    const trgtGrowerOrderNumber = fixture.dataBag.getData(DataBagKeys.TARGET_GROWER_ORDER_NUMBER) as string;
    await transferProducts(false, true, false, trgtGrowerOrderNumber);
});

Given('user transfers products to another grower having no existing order', async function () {
    await transferProducts(true, false);
});

Given('user transfers products to another grower having an existing order', async function () {
    const trgtGrowerOrderNumber = fixture.dataBag.getData(DataBagKeys.TARGET_GROWER_ORDER_NUMBER) as string;
    await transferProducts(true, true, false, trgtGrowerOrderNumber);
});
function getProductInfo(growerOrderItem: GrowerOrderItemInfo): ProductInfo{
    let prodToTransfer = new ProductInfo();
    prodToTransfer.existingCountOnTheOrder = growerOrderItem.geu;
    prodToTransfer.name = growerOrderItem.productNameFilter + " - " + growerOrderItem.marketingBrand;
    prodToTransfer.itemDescription = growerOrderItem.itemDescription;
    if(growerOrderItem.packageSize != null) // we check != null because, it means !== undefined and !== null.
        prodToTransfer.packageSize = growerOrderItem.packageSize.trim();
    if(growerOrderItem.seedSize != null)
        prodToTransfer.seedSize = growerOrderItem.seedSize.trim();
    if(growerOrderItem.technology != null)
        prodToTransfer.technology = growerOrderItem.technology.trim();
    if(growerOrderItem.treatment != null)
        prodToTransfer.treatment = growerOrderItem.treatment.trim();

    return prodToTransfer;
}
async function transferProducts_obsolete(transerDetails: DataTable, isTheDestinationGrowerFromSameDealer: boolean, shouldTransferToExistingOrder: boolean, screenValidationOnly: boolean = false
    ,targetOrderId: string = ""
) {
    fixture.logger.info(`transferProducts started`);
    let result = true;
    let dealerAccountNumber = fixture.dataBag.getData(DataBagKeys.SOURCE_DEALER_ACCOUNT_NUMBER) as string;
    let growerOrderIdForAPI = fixture.dataBag.getData(DataBagKeys.ORDER_ID_FOR_API) as number;

    try {
        const recordDetail = transerDetails.rowsHash();

        const targetGrowerData = fixture.dataBag.getData(DataBagKeys.ANOTHER_GROWER) as DealerGrowerInfo;
    
        const destinationGrower = new GrowerDetails();
        destinationGrower.name = targetGrowerData.growerName;
        let tempAddress = "";
        if(targetGrowerData.address1 !== undefined && targetGrowerData.address1 !== null && targetGrowerData.address1.length > 0){
            tempAddress = targetGrowerData.address1;
        }
        if(targetGrowerData.city !== undefined && targetGrowerData.city !== null && targetGrowerData.city.length > 0){
            if(tempAddress !== "")
                tempAddress = tempAddress + ", " + targetGrowerData.city;
            else
                tempAddress = targetGrowerData.city;
        }
        if(targetGrowerData.state !== undefined && targetGrowerData.state !== null && targetGrowerData.state.length > 0){
            if(tempAddress !== "")
                tempAddress = tempAddress + ", " + targetGrowerData.state;
            else
                tempAddress = targetGrowerData.state;
        }
        if(targetGrowerData.zip !== undefined && targetGrowerData.zip !== null && targetGrowerData.zip.length > 0){
            if(tempAddress !== "")
                tempAddress = tempAddress + " - " + targetGrowerData.zip;
            else
                tempAddress = targetGrowerData.zip;
        }
        destinationGrower.address = tempAddress;
        destinationGrower.growerGMK = targetGrowerData.gmk.toString();
        destinationGrower.growerGLN = targetGrowerData.gln;
        //let targetOrderId: string = "";
        if (shouldTransferToExistingOrder) {
            if(targetOrderId.length === 0)
                targetOrderId = StepDataHelper.getSingleStringNodeData(recordDetail.existingOrderID).trim();
            fixture.dataBag.saveData(DataBagKeys.TARGET_ORDER_ID_FOR_TRANSFER, targetOrderId);
            fixture.logger.info(`transfer will be to existing order - ${targetOrderId}`);
        } else
            fixture.logger.info(`transfer will be to new order`);

        //const productsToTransfer = StepDataHelper.getMultipleTestDataRecordsForType(TestDataType.ProductInfo, recordDetail.products) as ProductInfo[];
        //fixture.logger.info(`done with productsToTransfer`);
        
        //call API to get the seller info
        const growerOrderItems = await StepDataHelper.getGrowerOrderItems(dealerAccountNumber, growerOrderIdForAPI.toString(),1);
        let productsToTransfer: ProductInfo[] = [];
        let prodToTransfer1 = getProductInfo(growerOrderItems[0]);
        productsToTransfer.push(prodToTransfer1);
        if (growerOrderItems.length > 1) { //we will try to transfer max 2 products
            let prodToTransfer2 = getProductInfo(growerOrderItems[1]);
            productsToTransfer.push(prodToTransfer2);
        }

        //const updatedSeller = StepDataHelper.getSingleTestDataRecordForType(TestDataType.SellerInfo, recordDetail.seller) as SellerInfo;
        //call API to get the seller info
        let updatedSeller = new SellerInfo();
        const sellerDetails = await StepDataHelper.getSeller(targetGrowerData.shipToAccount.toString());
        updatedSeller.name = sellerDetails != null ? sellerDetails.accountName : "";

        const transferModifications = StepDataHelper.getSingleTestDataRecordForType(TestDataType.ProductOrderInfo, recordDetail.transferModifications) as ProductOrderInfo;
        fixture.logger.info(`done with transferModifications`);

        const sharedSteps = new SharedSteps();
        //step 1: select products to transfer on the order page
        const lineItemAddedDuringNavigation = await sharedSteps.updateOrderIfModifiedDuringNavigation();
        fixture.logger.info(`done with lineItemAddedDuringNavigation`);

        const sharedBehavior = await StepPageHelper.getSharedPageBehavior();
        const transferringProductNames: string[] = [];

        if (lineItemAddedDuringNavigation) {
            const topLineItemProductName = await sharedBehavior.getOrderTopLineItemProductName();
            fixture.logger.info(`a new line item to the order has been added and hence this product - ${topLineItemProductName} - will be used for transfer`);
            fixture.logger.info(`about to start IF - selectOrderProductLineItems`);
            await sharedBehavior.selectProductTopOrderLineItem();
            fixture.logger.info(`done with IF - selectOrderProductLineItems`);
            transferringProductNames.push(topLineItemProductName);
        } else {
            for (let i = 0; i < productsToTransfer.length; i++) {
                transferringProductNames.push(productsToTransfer[i].name.trim());
            }
            fixture.logger.info(`following products will be used for transfer`);
            fixture.logger.info(transferringProductNames.toString());

            fixture.logger.info(`about to start ELSE - selectOrderProductLineItems`);
            await sharedBehavior.selectOrderProductLineItems(productsToTransfer);
            fixture.logger.info(`done with selectOrderProductLineItems`);
        }

        const orderPage = await StepPageHelper.getAddGrowerOrderPage();
        let transferProductPage: ProductTransferSameDealerPage | ProductTransferAnotherDealerPage;
        let checkDeliveryDate: boolean = true;

        const existingProductRowCount = await sharedBehavior.getExistingProductRowCountOnDealerOrGrowerOrder();
        if (isTheDestinationGrowerFromSameDealer) {
            
            //step 2: navigate to transfer-products page
            await orderPage.navigateToTransferProductOnSameDealer();

            //step 3: enter transfering product details (such as units, etc.,)
            transferProductPage = await StepPageHelper.getProductTransferSameDealerPage();
            //while(! (await transferProductPage.isPageStable()));
            fixture.logger.info(`about to start ELSE - selectUpdatedSeller`);
            await transferProductPage.selectUpdatedSeller(updatedSeller.name.trim());

            //const destinationGrower = StepDataHelper.getSingleTestDataRecordForType(TestDataType.GrowerDetails, recordDetail.destinationGrower) as GrowerDetails;
            //fixture.logger.info(`done with destinationGrower`);
            await transferProductPage.selectTargetGrower(destinationGrower, targetOrderId);

            checkDeliveryDate = false;
            transferModifications.deliveryDate = "";
        } else {
            //step 2: navigate to transfer-products page
            await orderPage.navigateToTransferProductToDifferentDealer();

            //step 3: enter transfering product details (such as units, etc.,)
            transferProductPage = await StepPageHelper.getProductTransferAnotherDealerPage();
            //const destinationDealer = StepDataHelper.getSingleTestDataRecordForType(TestDataType.AccountDetailsForOrderModification, recordDetail.destinationDealer) as AccountDetailsForOrderModification;
            let destinationDealer = new AccountDetailsForOrderModification();
            destinationDealer.number = targetGrowerData.shipToAccount.toString();
            destinationDealer.name = targetGrowerData.dealerName;

            await transferProductPage.selectTargetDealer(destinationDealer);
            fixture.logger.info(`done with destinationDealer`);
            //await transferProductPage.selectTargetGrower(destinationDealer.relatedGrower);
            await transferProductPage.selectTargetGrower(destinationGrower);
            fixture.logger.info(`done with destination dealer's relatedGrower`);
            if(updatedSeller.name != null && updatedSeller.name.length > 0)
                await transferProductPage.selectUpdatedSeller(updatedSeller.name.trim());
            await transferProductPage.fillCustomerPO(transferModifications.customerPO.trim());
        }

        fixture.logger.info(`about to start ELSE - fillOrderOtherDetails`);
        await transferProductPage.fillOrderOtherDetails();
        fixture.logger.info(`about to start filling product quantities`);

        if (transferModifications.units == undefined || transferModifications.units.length == 0)
            transferModifications.units = "10";

        if (screenValidationOnly) {
            let res = await transferProductPage.verifyLineItemsButtonsFunctionality(existingProductRowCount, transferringProductNames.length, checkDeliveryDate);
            sharedSteps.validateStepActionResult(res, 'failed to verify units functionality on product transfer page');

            const fromOrderId = fixture.dataBag.getData(DataBagKeys.ORDER_ID) as string;
            res = await transferProductPage.verifyOrderIdsDisplay(fromOrderId, targetOrderId);
            sharedSteps.validateStepActionResult(res, 'failed to verify order IDs display on product transfer page');

            res = await transferProductPage.canClickTransfer();
            sharedSteps.validateStepActionResult(res, 'failed to verify transfer-units button status on product transfer page');

            await transferProductPage.closeTransferProductsPage();
        } else {
            await transferProductPage.fillLineItemDetails_obsolete(existingProductRowCount, transferringProductNames, transferModifications);

            //step 4: complete transfer process (click the button)
            const transferMsg = await transferProductPage.clickTransfer();
            const transferBtnVisibleStatus = await transferProductPage.isTransferButtonVisible();
            fixture.dataBag.saveData(DataBagKeys.OPERATION_COMPLETION_MESSAGE, transferMsg);
            fixture.dataBag.saveData(DataBagKeys.TRANSFER_BUTTON_STATUS, transferBtnVisibleStatus);
        }
    } catch (error) {
        result = false;
        fixture.logger.error("failed to transfer products on Order page. Error: " + error);
    }
    expect(result).toBeTruthy();
    fixture.logger.info(`transferProducts completed`);
}

async function transferProducts(isTheDestinationGrowerFromSameDealer: boolean, shouldTransferToExistingOrder: boolean, screenValidationOnly: boolean = false
    ,targetOrderId: string = ""
) {
    fixture.logger.info(`transferProducts started`);
    let result = true;
    try {
        const sharedSteps = new SharedSteps();
        //step 1: select products to transfer on the order page
        await sharedSteps.updateOrderIfModifiedDuringNavigation();
        fixture.logger.info(`done with lineItemAddedDuringNavigation`);

        const destinationGrower = new GrowerDetails();
        destinationGrower.name = fixture.dataBag.getData(DataBagKeys.TARGET_GROWER_NAME) as string;
        destinationGrower.growerGMK = (fixture.dataBag.getData(DataBagKeys.TARGET_GROWER_GMK) as number).toString();
        
        if (shouldTransferToExistingOrder) {
            fixture.dataBag.saveData(DataBagKeys.TARGET_ORDER_ID_FOR_TRANSFER, targetOrderId);
            fixture.logger.info(`transfer will be to existing order - ${targetOrderId}`);
        } else
            fixture.logger.info(`transfer will be to new order`);

        let productsToTransfer: ProductInfo[] = [];
        let product =  new ProductInfo();
        product.itemNumber = fixture.dataBag.getData(DataBagKeys.SOURCE_PRODUCT_ITEM_NUMBER_TO_USE) as string; 
        productsToTransfer.push(product);

        //call API to get the seller info
        let updatedSeller = new SellerInfo();
        let srcDealerAccountNumber = fixture.dataBag.getData(DataBagKeys.SOURCE_DEALER_ACCOUNT_NUMBER) as string;
        let trgtDealerAccountNumber = fixture.dataBag.getData(DataBagKeys.TARGET_DEALER_ACCOUNT_NUMBER) as string;
        let dealerAccForSeller = isTheDestinationGrowerFromSameDealer ? srcDealerAccountNumber : trgtDealerAccountNumber;
        
        const sellerDetails = await StepDataHelper.getSeller(dealerAccForSeller);
        updatedSeller.name = sellerDetails != null ? sellerDetails.accountName : "";

        const transferModifications = new ProductOrderInfo();
        transferModifications.units = (fixture.dataBag.getData(DataBagKeys.PRODUCT_CONVERSION_OR_MIN_TRANSFERRABLE_QTY_OR_ORDER_QTY) as number).toString();
        transferModifications.customerPO = "qa-automation-" + DateHelper.getUniqueNumberBasedOnDate();
        fixture.logger.info(`done with transferModifications`);
        /*
        const sharedSteps = new SharedSteps();
        //step 1: select products to transfer on the order page
        const lineItemAddedDuringNavigation = await sharedSteps.updateOrderIfModifiedDuringNavigation();
        fixture.logger.info(`done with lineItemAddedDuringNavigation`);
        */
        const sharedBehavior = await StepPageHelper.getSharedPageBehavior();
        //const transferringProductNames: string[] = [];
        
        await sharedBehavior.selectOrderProductLineItemsByItemNumber(productsToTransfer);
        const orderPage = await StepPageHelper.getAddGrowerOrderPage();
        let transferProductPage: ProductTransferSameDealerPage | ProductTransferAnotherDealerPage;
        //let checkDeliveryDate: boolean = true;

        const existingProductRowCount = await sharedBehavior.getExistingProductRowCountOnDealerOrGrowerOrder();
        transferModifications.deliveryDate = "";
        if (isTheDestinationGrowerFromSameDealer) {
            
            //step 2: navigate to transfer-products page
            await orderPage.navigateToTransferProductOnSameDealer();

            //step 3: enter transfering product details (such as units, etc.,)
            transferProductPage = await StepPageHelper.getProductTransferSameDealerPage();
            //while(! (await transferProductPage.isPageStable()));
            fixture.logger.info(`about to start ELSE - selectUpdatedSeller`);
            await transferProductPage.selectUpdatedSeller(updatedSeller.name.trim());

            //const destinationGrower = StepDataHelper.getSingleTestDataRecordForType(TestDataType.GrowerDetails, recordDetail.destinationGrower) as GrowerDetails;
            //fixture.logger.info(`done with destinationGrower`);
            await transferProductPage.selectTargetGrower(destinationGrower, targetOrderId);

            //checkDeliveryDate = false;
            //transferModifications.deliveryDate = "";
        } else {
            //step 2: navigate to transfer-products page
            await orderPage.navigateToTransferProductToDifferentDealer();

            //step 3: enter transfering product details (such as units, etc.,)
            transferProductPage = await StepPageHelper.getProductTransferAnotherDealerPage();
            //const destinationDealer = StepDataHelper.getSingleTestDataRecordForType(TestDataType.AccountDetailsForOrderModification, recordDetail.destinationDealer) as AccountDetailsForOrderModification;
            let destinationDealer = new AccountDetailsForOrderModification();
            //destinationDealer.number = targetGrowerData.shipToAccount.toString();
            //destinationDealer.name = targetGrowerData.dealerName;
            destinationDealer.number = trgtDealerAccountNumber;

            await transferProductPage.selectTargetDealer(destinationDealer);
            fixture.logger.info(`done with destinationDealer`);
            //await transferProductPage.selectTargetGrower(destinationDealer.relatedGrower);
            await transferProductPage.selectTargetGrower(destinationGrower);
            fixture.logger.info(`done with destination dealer's relatedGrower`);
            await transferProductPage.selectUpdatedSeller(updatedSeller.name.trim());
            await transferProductPage.fillCustomerPO(transferModifications.customerPO.trim());
        }

        fixture.logger.info(`about to start ELSE - fillOrderOtherDetails`);
        await transferProductPage.fillOrderOtherDetails();
        fixture.logger.info(`about to start filling product quantities`);

        if (transferModifications.units == undefined || transferModifications.units == null || transferModifications.units.length == 0)
            transferModifications.units = "10";

        await transferProductPage.fillLineItemDetails(existingProductRowCount, productsToTransfer.length, transferModifications);

        //step 4: complete transfer process (click the button)
        const transferMsg = await transferProductPage.clickTransfer();
        const transferBtnVisibleStatus = await transferProductPage.isTransferButtonVisible();
        fixture.dataBag.saveData(DataBagKeys.OPERATION_COMPLETION_MESSAGE, transferMsg);
        fixture.dataBag.saveData(DataBagKeys.TRANSFER_BUTTON_STATUS, transferBtnVisibleStatus);
    } catch (error) {
        result = false;
        fixture.logger.error("failed to transfer products on Order page. Error: " + error);
    }
    expect(result).toBeTruthy();
    fixture.logger.info(`transferProducts completed`);
}

Then('the transfer must succeed with the message {string}', async function (successMsg: string) {
    await checkTransferStatus(successMsg);
});
Then('order page must display target grower\'s existing order id', async function () {
    await checkOrderId(true);
});

Then('order page must display target grower\'s new order id', async function () {
    await checkOrderId(false);
});

Then('user should be able to transfers products to another dealer-grower having an existing order', async function (transerDetails: DataTable) {
    const targetGrowerData = fixture.dataBag.getData(DataBagKeys.ANOTHER_GROWER) as DealerGrowerInfo;
    let targetGrowerOrderId = await DataRequirementsSteps.ensureGrowerHasAnOrder(
        {accountNumber: targetGrowerData.shipToAccount.toString(), growerGMK: targetGrowerData.gmk.toString()});
    await transferProducts_obsolete(transerDetails, false, true, true, targetGrowerOrderId);
});

Then('user should be able to transfers products to another grower having an existing order', async function (transerDetails: DataTable) {
    const recordDetail = transerDetails.rowsHash();
    let dealerAccountNumber = fixture.dataBag.getData(DataBagKeys.SOURCE_DEALER_ACCOUNT_NUMBER) as string;
    //const destinationGrower = StepDataHelper.getSingleTestDataRecordForType(TestDataType.GrowerDetails, recordDetail.destinationGrower) as GrowerDetails;
    const targetGrower = fixture.dataBag.getData(DataBagKeys.ANOTHER_GROWER) as DealerGrowerInfo;
    let targetGrowerOrderId = await DataRequirementsSteps.ensureGrowerHasAnOrder(
        //{accountNumber: dealerAccountNumber, growerGMK: destinationGrower.growerGMK});
        {accountNumber: dealerAccountNumber, growerGMK: targetGrower.gmk.toString()});
    await transferProducts_obsolete(transerDetails, true, true, true, targetGrowerOrderId);
});
async function checkTransferStatus(msg: string) {
    let result = true;
    try {
        /*const productTransferPage = await StepPageHelper.getProductTransferSameDealerPage();
        result = await productTransferPage.checkProductTransferMessageDisplay(msg);*/
        const actualTransferMsg = fixture.dataBag.getData(DataBagKeys.OPERATION_COMPLETION_MESSAGE) as string;
        if (actualTransferMsg === undefined || actualTransferMsg === null || actualTransferMsg.length === 0) {
            fixture.logger.warn('could not retrieve toast message hence skipping it and checking for "Transfer Units" butoon visibility which must be false');
            const transferBtnVisibleStatus = fixture.dataBag.getData(DataBagKeys.TRANSFER_BUTTON_STATUS) as boolean;
            expect(transferBtnVisibleStatus).toBeFalsy();
        } else {
            expect(actualTransferMsg).toContain(msg);
        }
    } catch (error) {
        result = false;
        fixture.logger.error("failed to verify product-transferred message. Error: " + error);
    }
}

async function checkOrderId(shouldExpectExistingOrder: boolean) {
    try {
        const orderPage = await StepPageHelper.getAddGrowerOrderPage();
        const orderIdUsedForTransfer = fixture.dataBag.getData(DataBagKeys.ORDER_ID) as string;
        const currentDisplayedOrderId = await orderPage.getCurrentDisplayedGrowerOrderId();
        fixture.logger.info(`order id used for transfer is...${orderIdUsedForTransfer}`);
        fixture.logger.info(`displayed order id is...${currentDisplayedOrderId}`);
        expect(currentDisplayedOrderId == orderIdUsedForTransfer).toBeFalsy();
        if (shouldExpectExistingOrder) {
            const targetOrderId = fixture.dataBag.getData(DataBagKeys.TARGET_ORDER_ID_FOR_TRANSFER) as string;
            fixture.logger.info(`target order id is...${targetOrderId}`);
            expect(currentDisplayedOrderId == targetOrderId).toBeTruthy();
        }
    } catch (error) {
        fixture.logger.error("failed to verify order id on Order page. Error: " + error);
    }
}