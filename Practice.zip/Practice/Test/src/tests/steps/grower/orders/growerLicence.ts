import { When, Then, setDefaultTimeout } from "@cucumber/cucumber";
import { expect } from "@playwright/test";
import { fixture } from "../../../../hooks/fixture";
import StepPageHelper from "../../stepPageHelper";
import DataBagKeys from "../../dataBagKeys";
import GrowerOrderPage from "../../../../pages/seed/orders/grower/growerOrderPage";
 
setDefaultTimeout(60 * 1000);
 
// Navigate to Grower Orders
// When("user navigates to Grower Orders", async function () {
//     const growerOrderPage = await StepPageHelper.getAddGrowerOrderPage();
//     await growerOrderPage.navigateToGrowerOrders();
// });
 
// Verify Grower Orders screen
Then("the Grower Orders screen should be displayed", async function () {
    const growerOrderPage = await StepPageHelper.getAddGrowerOrderPage();
    //expect(await growerOrderPage.isGrowerOrdersPageDisplayed()).toBeTruthy();
    expect(await growerOrderPage.isPageStable()).toBeTruthy();
});
 
// // Verify License Status column
// Then("the License Status column should be displayed", async function () {
//     const growerOrderPage = await StepPageHelper.getAddGrowerOrderPage();
//     expect(await growerOrderPage.isLicenseStatusColumnDisplayed()).toBeTruthy();
// });
 
// // Verify a specific License Status
// Then(
//     'the Grower Orders should contain a grower with License Status {string}',
//     async function (licenseStatus: string) {
//         const growerOrderPage = await StepPageHelper.getAddGrowerOrderPage();
 
//         expect(
//             await growerOrderPage.isLicenseStatusDisplayed(licenseStatus)
//         ).toBeTruthy();
//     }
// );
 
// // Verify Equiv Units
// Then("the Equiv Units (BG) should be displayed", async function () {
//     const growerOrderPage = await StepPageHelper.getAddGrowerOrderPage();
//     expect(await growerOrderPage.isEquivUnitsDisplayed()).toBeTruthy();
// });
 
// // Verify Last Updated
// Then("the Last Updated date should be displayed", async function () {
//     const growerOrderPage = await StepPageHelper.getAddGrowerOrderPage();
//     expect(await growerOrderPage.isLastUpdatedDisplayed()).toBeTruthy();
// });
 
// // Verify Items per page
// Then(
//     'the "Items per page" should display {string}',
//     async function (itemsPerPage: string) {
//         const growerOrderPage = await StepPageHelper.getAddGrowerOrderPage();
 
//         expect(
//             await growerOrderPage.getItemsPerPage()
//         ).toBe(itemsPerPage);
//     }
// );
 
// // Capture Grower Order ID
// When(
//     'user captures the Grower Order ID from the selected order',
//     async function () {
//         const growerOrderPage = await StepPageHelper.getAddGrowerOrderPage();
 
//         const orderId = await growerOrderPage.getSelectedGrowerOrderId();
 
//         fixture.dataBag.saveData(DataBagKeys.ORDER_ID, orderId);
//     }
// );
 
// // Click Grower License link
// When('user clicks on the "Grower License" link', async function () {
//     const growerOrderPage = await StepPageHelper.getAddGrowerOrderPage();
 
//     await growerOrderPage.clickGrowerLicenseLink();
// });
 
// // Verify Grower License page
// Then(
//     "the Grower License page should open in the same tab",
//     async function () {
//         const growerOrderPage = await StepPageHelper.getAddGrowerOrderPage();
 
//         expect(
//             await growerOrderPage.isGrowerLicensePageDisplayed()
//         ).toBeTruthy();
//     }
// );
 
// // Verify Grower Order Number
// Then("the Grower Order Number should be displayed", async function () {
//     const growerOrderPage = await StepPageHelper.getAddGrowerOrderPage();
 
//     expect(
//         await growerOrderPage.getGrowerOrderNumber()
//     ).toBeTruthy();
// });
 
// // Compare Grower Order ID with Grower Order Number
// Then(
//     "the Grower Order Number should match the captured Grower Order ID",
//     async function () {
//         const growerOrderPage = await StepPageHelper.getAddGrowerOrderPage();
 
//         const capturedOrderId =
//             fixture.dataBag.getData(DataBagKeys.ORDER_ID) as string;
 
//         const growerOrderNumber =
//             await growerOrderPage.getGrowerOrderNumber();
 
//         expect(growerOrderNumber).toBe(capturedOrderId);
//     }
// );