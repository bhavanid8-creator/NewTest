/*eslint @typescript-eslint/no-unsafe-argument: "off" */
/*eslint @typescript-eslint/no-unsafe-assignment: "off" */
/*eslint @typescript-eslint/no-unsafe-call: "off" */
/*eslint @typescript-eslint/no-unsafe-member-access: "off" */
const { format } = require('date-fns');
import { Given, setDefaultTimeout, When } from "@cucumber/cucumber";

import { fixture } from "../../../../hooks/fixture";
import { expect } from "@playwright/test";
import StepDataHelper from "../../stepDataHelper";
import { TestDataType } from "../../../../helpers/util/test-data/TestDataType";
import AccountDetailsForOrderModification from "../../../../helpers/util/test-data/grower/accountDetailsForOrderModification";
import ProductOrderLineItemInfo from "../../../../helpers/util/test-data/productOrder/productOrderLineItemInfo";
import AddProductsToOrderPageSteps from "../../addProductsToOrderPageSteps";
import ProductToAddOrDeleteOrUpdate from "../../../../helpers/util/test-data/productOrder/productToAddOrDeleteOrUpdate";
import ProductOrderInfo from "../../../../helpers/util/test-data/productOrder/productOrderInfo";
import DataBagKeys from "../../dataBagKeys";
import StepPageHelper from "../../stepPageHelper";
import GrowerOrderPage from "../../../../pages/seed/orders/grower/growerOrderPage";
import GrowerDetails from "../../../../helpers/util/test-data/grower/growerDetails";
import VerifyProductCatalog from "../../../../helpers/util/test-data/product/verifyProductCatalog";
import ProductFilter from "../../../../helpers/util/test-data/product/productFilter";
import ProductChangeInfo from "../../../../helpers/util/api/models/productChangeInfo";
import DateHelper from "../../../../helpers/types/dateHelper";
import ProductInfo from "../../../../helpers/util/test-data/product/productInfo";
import DealerGrowerInfo from "../../../../helpers/util/api/models/dealerGrowerInfo";
import SharedSteps from "../../sharedSteps";
import AccountDetails from "../../../../helpers/util/test-data/dealer/accountDetails";

setDefaultTimeout(60 * 1000 * 2)

Given('user navigates to the order {string}', async function (orderAccountInfo: string) {
    await navigateToGrowerOrder_obsolete({orderAccountInfo: orderAccountInfo});
});

Given('user navigates to the order {string} for the product modification with the option {string}', async function (orderAccountInfo: string, option: string) {
    await navigateToGrowerOrder_obsolete({orderAccountInfo: orderAccountInfo, productModificationOption: option});
});

Given('user navigates to the order for the product modification', async function () {
    const accountNumber = fixture.dataBag.getData(DataBagKeys.SOURCE_DEALER_ACCOUNT_NUMBER) as number;
    const gMK = fixture.dataBag.getData(DataBagKeys.SOURCE_GROWER_GMK) as number;
    const growerOrderNumber = fixture.dataBag.getData(DataBagKeys.SOURCE_GROWER_ORDER_NUMBER) as string;
    const productModificationOption = fixture.dataBag.getData(DataBagKeys.MODIFICATION_OPTION) as string;
    const growerName = fixture.dataBag.getData(DataBagKeys.SOURCE_GROWER_NAME) as string;
    await navigateToGrowerOrderForProductModification({dealerAccountNumber: accountNumber, growerGMK: gMK, growerName: growerName, growerOrderNumber: growerOrderNumber, productModificationOption: productModificationOption});
});

Given('user navigates to the order {string} for product transfer', async function (orderAccountInfo: string) {
    await navigateToGrowerOrder_obsolete({orderAccountInfo: orderAccountInfo, isOperationGrowerProductTransfer: true, isGrowerProductTransferWithinDealer: true});
});

Given('user navigates to the order for product transfer', async function () {
    const accountNumber = fixture.dataBag.getData(DataBagKeys.SOURCE_DEALER_ACCOUNT_NUMBER) as number;
    const gMK = fixture.dataBag.getData(DataBagKeys.SOURCE_GROWER_GMK) as number;
    const growerOrderNumber = fixture.dataBag.getData(DataBagKeys.SOURCE_GROWER_ORDER_NUMBER) as string;
    const growerName = fixture.dataBag.getData(DataBagKeys.SOURCE_GROWER_NAME) as string;
    await navigateToGrowerOrderForProductModification({dealerAccountNumber: accountNumber, growerGMK: gMK, growerName: growerName, growerOrderNumber: growerOrderNumber, isOperationGrowerProductTransfer: true});
});

Given('user navigates to the grower order for updating order', async function () {
    const accountNumber = fixture.dataBag.getData(DataBagKeys.SOURCE_DEALER_ACCOUNT_NUMBER) as number;
    const gMK = fixture.dataBag.getData(DataBagKeys.SOURCE_GROWER_GMK) as number;
    const growerOrderNumber = fixture.dataBag.getData(DataBagKeys.SOURCE_GROWER_ORDER_NUMBER) as string;
    await navigateToGrowerOrderForUpdate({dealerAccountNumber: accountNumber, growerGMK: gMK, growerName: "", growerOrderNumber: growerOrderNumber});
});

async function navigateToGrowerOrderForUpdate(navigationData: {dealerAccountNumber: number; growerGMK: number; growerName: string; growerOrderNumber: string; }){
    let result = true;
    try {
        let orderAccountsData: AccountDetailsForOrderModification = new AccountDetailsForOrderModification();
        orderAccountsData.number = navigationData.dealerAccountNumber.toString();
        orderAccountsData.relatedGrower = new GrowerDetails();
        orderAccountsData.relatedGrower.growerGMK = navigationData.growerGMK.toString();
        orderAccountsData.relatedGrower.name = navigationData.growerName;

        const headerNavigationPage = await StepPageHelper.getHeaderNavigationPage();
        await headerNavigationPage.navigateToSeedOrdersPage();

        const seedOrdersPage = await StepPageHelper.getSeedOrdersPage();
        
        await seedOrdersPage.selectDealer(orderAccountsData.number);
        fixture.logger.info(`dealer with account number - ${orderAccountsData.number} - selected`);
        
        /*const growerName = await seedOrdersPage.getGrowerNameFromTheDropdown(orderAccountsData.relatedGrower.growerGMK);
        fixture.dataBag.saveData(DataBagKeys.SOURCE_GROWER_NAME, growerName);
        orderAccountsData.relatedGrower.name = growerName;*/

        await seedOrdersPage.selectGrower(orderAccountsData.relatedGrower.growerGMK);
        fixture.logger.info(`grower with GMK - ${orderAccountsData.relatedGrower.growerGMK} selected`);
        orderAccountsData.orderIdToUpdate = navigationData.growerOrderNumber;
        fixture.dataBag.saveData(DataBagKeys.ORDER_ID, orderAccountsData.orderIdToUpdate);
        fixture.logger.info(`Grower order id that will be used for the scenario is - ${orderAccountsData.orderIdToUpdate}`);

        const productFilter = getGrowerProductFilterByItemNumber();

        let skipNavigationCheck = (orderAccountsData.relatedGrower.name == null || orderAccountsData.relatedGrower.name.length == 0); 
        let userCanNavigateToOrder = true;
        if(!skipNavigationCheck)
            userCanNavigateToOrder = await seedOrdersPage.canNavigateToOrder(orderAccountsData.relatedGrower.name);
        
        let growerOrderPage: GrowerOrderPage;
        if(!userCanNavigateToOrder)//we successfully selected dealer and grower 
        //but it seems there is no line item in the order so let us add. 
        {
            fixture.logger.warn(`specified order ${orderAccountsData.orderIdToUpdate} exists but it has no products and hence going to add a new line item`);
            await seedOrdersPage.clickCreateNewGrowerOrderButton(); //when we go to the page, we expect dealer account was already selected so we skip selecting that account
            
            growerOrderPage = await StepPageHelper.getAddGrowerOrderPage();
            await growerOrderPage.selectGrowerFromDropDown(orderAccountsData.relatedGrower);
            await addProductToTheOrder(orderAccountsData.orderIdToUpdate, productFilter);
        }
        else 
        {
            await seedOrdersPage.goToUpdateOrderPage(orderAccountsData);
            growerOrderPage = await StepPageHelper.getAddGrowerOrderPage();
            const orderIsEditable = await growerOrderPage.isOrderEditable();
            fixture.logger.info(`is order - ${orderAccountsData.orderIdToUpdate} - editable: ${orderIsEditable}`);
            expect(orderIsEditable).toBeTruthy();

            let actualOperationType = fixture.dataBag.getData(DataBagKeys.ORDER_UPDATE_TYPE) as string;
            if (actualOperationType == "DeleteProduct")//if this is delete operation, first we need to add the product to the order before deleting it
            {
                await addProductToTheGrowerOrder(orderAccountsData.orderIdToUpdate, productFilter);
                await updateOrder();
            }
        }
    } catch (error) {
        result = false;
        fixture.logger.error("failed to navigate to existing grower order page. Error: " + error);
    }
    expect(result).toBeTruthy();
}

Given('user navigates to the new grower order', async function () {
    const accountNumber = fixture.dataBag.getData(DataBagKeys.SOURCE_DEALER_ACCOUNT_NUMBER) as number;
    const gMK = fixture.dataBag.getData(DataBagKeys.SOURCE_GROWER_GMK) as number;
    await navigateToGrowerOrderForCreate({dealerAccountNumber: accountNumber, growerGMK: gMK});
    /*const addGrowerOrderPage = await StepPageHelper.getAddGrowerOrderPage();
    await addGrowerOrderPage.navigateToAddProductsPage();*/
});

Given('user opens add-products page', async function () {
    const addGrowerOrderPage = await StepPageHelper.getAddGrowerOrderPage();
    await addGrowerOrderPage.navigateToAddProductsPage();
});

async function navigateToGrowerOrderForCreate(navigationData: {dealerAccountNumber: number; growerGMK: number; }){
    let result = true;
    try {
        /*let orderAccountsData: AccountDetailsForOrderModification = new AccountDetailsForOrderModification();
        orderAccountsData.number = navigationData.dealerAccountNumber.toString();
        orderAccountsData.relatedGrower = new GrowerDetails();
        orderAccountsData.relatedGrower.growerGMK = navigationData.growerGMK.toString();*/

        const headerNavigationPage = await StepPageHelper.getHeaderNavigationPage();
        await headerNavigationPage.navigateToSeedOrdersPage();

        const seedOrdersPage = await StepPageHelper.getSeedOrdersPage();
        
        await seedOrdersPage.clickCreateNewGrowerOrderButton();
        const addGrowerOrderPage = await StepPageHelper.getAddGrowerOrderPage();

        let accountDetails = new AccountDetails();
        accountDetails.number = navigationData.dealerAccountNumber.toString();

        let growerDetails = new GrowerDetails();
        growerDetails.growerGMK = navigationData.growerGMK.toString();
        growerDetails.name = navigationData.growerGMK.toString(); //temporary assignment
        await addGrowerOrderPage.selectAccountFromDropDown(accountDetails);
        await addGrowerOrderPage.selectGrowerFromDropDown(growerDetails);    
    } catch (error) {
        result = false;
        fixture.logger.error("failed to navigate to existing grower order page. Error: " + error);
    }
    expect(result).toBeTruthy();
}

function getGrowerProductFilterByItemNumber(): ProductFilter {
    const itemNumber = fixture.dataBag.getData(DataBagKeys.SOURCE_PRODUCT_ITEM_NUMBER_TO_USE) as string;
    const sharedSteps = new SharedSteps();
    return sharedSteps.getProductFilterDataByItemNumber(itemNumber);
}

async function addProductToTheGrowerOrder(orderIdToUpdate: string, productFilter: ProductFilter){
    const sourceProductItemNumber = fixture.dataBag.getData(DataBagKeys.SOURCE_PRODUCT_ITEM_NUMBER_TO_USE) as string;
    const productQty = fixture.dataBag.getData(DataBagKeys.PRODUCT_CONVERSION_OR_MIN_TRANSFERRABLE_QTY_OR_ORDER_QTY) as number;
    await addProductToTheOrder(orderIdToUpdate, productFilter, sourceProductItemNumber, productQty * 20);
}

Given('user navigates to the order {string} for product transfer to another dealer', async function (orderAccountInfo: string) {
    fixture.logger.info('product transfer to another dealer-grower');
    await navigateToGrowerOrder_obsolete({orderAccountInfo: orderAccountInfo, isOperationGrowerProductTransfer: true, isGrowerProductTransferWithinDealer: false});
});

async function navigateToGrowerOrder_obsolete(navigationData: {orderAccountInfo: string; productModificationOption?: string; isOperationGrowerProductTransfer?: boolean; isGrowerProductTransferWithinDealer?: boolean;}){
    let result = true;
    let growersRecordCount = 1;
    let growerData: DealerGrowerInfo[] = [];
    let getGrowersFromDifferentDealers = false;
    try {
        const orderAccountsData = StepDataHelper.getSingleTestDataRecordForType(TestDataType.AccountDetailsForOrderModification, navigationData.orderAccountInfo) as AccountDetailsForOrderModification;
        
        //fill the data by calling the API
        
        if (navigationData.isOperationGrowerProductTransfer) {
            growersRecordCount = 2;
            if (!navigationData.isGrowerProductTransferWithinDealer) {
                getGrowersFromDifferentDealers = true;
            }
        }
        fixture.logger.info(`value of getGrowersFromDifferentDealers - ${getGrowersFromDifferentDealers}`);
        growerData = await StepDataHelper.getGrowersWithExistingOrder("0", growersRecordCount, getGrowersFromDifferentDealers);
        orderAccountsData.number = growerData[0].shipToAccount.toString();
        orderAccountsData.name = growerData[0].dealerName;
        orderAccountsData.relatedGrower = new GrowerDetails();
        orderAccountsData.relatedGrower.name = growerData[0].growerName;
        let tempAddress = "";
        if(growerData[0].address1 !== undefined && growerData[0].address1 !== null && growerData[0].address1.length > 0){
            tempAddress = growerData[0].address1;
        }

        if(growerData[0].city !== undefined && growerData[0].city !== null && growerData[0].city.length > 0){
            if(tempAddress !== "")
                tempAddress = tempAddress + ", " + growerData[0].city;
            else
                tempAddress = growerData[0].city;
        }
        if(growerData[0].state !== undefined && growerData[0].state !== null && growerData[0].state.length > 0){
            if(tempAddress !== "")
                tempAddress = tempAddress + ", " + growerData[0].state;
            else
                tempAddress = growerData[0].state;
        }
        if(growerData[0].zip !== undefined && growerData[0].zip !== null && growerData[0].zip.length > 0){
            if(tempAddress !== "")
                tempAddress = tempAddress + " - " + growerData[0].zip;
            else
                tempAddress = growerData[0].zip;
        }
        orderAccountsData.relatedGrower.address = tempAddress;
        orderAccountsData.relatedGrower.growerGMK = growerData[0].gmk.toString();
        orderAccountsData.relatedGrower.growerGLN = growerData[0].gln;
        /*
        await DataRequirementsSteps.ensureGrowerHasAnOrder(
            {accountNumber: orderAccountsData.number, growerGMK: orderAccountsData.relatedGrower.growerGMK});
        */
        fixture.dataBag.saveData(DataBagKeys.SOURCE_DEALER_ACCOUNT_NUMBER, orderAccountsData.number);
        
        const headerNavigationPage = await StepPageHelper.getHeaderNavigationPage();
        await headerNavigationPage.navigateToSeedOrdersPage();

        const seedOrdersPage = await StepPageHelper.getSeedOrdersPage();
        
        const sharedPage = await StepPageHelper.getSharedPageBehavior();

        const dealerFullDetails = sharedPage.buildAccountSelectionText(orderAccountsData);
        //await seedOrdersPage.selectDealer(orderAccountsData.name);
        await seedOrdersPage.selectDealer(orderAccountsData.number);
        fixture.logger.info(`dealer with details - ${dealerFullDetails} - selected`);

        const growerFullDetails = sharedPage.buildGrowerSelectionText(orderAccountsData.relatedGrower);
        //await seedOrdersPage.selectGrower(orderAccountsData.relatedGrower.name);
        await seedOrdersPage.selectGrower(orderAccountsData.relatedGrower.growerGMK);
        fixture.logger.info(`grower with details - ${growerFullDetails} selected`);
        
        orderAccountsData.orderIdToUpdate = await seedOrdersPage.getGrowerOrderIdFromTheSeedOrderPageTable(orderAccountsData.relatedGrower.name);
        fixture.dataBag.saveData(DataBagKeys.ORDER_ID, orderAccountsData.orderIdToUpdate);
        fixture.dataBag.saveData(DataBagKeys.ORDER_ID_FOR_API, growerData[0].growerOrderId);
        fixture.logger.info(`Grower order id that will be used for the scenario is - ${orderAccountsData.orderIdToUpdate}`);
        
        const productFilter = getProductFilterData();

        const userCanNavigateToOrder = await seedOrdersPage.canNavigateToOrder(orderAccountsData.relatedGrower.name);
        let growerOrderPage: GrowerOrderPage;
        if(!userCanNavigateToOrder)//we successfully selected dealer and grower 
        //but it seems there is no line item in the order so let us add. 
        {
            fixture.logger.warn(`specified order ${orderAccountsData.orderIdToUpdate} exists but it has no products and hence going to add a new line item`);
            await seedOrdersPage.clickCreateNewGrowerOrderButton(); //when we go to the page, we expect dealer account was already selected so we skip selecting that account
            
            growerOrderPage = await StepPageHelper.getAddGrowerOrderPage();
            await growerOrderPage.selectGrowerFromDropDown(orderAccountsData.relatedGrower);
            //const productToAddDetails = StepDataHelper.getSingleTestDataRecordForType(TestDataType.ProductToAddOrDeleteOrUpdate, lineItemInfo) as ProductToAddOrDeleteOrUpdate;
            //await addLineItemToTheOrder(productToAddDetails, orderAccountsData.orderIdToUpdate);
            await addProductToTheOrder_obsolete(orderAccountsData.orderIdToUpdate, productFilter);
        }
        else 
        {
            await seedOrdersPage.goToUpdateOrderPage(orderAccountsData);
            growerOrderPage = await StepPageHelper.getAddGrowerOrderPage();
            const orderIsEditable = await growerOrderPage.isOrderEditable();
            fixture.logger.info(`is order - ${orderAccountsData.orderIdToUpdate} - editable: ${orderIsEditable}`);
            expect(orderIsEditable).toBeTruthy();

            if(navigationData.productModificationOption !== undefined && navigationData.productModificationOption !== null && navigationData.productModificationOption.length > 0){
                //scenario is modifying product so ensure the order has right products on the order
                const modificationDetails = await StepDataHelper.getModifiableProductForGrower(parseInt(orderAccountsData.number), navigationData.productModificationOption, productFilter);
                fixture.dataBag.saveData(DataBagKeys.PRODUCT_MODIFICATION_ORIGINAL_PRODUCT, modificationDetails.product);
                fixture.dataBag.saveData(DataBagKeys.PRODUCT_MODIFICATION_REPLACEMENT_PRODUCT, modificationDetails.modifyingProduct);
                await addProductToTheOrder_obsolete(orderAccountsData.orderIdToUpdate, productFilter, modificationDetails.product.itemDescription, modificationDetails.modifyingProduct.conv * 20);
                fixture.dataBag.saveData(DataBagKeys.MODIFICATION_OPTION, navigationData.productModificationOption);
            }
        }
    } catch (error) {
        result = false;
        fixture.logger.error("failed to navigate to existing grower order page. Error: " + error);
    }
    expect(result).toBeTruthy();
    if(navigationData.isOperationGrowerProductTransfer){
        let targetGrower: DealerGrowerInfo;
        fixture.logger.info(`growerData length is...${growerData.length}`);
        if (!navigationData.isGrowerProductTransferWithinDealer) { 
            fixture.logger.info('grower proudct transfer is outside dealer network');
            targetGrower = growerData.filter(g => g.gmk !== growerData[0].gmk && g.shipToAccount != growerData[0].shipToAccount)[0];
            fixture.logger.info(`targetGrower is...${JSON.stringify(targetGrower)}`);
        } else {
            fixture.logger.info('grower proudct transfer is inside dealer network');
            fixture.logger.info(`first grower is...${JSON.stringify(growerData[0])}`);
            fixture.logger.info(`second grower is...${JSON.stringify(growerData[1])}`);
            const temp = growerData.filter(g => g.gmk !== growerData[0].gmk && g.shipToAccount == growerData[0].shipToAccount);
            targetGrower = temp[0];
            fixture.logger.info(`targetGrower is...${JSON.stringify(targetGrower)}`);
        }
        fixture.dataBag.saveData(DataBagKeys.ANOTHER_GROWER, targetGrower);
        fixture.logger.info(`to transfer products , target grower name is - ${targetGrower.growerName} and GMK is - ${targetGrower.gmk}`);
    }
}

async function navigateToGrowerOrderForProductModification(navigationData: {dealerAccountNumber: number; growerGMK: number; growerName: string; growerOrderNumber: string; productModificationOption?: string; isOperationGrowerProductTransfer?: boolean; isGrowerProductTransferWithinDealer?: boolean;}){
    let result = true;
    try {
        let orderAccountsData: AccountDetailsForOrderModification = new AccountDetailsForOrderModification();
        orderAccountsData.number = navigationData.dealerAccountNumber.toString();
        orderAccountsData.relatedGrower = new GrowerDetails();
        orderAccountsData.relatedGrower.growerGMK = navigationData.growerGMK.toString();
        orderAccountsData.relatedGrower.name = navigationData.growerName;

        const headerNavigationPage = await StepPageHelper.getHeaderNavigationPage();
        await headerNavigationPage.navigateToSeedOrdersPage();

        const seedOrdersPage = await StepPageHelper.getSeedOrdersPage();
        
        await seedOrdersPage.selectDealer(orderAccountsData.number);
        fixture.logger.info(`dealer with account number - ${orderAccountsData.number} - selected`);
        
        /*const growerName = await seedOrdersPage.getGrowerNameFromTheDropdown(orderAccountsData.relatedGrower.growerGMK);
        fixture.dataBag.saveData(DataBagKeys.SOURCE_GROWER_NAME, growerName);
        orderAccountsData.relatedGrower.name = growerName;*/

        await seedOrdersPage.selectGrower(orderAccountsData.relatedGrower.growerGMK);
        fixture.logger.info(`grower with GMK - ${orderAccountsData.relatedGrower.growerGMK} selected`);
        orderAccountsData.orderIdToUpdate = navigationData.growerOrderNumber;
        fixture.dataBag.saveData(DataBagKeys.ORDER_ID, orderAccountsData.orderIdToUpdate);
        fixture.logger.info(`Grower order id that will be used for the scenario is - ${orderAccountsData.orderIdToUpdate}`);

        const itemNumber = fixture.dataBag.getData(DataBagKeys.SOURCE_PRODUCT_ITEM_NUMBER_TO_USE) as string;
        const sharedSteps = new SharedSteps();
        const productFilter = sharedSteps.getProductFilterDataByItemNumber(itemNumber);

        let skipNavigationCheck = (orderAccountsData.relatedGrower.name == null || orderAccountsData.relatedGrower.name.length == 0); 
        let userCanNavigateToOrder = true;
        if(!skipNavigationCheck)
            userCanNavigateToOrder = await seedOrdersPage.canNavigateToOrder(orderAccountsData.relatedGrower.name);
        
        let growerOrderPage: GrowerOrderPage;
        if(!userCanNavigateToOrder)//we successfully selected dealer and grower 
        //but it seems there is no line item in the order so let us add. 
        {
            fixture.logger.warn(`specified order ${orderAccountsData.orderIdToUpdate} exists but it has no products and hence going to add a new line item`);
            await seedOrdersPage.clickCreateNewGrowerOrderButton(); //when we go to the page, we expect dealer account was already selected so we skip selecting that account
            
            growerOrderPage = await StepPageHelper.getAddGrowerOrderPage();
            await growerOrderPage.selectGrowerFromDropDown(orderAccountsData.relatedGrower);
            await addProductToTheOrder(orderAccountsData.orderIdToUpdate, productFilter);
        }
        else 
        {
            await seedOrdersPage.goToUpdateOrderPage(orderAccountsData);
            growerOrderPage = await StepPageHelper.getAddGrowerOrderPage();
            const orderIsEditable = await growerOrderPage.isOrderEditable();
            fixture.logger.info(`is order - ${orderAccountsData.orderIdToUpdate} - editable: ${orderIsEditable}`);
            expect(orderIsEditable).toBeTruthy();

            //if(navigationData.productModificationOption !== undefined && navigationData.productModificationOption !== null && navigationData.productModificationOption.length > 0)
            {
                //scenario is modifying product so ensure the order has right products on the order
                const sourceProductItemNumber = fixture.dataBag.getData(DataBagKeys.SOURCE_PRODUCT_ITEM_NUMBER_TO_USE) as string;
                const productQty = fixture.dataBag.getData(DataBagKeys.PRODUCT_CONVERSION_OR_MIN_TRANSFERRABLE_QTY_OR_ORDER_QTY) as number;
                const targetProductItemNumber = fixture.dataBag.getData(DataBagKeys.TARGET_PRODUCT_ITEM_NUMBER_TO_USE) as string;
                if (targetProductItemNumber !== undefined && targetProductItemNumber !== null) {
                    const modifyingProduct = new ProductChangeInfo();
                    modifyingProduct.itemNumber = targetProductItemNumber;
                    modifyingProduct.conv = productQty;
                    fixture.dataBag.saveData(DataBagKeys.PRODUCT_MODIFICATION_REPLACEMENT_PRODUCT, modifyingProduct);
                }
                await addProductToTheOrder(orderAccountsData.orderIdToUpdate, productFilter, sourceProductItemNumber, productQty * 20);
            }
        }
    } catch (error) {
        result = false;
        fixture.logger.error("failed to navigate to existing grower order page. Error: " + error);
    }
    expect(result).toBeTruthy();
}

function getProductFilterData(): ProductFilter {
    const productFilter = new ProductFilter();
    productFilter.filterCategory = "Product Line";
    productFilter.searchKey = "ALFALFA";
    return productFilter;
}

async function addProductToTheOrder_obsolete(orderIdToUpdate: string, productFilter: ProductFilter, itemDescription: string = "", orderUnits: number = 0) {
    const productToAdd = new ProductToAddOrDeleteOrUpdate();
    productToAdd.productSelection = new VerifyProductCatalog();
    productToAdd.productSelection.filters = [productFilter];
    productToAdd.productSelection.onlyShowProductOnDealerOrder = false;
    productToAdd.productSelection.onlyShowProductWithAvailability = false;

    await addLineItemToTheOrder_obsolete(productToAdd, orderIdToUpdate, itemDescription, orderUnits);
    
    fixture.dataBag.saveData(DataBagKeys.ORDER_LINE_ITEM_ADDED_OR_MODIFIED_DURING_NAVIGATION, true);
    fixture.logger.info(`new line has been added to the order ${orderIdToUpdate} during navigation (ORDER IS NOT UPDATED YET!)`);
}

Given('user adds new line item to the order and sets line item order info', async function () {
    await addNewLineItemToTheGrowerOrderWithProperties();
});

When('user adds new line item to the order and sets order info at line item level', async function () {
    await addNewLineItemToTheGrowerOrderWithProperties();
});

async function addNewLineItemToTheGrowerOrderWithProperties() {
    let growerOrderNumber = fixture.dataBag.getData(DataBagKeys.SOURCE_GROWER_ORDER_NUMBER) as string;
    if (growerOrderNumber !== undefined) {
        fixture.logger.info(`updating existing order : ${growerOrderNumber} with a new product has started`);
        const lineItemAddedDuringNavigation = fixture.dataBag.getData(DataBagKeys.ORDER_LINE_ITEM_ADDED_OR_MODIFIED_DURING_NAVIGATION) as boolean;
        if (lineItemAddedDuringNavigation != undefined && lineItemAddedDuringNavigation) {
            fixture.logger.warn("a new line item was added during navigation hence skipping this step");
            return;
        }
    }else{
        growerOrderNumber = "";
        fixture.logger.info(`updating the new order with a new product has started`);
    }
    let result = true;
    try {
        const productFilter = getGrowerProductFilterByItemNumber();
        await addProductToTheGrowerOrder(growerOrderNumber, productFilter);
    } catch (error) {
        result = false;
        if(growerOrderNumber !=null && growerOrderNumber !== "")
            fixture.logger.error(`failed to add new line item to the order ${growerOrderNumber}. Error: ${error}`);
        else
            fixture.logger.error(`failed to add new line item to the new order. Error: ${error}`);
    }
    expect(result).toBeTruthy();
}
/**
 * This method just adds a new line item but does not complete 'Update Order' action
 * @param productToAddDetails
 * @param orderId 
 */
async function addLineItemToTheOrder_obsolete(productToAddDetails: ProductToAddOrDeleteOrUpdate, orderId: string, targetProductDescription: string = "", orderUnits: number = 0){
    const addProductsToOrderPageSteps = new AddProductsToOrderPageSteps();
    const growerOrderPage = await StepPageHelper.getAddGrowerOrderPage();

    const dealerAccountNumber = fixture.dataBag.getData(DataBagKeys.SOURCE_DEALER_ACCOUNT_NUMBER) as string;
    // step 1: adding products
    fixture.logger.info("product will be added to the order : " + orderId);
    const filterCategoryInfo: string = productToAddDetails.productSelection.filters[0].filterCategory;
    const searchKeyInfo: string = productToAddDetails.productSelection.filters[0].searchKey;
    const onlyShowProductOnDealerOrderInfo: string = productToAddDetails.productSelection.onlyShowProductOnDealerOrder.toString();
    const onlyShowProductWithAvailabilityInfo: string = productToAddDetails.productSelection.onlyShowProductWithAvailability.toString();
    //const productsInfo: string[] = [productToAddDetails.productSelection.expectedProducts[0].name]; ---> we will retrieve this using API

    productToAddDetails.productOrderInfo = new ProductOrderInfo();
    productToAddDetails.productOrderInfo.customerPO = "qa-automation-" + DateHelper.getUniqueNumberBasedOnDate();
    productToAddDetails.productOrderInfo.deliveryDate = DateHelper.getDateTimeUTC(5);
    const sellerDetails = await StepDataHelper.getSeller(dealerAccountNumber);
    productToAddDetails.productOrderInfo.seller = sellerDetails != null ? sellerDetails.accountName : "";
    productToAddDetails.productSelection.expectedProducts = [];

    const productsInfo: string[] = [];
    if (targetProductDescription.length === 0) {
        //get the product from the API
        const productsInfoTemp = await StepDataHelper.getProductsForGrower(parseInt(dealerAccountNumber), filterCategoryInfo, searchKeyInfo,
            productToAddDetails.productSelection.onlyShowProductWithAvailability, productToAddDetails.productSelection.onlyShowProductOnDealerOrder);
        if (productsInfoTemp == null || productsInfoTemp.length == 0) {
            fixture.logger.error("Could not retrieve products with selected criteria. Hence exiting from the scenario");
            expect(false).toBeTruthy();
        }
        productsInfo.push(productsInfoTemp[0].itemDescription);
        productToAddDetails.productSelection.expectedProducts[0] = productsInfoTemp[0];
        productToAddDetails.productOrderInfo.units = (productsInfoTemp[0].conversionUnits * 20).toString();
    }else {
        productsInfo.push(targetProductDescription);
        productToAddDetails.productSelection.expectedProducts[0] = fixture.dataBag.getData(DataBagKeys.PRODUCT_MODIFICATION_ORIGINAL_PRODUCT) as ProductInfo;
        productToAddDetails.productOrderInfo.units = orderUnits.toString();
    }

    await growerOrderPage.navigateToAddProductsPage();
    await addProductsToOrderPageSteps.searchForProducts(filterCategoryInfo, searchKeyInfo, onlyShowProductOnDealerOrderInfo, onlyShowProductWithAvailabilityInfo);
    await addProductsToOrderPageSteps.selectProducts(productsInfo, false);
    const msg = await addProductsToOrderPageSteps.addSelectedProductsToOrder();
    fixture.logger.info(`received message after adding products to the order is...${msg}`);
    //await growerOrderPage.checkProductsAddedMessageDisplay();
    expect(msg).not.toBeNull();
    expect(msg.length).toBeGreaterThan(0);

    // step 2: set product order info
    const orderLineItem = new ProductOrderLineItemInfo();
    orderLineItem.productInfo = productToAddDetails.productSelection.expectedProducts[0];
    orderLineItem.productOrderInfo = productToAddDetails.productOrderInfo;

    fixture.logger.info(`product order details...${orderLineItem.productOrderInfo.toString()}`);
    //await growerOrderPage.fillOrderTopLineItemDetails(orderLineItem.productOrderInfo);
    await growerOrderPage.fillLineItemDetails_obsolete(orderLineItem.productInfo.itemDescription, orderLineItem.productOrderInfo);
    fixture.logger.info(`order details have been set for the above product in the order : ${orderId}`);

    // step 3: fill other details that are common to all line items
    await growerOrderPage.fillOrderOtherDetails();
    fixture.logger.info(`order other details such as non-subscriber email, etc., have been set for the above product in the order : ${orderId}`);
}

async function addProductToTheOrder(orderIdToUpdate: string, productFilter: ProductFilter, expectedProductNumber: string = "", orderUnits: number = 0) {
    const growerOrderPage = await StepPageHelper.getAddGrowerOrderPage();
    
    let orderUpdateOperationResult:{orderContainsTheProduct: boolean, qtyIncremented: boolean};
    if (expectedProductNumber.length > 0) {
        orderUpdateOperationResult = await growerOrderPage.incrementUnitsIfLineItemAvailable(expectedProductNumber, orderUnits.toString());
    }

    let orderModified = false;
    if (!orderUpdateOperationResult.orderContainsTheProduct) {
        const productToAdd = new ProductToAddOrDeleteOrUpdate();
        productToAdd.productSelection = new VerifyProductCatalog();
        productToAdd.productSelection.filters = [productFilter];
        productToAdd.productSelection.onlyShowProductOnDealerOrder = false;
        productToAdd.productSelection.onlyShowProductWithAvailability = false;

        productToAdd.productSelection.expectedProducts = [];
        let expectedProduct = new ProductInfo();
        expectedProduct.itemNumber = expectedProductNumber;
        productToAdd.productSelection.expectedProducts.push(expectedProduct);

        productToAdd.productOrderInfo = new ProductOrderInfo();
        productToAdd.productOrderInfo.units = orderUnits.toString();
        await addLineItemToTheOrder(productToAdd, orderIdToUpdate);
        orderModified = true;
    }else if (orderUpdateOperationResult.orderContainsTheProduct && orderUpdateOperationResult.qtyIncremented) 
        orderModified = true;
    
    fixture.dataBag.saveData(DataBagKeys.ORDER_LINE_ITEM_ADDED_OR_MODIFIED_DURING_NAVIGATION, orderModified);
    if(orderModified)
    {
        if(orderIdToUpdate != null && orderIdToUpdate.length > 0)
            fixture.logger.info(`order - ${orderIdToUpdate} - line has been added or modified during navigation (ORDER IS NOT UPDATED YET!)`);
        else
            fixture.logger.info(`a line has been added to the new order`);
    }
}

/**
* This method just adds a new line item but does not complete 'Update Order' action
* @param productToAddDetails
* @param orderId 
*/
async function addLineItemToTheOrder(productToAddDetails: ProductToAddOrDeleteOrUpdate, orderId: string) {
    const addProductsToOrderPageSteps = new AddProductsToOrderPageSteps();
    const growerOrderPage = await StepPageHelper.getAddGrowerOrderPage();

    const dealerAccountNumber = fixture.dataBag.getData(DataBagKeys.SOURCE_DEALER_ACCOUNT_NUMBER) as string;
    // step 1: adding products
    if(orderId != null && orderId.length > 0)
        fixture.logger.info("product will be added to the order : " + orderId);
    else
        fixture.logger.info("adding product to the order started");

    const filterCategoryInfo: string = productToAddDetails.productSelection.filters[0].filterCategory;
    const searchKeyInfo: string = productToAddDetails.productSelection.filters[0].searchKey;
    const onlyShowProductOnDealerOrderInfo: string = productToAddDetails.productSelection.onlyShowProductOnDealerOrder.toString();
    const onlyShowProductWithAvailabilityInfo: string = productToAddDetails.productSelection.onlyShowProductWithAvailability.toString();
    await fillGrowerProductOrderInfo(productToAddDetails.productOrderInfo);
    const productsInfo: string[] = [];
    productToAddDetails.productSelection.expectedProducts.forEach((product) => {
        productsInfo.push(product.itemNumber);
    });

    await growerOrderPage.navigateToAddProductsPage();
    await addProductsToOrderPageSteps.searchForProducts(filterCategoryInfo, searchKeyInfo, onlyShowProductOnDealerOrderInfo, onlyShowProductWithAvailabilityInfo);
    await addProductsToOrderPageSteps.selectProductsByItemNumbers(productsInfo, false);
    const msg = await addProductsToOrderPageSteps.addSelectedProductsToOrder();
    fixture.logger.info(`received message after adding products to the order is...${msg}`);

    // step 2: set product order info
    const orderLineItem = new ProductOrderLineItemInfo();
    orderLineItem.productInfo = productToAddDetails.productSelection.expectedProducts[0];
    orderLineItem.productOrderInfo = productToAddDetails.productOrderInfo;

    fixture.logger.info(`product order details...${orderLineItem.productOrderInfo.toString()}`);
    await growerOrderPage.fillLineItemDetails(orderLineItem.productInfo.itemNumber, orderLineItem.productOrderInfo);
    if(orderId != null && orderId.length > 0)
        fixture.logger.info(`order details have been set for the above product in the order : ${orderId}`);
    else
        fixture.logger.info(`order details have been set for the above product in the new order`);

    // step 3: fill other details that are common to all line items
    await growerOrderPage.fillOrderOtherDetails();
    fixture.logger.info(`order other details such as non-subscriber email, etc., have been set for the above product in the order`);
}
export async function fillGrowerProductOrderInfo(productOrderInfo: ProductOrderInfo): Promise<void>{
    if (productOrderInfo === undefined || productOrderInfo === null)
        productOrderInfo = new ProductOrderInfo();
    productOrderInfo.customerPO = "qa-automation-" + DateHelper.getUniqueNumberBasedOnDate();
    //productOrderInfo.deliveryDate = DateHelper.getDateTimeUTC(5);
    productOrderInfo.deliveryDate = DateHelper.getDateTimeUTC(0); //adding extra days can cause the date to go beyond the crop year end date so always set the delivery date as today
    const dealerAccountNumber = fixture.dataBag.getData(DataBagKeys.SOURCE_DEALER_ACCOUNT_NUMBER) as number;
    const sellerDetails = await StepDataHelper.getSeller(dealerAccountNumber.toString());
    productOrderInfo.seller = sellerDetails != null ? sellerDetails.accountName : "";
}

Given('user clicks on Update-Order button', async function () {
    let result = true;
    try {
        const skipOrderUpdate = fixture.dataBag.getData(DataBagKeys.SKIP_ORDER_UPDATE) as boolean;
        if(skipOrderUpdate != undefined && skipOrderUpdate){
            return;
        }
        const msg = await updateOrder();
        fixture.dataBag.saveData(DataBagKeys.OPERATION_COMPLETION_MESSAGE, msg);
    } catch (error) {
        result = false;
        fixture.logger.error("failed to click on Update-Order button on Update-Grower-Order page. Error: " + error);
    }
    expect(result).toBeTruthy();
});

async function updateOrder(): Promise<string>{
    const addGrowerOrderPage = await StepPageHelper.getAddGrowerOrderPage();
    return await addGrowerOrderPage.placeOrUpdateOrder(false);
}

Given('user modifies products', async function () {
    let result = true;
    const orderId = fixture.dataBag.getData(DataBagKeys.ORDER_ID);
    const option = fixture.dataBag.getData(DataBagKeys.MODIFICATION_OPTION) as string;
    fixture.logger.error(`attempting to modify line items of the order ${orderId}`);
    const lineItemAddedDuringNavigation = fixture.dataBag.getData(DataBagKeys.ORDER_LINE_ITEM_ADDED_OR_MODIFIED_DURING_NAVIGATION) as boolean;
    
    try {
        if(lineItemAddedDuringNavigation != undefined && lineItemAddedDuringNavigation){
            await updateOrder();
        }
        const addGrowerOrderPage = await StepPageHelper.getAddGrowerOrderPage();
        await addGrowerOrderPage.navigateToReplaceProductPage(option, 10000);//we delay operation to ensure grower-order-updated message disappears
        fixture.logger.info(`navigated to modify-product page`);

        const replaceOrderProductPage = await StepPageHelper.getReplaceOrderProductPage();
        //while(!await replaceOrderProductPage.isPageLoaded());
        fixture.logger.info(`modify-product page loaded successfully`);

        let oneLineitemInspected = false;
        let atleastOneLineitemModified = false;
        do{
            if (oneLineitemInspected) {
                fixture.logger.info(`moving to next product`);
                await replaceOrderProductPage.moveToNextLineItem();
            }
            fixture.logger.info(`about to modify a product`);
            //const tempResult = await replaceOrderProductPage.setTopReplaceableProductQtyIfFound(quanity);
            const modifyingProduct = fixture.dataBag.getData(DataBagKeys.PRODUCT_MODIFICATION_REPLACEMENT_PRODUCT) as ProductChangeInfo;
            const tempResult = await replaceOrderProductPage.setReplaceableProductQty_obsolete(modifyingProduct);
            if(!atleastOneLineitemModified)
                atleastOneLineitemModified = tempResult;
            fixture.logger.info(`completed modification inspection for one product`);
            oneLineitemInspected = true;
        }while(await replaceOrderProductPage.isAnotherLineItemAvailable());
        fixture.logger.info(`completed modification inspection for all products; going back to order page`);
        await replaceOrderProductPage.goBackToOrder();
        if (atleastOneLineitemModified) {
            fixture.dataBag.saveData(DataBagKeys.SKIP_ORDER_UPDATE, false);
            fixture.logger.info(`about to update order with replaced products`);
        } else {
            fixture.dataBag.saveData(DataBagKeys.SKIP_ORDER_UPDATE, true);
            fixture.logger.warn(`no product is replaced and hence not updating the order`);
        }
        fixture.logger.info(`products of the order ${orderId} have been inspected for modification and replaced where applicable`);
    } catch (error) {
        result = false;
        fixture.logger.error("failed to modify/replace products on Update-Grower-Order page. Error: " + error);
    }
    expect(result).toBeTruthy();
});
Given('user modifies a product', async function () {
    let result = true;
    const orderId = fixture.dataBag.getData(DataBagKeys.ORDER_ID);
    const option = fixture.dataBag.getData(DataBagKeys.MODIFICATION_OPTION) as string;
    fixture.logger.error(`attempting to modify line items of the order ${orderId}`);
    const lineItemAddedDuringNavigation = fixture.dataBag.getData(DataBagKeys.ORDER_LINE_ITEM_ADDED_OR_MODIFIED_DURING_NAVIGATION) as boolean;
    
    try {
        if(lineItemAddedDuringNavigation != undefined && lineItemAddedDuringNavigation){
            await updateOrder();
        }
        const addGrowerOrderPage = await StepPageHelper.getAddGrowerOrderPage();
        await addGrowerOrderPage.navigateToReplaceProductPage(option, 10000);//we delay operation to ensure grower-order-updated message disappears
        fixture.logger.info(`navigated to modify-product page`);

        const replaceOrderProductPage = await StepPageHelper.getReplaceOrderProductPage();
        fixture.logger.info(`modify-product page loaded successfully`);

        let oneLineitemInspected = false;
        let atleastOneLineitemModified = false;
        do{
            if (oneLineitemInspected) {
                fixture.logger.info(`moving to next product`);
                await replaceOrderProductPage.moveToNextLineItem();
            }
            fixture.logger.info(`about to modify a product`);
            const modifyingProduct = fixture.dataBag.getData(DataBagKeys.PRODUCT_MODIFICATION_REPLACEMENT_PRODUCT) as ProductChangeInfo;
            const tempResult = await replaceOrderProductPage.setReplaceableProductQty(modifyingProduct);
            if(!atleastOneLineitemModified)
                atleastOneLineitemModified = tempResult;
            fixture.logger.info(`completed modification inspection for one product`);
            oneLineitemInspected = true;
        }while(await replaceOrderProductPage.isAnotherLineItemAvailable());
        fixture.logger.info(`completed modification inspection for all products; going back to order page`);
        await replaceOrderProductPage.goBackToOrder();
        if (atleastOneLineitemModified) {
            fixture.dataBag.saveData(DataBagKeys.SKIP_ORDER_UPDATE, false);
            fixture.logger.info(`about to update order with replaced products`);
        } else {
            fixture.dataBag.saveData(DataBagKeys.SKIP_ORDER_UPDATE, true);
            fixture.logger.warn(`no product is replaced and hence not updating the order`);
        }
        fixture.logger.info(`products of the order ${orderId} have been inspected for modification and replaced where applicable`);
    } catch (error) {
        result = false;
        fixture.logger.error("failed to modify/replace products on Update-Grower-Order page. Error: " + error);
    }
    expect(result).toBeTruthy();
});
Given('user modifies first line item', async function () {
    let result = true;
    const orderId = fixture.dataBag.getData(DataBagKeys.ORDER_ID);
    fixture.logger.error(`attempting to update one top line item from the order ${orderId}`);
    const lineItemAddedDuringNavigation = fixture.dataBag.getData(DataBagKeys.ORDER_LINE_ITEM_ADDED_OR_MODIFIED_DURING_NAVIGATION) as boolean;
    
    try {
        const addGrowerOrderPage = await StepPageHelper.getAddGrowerOrderPage();
        if(lineItemAddedDuringNavigation != undefined && lineItemAddedDuringNavigation){
            await updateOrder();
        }
        
        const updatedProductOrderInfo: ProductOrderInfo = new ProductOrderInfo();
        updatedProductOrderInfo.units = "150";
        updatedProductOrderInfo.deliveryDate = format(new Date(), addGrowerOrderPage.dateFormatInTheCalendar);
        updatedProductOrderInfo.seller = "";
        updatedProductOrderInfo.customerPO = "qa-auto-123";
        await addGrowerOrderPage.fillOrderTopLineItemDetails(updatedProductOrderInfo, 10000);//here delay is to ensure 'Grower Order #no updated successfully.' message to disappear
        fixture.logger.info(`one top line item from the order ${orderId} has been updated`);

        // fill other details that are common to all line items
        await addGrowerOrderPage.fillOrderOtherDetails();
        fixture.logger.info(`order other details such as non-subscriber email, etc., have been set for the above product in the order : ${orderId}`);
    } catch (error) {
        result = false;
        fixture.logger.error(`failed to update a line item from the order ${orderId}. Error: ${error}`);
    }
    expect(result).toBeTruthy();
});

Given('user deletes first line item', async function () {
    let result = true;
    const orderId = fixture.dataBag.getData(DataBagKeys.ORDER_ID);
    fixture.logger.error(`attempting to delete one top line item from the order ${orderId}`);
    const lineItemAddedDuringNavigation = fixture.dataBag.getData(DataBagKeys.ORDER_LINE_ITEM_ADDED_OR_MODIFIED_DURING_NAVIGATION) as boolean;
    
    try {
        if(lineItemAddedDuringNavigation != undefined && lineItemAddedDuringNavigation){
            await updateOrder();
        }
        const addGrowerOrderPage = await StepPageHelper.getAddGrowerOrderPage();
        
        await addGrowerOrderPage.deleteOrderTopLineItem();
        fixture.logger.error(`one top line item from the order ${orderId} has been deleted`);
    } catch (error) {
        result = false;
        fixture.logger.error(`failed to delete a line item from the order ${orderId}. Error: ${error}`);
    }
    expect(result).toBeTruthy();
});

