import { BrowserContextOptions, Page } from "@playwright/test";
import { fixture } from "../../hooks/fixture";
import AccountPage from "../../pages/account/accountPage";
import EmulationPage from "../../pages/emulation/emulationPage";
import SalesAndCreditOrderEnquiryPage from "../../pages/jde/salesAndCreditOrderEnquiryPage";
import HeaderNavigationPage from "../../pages/landing/headerNavigationPage";
import LoginPage from "../../pages/login/loginPage";
import SeedFulfillmentPage from "../../pages/seed/fulfillment/seedFulfillmentPage";
import AddProductsToTheOrderPage from "../../pages/seed/orders/addProductsToTheOrderPage";
import DealerOrderPage from "../../pages/seed/orders/dealer/dealerOrderPage";
import GrowerOrderPage from "../../pages/seed/orders/grower/growerOrderPage";
import ProductTransferAnotherDealerPage from "../../pages/seed/orders/grower/productTransferAnotherDealerPage";
import ProductTransferSameDealerPage from "../../pages/seed/orders/grower/productTransferSameDealerPage";
import ReplaceOrderProductPage from "../../pages/seed/orders/replaceOrderProductPage";
import SeedOrdersPage from "../../pages/seed/orders/seedOrdersPage";
import StockTransfersPage from "../../pages/seed/stock-transfers/stockTransfersPage";
import SharedPageBehavior from "../../pages/sharedPageBehavior";
import PlaywrightWrapperCommon from "../../helpers/wrapper/pwWrapperCommon";
import ProductTransferOutsideTerritoryPage from "../../pages/seed/orders/productTransferOutsideTerritoryPage";
import AddEAProductsToTheOrderPage from "../../pages/seed/orders/addEAProductsToTheOrderPage";
import DataBagKeys from "./dataBagKeys";
import CppOrdersPage from "../../pages/cpp/orders/cppOrdersPage";
import CppNewOrderPage from "../../pages/cpp/orders/cppNewOrderPage";
import AddProductsToTheCppOrderPage from "../../pages/cpp/orders/addProductsToTheCppOrderPage";
import PlacedCppOrderSummaryPage from "../../pages/cpp/orders/placedCppOrderSummaryPage";
import CppProductReturnsPage from "../../pages/cpp/returns/product/productReturnsPage";
import CppNewProductReturnPage from "../../pages/cpp/returns/product/newProductReturnPage";
import AddProductsToTheCppProductReturnPage from "../../pages/cpp/returns/product/addProductsToTheCppProductReturnPage";
import CppSubmittedReturnSummaryPage from "../../pages/cpp/returns/cppSubmittedReturnSummaryPage";
import CppInoculantReturnsPage from "../../pages/cpp/returns/inoculant/inoculantReturnsPage";
import CppNewInoculantReturnPage from "../../pages/cpp/returns/inoculant/newInoculantReturnPage";
import AddProductsToTheCppInoculantReturnPage from "../../pages/cpp/returns/inoculant/addProductsToTheCppInoculantReturnPage";
import SeedReplantPage from "../../pages/seed/replant/seedReplantPage";
import SeedReservationsListPage from "../../pages/seed/reservations/seedReservationsListPage";
import SeedReservationPage from "../../pages/seed/reservations/seedReservationPage";

export default class StepPageHelper {
    static async getSharedPageBehavior()
    {
        return await fixture.pageFactory.getPage(SharedPageBehavior, fixture.page);
    }

    static async getLoginPage(){
        return await fixture.pageFactory.getPage(LoginPage, fixture.page);
    }

    static async getHeaderNavigationPage(){
        return await fixture.pageFactory.getPage(HeaderNavigationPage, fixture.page);
    }

    static async getAccountPage(){
        return await fixture.pageFactory.getPage(AccountPage, fixture.page);
    }

    static async getEmulationPage(){
        return await fixture.pageFactory.getPage(EmulationPage, fixture.page);
    }
    static async getAddProductToTheOrderPage(){
        return await fixture.pageFactory.getPage(AddProductsToTheOrderPage, fixture.page);
    }

    static async getAddEAProductToTheOrderPage(){
        return await fixture.pageFactory.getPage(AddEAProductsToTheOrderPage, fixture.page);
    }

    static async getAddGrowerOrderPage(){
        return await fixture.pageFactory.getPage(GrowerOrderPage, fixture.page);
    }

    static async getDealerOrderPage(){
        return await fixture.pageFactory.getPage(DealerOrderPage, fixture.page);
    }
    static async getSeedOrdersPage(){
        return await fixture.pageFactory.getPage(SeedOrdersPage, fixture.page);
    }

    static async getReplaceOrderProductPage(){
        return await fixture.pageFactory.getPage(ReplaceOrderProductPage, fixture.page);
    }

    static async getProductTransferSameDealerPage(){
        return await fixture.pageFactory.getPage(ProductTransferSameDealerPage, fixture.page);
    }

    static async getProductTransferAnotherDealerPage(){
        return await fixture.pageFactory.getPage(ProductTransferAnotherDealerPage, fixture.page);
    }

    static async getProductTransferOutsideTerritoryPage(){
        return await fixture.pageFactory.getPage(ProductTransferOutsideTerritoryPage, fixture.page);
    }

    static async getStockTransfersPage(){
        return await fixture.pageFactory.getPage(StockTransfersPage, fixture.page);
    }

    static async getSeedFulfillmentPage(){
        return await fixture.pageFactory.getPage(SeedFulfillmentPage, fixture.page);
    }

    static async getJDESalesAndCreditOrderEnquiryPage(){
        /*const contextOptions: BrowserContextOptions = {};
        contextOptions.ignoreHTTPSErrors = true;
        const pwWrapperCommon = new PlaywrightWrapperCommon(fixture.page);
        const newPage = await pwWrapperCommon.getNewPageWithNewContext(contextOptions);*/
        const newPage = await fixture.page.context().newPage();
        const width = fixture.dataBag.getData(DataBagKeys.SCREEN_WIDTH) as number;
        const height = fixture.dataBag.getData(DataBagKeys.SCREEN_HEIGHT) as number;
        await newPage.setViewportSize({ width: width, height: height });
        return await fixture.pageFactory.getPage(SalesAndCreditOrderEnquiryPage, newPage);
    }

    static async getCppOrdersPage(){
        return await fixture.pageFactory.getPage(CppOrdersPage, fixture.page);
    }
    
    static async getCppProductReturnsPage(){
        return await fixture.pageFactory.getPage(CppProductReturnsPage, fixture.page);
    }

    static async getCppInoculantReturnsPage(){
        return await fixture.pageFactory.getPage(CppInoculantReturnsPage, fixture.page);
    }

    static async getCppNewOrderPage(){
        return await fixture.pageFactory.getPage(CppNewOrderPage, fixture.page);
    }

    static async getCppNewProductReturnPage(){
        return await fixture.pageFactory.getPage(CppNewProductReturnPage, fixture.page);
    }

    static async getCppNewInoculantReturnPage(){
        return await fixture.pageFactory.getPage(CppNewInoculantReturnPage, fixture.page);
    }

    static async getAddProductToTheCppOrderPage(){
        return await fixture.pageFactory.getPage(AddProductsToTheCppOrderPage, fixture.page);
    }

    static async getAddProductsToTheCppProductReturnPage(){
        return await fixture.pageFactory.getPage(AddProductsToTheCppProductReturnPage, fixture.page);
    }

    static async getAddProductsToTheCppInoculantReturnPage(){
        return await fixture.pageFactory.getPage(AddProductsToTheCppInoculantReturnPage, fixture.page);
    }

    static async getPlacedCppOrderSummaryPage(){
        return await fixture.pageFactory.getPage(PlacedCppOrderSummaryPage, fixture.page);
    }

    static async getSubmittedCppReturnSummaryPage(){
        return await fixture.pageFactory.getPage(CppSubmittedReturnSummaryPage, fixture.page);
    }

    static async getSeedReplantPage(){
        return await fixture.pageFactory.getPage(SeedReplantPage, fixture.page);
    }

    static async getSeedReservationsListPage(){
        return await fixture.pageFactory.getPage(SeedReservationsListPage, fixture.page);
    }

    static async getSeedReservationPage(){
        return await fixture.pageFactory.getPage(SeedReservationPage, fixture.page);
    }
}