import { When, setDefaultTimeout } from "@cucumber/cucumber";
import { expect } from "@playwright/test";
import { fixture } from "../../../../../hooks/fixture";
import StepPageHelper from "../../../stepPageHelper";
import DataBagKeys from "../../../dataBagKeys";
import DealerOrderProductReplacementRequest from "../../../../../helpers/util/test-data/productOrder/dealerOrderProductReplacementRequest";
import ProductInfo from "../../../../../helpers/util/test-data/product/productInfo";
import ProductChangeInfo from "../../../../../helpers/util/api/models/productChangeInfo";

setDefaultTimeout(60 * 1000 * 4)

When('user selects a product line item on the order page that can be modified by {string}', async function (modificationOption: string) {
    fixture.dataBag.saveData(DataBagKeys.SKIP_ORDER_UPDATE, false);
    // modificationOption will be either "Package Size" or "Seed Size" or "Treatment"
    let dealerOrderRequest = fixture.dataBag.getData(DataBagKeys.OLD_DEALER_ORDER_MODIFY_REQUEST) as DealerOrderProductReplacementRequest;
    const dealerOrderPage = await StepPageHelper.getDealerOrderPage();
    let productName = "";
    if (modificationOption == 'Package Size') {
        productName = dealerOrderRequest.productToModifyByPackageSize.product.name;
        fixture.dataBag.saveData(DataBagKeys.OLD_DEALER_ORDER_MODIFY_REQUEST_OBJ, dealerOrderRequest.productToModifyByPackageSize);
    }
    else if (modificationOption == 'Seed Size') {
        productName = dealerOrderRequest.productToModifyBySeedSize.product.name;
        fixture.dataBag.saveData(DataBagKeys.OLD_DEALER_ORDER_MODIFY_REQUEST_OBJ, dealerOrderRequest.productToModifyBySeedSize);
    }
    else if (modificationOption == 'Treatment') {
        productName = dealerOrderRequest.productToModifyByTreatment.product.name;
        fixture.dataBag.saveData(DataBagKeys.OLD_DEALER_ORDER_MODIFY_REQUEST_OBJ, dealerOrderRequest.productToModifyByTreatment);
    }

    expect(productName.length).toBeGreaterThan(1);
    await dealerOrderPage.selectLineitem(productName);
    fixture.logger.info(`the product -${productName}- is selected for modification by - ${modificationOption}`);
});

When('user selects a product line item on the order page', async function () {
    const itemNumber = fixture.dataBag.getData(DataBagKeys.SOURCE_PRODUCT_ITEM_NUMBER_TO_USE) as string;
    let productInfo = new ProductInfo();
    productInfo.itemNumber = itemNumber;
    const sharedBehavior = await StepPageHelper.getSharedPageBehavior();
    await sharedBehavior.selectOrderProductLineItemsByItemNumber([productInfo]);
    fixture.logger.info(`the product -${itemNumber}- is selected for modification`);
});

When('navigates to product modification page', async function () {
    const modificationOption = fixture.dataBag.getData(DataBagKeys.MODIFICATION_OPTION) as string;
    const addGrowerOrderPage = await StepPageHelper.getAddGrowerOrderPage();
    await addGrowerOrderPage.navigateToReplaceProductPage(modificationOption, 100, false);
    fixture.logger.info(`navigated to modify-product page`);
});

When('specifies units for the replacing product and previews changes', async function () {
    let result = true;
    const replaceOrderProductPage = await StepPageHelper.getReplaceOrderProductPage();
        fixture.logger.info(`modify-product page loaded successfully`);
    try{
        let oneLineitemInspected = false;
        let atleastOneLineitemModified = false;
        do{
            if (oneLineitemInspected) {
                fixture.logger.info(`moving to next product`);
                await replaceOrderProductPage.moveToNextLineItem();
            }
            fixture.logger.info(`trying to modify a product`);
            let productChangeInfo = new ProductChangeInfo();
            productChangeInfo.itemNumber = fixture.dataBag.getData(DataBagKeys.TARGET_PRODUCT_ITEM_NUMBER_TO_USE) as string;
            productChangeInfo.conv = fixture.dataBag.getData(DataBagKeys.PRODUCT_CONVERSION_OR_MIN_TRANSFERRABLE_QTY_OR_ORDER_QTY) as number;
            const tempResult = await replaceOrderProductPage.setReplaceableProductQty(productChangeInfo);
            if(!atleastOneLineitemModified)
                atleastOneLineitemModified = tempResult;
            fixture.logger.info(`completed modification inspection for one product`);
            oneLineitemInspected = true;
        }while(await replaceOrderProductPage.isAnotherLineItemAvailable());
        fixture.logger.info(`completed modification inspection for all products; going back to order page`);
        await replaceOrderProductPage.goBackToOrder();
        if (atleastOneLineitemModified) {
            fixture.dataBag.saveData(DataBagKeys.SKIP_ORDER_UPDATE, false);
            fixture.logger.info(`about to update order with replaced products`);
        } else {
            result = false;
            fixture.dataBag.saveData(DataBagKeys.SKIP_ORDER_UPDATE, true);
            fixture.logger.warn(`no product is replaced and hence not updating the order`);
        }
    } catch (error) {
        result = false;
        fixture.logger.error("failed to modify/replace products on Modify-Dealer-Order page. Error: " + error);
    }
    expect(result).toBeTruthy();
});