import { Given, When, setDefaultTimeout } from "@cucumber/cucumber";
import { expect } from "@playwright/test";
import { fixture } from "../../../../../hooks/fixture";
import StepPageHelper from "../../../stepPageHelper";
import DataBagKeys from "../../../dataBagKeys";
import NewDealerOrderRequest from "../../../../../helpers/util/test-data/productOrder/newDealerOrderRequest";
import AddProductsToOrderPageSteps from "../../../addProductsToOrderPageSteps";
import ProductOrderLineItemInfo from "../../../../../helpers/util/test-data/productOrder/productOrderLineItemInfo";
import ProductOrderInfo from "../../../../../helpers/util/test-data/productOrder/productOrderInfo";
import UpdateDealerOrderRequest from "../../../../../helpers/util/test-data/productOrder/updateDealerOrderRequest";
import DealerOrderProductReplacementRequest from "../../../../../helpers/util/test-data/productOrder/dealerOrderProductReplacementRequest";
import DataRequirementsSteps from "../../../dataRequirementsSteps";
import NewDealerOrderWithEARequest from "../../../../../helpers/util/test-data/productOrder/newDealerOrderWithEARequest";
import UpdateDealerOrderWithEARequest from "../../../../../helpers/util/test-data/productOrder/updateDealerOrderWithEARequest";
import { ProductSelectionFilters } from "../../../../../helpers/util/test-data/product/productsSelection";
import ProductInfo from "../../../../../helpers/util/test-data/product/productInfo";

setDefaultTimeout(60 * 1000 * 2)

Given('user selects Account details and navigates to the new dealer order', async function () {
    await selectAccountDetailsAndNavigateToDealerOrder();
});

Given('dealer order does not exist', async function () {
    const dealerOrderRequest = getDealerOrderRequestData();
    await DataRequirementsSteps.ensureDealerDoesNotHaveAnOrder(dealerOrderRequest.orderAccount.number);
});

Given('dealer EA order does not exist', async function () {
    const dealerOrderRequest = getDealerEAOrderRequestData();
    await DataRequirementsSteps.ensureDealerDoesNotHaveAnOrder(dealerOrderRequest.orderAccount.number);
});

Given('user selects Account details and navigates to the existing dealer order', async function () {
    const dealerOrderRequest = getDealerOrderRequestData();
    await DataRequirementsSteps.ensureDealerHasAnOrder({ accountNumber: dealerOrderRequest.orderAccount.number });
    await selectAccountDetailsAndNavigateToDealerOrder();
});

Given('user navigates to the dealer order', async function () {
    const dealerName = fixture.dataBag.getData(DataBagKeys.SOURCE_DEALER_NAME) as string;
    await navigateToDealerOrderForCreateOrProductModification(dealerName);
});

async function navigateToDealerOrderForCreateOrProductModification(dealerName: string){
    const headerNavigationPage = await StepPageHelper.getHeaderNavigationPage();
    await headerNavigationPage.navigateToSeedOrdersPage();

    const seedOrdersPage = await StepPageHelper.getSeedOrdersPage();
    await seedOrdersPage.clickDealerOrdersTab();
    await seedOrdersPage.selectDealer(dealerName);
    await seedOrdersPage.clickDealerOrder(dealerName);
}
Given('user selects Account details and navigates to the existing dealer order for EA updates', async function () {
    const dealerOrderRequest = getDealerOrderRequestData();
    //NOTE: for EA orders, we don't modify DB records
    await selectAccountDetailsAndNavigateToDealerOrder();
});

function getDealerOrderRequestData(): NewDealerOrderRequest | UpdateDealerOrderRequest | DealerOrderProductReplacementRequest
| UpdateDealerOrderWithEARequest {
    let dealerOrderRequest: NewDealerOrderRequest | UpdateDealerOrderRequest | DealerOrderProductReplacementRequest | UpdateDealerOrderWithEARequest;
    const dealerOrderRequestType = fixture.dataBag.getData(DataBagKeys.DEALER_ORDER_REQUEST_TYPE) as string;
    if(dealerOrderRequestType === "NEW")
        dealerOrderRequest = fixture.dataBag.getData(DataBagKeys.NEW_DEALER_ORDER_REQUEST) as NewDealerOrderRequest;
    else if(dealerOrderRequestType === "UPDATE")
        {
            dealerOrderRequest = fixture.dataBag.getData(DataBagKeys.OLD_DEALER_ORDER_REQUEST) as UpdateDealerOrderRequest;
            if(dealerOrderRequest === undefined || dealerOrderRequest === null){
                dealerOrderRequest = fixture.dataBag.getData(DataBagKeys.OLD_DEALER_ORDER_WITH_EA_REQUEST) as UpdateDealerOrderWithEARequest;
            }
        }
    else
        dealerOrderRequest = fixture.dataBag.getData(DataBagKeys.OLD_DEALER_ORDER_MODIFY_REQUEST) as DealerOrderProductReplacementRequest;

    return dealerOrderRequest;
}

function getDealerEAOrderRequestData(): NewDealerOrderWithEARequest | UpdateDealerOrderWithEARequest{
    let dealerEAOrderRequest: NewDealerOrderWithEARequest | UpdateDealerOrderWithEARequest;
    const dealerOrderRequestType = fixture.dataBag.getData(DataBagKeys.DEALER_ORDER_REQUEST_TYPE) as string;
    if(dealerOrderRequestType === "NEW")
        dealerEAOrderRequest = fixture.dataBag.getData(DataBagKeys.NEW_DEALER_ORDER_REQUEST) as NewDealerOrderWithEARequest;
    else if(dealerOrderRequestType === "UPDATE")
        dealerEAOrderRequest = fixture.dataBag.getData(DataBagKeys.OLD_DEALER_ORDER_WITH_EA_REQUEST) as UpdateDealerOrderWithEARequest;
    /*else
        dealerOrderRequest = fixture.dataBag.getData(DataBagKeys.OLD_DEALER_ORDER_MODIFY_REQUEST) as DealerOrderProductReplacementRequest;
    */
    return dealerEAOrderRequest;
}

async function selectAccountDetailsAndNavigateToDealerOrder() {
    const headerNavigationPage = await StepPageHelper.getHeaderNavigationPage();
    await headerNavigationPage.navigateToSeedOrdersPage();

    const seedOrdersPage = await StepPageHelper.getSeedOrdersPage();
    await seedOrdersPage.clickDealerOrdersTab();
    let dealerOrderRequest = getDealerOrderRequestData();
    await seedOrdersPage.selectDealer(dealerOrderRequest.orderAccount.name);
    await seedOrdersPage.clickDealerOrder(dealerOrderRequest.orderAccount.name);
}
When('user opens Add-Products-to-the-order page', async function () {
    await navigateToDealerAddProductToTheOrder();
});

export async function navigateToDealerAddProductToTheOrder(){
    const dealerOrderPage = await StepPageHelper.getDealerOrderPage();
    let result = await dealerOrderPage.isOrderEditable();
    if(!result)
        fixture.logger.error("account is not editable");
    expect(result).toBeTruthy();

    result = await dealerOrderPage.clickAddProductBtn();
    if(!result)
        fixture.logger.error("account is not eligible for ordering");

    expect(result).toBeTruthy();
}

When('adds products to the dealer order', async function () {
    await addProductToTheDealerOrder();
});

export async function addProductToTheDealerOrder(){
    const addProductsToOrderPageSteps = new AddProductsToOrderPageSteps();
    const itemNumber = fixture.dataBag.getData(DataBagKeys.SOURCE_PRODUCT_ITEM_NUMBER_TO_USE) as string;
    await addProductsToOrderPageSteps.searchForProducts(ProductSelectionFilters.itemNumber
        ,itemNumber
        , "false" //for dealer order this is not applicable hence always send FALSE
        , (false).toString());//on dealer order, default value for onlyShowProductWithAvailability is TRUE whereas the same on grower order, it is FALSE
    await addProductsToOrderPageSteps.selectProductsByItemNumbers([itemNumber], false);
    const msg = await addProductsToOrderPageSteps.addSelectedProductsToOrder();
    fixture.logger.info(`received message after adding products to the order is...${msg}`);
    expect(msg).not.toBeNull();
    expect(msg.length).toBeGreaterThan(0);
}

When('sets various properties for each new line item on Dealer-order page', async function () {
    await setDealerOrderLineitemProperties();
});

export async function setDealerOrderLineitemProperties(setQtyToZero: boolean = false){
    let productOrderLineItemInfo = new ProductOrderLineItemInfo();
    let productInfo = new ProductInfo();
    productInfo.itemNumber = fixture.dataBag.getData(DataBagKeys.SOURCE_PRODUCT_ITEM_NUMBER_TO_USE) as string;
    productOrderLineItemInfo.productInfo = productInfo;
    productOrderLineItemInfo.productOrderInfo = new ProductOrderInfo();
    
    const unitsValue = setQtyToZero ? "0" : (fixture.dataBag.getData(DataBagKeys.PRODUCT_CONVERSION_OR_MIN_TRANSFERRABLE_QTY_OR_ORDER_QTY) as number).toString();
    productOrderLineItemInfo.productOrderInfo.units = unitsValue;

    await setOrderLineitemProperties([productOrderLineItemInfo]);
}

async function setOrderLineitemProperties(productsToOrder: ProductOrderLineItemInfo[]){
    fixture.logger.info("Setting various properties for each line item on order page has started");
    let result = true;
    try {
        const dealerOrderPage = await StepPageHelper.getDealerOrderPage();
        await dealerOrderPage.fillProductOrderDetails(productsToOrder);
    } catch (error) {
        fixture.logger.error("Setting various properties for each line item on order page failed. Error: " + error);
        result = false;
    }
    expect(result).toBeTruthy();
    fixture.logger.info("Setting various properties for each line item on order page has completed");
}

When('user increments quantity for an existing line item on order page', async function () {
    await increaseOrDecreaseQty();
});

When('user decrements quantity for an existing line item on order page', async function () {
    await increaseOrDecreaseQty();
});

When('user deletes an existing line item on order page', async function () {
    await updateProductQty(true);
});

async function increaseOrDecreaseQty(){
    const sharedBehavior = await StepPageHelper.getSharedPageBehavior();
    const itemNumber = fixture.dataBag.getData(DataBagKeys.SOURCE_PRODUCT_ITEM_NUMBER_TO_USE) as string;
    const operationType = fixture.dataBag.getData(DataBagKeys.ORDER_UPDATE_TYPE) as string;
    const shouldIncrease = (operationType == "IncreaseQty");
    await sharedBehavior.increaseOrDecreaseLineItemUnitsValue(itemNumber, shouldIncrease);
}

async function updateProductQty(isDelete: boolean) {
    if (isDelete) {
        await setDealerOrderLineitemProperties(true);
    } else {
        throw Error(`updateProductQty is not implemented except for DeleteProduct`);
    }
}