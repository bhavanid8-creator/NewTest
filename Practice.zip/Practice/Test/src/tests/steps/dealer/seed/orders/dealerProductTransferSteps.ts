import { DataTable, Given, Then, setDefaultTimeout } from "@cucumber/cucumber";
import { expect } from "@playwright/test";
import { TestDataType } from "../../../../../helpers/util/test-data/TestDataType";
import AccountDetailsForOrderModification from "../../../../../helpers/util/test-data/grower/accountDetailsForOrderModification";
import ProductInfo from "../../../../../helpers/util/test-data/product/productInfo";
import ProductOrderInfo from "../../../../../helpers/util/test-data/productOrder/productOrderInfo";
import { fixture } from "../../../../../hooks/fixture";
import ProductTransferAnotherDealerPage from "../../../../../pages/seed/orders/grower/productTransferAnotherDealerPage";
import DataBagKeys from "../../../dataBagKeys";
import SharedSteps from "../../../sharedSteps";
import StepDataHelper from "../../../stepDataHelper";
import StepPageHelper from "../../../stepPageHelper";
import ProductTransferOutsideTerritoryPage from "../../../../../pages/seed/orders/productTransferOutsideTerritoryPage";
import DataRequirementsSteps from "../../../dataRequirementsSteps";
import ProductChangeInfo from "../../../../../helpers/util/api/models/productChangeInfo";
import { addProductToTheDealerOrder, navigateToDealerAddProductToTheOrder, setDealerOrderLineitemProperties } from "./createUpdateDealerOrderSteps";
import AddProductsToOrderPageSteps from "../../../addProductsToOrderPageSteps";
import { ProductSelectionFilters } from "../../../../../helpers/util/test-data/product/productsSelection";
import ProductOrderLineItemInfo from "../../../../../helpers/util/test-data/productOrder/productOrderLineItemInfo";
import { placeOrUpdateOrder } from "../../../grower/orders/createGrowerOrderSteps";

setDefaultTimeout(60 * 1000 * 2)

Given('user navigates to the dealer order {string}', async function (orderAccountInfo: string)
{
    let result = true;
    try {
        const orderAccountsData = StepDataHelper.getSingleTestDataRecordForType(TestDataType.AccountDetailsForOrderModification, orderAccountInfo) as AccountDetailsForOrderModification;
        
        await DataRequirementsSteps.ensureDealerHasAnOrder({accountNumber: orderAccountsData.number});
        
        const headerNavigationPage = await StepPageHelper.getHeaderNavigationPage();
        await headerNavigationPage.navigateToSeedOrdersPage();

        const seedOrdersPage = await StepPageHelper.getSeedOrdersPage();
        
        const sharedPage = await StepPageHelper.getSharedPageBehavior();
        const dealerFullDetails = sharedPage.buildAccountSelectionText(orderAccountsData);

        await seedOrdersPage.clickDealerOrdersTab();
        await seedOrdersPage.selectDealer(orderAccountsData.name);
        orderAccountsData.orderIdToUpdate = await seedOrdersPage.getDealerOrderIdFromTheSeedOrderPageTable(orderAccountsData.name);
        fixture.logger.info(`dealer order ID is - ${orderAccountsData.orderIdToUpdate}`);
        await seedOrdersPage.clickDealerOrder(orderAccountsData.name);

        fixture.logger.info(`dealer with details - ${dealerFullDetails} - selected`);
        fixture.dataBag.saveData(DataBagKeys.ORDER_ID, orderAccountsData.orderIdToUpdate);
    } catch (error) {
        result = false;
        fixture.logger.error("failed to navigate to existing grower order page. Error: " + error);
    }
    expect(result).toBeTruthy();
});

Given('user navigates to the dealer order for product transfer', async function () {
    const accountNumber = fixture.dataBag.getData(DataBagKeys.SOURCE_DEALER_ACCOUNT_NUMBER) as number;
    const dealerName = fixture.dataBag.getData(DataBagKeys.SOURCE_DEALER_NAME) as string;
    const dealerOrderNumber = fixture.dataBag.getData(DataBagKeys.SOURCE_DEALER_ORDER_NUMBER) as string;
    await navigateToDealerOrderForProductTransfer({dealerAccountNumber: accountNumber, dealerName: dealerName, dealerOrderNumber: dealerOrderNumber, isOperationProductTransfer: true});
});

async function navigateToDealerOrderForProductTransfer(navigationData: {dealerAccountNumber: number; dealerName: string; dealerOrderNumber: string; productModificationOption?: string; isOperationProductTransfer?: boolean; }){
    let result = true;
    try {
        let orderAccountsData: AccountDetailsForOrderModification = new AccountDetailsForOrderModification();
        orderAccountsData.number = navigationData.dealerAccountNumber.toString();
        orderAccountsData.name = navigationData.dealerName;
        const headerNavigationPage = await StepPageHelper.getHeaderNavigationPage();
        await headerNavigationPage.navigateToSeedOrdersPage();

        const seedOrdersPage = await StepPageHelper.getSeedOrdersPage();
        await seedOrdersPage.clickDealerOrdersTab();
        await seedOrdersPage.selectDealer(orderAccountsData.number);
        fixture.logger.info(`dealer with account number - ${orderAccountsData.number} - selected`);
        await seedOrdersPage.clickDealerOrder(orderAccountsData.name);
        fixture.logger.info(`dealer - ${orderAccountsData.name} - order opened`);

        orderAccountsData.orderIdToUpdate = navigationData.dealerOrderNumber;
        fixture.dataBag.saveData(DataBagKeys.ORDER_ID, orderAccountsData.orderIdToUpdate);
        fixture.logger.info(`dealer order id that will be used for the scenario is - ${orderAccountsData.orderIdToUpdate}`);

        const sourceProductItemNumber = fixture.dataBag.getData(DataBagKeys.SOURCE_PRODUCT_ITEM_NUMBER_TO_USE) as string;

        //ensure the order has right products on the order
        const targetProductItemNumber = fixture.dataBag.getData(DataBagKeys.TARGET_PRODUCT_ITEM_NUMBER_TO_USE) as string;
        const modifyingProduct = new ProductChangeInfo();
        modifyingProduct.itemNumber = targetProductItemNumber;
        const productQty = fixture.dataBag.getData(DataBagKeys.PRODUCT_CONVERSION_OR_MIN_TRANSFERRABLE_QTY_OR_ORDER_QTY) as number;
        modifyingProduct.conv = productQty;
        fixture.dataBag.saveData(DataBagKeys.PRODUCT_MODIFICATION_REPLACEMENT_PRODUCT, modifyingProduct);
        await addProductToTheOrder(orderAccountsData.orderIdToUpdate, sourceProductItemNumber, productQty.toString());

    } catch (error) {
        result = false;
        fixture.logger.error("failed to navigate to existing grower order page. Error: " + error);
    }
    expect(result).toBeTruthy();
}

Given('user navigates to the dealer order for updating order', async function () {
    await openDealerOrder(false);
});

Given('user navigates to the dealer order for updating EA order', async function () {
    await openDealerOrder(true);
});

async function openDealerOrder(isOperationEA: boolean) {
    const accountNumber = fixture.dataBag.getData(DataBagKeys.SOURCE_DEALER_ACCOUNT_NUMBER) as number;
    const dealerName = fixture.dataBag.getData(DataBagKeys.SOURCE_DEALER_NAME) as string;
    const dealerOrderNumber = fixture.dataBag.getData(DataBagKeys.SOURCE_DEALER_ORDER_NUMBER) as string;
    await navigateToDealerOrderForUpdate(isOperationEA, {dealerAccountNumber: accountNumber, dealerName: dealerName, dealerOrderNumber: dealerOrderNumber});
}

async function navigateToDealerOrderForUpdate(isOperationEA: boolean, navigationData: {dealerAccountNumber: number; dealerName: string; dealerOrderNumber: string;}){
    let result = true;
    try {
        let orderAccountsData: AccountDetailsForOrderModification = new AccountDetailsForOrderModification();
        orderAccountsData.number = navigationData.dealerAccountNumber.toString();
        orderAccountsData.name = navigationData.dealerName;
        const headerNavigationPage = await StepPageHelper.getHeaderNavigationPage();
        await headerNavigationPage.navigateToSeedOrdersPage();

        const seedOrdersPage = await StepPageHelper.getSeedOrdersPage();
        await seedOrdersPage.clickDealerOrdersTab();
        await seedOrdersPage.selectDealer(orderAccountsData.number);
        fixture.logger.info(`dealer with account number - ${orderAccountsData.number} - selected`);
        await seedOrdersPage.clickDealerOrder(orderAccountsData.name);
        fixture.logger.info(`dealer - ${orderAccountsData.name} - order opened`);

        if (navigationData.dealerOrderNumber != null) {
            orderAccountsData.orderIdToUpdate = navigationData.dealerOrderNumber;
            fixture.dataBag.saveData(DataBagKeys.ORDER_ID, orderAccountsData.orderIdToUpdate);
            fixture.logger.info(`dealer order id that will be used for the scenario is - ${orderAccountsData.orderIdToUpdate}`);
        }
        
        const operationType = fixture.dataBag.getData(DataBagKeys.ORDER_UPDATE_TYPE) as string;
        if(operationType == "DeleteProduct"){
            //to delete a product, first we add that product to the order
            await navigateToDealerAddProductToTheOrder();
            await addProductToTheDealerOrder();
            await setDealerOrderLineitemProperties();
            await placeOrUpdateOrder(false, "failed to click on Update-Order button on Dealer-Order page.");
        }
    } catch (error) {
        result = false;
        fixture.logger.error("failed to navigate to existing grower order page. Error: " + error);
    }
    expect(result).toBeTruthy();
}

async function addProductToTheOrder(orderIdToUpdate: string, expectedProductNumber: string, orderUnits: string) {
    const dealerOrderPage = await StepPageHelper.getDealerOrderPage();
    let result = await dealerOrderPage.isOrderEditable();
    if(!result)
        fixture.logger.error("account is not editable");
    expect(result).toBeTruthy();
    
    let {orderContainsTheProduct, qtyIncremented} = await dealerOrderPage.incrementUnitsIfLineItemAvailable(expectedProductNumber, orderUnits);
    let orderModified = false;
    //if (orderContainsTheProduct && qtyIncremented != null && !qtyIncremented) 
    if (!orderContainsTheProduct) 
    {
        fixture.logger.info(`dealer order does not have the product with the item number ${expectedProductNumber}; hence it will be added to the order`);
        result = await dealerOrderPage.clickAddProductBtn();
        if (!result)
            fixture.logger.error("account is not eligible for ordering");

        expect(result).toBeTruthy();

        const addProductsToOrderPageSteps = new AddProductsToOrderPageSteps();
        result = await addProductsToOrderPageSteps.searchForProducts(ProductSelectionFilters.itemNumber
            ,expectedProductNumber
            , "false" //for dealer order this is not applicable hence always send FALSE
            , "true");

        if (!result)
            fixture.logger.error(`product with item number ${expectedProductNumber} could not be found`);

        expect(result).toBeTruthy();
        const productsInfo: string[] = [expectedProductNumber];

        await addProductsToOrderPageSteps.selectProductsByItemNumbers(productsInfo, false);
        const msg = await addProductsToOrderPageSteps.addSelectedProductsToOrder();
        fixture.logger.info(`received message after adding products to the order is...${msg}`);

        const orderLineItem = new ProductOrderLineItemInfo();
        orderLineItem.productInfo = new ProductInfo();
        orderLineItem.productInfo.itemNumber = expectedProductNumber;
        orderLineItem.productOrderInfo = new ProductOrderInfo();
        orderLineItem.productOrderInfo.units = orderUnits;
        await dealerOrderPage.fillProductOrderDetails([orderLineItem]);
        fixture.logger.info(`completed entering units value`);
        orderModified = true;
    }else if (orderContainsTheProduct && qtyIncremented != null && qtyIncremented) 
        orderModified = true;

    fixture.dataBag.saveData(DataBagKeys.ORDER_LINE_ITEM_ADDED_OR_MODIFIED_DURING_NAVIGATION, orderModified);
    fixture.logger.info(`order - ${orderIdToUpdate} - line has been added or modified during navigation (ORDER IS NOT UPDATED YET!)`);
}

Given('user transfers products to another dealer having no existing order', async function () {
    await transferProducts(true, false);
});

Given('user transfers products to another dealer having an existing order', async function () {
    const trgtDealerOrderNumber = fixture.dataBag.getData(DataBagKeys.TARGET_DEALER_ORDER_NUMBER) as string;
    await transferProducts(true, true, trgtDealerOrderNumber);
});

Given('user transfers products to another dealer from another territory', async function () {
    await transferProducts(false, false);
});

Then('user should be able to transfers products to another dealer having an existing order', async function (transerDetails: DataTable) {
    const recordDetail = transerDetails.rowsHash();
    const destinationDealer = StepDataHelper.getSingleTestDataRecordForType(TestDataType.AccountDetailsForOrderModification, recordDetail.destinationDealer) as AccountDetailsForOrderModification;
    let destinationDealerOrderNumber = await DataRequirementsSteps.ensureDealerHasAnOrder({accountNumber: destinationDealer.number});
    await transferProducts_obsolete(transerDetails, true, true, false, destinationDealerOrderNumber);
});

Then('user should be able to transfers products to another dealer from another territory', async function (transerDetails: DataTable) {
    const recordDetail = transerDetails.rowsHash();
    const destinationDealer = StepDataHelper.getSingleTestDataRecordForType(TestDataType.AccountDetailsForOrderModification, recordDetail.destinationDealer) as AccountDetailsForOrderModification;
    await DataRequirementsSteps.ensureDealerDoesNotHaveAnOrder(destinationDealer.number);
    await transferProducts_obsolete(transerDetails, false, true, true);
});

async function transferProducts_obsolete(transerDetails: DataTable, shouldTransferToExistingOrder: boolean, screenValidationOnly: boolean = false, isTrasferOutsideTerritory: boolean = false
    , destinationDealerOrderNumber: string = ""
) {
    fixture.logger.info(`dealer transferProducts started`);
    let result = true;
    try {
        const recordDetail = transerDetails.rowsHash();

        let targetOrderId: string = "";
        if (shouldTransferToExistingOrder) {
            if(destinationDealerOrderNumber.length === 0)
                targetOrderId = StepDataHelper.getSingleStringNodeData(recordDetail.existingOrderID).trim();
            else
                targetOrderId = destinationDealerOrderNumber;

            fixture.dataBag.saveData(DataBagKeys.TARGET_ORDER_ID_FOR_TRANSFER, targetOrderId);
            fixture.logger.info(`transfer will be to existing order - ${targetOrderId}`);
        } else
            fixture.logger.info(`transfer will be to new order`);

        const productsToTransfer = StepDataHelper.getMultipleTestDataRecordsForType(TestDataType.ProductInfo, recordDetail.products) as ProductInfo[];

        const transferModifications = StepDataHelper.getSingleTestDataRecordForType(TestDataType.ProductOrderInfo, recordDetail.transferModifications) as ProductOrderInfo;

        const sharedSteps = new SharedSteps();
        //step 1: select products to transfer on the order page
        const transferringProductNames: string[] = [];

        const orderPage = await StepPageHelper.getDealerOrderPage();
        for (let i = 0; i < productsToTransfer.length; i++) {
            const tempName = productsToTransfer[i].name.trim();
            fixture.logger.info(`selecting the product ${tempName} for transfer`);
            await orderPage.selectLineitem(tempName);
            transferringProductNames.push(tempName);
        }
        
        let transferProductPage: ProductTransferAnotherDealerPage | ProductTransferOutsideTerritoryPage;
        const sharedBehavior = await StepPageHelper.getSharedPageBehavior();
        const existingProductRowCount = await sharedBehavior.getExistingProductRowCountOnDealerOrGrowerOrder();
        //step 2: navigate to transfer-products page
        if (!isTrasferOutsideTerritory) {
            await orderPage.navigateToTransferProduct();
            transferProductPage = await StepPageHelper.getProductTransferAnotherDealerPage();
        }
        else {
            await orderPage.navigateToTransferProductOutsideTerritory();
            transferProductPage = await StepPageHelper.getProductTransferOutsideTerritoryPage();
        }

        //step 3: enter transfering product details (such as units, etc.,)
        
        const destinationDealer = StepDataHelper.getSingleTestDataRecordForType(TestDataType.AccountDetailsForOrderModification, recordDetail.destinationDealer) as AccountDetailsForOrderModification;
        fixture.logger.info(`selecting target dealer`);
        if (!isTrasferOutsideTerritory) {
            await (transferProductPage as ProductTransferAnotherDealerPage).selectTargetDealer(destinationDealer, true);
        }
        else {
            await (transferProductPage as ProductTransferOutsideTerritoryPage).selectOutsideTerritoryDealer(destinationDealer.number);
            transferModifications.deliveryDate = "";
        }
        fixture.logger.info(`completing other details`);
        await transferProductPage.fillOrderOtherDetails();

        if (transferModifications.units == undefined || transferModifications.units.length == 0)
            transferModifications.units = "1";

        await transferProductPage.fillLineItemDetails_obsolete(existingProductRowCount, transferringProductNames, transferModifications);

        if (screenValidationOnly) {
            const fromOrderId = fixture.dataBag.getData(DataBagKeys.ORDER_ID) as string;
            let res = await transferProductPage.verifyOrderIdsDisplay(fromOrderId, targetOrderId);
            sharedSteps.validateStepActionResult(res, 'failed to verify order IDs display on product transfer page');

            res = await transferProductPage.canClickTransfer();
            sharedSteps.validateStepActionResult(res, 'failed to verify transfer-units button status on product transfer page');

            await transferProductPage.closeTransferProductsPage(isTrasferOutsideTerritory);
        } else {
            //step 4: complete transfer process (click the button)
            const transferMsg = await transferProductPage.clickTransfer();
            fixture.dataBag.saveData(DataBagKeys.OPERATION_COMPLETION_MESSAGE, transferMsg);
            const transferBtnVisibleStatus = await transferProductPage.isTransferButtonVisible();
            fixture.dataBag.saveData(DataBagKeys.TRANSFER_BUTTON_STATUS, transferBtnVisibleStatus);
        }
    } catch (error) {
        result = false;
        fixture.logger.error("failed to transfer products on Order page. Error: " + error);
    }
    expect(result).toBeTruthy();
    fixture.logger.info(`transferProducts completed`);
}
async function transferProducts(isTheDestinationDealerFromSameParent: boolean, shouldTransferToExistingOrder: boolean, targetOrderId: string = ""
) {
    fixture.logger.info(`dealer transferProducts started`);
    let result = true;
    try {
        const sharedSteps = new SharedSteps();
        //step 1: select products to transfer on the order page
        await sharedSteps.updateOrderIfModifiedDuringNavigation();
        fixture.logger.info(`done with updating order during navigation`);

        if (shouldTransferToExistingOrder) {
            fixture.dataBag.saveData(DataBagKeys.TARGET_ORDER_ID_FOR_TRANSFER, targetOrderId);
            fixture.logger.info(`transfer will be to existing order - ${targetOrderId}`);
        } else
            fixture.logger.info(`transfer will be to new order`);

        let productsToTransfer: ProductInfo[] = [];
        let product =  new ProductInfo();
        product.itemNumber = fixture.dataBag.getData(DataBagKeys.SOURCE_PRODUCT_ITEM_NUMBER_TO_USE) as string; 
        productsToTransfer.push(product);

        let trgtDealerAccountNumber = fixture.dataBag.getData(DataBagKeys.TARGET_DEALER_ACCOUNT_NUMBER) as number;
        
        const transferModifications = new ProductOrderInfo();
        transferModifications.units = (fixture.dataBag.getData(DataBagKeys.PRODUCT_CONVERSION_OR_MIN_TRANSFERRABLE_QTY_OR_ORDER_QTY) as number).toString();
        const sharedBehavior = await StepPageHelper.getSharedPageBehavior();
        
        await sharedBehavior.selectOrderProductLineItemsByItemNumber(productsToTransfer);
        const orderPage = await StepPageHelper.getDealerOrderPage();
        let transferProductPage: ProductTransferAnotherDealerPage | ProductTransferOutsideTerritoryPage;

        const existingProductRowCount = await sharedBehavior.getExistingProductRowCountOnDealerOrGrowerOrder();
        const destinationDealer = new AccountDetailsForOrderModification();
        destinationDealer.number = trgtDealerAccountNumber.toString();
        destinationDealer.name = fixture.dataBag.getData(DataBagKeys.TARGET_DEALER_NAME) as string;
        
        //step 2: navigate to transfer-products page
        if (isTheDestinationDealerFromSameParent) {
            await orderPage.navigateToTransferProduct();
            transferProductPage = await StepPageHelper.getProductTransferAnotherDealerPage();
            await transferProductPage.selectTargetDealer(destinationDealer, true);
        }
        else {
            await orderPage.navigateToTransferProductOutsideTerritory();
            transferProductPage = await StepPageHelper.getProductTransferOutsideTerritoryPage();
            await transferProductPage.selectOutsideTerritoryDealer(destinationDealer.number);
            transferModifications.deliveryDate = "";
        }

        fixture.logger.info(`completing other details`);
        await transferProductPage.fillOrderOtherDetails();
        fixture.logger.info(`about to start filling product quantities`);

        if (transferModifications.units == undefined || transferModifications.units == null || transferModifications.units.length == 0)
            transferModifications.units = "10";

        await transferProductPage.fillLineItemDetails(existingProductRowCount, productsToTransfer.length, transferModifications);

        //step 4: complete transfer process (click the button)
        await transferProductPage.previewChangesForTransfer();
        const addGrowerOrderPage = await StepPageHelper.getAddGrowerOrderPage();
        const transferMsg = await addGrowerOrderPage.placeOrUpdateOrder(false);
        //const transferBtnVisibleStatus = await transferProductPage.isTransferButtonVisible();
        fixture.dataBag.saveData(DataBagKeys.OPERATION_COMPLETION_MESSAGE, transferMsg);
        //fixture.dataBag.saveData(DataBagKeys.TRANSFER_BUTTON_STATUS, transferBtnVisibleStatus);
    } catch (error) {
        result = false;
        fixture.logger.error("failed to transfer products on Order page. Error: " + error);
    }
    expect(result).toBeTruthy();
    fixture.logger.info(`transferProducts completed`);
}

Then('order page must display source dealer order id', async function () {
    //await checkDisplayedDealerOrderId(true);
    await checkDisplayedDealerOrderId();
});
/*
Then('order page must display source dealer order id', async function () {
    await checkDisplayedDealerOrderId(false);
});*/
//async function checkDisplayedDealerOrderId(shouldExpectExistingOrder: boolean) {
async function checkDisplayedDealerOrderId() {
    try {
        const orderPage = await StepPageHelper.getAddGrowerOrderPage();
        const orderIdUsedForTransfer = fixture.dataBag.getData(DataBagKeys.ORDER_ID) as string;
        const currentDisplayedOrderId = await orderPage.getCurrentDisplayedDealerOrderId();
        fixture.logger.info(`order id used for transfer is...${orderIdUsedForTransfer}`);
        fixture.logger.info(`displayed order id is...${currentDisplayedOrderId}`);
        /*expect(currentDisplayedOrderId == orderIdUsedForTransfer).toBeFalsy();
        if (shouldExpectExistingOrder) {
            const targetOrderId = fixture.dataBag.getData(DataBagKeys.TARGET_ORDER_ID_FOR_TRANSFER) as string;
            fixture.logger.info(`target order id is...${targetOrderId}`);
            expect(currentDisplayedOrderId == targetOrderId).toBeTruthy();
        }*/
        expect(currentDisplayedOrderId == orderIdUsedForTransfer).toBeTruthy(); //new behavior as per the ticket https://dev.azure.com/lolinc/CropInputs/_workitems/edit/319467
    } catch (error) {
        fixture.logger.error("failed to verify order id on Order page. Error: " + error);
    }
}