/*eslint @typescript-eslint/no-unsafe-argument: "off" */
/*eslint @typescript-eslint/no-unsafe-assignment: "off" */
/*eslint @typescript-eslint/no-unsafe-call: "off" */
/*eslint @typescript-eslint/no-unsafe-member-access: "off" */
import { Given, When, Then, setDefaultTimeout } from "@cucumber/cucumber";

import { fixture } from "../../../../hooks/fixture";
import { expect } from "@playwright/test";
import DataBagKeys from "../../dataBagKeys";
import StepPageHelper from "../../stepPageHelper";
import { DealerRoleInStockTransfer } from "../../../../pages/seed/stock-transfers/stockTransfersPage";
import PickupOrDeliveryInfo from "../../../../helpers/util/test-data/dealer/pickupOrDeliveryInfo";
import DateHelper from "../../../../helpers/types/dateHelper";
import FreightInstructions from "../../../../helpers/util/test-data/dealer/freightInstructions";
import ProductsSelection from "../../../../helpers/util/test-data/product/productsSelection";
import ProductFilter from "../../../../helpers/util/test-data/product/productFilter";
import ProductInfo from "../../../../helpers/util/test-data/product/productInfo";
import StockTransferQuantity from "../../../../helpers/util/test-data/dealer/stockTransferQuantity";

setDefaultTimeout(60 * 1000 * 2)

Given('user is on stock-transfers page', async function () {
    const headerNavigationPage = await StepPageHelper.getHeaderNavigationPage();
    await headerNavigationPage.navigateToStockTransfersPage();
});

async function completeRequestSubmission(){
    await startNewTransferRequest();
    await selectDealers();
    await selectDeliveryOption();
    await providePickupInfo();
    await addProducts();
    await submitRequest();
}
Given('sending dealer has already submitted a stock transfer request', async function () {
    await completeRequestSubmission();
});

Given('sending dealer has already resubmitted a stock transfer request', async function () {
    const stockTransfersPage = await StepPageHelper.getStockTransfersPage();
    await completeRequestSubmission();
    await openRequest(DealerRoleInStockTransfer.Receiving_Dealer);
    await stockTransfersPage.rejectRequest();
    await openRequest(DealerRoleInStockTransfer.Sending_Dealer);
    await stockTransfersPage.resubmitRequest();
});

Given('receiving dealer has rejected a stock transfer request', async function () {
    const stockTransfersPage = await StepPageHelper.getStockTransfersPage();
    await completeRequestSubmission();
    await openRequest(DealerRoleInStockTransfer.Receiving_Dealer);
    await stockTransfersPage.rejectRequest();
});

async function startNewTransferRequest(){
    const stockTransfersPage = await StepPageHelper.getStockTransfersPage();
    await stockTransfersPage.clickNewStockTransferBtn();
}
When('user starts a new stock transfer request', async function () {
    await startNewTransferRequest();
});

async function selectDealers(){
    const stockTransfersPage = await StepPageHelper.getStockTransfersPage();
    
    const srcAccountName = fixture.dataBag.getData(DataBagKeys.SOURCE_DEALER_NAME) as string;
    await stockTransfersPage.selectTransferFromAccount(srcAccountName);
    fixture.logger.info(`sending dealer - ${srcAccountName} - selected`);
    
    const trgtAccountName = fixture.dataBag.getData(DataBagKeys.TARGET_DEALER_NAME) as string;
    const trgtAccountNumber = fixture.dataBag.getData(DataBagKeys.TARGET_DEALER_ACCOUNT_NUMBER) as number;
    await stockTransfersPage.selectTransferToAccount(trgtAccountName, trgtAccountNumber.toString());
    fixture.logger.info(`receiving dealer with details - ${trgtAccountName} - selected`);
}
When('selects transfer-from and transfer-to accounts', async function () {
    await selectDealers();
});

async function selectDeliveryOption(){
    const stockTransfersPage = await StepPageHelper.getStockTransfersPage();
    const deliveryOption = process.env.DEALER_STOCK_TRANSFER_OPTION;
    await stockTransfersPage.selectDeliveryOption(deliveryOption);
    fixture.logger.info(`delivery option - ${deliveryOption} - selected`);
}
When('selects delivery option', async function () {
    await selectDeliveryOption();
});

async function providePickupInfo(){
    const stockTransfersPage = await StepPageHelper.getStockTransfersPage();
    const pickupOrDeliveryInfo = new PickupOrDeliveryInfo();
    pickupOrDeliveryInfo.contactName = "qa-automation";
    pickupOrDeliveryInfo.contactNumber = "1234567890";
    pickupOrDeliveryInfo.desiredDate = DateHelper.getDateTimeUTC();
    pickupOrDeliveryInfo.freightInstructions = new FreightInstructions();
    pickupOrDeliveryInfo.freightInstructions.driverAssistanceRequired = true;
    pickupOrDeliveryInfo.freightInstructions.nonStockPallet = "10";
    pickupOrDeliveryInfo.freightInstructions.stockPallet = "10";
    pickupOrDeliveryInfo.freightInstructions.palletJackRequired = true;
    pickupOrDeliveryInfo.freightInstructions.emptyCBox = "10";
    pickupOrDeliveryInfo.isLocationDifferentThanDealerLocation = true;
    pickupOrDeliveryInfo.shippingInstructions = "just deliver for automation testing";
    await stockTransfersPage.fillPickupOrDeliveryInfo(pickupOrDeliveryInfo);
}
When('provides pickup information', async function () {
    await providePickupInfo();
});

async function addProducts(){
    const stockTransfersPage = await StepPageHelper.getStockTransfersPage();
    const productToSelect = new ProductsSelection();
    
    const productFilter = new ProductFilter();
    productFilter.filterCategory = "Lot #";
    productFilter.searchKey = fixture.dataBag.getData(DataBagKeys.LOT_NUMBER) as string;
    productToSelect.filters = [productFilter];
    
    const productInfo = new ProductInfo();
    productInfo.itemNumber = fixture.dataBag.getData(DataBagKeys.SOURCE_PRODUCT_ITEM_NUMBER_TO_USE) as string;
    
    productToSelect.expectedProducts = [productInfo];
    
    const stockTransferQuantity = new StockTransferQuantity();
    stockTransferQuantity.productId = productInfo.itemNumber;
    stockTransferQuantity.qty = (fixture.dataBag.getData(DataBagKeys.PRODUCT_CONVERSION_OR_MIN_TRANSFERRABLE_QTY_OR_ORDER_QTY) as number).toString();
    productToSelect.transferQuantities = [stockTransferQuantity];

    await stockTransfersPage.addProducts([productToSelect]);
    fixture.logger.info("products are added to the request");
}
When('adds products to the transfer request', async function () {
    await addProducts();
});

async function submitRequest(){
    const stockTransfersPage = await StepPageHelper.getStockTransfersPage();
    const newReqId = await stockTransfersPage.submitRequest();
    expect(newReqId).not.toBeNull();
    expect(newReqId.length).toBeGreaterThan(1);
}
When('{word} the request', async function (action: string) {
    //action can be either "submits" or "approves" or "rejects"
    const stockTransfersPage = await StepPageHelper.getStockTransfersPage();
    if(action == "submits"){
       await submitRequest();
    }else if(action == "approves"){
        await stockTransfersPage.approveRequest();
     }else if(action == "rejects"){
        await stockTransfersPage.rejectRequest();
     }
});

async function openRequest(dealerTab: DealerRoleInStockTransfer, delayInMs:number = 0){
    const stockTransfersPage = await StepPageHelper.getStockTransfersPage();
    const reqId = fixture.dataBag.getData(DataBagKeys.STOCK_TRANSFER_REQUEST_ID) as string;
    await stockTransfersPage.openRequest(dealerTab, reqId, delayInMs);
    
}
When('user opens the submitted stock transfer request as receiving dealer', async function () {
    await openRequest(DealerRoleInStockTransfer.Receiving_Dealer);
});

When('user opens the rejected stock transfer request as sending dealer', async function () {
    await openRequest(DealerRoleInStockTransfer.Sending_Dealer);
});

When('submits the updated request again', async function () {
    const stockTransfersPage = await StepPageHelper.getStockTransfersPage();
    await stockTransfersPage.resubmitRequest();
});

Then('sending dealer should view a new request with {word} status', async function (requestStatus: string) {
    await verifyReqStatus(DealerRoleInStockTransfer.Sending_Dealer, requestStatus);
});

Then('sending dealer should view the same request with {word} status', async function (requestStatus: string) {
    await verifyReqStatus(DealerRoleInStockTransfer.Sending_Dealer, requestStatus);
});

Then('sending dealer should be able to view the receiving dealer comments', async function () {
    const stockTransfersPage = await StepPageHelper.getStockTransfersPage();
    await openRequest(DealerRoleInStockTransfer.Sending_Dealer, 1500);
    const msg = await stockTransfersPage.getRejectionText();
    fixture.logger.info("rejection comments are..."+ msg);
    expect(msg).not.toBeNull();
    expect(msg.length).toBeGreaterThan(1);
});

Then('receiving dealer should view the same request with {word} status', async function (requestStatus: string) {
    await verifyReqStatus(DealerRoleInStockTransfer.Receiving_Dealer, requestStatus);
});

async function verifyReqStatus(dealerTab: DealerRoleInStockTransfer, expectedStatus: string){
    const stockTransfersPage = await StepPageHelper.getStockTransfersPage();
    const reqId = fixture.dataBag.getData(DataBagKeys.STOCK_TRANSFER_REQUEST_ID) as string;
    const actualStatus = await stockTransfersPage.getRequestStatus(dealerTab, reqId);
    expect(actualStatus).toBe(expectedStatus);
}