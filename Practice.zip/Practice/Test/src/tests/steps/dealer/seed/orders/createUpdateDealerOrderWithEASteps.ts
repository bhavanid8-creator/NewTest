import { Then, When, setDefaultTimeout } from "@cucumber/cucumber";
import { expect } from "@playwright/test";
import { fixture } from "../../../../../hooks/fixture";
import StepPageHelper from "../../../stepPageHelper";
import DataBagKeys from "../../../dataBagKeys";
import AddProductsToOrderPageSteps from "../../../addProductsToOrderPageSteps";
import { ProductSelectionFilters } from "../../../../../helpers/util/test-data/product/productsSelection";

setDefaultTimeout(60 * 1000 * 2)

When('user opens Add-EA-Products-to-the-order page', async function () {
    const dealerOrderPage = await StepPageHelper.getDealerOrderPage();
    let result = await dealerOrderPage.clickAddEAProductBtn();
    if(!result)
        fixture.logger.error("account is not eligible for ordering");

    expect(result).toBeTruthy();
});

When('user selects an EA product on the order', async function () {
    await countCurrentUnitsAndSelectEAProductRow(false);
});

async function countCurrentUnitsAndSelectEAProductRow(isOperationSwapping: boolean){
    const dealerOrderPage = await StepPageHelper.getDealerOrderPage();
    const itemNumber = fixture.dataBag.getData(DataBagKeys.SOURCE_PRODUCT_ITEM_NUMBER_TO_USE) as string;
    await dealerOrderPage.selectEAProductRow(itemNumber);
}

When('user selects an EA product on the order for swapping', async function () {
    await countCurrentUnitsAndSelectEAProductRow(true);
});

When('opens Modify-EA-Products-Quantity page', async function () {
    const dealerOrderPage = await StepPageHelper.getDealerOrderPage();
    await dealerOrderPage.openModifyEAUnitsPage()
});

When('opens Decrease-EA-Units page', async function () {
    const dealerOrderPage = await StepPageHelper.getDealerOrderPage();
    await dealerOrderPage.openDecreaseEAUnitsPage()
});

When('opens Swap-EA-Product page', async function () {
    const dealerOrderPage = await StepPageHelper.getDealerOrderPage();
    await dealerOrderPage.openSwapEAUnitsPage()
});

When('modifies quantity using {string} button and updates the order', async function (buttonName: string) {
    const shouldReduceQty = (buttonName === "-");
    const addProductsToOrderPageSteps = new AddProductsToOrderPageSteps();
    await addProductsToOrderPageSteps.modifyEAUnitsWithButtons(shouldReduceQty);
    await updateOrderWithEAProducts(addProductsToOrderPageSteps);
});

When('increases quantity using quantity textbox and updates the order', async function () {
    await increaseQuantityWithInput(true);
});

When('increases quantity using quantity textbox', async function () {
    await increaseQuantityWithInput(false);
});

When('enters EA units value using quantity textbox of the target product and updates the order', async function () {
    fixture.logger.info('staring entering quantity for the swapped product');
    const addProductsToOrderPageSteps = new AddProductsToOrderPageSteps();
    const targetProduct = fixture.dataBag.getData(DataBagKeys.TARGET_PRODUCT_ITEM_NUMBER_TO_USE) as string;
    const units = fixture.dataBag.getData(DataBagKeys.PRODUCT_CONVERSION_OR_MIN_TRANSFERRABLE_QTY_OR_ORDER_QTY) as number;
    await addProductsToOrderPageSteps.swapEAUnitsWithInput(targetProduct, units.toString());
    fixture.logger.info('completed entering quantity for the swapped product');
    await updateOrderWithEAProducts(addProductsToOrderPageSteps);
});

async function increaseQuantityWithInput(updateOrder: boolean){
    const addProductsToOrderPageSteps = new AddProductsToOrderPageSteps();
    const minQty = fixture.dataBag.getData(DataBagKeys.PRODUCT_CONVERSION_OR_MIN_TRANSFERRABLE_QTY_OR_ORDER_QTY) as number;
    await addProductsToOrderPageSteps.modifyEAUnitsWithInput(minQty);
    if(updateOrder)
        await updateOrderWithEAProducts(addProductsToOrderPageSteps);
}

When('adds EA products with quantities to the order', async function () {
    fixture.logger.info('adding EA products with quantities to the order step started');
    await addEAProductToTheDealerOrder();
});

export async function addEAProductToTheDealerOrder(){
    const addProductsToOrderPageSteps = new AddProductsToOrderPageSteps();
    const itemNumber = fixture.dataBag.getData(DataBagKeys.SOURCE_PRODUCT_ITEM_NUMBER_TO_USE) as string;
    await addProductsToOrderPageSteps.searchForEAProducts(ProductSelectionFilters.itemNumber
        ,itemNumber
        , "true");
    const unitsValue = (fixture.dataBag.getData(DataBagKeys.PRODUCT_CONVERSION_OR_MIN_TRANSFERRABLE_QTY_OR_ORDER_QTY) as number).toString();
    await addProductsToOrderPageSteps.selectEAProductsByItemNumber([itemNumber], [unitsValue], false);
    await updateOrderWithEAProducts(addProductsToOrderPageSteps);
}

async function updateOrderWithEAProducts(addProductsToOrderPageSteps:  AddProductsToOrderPageSteps){
    const msg = await addProductsToOrderPageSteps.updateOrderWithEAProducts();
    fixture.logger.info(`received message after adding products to the order is...${msg}`);
    expect(msg).not.toBeNull();
    expect(msg.length).toBeGreaterThan(0);
}

Then('the dealer order must be updated with the EA products', async function () {
    await checkUpdatedEAProductCountOnTheOrder();
});

Then('the dealer order must be updated with the original and swapped EA products', async function () {
    await checkUpdatedEAProductCountOnTheOrderForSwappedOperation();
});

Then('EA units on the dealer order must be incremented', async function () {
    await checkUpdatedEAProductCountOnTheOrder();
});

Then('EA units on the dealer order must be decremented', async function () {
    await checkUpdatedEAProductCountOnTheOrder();
});

Then('user should not be allowed to increment the quantity and update the order', async function () {
    const sharedPage = await StepPageHelper.getSharedPageBehavior(); 
    const errorTxt = "EA Modifiable Units can be only decreased";
    let result = await sharedPage.checkIfErrorExists(errorTxt);
    expect(result).toBeTruthy();
    await sharedPage.revertAllErrors();
    result = await sharedPage.checkIfErrorExists(errorTxt);
    expect(result).toBeFalsy();
});

async function checkUpdatedEAProductCountOnTheOrder() {
    const dealerOrderPage = await StepPageHelper.getDealerOrderPage();
    const itemNumber = fixture.dataBag.getData(DataBagKeys.SOURCE_PRODUCT_ITEM_NUMBER_TO_USE) as string;
    let displayedEAUnitsValue = await dealerOrderPage.getEAUnitsValue(itemNumber);
    const expectedEAUnitsValue = fixture.dataBag.getData(DataBagKeys.EA_UNITS) as number;
    fixture.logger.info(`expected EA Units value is - ${expectedEAUnitsValue}`);
    expect(displayedEAUnitsValue).toEqual(expectedEAUnitsValue);
}
async function checkUpdatedEAProductCountOnTheOrderForSwappedOperation() {
    const dealerOrderPage = await StepPageHelper.getDealerOrderPage();
    let itemNumber = fixture.dataBag.getData(DataBagKeys.SOURCE_PRODUCT_ITEM_NUMBER_TO_USE) as string;
    let displayedEAUnitsValue = await dealerOrderPage.getEAUnitsValue(itemNumber);
    let expectedEAUnitsValue = fixture.dataBag.getData(DataBagKeys.EA_UNITS) as number;
    fixture.logger.info(`expected EA Units value for the soruce product is - ${expectedEAUnitsValue}`);
    expect(displayedEAUnitsValue).toEqual(expectedEAUnitsValue);

    itemNumber = fixture.dataBag.getData(DataBagKeys.TARGET_PRODUCT_ITEM_NUMBER_TO_USE) as string;
    displayedEAUnitsValue = await dealerOrderPage.getEAUnitsValue(itemNumber);
    expectedEAUnitsValue = fixture.dataBag.getData(DataBagKeys.TO_ITEM_EA_UNITS) as number;
    fixture.logger.info(`expected EA Units value for the swapped product is - ${expectedEAUnitsValue}`);
    expect(displayedEAUnitsValue).toEqual(expectedEAUnitsValue);
}