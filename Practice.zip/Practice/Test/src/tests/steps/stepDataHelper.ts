import { expect } from "playwright/test";
import ApiManager from "../../helpers/util/api/apiManager";
import ProductAvailabilityRequest from "../../helpers/util/api/models/requests/productAvailabilityRequest";
import { TestDataType } from "../../helpers/util/test-data/TestDataType";
import TestDataRequest from "../../helpers/util/test-data/testDataRequest";
import { fixture } from "../../hooks/fixture";
import ProductInfo from "../../helpers/util/test-data/product/productInfo";
import ProductChangeInfo from "../../helpers/util/api/models/productChangeInfo";
import ProductFilter from "../../helpers/util/test-data/product/productFilter";
import DealerSellerInfo from "../../helpers/util/api/models/dealerSellerInfo";
import GrowerOrderItemInfo from "../../helpers/util/api/models/growerOrderItemInfo";
import SeedFulfillmentInfo from "../../helpers/util/api/models/seedFulfillmentInfo";

export default class StepDataHelper {
    
    static getDataStoreName(dataPath: string){
        const parsedDataRefs = fixture.testDataProvider.parseDataPath(dataPath);
        return parsedDataRefs[1];
    }
    static getSingleTestDataRecordForType(type: TestDataType, dataPath: string) {
        return this.getTestDataRecordForType(type, dataPath, true);
    }

    static getMultipleTestDataRecordsForType(type: TestDataType, dataPath: string) {
        return this.getTestDataRecordForType(type, dataPath, false);
    }

    private static getTestDataRecordForType(type: TestDataType, dataPath: string, returnSingleResult: boolean) {
        const dataRequest = new TestDataRequest();
        dataRequest.dataType = type;
        dataRequest.dataPath = dataPath;

        return fixture.testDataProvider.getTestDataFromDataStore(dataRequest, returnSingleResult);
    }
    static getSingleStringNodeData(dataPath: string): string{
        return StepDataHelper.getStringData(dataPath, true) as string;
    }

    static getStringNodeListData(dataPath: string): string[]{
        return StepDataHelper.getStringData(dataPath, false) as string[];
    }

    private static getStringData(dataPath: string, returnSingleResult: boolean): string | string[]{
        //const testDataProvider = pf.getTestDataProvider();
        const dataRequest = new TestDataRequest();
    
        dataRequest.dataType = TestDataType.String;
        dataRequest.dataPath = dataPath;
    
        const result = fixture.testDataProvider.getTestDataFromDataStore<TestDataType.String>(dataRequest, returnSingleResult);

        if(returnSingleResult)
            return result as string;
        else
            return result as string[];
    }

    static async getProductsForGrower(dealerAccountNumber: number, filterCategory: string, filterValue: string, returnProductsWithAvailabilityOnly: boolean = true, returnProductsThatAreOnDealerOrderOnly: boolean = false, countOfProducts: number = 1):
        Promise<ProductInfo[]>{
        let request = new ProductAvailabilityRequest();
        request.AccountNumber = dealerAccountNumber;
        switch (filterCategory) {
            case "Product Line":
                {
                    request.ProductLineList = [];
                    request.ProductLineList.push(filterValue);
                } break;
            case "Product Name":
                {
                    request.Brand = filterValue;
                } break;
            case "Brand":
                {
                    request.MarketingBrandList = [];
                    request.MarketingBrandList.push(filterValue);
                } break;
        }
        request.IsAvailabilityChecked = returnProductsWithAvailabilityOnly;
        request.IsRelatedtoDealerItemsOnly = returnProductsThatAreOnDealerOrderOnly;

        let response = await ApiManager.getAvailableProductsForTheAccount(request);
        /* DON'T PERFORM VALIDATIONS
        expect(response).toBeDefined();
        expect(response.length).toBeGreaterThan(0);*/
        if(response === undefined || response === null || response.length === 0)
            return [];
        fixture.logger.info(`available products count is...${response.length}`);
        countOfProducts = response.length > countOfProducts ? countOfProducts : response.length; //actual response length could be smaller than countOfProducts hence limit it to actual response length
        const result: ProductInfo[] = [];
        for(let index=0; index<response.length; index++){
            const product = new ProductInfo();
            //fixture.logger.info(`response[${index}] is ${JSON.stringify(response[index])}`);
            product.itemNumber = response[index].itemId.toString();
            product.name = response[index].brand;
            product.packageSize = response[index].packageSize;
            product.seedSize = response[index].seedSize.toString();
            product.technology = response[index].technology;
            product.treatment = response[index].treatment;
            product.conversionUnits = response[index].conv;
            product.itemDescription = response[index].itemDescription;
            result.push(product);
        }
        return result;
    }

    static async getDealersWithExistingOrder(recordCountToReturn: number){
        const dealerData = await ApiManager.getDealersWithOrders(recordCountToReturn);
        expect(dealerData).toBeDefined();
        expect(dealerData).not.toBeNull();
        expect(dealerData.length).toBeGreaterThanOrEqual(recordCountToReturn);
    
        return dealerData;
    }
    
    static async getGrowersWithExistingOrder(dealerAccountNumber: string = "0", recordCountToReturn: number = 1, getGrowersFromDifferentDealers: boolean = false){
        const growerData = await ApiManager.getGrowersWithOrders(recordCountToReturn, dealerAccountNumber, false, getGrowersFromDifferentDealers);
        expect(growerData).toBeDefined();
        expect(growerData).not.toBeNull();
        expect(growerData.length).toBeGreaterThanOrEqual(recordCountToReturn);
        return growerData;
    }

    static async getGrowersWithExistingOrderWithNoValidations(dealerAccountNumber: string = "0", recordCountToReturn: number = 1, getGrowersFromDifferentDealers: boolean = false){
        return await ApiManager.getGrowersWithOrders(recordCountToReturn, dealerAccountNumber, false, getGrowersFromDifferentDealers);
    }
    /**
     * Returns a product that can be selected for modification with the specified option
     * @param dealerAccountNumber 
     * @param modificationOption 
     * @returns 
     */
    static async getModifiableProductForGrower(dealerAccountNumber: number, modificationOption: string, productFilter: ProductFilter):
        Promise<{ product: ProductInfo, modifyingProduct: ProductChangeInfo }> {
        const availableProducts = await StepDataHelper.getProductsForGrower(dealerAccountNumber, productFilter.filterCategory, productFilter.searchKey, true, false, 100);
        for (let index = 0; index < availableProducts.length; index++) {
            const productChangeInfoDetails = await ApiManager.getModifiableProducts(dealerAccountNumber, parseInt(availableProducts[index].itemNumber), modificationOption);
            if (productChangeInfoDetails !== undefined && productChangeInfoDetails !== null && productChangeInfoDetails.length > 0) {
                return { product: availableProducts[index], modifyingProduct: productChangeInfoDetails[0] };
            }
        }
        //if we are here means, we could not find modifiable product
        fixture.logger.error(`could not find modifiable products`);
        expect(false).toBeTruthy();
    }

    static async getSeller(accountNumber: string): Promise<DealerSellerInfo>{
        const sellers = await ApiManager.getSellersForTheDealer(accountNumber);
        let result: DealerSellerInfo = null;
        if (sellers === undefined || sellers === null || sellers.length === 0) {
            fixture.logger.error(`could not find sellers`);
        } else {
            result = sellers[0];
        }
        /* SELLERS INFO IS NOT ALWAYS AVAILABLE SO DO NOT PERFORM VALIDATIONS
        expect(result).toBeDefined();
        expect(result).not.toBeNull();*/
        return result;
    }


    static validateAccountNumber(accountNumberData: string): boolean {
        const numbers = accountNumberData.split(',');
        for (let i = 0; i < numbers.length; i++) {
            const accountNumber = numbers[i].trim();
            // Check if the variable is a number only
            const isNumberOnly = /^\d+$/.test(accountNumber);
            if (!isNumberOnly) {
                fixture.logger.error(`account number -${accountNumber}- data type validation failed: account number should be a number`);
                return false;
            }

            // Check if it does not begin with zero
            const doesNotBeginWithZero = !/^0/.test(accountNumber);
            if (!doesNotBeginWithZero) {
                fixture.logger.error(`account number -${accountNumber}- format validation failed: account number should not start with zero`);
                return false;
            }

            // Check if the length is between 5 and 10
            const lengthValid = accountNumber.length >= 5 && accountNumber.length <= 10;
            if (!lengthValid) {
                fixture.logger.error(`account number -${accountNumber}- length validation failed: it must be between 5 and 10 inclusive`);
                return false;
            }
        }
        fixture.logger.info(`account number validations passed for the account number data -${accountNumberData}`);
        return true;
    }
    
    static async getSeedFulfillmentData(): Promise<SeedFulfillmentInfo>{
        let retryCount = 3;
        let result: SeedFulfillmentInfo;
        while (retryCount > 0) {
            result = await ApiManager.getDataForSeedFulfillment();
            /*
            //temp data
            result = new SeedFulfillmentInfo();
            result.Error = null;
            result.AccountNumber = 7021980;
            result.AccountName = "RIVER VALLEY COOP-ANNAWAN";
            result.DealerOrderNumber = "20240802011034";
            result.BranchPlantId = "501552";
            result.ItemNumber = "1691576";
            result.AvailableToShip = 40;
            result.SeedWeightPerReleaseUnit = 1723.2;
            result.PalletWeight = 70;
            result.PalletQuantity = 1;
            result.PalletType = "LOL PALLET STOCK 54INX42IN";
    
            //temp data
            */
            expect(result).toBeDefined();
            expect(result).not.toBeNull();
            fixture.logger.info('checking seed fulfillment API response error object that should be null');
            if (result.Error != null) {
                fixture.logger.warn(`seed fulfillment API failed with the error - ${JSON.stringify(result.Error)}`);
                if (retryCount > 0) {
                    fixture.logger.warn(`Retrying seed fulfillment API again.`);
                    --retryCount;
                    continue;
                }
            } else {
                retryCount = 0;
            }
            expect(result.Error).toBeNull();
            fixture.logger.info('checking seed fulfillment data properties');
            fixture.logger.info(`dealer account name is - ${result.AccountName}`);
            expect(result.AccountName).not.toBeNull();
            expect(result.AccountName.length).toBeGreaterThan(0);
            fixture.logger.info(`dealer account number is - ${result.AccountNumber}`);
            expect(result.AccountNumber).not.toBeNull();
            fixture.logger.info(`dealer order number is - ${result.DealerOrderNumber}`);
            expect(result.DealerOrderNumber).not.toBeNull();
            expect(result.DealerOrderNumber.length).toBeGreaterThan(0);
            fixture.logger.info(`branch plant id is - ${result.BranchPlantId}`);
            expect(result.BranchPlantId).not.toBeNull();
            expect(result.BranchPlantId.length).toBeGreaterThan(0);
            fixture.logger.info(`item number is - ${result.ItemNumber}`);
            expect(result.ItemNumber).not.toBeNull();
            expect(result.ItemNumber.length).toBeGreaterThan(0);
            fixture.logger.info(`AvailableToShip is - ${result.AvailableToShip}`);
            expect(result.AvailableToShip).not.toBeNull();
            expect(result.AvailableToShip).toBeGreaterThan(0);
            fixture.logger.info(`SeedWeightPerReleaseUnit is - ${result.SeedWeightPerReleaseUnit}`);
            expect(result.SeedWeightPerReleaseUnit).not.toBeNull();
            expect(result.SeedWeightPerReleaseUnit).toBeGreaterThanOrEqual(0);
        }
        return result;
    }

    static async getGrowerOrderItems(accountNumber: string, growerOrderId: string, minGeuQty: number = 0): Promise<GrowerOrderItemInfo[]>{
        const items = await ApiManager.getGrowerOrderItems(accountNumber, growerOrderId, minGeuQty);
        if (items === undefined || items === null || items.length === 0) {
            fixture.logger.error(`could not get grower order items`);
            expect(items).toBeDefined();
            expect(items).not.toBeNull();
            expect(items.length).toBeGreaterThan(0);
        }

        return items;
    }
}