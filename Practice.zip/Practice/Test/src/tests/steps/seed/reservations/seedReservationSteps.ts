import { Then, When } from "@cucumber/cucumber";
import { expect } from "@playwright/test";
import StepPageHelper from "../../stepPageHelper";
import { fixture } from "../../../../hooks/fixture";
import DataBagKeys from "../../dataBagKeys";
import ProductLineAndMarketingBrand from "../../../../helpers/util/db/resultSets/seed/productLineAndMarketingBrand";

When('user navigates to the new seed reservation page', async function () {
    await navigateToNewSeedReservationPage();
});

When('user navigates to the existing seed reservation page', async function () {
    await navigateToExistingSeedReservationPage({shipToAccount: (fixture.dataBag.getData(DataBagKeys.SHIP_TO_DEALER_NUMBER) as number).toString(),
        growerGmk: (fixture.dataBag.getData(DataBagKeys.GROWER_GMK) as number).toString(),
        seedReservationId: (fixture.dataBag.getData(DataBagKeys.SEED_RESERVATION_ID) as number).toString()});
});

When('fills reservation header details', async function () {
    fixture.logger.info('filling reservation header details');
    const seedReservationPage = await StepPageHelper.getSeedReservationPage();
    const shipToAccountNumber = (fixture.dataBag.getData(DataBagKeys.SHIP_TO_DEALER_NUMBER) as number).toString();
    const sellerNumber = (fixture.dataBag.getData(DataBagKeys.SELLER_NUMBER) as number).toString();
    const growerGmk = (fixture.dataBag.getData(DataBagKeys.GROWER_GMK) as number).toString();
    
    await seedReservationPage.selectAccountFromDropDown(shipToAccountNumber);
    await seedReservationPage.selectSellerFromDropDown(sellerNumber);
    await seedReservationPage.selectGrowerFromDropDown(growerGmk);

    const addReservationBtnEnabled = await seedReservationPage.isAddReservationButtonEnabled();
    expect(addReservationBtnEnabled).toBeTruthy();

    await seedReservationPage.fillRetailerInfo();
    
    fixture.logger.info('filled reservation header details');
});

When('adds new line item to the existing reservation', async function () {
    fixture.logger.info('adding new line item to the existing reservation');
    await addNewLineItemToTheReservation(false);
    fixture.logger.info('added new line item to the existing reservation');
});

When('adds new line item to the reservation', async function () {
    fixture.logger.info('adding new line item to the reservation');
    await addNewLineItemToTheReservation(true);
    fixture.logger.info('added new line item to the reservation');
});

async function addNewLineItemToTheReservation(isNewReservation: boolean = true) {
    const seedReservationPage = await StepPageHelper.getSeedReservationPage();
    await seedReservationPage.clickOnAddReservationButton();
    let productLine = "";
    let marketingBrand = "";

    if (isNewReservation) {
        const productLineAndMarketingBrandInfo = fixture.dataBag.getData(DataBagKeys.PRODUCT_LINE_AND_MARKETING_BRAND_INFO_CONFIG) as ProductLineAndMarketingBrand[];
        productLine = productLineAndMarketingBrandInfo[1].ProductLineName;
        marketingBrand = productLineAndMarketingBrandInfo[1].MarketingBrandName;

        await seedReservationPage.selectProductLineForANewReservation(productLine);
        await seedReservationPage.selectMarketingBrandForANewReservation(marketingBrand);
        await seedReservationPage.increaseReservationQty();

        const isSubmitReservationBtnEnabled = await seedReservationPage.isSubmitReservationButtonEnabled();
        expect(isSubmitReservationBtnEnabled).toBeTruthy();

    } else {
        const productLineAndMarketingBrandInfo = fixture.dataBag.getData(DataBagKeys.MISSING_PRODUCT_LINE_AND_MARKETING_BRAND_INFO) as ProductLineAndMarketingBrand;
        productLine = productLineAndMarketingBrandInfo.ProductLineName;
        marketingBrand = productLineAndMarketingBrandInfo.MarketingBrandName;
        await seedReservationPage.selectProductLineForAnExistingReservation(productLine);
        await seedReservationPage.selectMarketingBrandForAnExistingReservation(marketingBrand);
        await seedReservationPage.increaseReservationQty();
        const isUpdateReservationBtnEnabled = await seedReservationPage.isUpdateReservationButtonEnabled();
        expect(isUpdateReservationBtnEnabled).toBeTruthy();
    }
}

When('attempts to remove the line item from the reservation', async function () {
    fixture.logger.info('attempting to remove the line item from the reservation');
    const seedReservationPage = await StepPageHelper.getSeedReservationPage();
    const productLineAndMarketingBrandInfo = fixture.dataBag.getData(DataBagKeys.PRODUCT_LINE_AND_MARKETING_BRAND_INFO) as ProductLineAndMarketingBrand;
    const productLine = productLineAndMarketingBrandInfo.ProductLineName;
    const marketingBrand = productLineAndMarketingBrandInfo.MarketingBrandName;
    await seedReservationPage.selectReservationLineItem(productLine, marketingBrand);
    
    await seedReservationPage.clickOnDeleteButton(true); //confirming the deletion of the line item from the reservation
    fixture.logger.info('attempted to remove the line item from the reservation');
});

When('user clicks on Delete-Reservation', async function () {
    await deleteExistingSeedReservationPage({shipToAccount: (fixture.dataBag.getData(DataBagKeys.SHIP_TO_DEALER_NUMBER) as number).toString(),
        growerGmk: (fixture.dataBag.getData(DataBagKeys.GROWER_GMK) as number).toString(),
        seedReservationId: (fixture.dataBag.getData(DataBagKeys.SEED_RESERVATION_ID) as number).toString()});
});

When('user clicks on Submit-Reservation', async function () {
    fixture.logger.info('clicking on submit reservation button');
    const seedReservationPage = await StepPageHelper.getSeedReservationPage();
    await seedReservationPage.clickOnSubmitReservationButton();
    const isBackToReservationListBtnEnabled = await seedReservationPage.isBackToReservationListButtonEnabled();
    expect(isBackToReservationListBtnEnabled).toBeTruthy();
    fixture.logger.info('clicked on submit reservation button');
    fixture.logger.info('going back to seed reservations list page after submitting the reservation');
    await seedReservationPage.clickOnBackToReservationListButton();    
});

When('modifies reservation line quantity', async function () {
    const seedReservationPage = await StepPageHelper.getSeedReservationPage();
    const productLineAndMarketingBrandInfo = fixture.dataBag.getData(DataBagKeys.PRODUCT_LINE_AND_MARKETING_BRAND_INFO) as ProductLineAndMarketingBrand[];
    const productLine = productLineAndMarketingBrandInfo[0].ProductLineName;
    const marketingBrand = productLineAndMarketingBrandInfo[0].MarketingBrandName;
    await seedReservationPage.selectReservationLineItem(productLine, marketingBrand);
    await seedReservationPage.increaseReservationQty();
    const updateReservationBtnEnabled = await seedReservationPage.isUpdateReservationButtonEnabled();
    expect(updateReservationBtnEnabled).toBeTruthy();
});

When('user clicks on Update-Reservation', async function () {
    const seedReservationPage = await StepPageHelper.getSeedReservationPage();
    await seedReservationPage.clickOnUpdateReservationButton();
});

Then('a new reservation must be created', async function () {
    fixture.logger.info('verifying that a new reservation is created');
    const seedReservationsListPage = await StepPageHelper.getSeedReservationsListPage();
    const reservationStatus = await seedReservationsListPage.isReservationAvailable(
        (fixture.dataBag.getData(DataBagKeys.SHIP_TO_DEALER_NUMBER) as number).toString(), 
        (fixture.dataBag.getData(DataBagKeys.GROWER_GMK) as number).toString());
    
    expect(reservationStatus).toBeTruthy();
    fixture.logger.info('verified that a new reservation is created');
});

Then('the reservation must be updated', async function () {
    const seedReservationPage = await StepPageHelper.getSeedReservationPage();
    const isBackToReservationListBtnEnabled = await seedReservationPage.isBackToReservationListButtonEnabled();
    expect(isBackToReservationListBtnEnabled).toBeTruthy();
});

Then('Update-Reservation button should be disabled', async function () {
    const seedReservationPage = await StepPageHelper.getSeedReservationPage();
    const isUpdateReservationBtnEnabled = await seedReservationPage.isUpdateReservationButtonEnabled();
    expect(isUpdateReservationBtnEnabled).toBeFalsy();
});

Then('the reservation must be deleted', async function () {
    const seedReservationPage = await StepPageHelper.getSeedReservationsListPage();
    const isReservationAvailable = await seedReservationPage.isReservationAvailable(
        (fixture.dataBag.getData(DataBagKeys.SHIP_TO_DEALER_NUMBER) as number).toString(), 
        (fixture.dataBag.getData(DataBagKeys.GROWER_GMK) as number).toString());
    expect(isReservationAvailable).toBeFalsy();
});

async function navigateToNewSeedReservationPage(){
    fixture.logger.info('navigating to new seed reservation page');
    let result = true;
    try {
    const seedReservationsPage = await StepPageHelper.getSeedReservationsListPage();
    await seedReservationsPage.clickOnNewReservationButton();
    } catch (error) {
        result = false;
        fixture.logger.error("failed to navigate to new seed reservation page. Error: " + error);
    }
    expect(result).toBeTruthy();
    fixture.logger.info('navigated to new seed reservation page');
}

async function navigateToExistingSeedReservationPage(navigationData: {shipToAccount: string, growerGmk: string, seedReservationId: string;}){
    await invokeContextMenuAction(navigationData.shipToAccount, navigationData.growerGmk, navigationData.seedReservationId, 'Edit');
}

async function deleteExistingSeedReservationPage(navigationData: {shipToAccount: string, growerGmk: string, seedReservationId: string;}){
    await invokeContextMenuAction(navigationData.shipToAccount, navigationData.growerGmk, navigationData.seedReservationId, 'Delete');
}

async function invokeContextMenuAction(shipToAccount: string, growerGmk: string, seedReservationId: string, contextOption: string){
    let result = true;
    try {
        const seedReservationsListPage = await StepPageHelper.getSeedReservationsListPage();
        
        fixture.logger.info('selecting account - ' + shipToAccount + ' on seed reservation page');
        await seedReservationsListPage.selectAccountFromDropDown(shipToAccount);

        fixture.logger.info('selecting grower - ' + growerGmk + ' on seed reservation page');
        await seedReservationsListPage.selectGrowerFromDropDown(growerGmk);

        fixture.logger.info('clicking on reservation context menu for the reservation id - ' + seedReservationId);
        await seedReservationsListPage.clickOnReservationContextMenu(seedReservationId);

        if(contextOption === 'Edit'){
            await seedReservationsListPage.clickOnEditReservationContextMenuItem();
        } else if(contextOption === 'Delete'){
            await seedReservationsListPage.clickOnDeleteReservationContextMenuItem();
            await seedReservationsListPage.confirmOperationOnConfirmationDialog(true);
        } else if(contextOption === 'ConvertOrReconcile'){
            await seedReservationsListPage.clickOnConvertReconcileReservationContextMenuItem();
        }
    } catch (error) {
        result = false;
        fixture.logger.error("failed to invoke context menu action on seed reservation page. Error: " + error);
    }
    expect(result).toBeTruthy();
    fixture.logger.info('invoked context menu action on seed reservations list page');
}