import { Given, Then, When, setDefaultTimeout } from "@cucumber/cucumber";
import { expect } from "@playwright/test";
import { fixture } from "../../../../hooks/fixture";
import DataBagKeys from "../../dataBagKeys";
import { AccountFilterOption } from "../../../../pages/account/accountPage";
import EvolveDbManager from "../../../../helpers/util/db/evolveDbManager";
import { SkipScenarioError } from "../../../../helpers/util/errorHandler";
import SeedReplantRequestGetOrCreateSpResult from "../../../../helpers/util/db/resultSets/seed/seedReplantGetOrCreateSpResult";
import { setAccounts } from "../../grower/orders/verification/accountSetupSteps";

setDefaultTimeout(60 * 1000 * 5)
const userName = process.env.EvolveUserName;

Given('user sets single account context for seed replant {string} request', async function (requestType: string) {
    console.log(`Setting single account context for seed replant request type: ${requestType}`);
    try {
        await getDataForSeedReplantRequest.call(this, requestType);
    } catch (error) {
        // Sometimes instanceof can fail across module boundaries; handle by name/message too
        if (error instanceof SkipScenarioError || error?.name === 'SkipScenarioError' || /skipscenarioerror|skip/i.test(error?.message || '')) {
            fixture.logger.info('Skipping scenario due to SkipScenarioError (caught in outer step).');
            return;
        }
        // rethrow other errors so test framework can report them
        throw error;
    }

    fixture.dataBag.saveData(DataBagKeys.SEED_REPLANT_REQUEST_TYPE, requestType);
});

async function getDataForSeedReplantRequest(requestType: string){

        fixture.logger.info(`seed replant request type is - ${requestType}`);    
        fixture.logger.info("getting data for the scenario using stored procedure");
        let result = true;
        let spResult: SeedReplantRequestGetOrCreateSpResult = null;
        try {
            let evolveDbManager = new EvolveDbManager();
            const dbResult = await evolveDbManager.getDataForSeedReplantRequestGetOrCreate(requestType, userName);
            expect(dbResult.operationResult).toBeTruthy();
            expect(dbResult.operationData).toBeDefined();
            expect(dbResult.operationData).not.toBeNull();
            spResult = dbResult.operationData;

            if(requestType == "Active" || requestType == "Draft"){
                const activeOrDraftRows = Array.isArray(spResult.SeedReplantRequestActiveOrDraft)
                    ? spResult.SeedReplantRequestActiveOrDraft
                    : [spResult.SeedReplantRequestActiveOrDraft];
                const accNumber = activeOrDraftRows[0].AccountNumber.toString();
                await setAccounts(AccountFilterOption.ACCOUNT_NUMBER, accNumber, accNumber, true);
                fixture.dataBag.saveData(DataBagKeys.SEED_REPLANT_ACTIVE_OR_DRAFT, activeOrDraftRows);
                fixture.logger.info(`Saved to DataBag with key ${DataBagKeys.SEED_REPLANT_ACTIVE_OR_DRAFT}`);
            }
            if (requestType == "Create") {
                const createRows = Array.isArray(spResult.SeedReplantRequestCreate)
                    ? spResult.SeedReplantRequestCreate
                    : [spResult.SeedReplantRequestCreate];

                // Debug logging
                fixture.logger.info(`Total rows: ${createRows.length}`);
                createRows.forEach((row, index) => {
                    fixture.logger.info(`Row ${index}: ${JSON.stringify(row, null, 2)}`);
                    if (row) {
                        fixture.logger.info(`  - GrowerHaveLicense value: ${row.GrowerHaveLicense} (type: ${typeof row.GrowerHaveLicense})`);
                    }
                });

                const licensedRow = createRows.find(r => {
                    const v = r?.GrowerHaveLicense;
                    fixture.logger.info(`Checking row for licensed: GrowerHaveLicense = ${v} (type: ${typeof v})`);
                    return v === true || v === 'Yes' || v === 'Y' || (typeof v === 'string' && v.toLowerCase() === 'yes');
                });
                const unlicensedRow = createRows.find(r => {
                    const v = r?.GrowerHaveLicense;
                    fixture.logger.info(`Checking row for unlicensed: GrowerHaveLicense = ${v} (type: ${typeof v})`);
                    return v === false || v === 'No' || v === 'N' || (typeof v === 'string' && v.toLowerCase() === 'no');
                });

                if (licensedRow) fixture.dataBag.saveData(DataBagKeys.SEED_REPLANT_CREATE_LICENSED, licensedRow);
                if (unlicensedRow) fixture.dataBag.saveData(DataBagKeys.SEED_REPLANT_CREATE_UNLICENSED, unlicensedRow);
                fixture.logger.info(`Seed replant create rows found: Licensed - ${licensedRow ? 'Yes' : 'No'})`);
                fixture.logger.info(`Seed replant create rows found: Unlicensed - ${unlicensedRow ? 'No' : 'Yes'}`);

                // Maintain backward compatibility: save a single selected row (prefer licensed)
                const selectedRow = licensedRow ?? unlicensedRow ?? createRows[0];
                fixture.dataBag.saveData(DataBagKeys.SEED_REPLANT_CREATE, selectedRow);

                const accNumber = selectedRow.ShipToAccount.toString();
                await setAccounts(AccountFilterOption.ACCOUNT_NUMBER, accNumber, accNumber, true);
            }
        } catch (error) {
            if (error instanceof SkipScenarioError) {
                fixture.logger.info("Skipping scenario due to SkipScenarioError.");
                this.skip(); // ✅ This tells Cucumber to skip the scenario
                return; // stop further processing after skipping
            } else {
            fixture.logger.error("Setting account context for grower order modification failed. Error: " + error);
            result = false;
            }
        }
       expect(result).toBeTruthy();
    };