import { Given, When, Then } from '@cucumber/cucumber';
import { expect, Locator } from '@playwright/test';
import StepPageHelper from '../../stepPageHelper';
import { fixture } from '../../../../hooks/fixture';
import DataBagKeys from '../../dataBagKeys';

const shipTo = "shipTo";
const creditAccount = "creditAccount";
const grower = "grower";
const nonSubscriberEmail = "nonSubscriberEmail";
const seedReplantCreatePageBreadcrumb = "//li[@class='breadcrumb-item active']/a[text()='Seed Replant']/parent::li/following-sibling::li/span[@id='spnBreadcrum']";

Given ('User is on seed replant page', async function() {
  await navigateToSeedReplantPage();
});

Given('Status Notice message saved in DataBag from DataBase', async function () {
  const SeedReplantPage = await StepPageHelper.getSeedReplantPage();
  const statusNoticeMessage = await SeedReplantPage.getStatusNoticeMessageFromDB();
  fixture.logger.info(`Saving Status Notice message to DataBag with key ${DataBagKeys.SEED_REPLANT_STATUS_NOTICE_MESSAGE}: ${statusNoticeMessage}`);
  fixture.dataBag.saveData(DataBagKeys.SEED_REPLANT_STATUS_NOTICE_MESSAGE, statusNoticeMessage);
});

  async function navigateToSeedReplantPage() {
    try {
      const headerNavigationPage = await StepPageHelper.getHeaderNavigationPage();
      await headerNavigationPage.navigateToSeedReplantPage();
    } catch (err) {
      // eslint-disable-next-line no-console
      console.error('Error navigating to Seed Replant page in step module:', err);
      throw err;
    }
  }

When('User navigates to "Seed" menu and selects "Seed Replant"', async function () {
await navigateToSeedReplantPage();  
})

When('The user clicks on Create New Request from Seed Replant page', async function () {
  await createNewRequestButtonRedirection();
});

When('User enters the data in header fields {string} and select failed and Replant product then click on Save Draft button', async function (growerType: string) {
  if (growerType === "Licensed Grower") {
    await createSeedReplantDraftOrder("Yes"); // For licensed grower
  } else {
    await createSeedReplantDraftOrder("No"); // For unlicensed grower
  }     
});

When('User enters the data in header fields {string} and select failed and Replant product then click on Review Request button', async function (growerType: string) {
  if (growerType === "Licensed Grower") {
    await createSeedReplantRequest("Yes"); // For licensed grower
  } else {
    await createSeedReplantRequest("No"); // For unlicensed grower
  }  
});

When('User navigates to {string} tab', async function (tabName: string) {
  await navigateToTab(tabName);
});

When('User navigates to {string} tab and clicks on first request id from the list', async function (tabName: string) {
  const SeedReplantPage = await StepPageHelper.getSeedReplantPage();
  (this as any).selectedSeedReplantRequestNumber = await SeedReplantPage.openRequestDetailsByRequestId(tabName);
});

When('Get replant request details based on request and store in DataBag', async function () {
  const SeedReplantPage = await StepPageHelper.getSeedReplantPage();
  const requestNumber = (this as any).selectedSeedReplantRequestNumber;
  fixture.logger.info(`Fetching details for request number: ${requestNumber} and storing in DataBag`);
  await SeedReplantPage.getDataForSeedReplantRequestUsingSP("Detail", requestNumber);
});


async function navigateToTab(tabName: string) {
  const SeedReplantPage = await StepPageHelper.getSeedReplantPage();
  await SeedReplantPage.switchToTab(tabName);
}

When('User clicks on agrrement check box and then click on Submit for Approval', async function () {
  await submitSeedReplantRequestForApproval();
});

  async function createNewRequestButtonRedirection() {
    const SeedReplantPage = await StepPageHelper.getSeedReplantPage();
    await SeedReplantPage.openCreateNewSeedReplantPage();
}

  async function createSeedReplantDraftOrder(isGrowerLicensed: string) {
    const SeedReplantPage = await StepPageHelper.getSeedReplantPage();
    fixture.logger.info("createSeedReplantDraftOrder - isGrowerLicensed:", isGrowerLicensed);
    await SeedReplantPage.createNewSeedReplantDraft(isGrowerLicensed);
  }

  async function createSeedReplantRequest(isGrowerLicensed: string = "Yes") {
    const SeedReplantPage = await StepPageHelper.getSeedReplantPage();
    fixture.logger.info("createSeedReplantRequest - isGrowerLicensed:", isGrowerLicensed);
    await SeedReplantPage.createNewSeedReplantRequest(isGrowerLicensed);
  }

  async function submitSeedReplantRequestForApproval() {
    const SeedReplantPage = await StepPageHelper.getSeedReplantPage();
    await SeedReplantPage.submitApprovalForSeedReplantRequest();
  }

Then('The user should be able to view "Seed Replant" page', async function() {
  await verifyItsSeedReplantPage();
});

When('User clicks on filter option verify the list of header filters available on seed replant page', async function () {
  await verifyDropdownOptionsOnSeedReplantPage();
});

When('User clicks on Export to Excel on seed replant page', async function () {
  const SeedReplantPage = await StepPageHelper.getSeedReplantPage();
  (this as any).seedReplantExportResult = await SeedReplantPage.exportSeedReplantDataToExcel();
});

When('non of the filter is applied, user should be able to see all the records on Seed Replant page', async function () {
  const SeedReplantPage = await StepPageHelper.getSeedReplantPage();
  const rows = await SeedReplantPage.getAllRowTexts();
  expect(rows.length).toBeGreaterThan(0);
  // Save initial rows on the world context for later comparison
  (this as any).initialSeedReplantRows = rows;
});

Then('user should be able to filter the records based on applied header filters on Seed Replant page', async function () {
  const initial: string[] = (this as any).initialSeedReplantRows ?? [];
  const results: Record<string, string[]> = (this as any).filteredResultsByOption ?? {};
  expect(Object.keys(results).length).toBeGreaterThan(0);
  for (const [opt, rows] of Object.entries(results)) {
    expect(rows.length).toBeGreaterThan(0);
    // filtered results should be <= initial results
    expect(rows.length).toBeLessThanOrEqual(initial.length);
  }
});

Then('User should be able to see all the elements mentioned in scenario on seed replant page', async function() {
await verifyElementAvailability();
});

Then('Excel file should be downloaded with data on seed replant page', async function () {
  const exportResult = (this as any).seedReplantExportResult;
  if (exportResult) {
  expect(exportResult).toBeDefined();
    if (exportResult.filePath !== "" || exportResult.fileName !== "" || exportResult.rowCount !== 0) {
    expect(exportResult.filePath).toBeTruthy();
    expect(exportResult.fileName).toMatch(/\.xlsx$/i);
    expect(exportResult.rowCount).toBeGreaterThan(1);
    } else {
      fixture.logger.info('Excel export was triggered but no data was available to export. This is expected if there are no records on the Seed Replant page.');
    }
  } else {
    fixture.logger.info('No Data available to export, so Excel file download was not triggered. This is expected if there are no records on the Seed Replant page.');
  }
});

Then('Seed Replant Create Request page should be open', async function () {
  await verifyItsSeedReplantCreatePage();
});

Then('Order should be created as draft for {string} and user should redirect to draft order page', async function(growerType: string) {
  await verifyItDraftOrderTab(growerType === "Licensed Grower" ? "Yes" : "No");
});

Then('Request should be created for {string} and user should redirect to Review Request page', async function(growerType: string) {
  await verifyItIsSeedReplantReviewPage(); // For licensed grower
});

Then('Treatment details should be displayed for failed and replant products on review request page', async function() {
  await verifyTreatmentDetailsOnReviewRequestPage();
});

When('User clicks on View as PDF on seed replant review page', async function () {
  const SeedReplantPage = await StepPageHelper.getSeedReplantPage();
  (this as any).seedReplantPdfExportResult = await SeedReplantPage.viewRequestAsPdf();
});

Then('PDF should be generated with treatment details for failed and replant products', async function () {
  const pdfResult = (this as any).seedReplantPdfExportResult;
  expect(pdfResult).toBeDefined();
  expect(pdfResult.fileName).toMatch(/\.pdf$/i);
  expect(pdfResult.filePath).toBeTruthy();
  expect(pdfResult.fileSize).toBeGreaterThan(0);
  expect(pdfResult.failedTreatmentCount).toBeGreaterThan(0);
  expect(pdfResult.replantTreatmentCount).toBeGreaterThan(0);
});

Then('Request should not be created for UnLicensed Grower and user should stay on same page with validation error message', async function() {
  await verifyErrorMessageForUnLicensedGrower(); // For Unlicensed grower
});

Then('Order should be created and user should redirect to active seed replant request tab', async function() {
  await verifyItIsActiveSeedReplantTab();
});

Then('User should be able to see the expected columns on {string} tab', async function(tabName: string) {
  await verifyColumnsOnSeedReplantRequest(tabName);
});

Then('User should be able to see the correct list of replant request in {string} tab based on the status of the request', async function(tabName: string) {
  await verifyReplantRequestListInTab(tabName);
});

Then('Seed Replant Request details page should be open', async function() {
  await verifySeedReplantRequestDetailsPage((this as any).selectedSeedReplantRequestNumber);
});

Then('{string} seed replant request details should be correct and mapped to corresponding fields with expected action buttons', async function(tabName: string) {
  await verifySeedReplantRequestDetails(tabName);
});

  async function verifyColumnsOnSeedReplantRequest(tabName: string) {
    const SeedReplantPage = await StepPageHelper.getSeedReplantPage();
    await SeedReplantPage.verifyColumsAvailabilityOnSeedReplantRequest(tabName);
  }

  async function verifyItsSeedReplantPage() {
    const SeedReplantPage = await StepPageHelper.getSeedReplantPage();
    const headerText = await SeedReplantPage.verifyPageAndItsHeader("seed-replant-landing", "//h3"); 
    expect(headerText.trim()).toBe("Seed Replant");
  }

  async function verifyElementAvailability() {
    const SeedReplantPage = await StepPageHelper.getSeedReplantPage();
    await SeedReplantPage.verifyElementVisibility();
  }

  async function verifyItsSeedReplantCreatePage() {
    const SeedReplantPage = await StepPageHelper.getSeedReplantPage();
    const breadcrumbText = await SeedReplantPage.verifyPageAndItsHeader("seed-replant-request-entry", seedReplantCreatePageBreadcrumb); 
    expect(breadcrumbText.trim()).toBe("Create Request");
  }

  async function verifyItDraftOrderTab(isLicensedGrower: string) {
    const SeedReplantPage = await StepPageHelper.getSeedReplantPage();
    await SeedReplantPage.verifyCreatedOrderIsInDraftTab(isLicensedGrower);
  }

  async function verifyErrorMessageForUnLicensedGrower() {
    const SeedReplantPage = await StepPageHelper.getSeedReplantPage();
    await SeedReplantPage.verifyErrorMessageForUnlicensedGrower();
  }

  async function verifyItIsActiveSeedReplantTab() {
    const SeedReplantPage = await StepPageHelper.getSeedReplantPage();
    await SeedReplantPage.verifySubmitedRequestIsInActiveReplantRequestTab();
  }

  async function verifyItIsSeedReplantReviewPage() {
    const SeedReplantPage = await StepPageHelper.getSeedReplantPage();
    await SeedReplantPage.verifyElementsVisibilityOnSeedReplantRequestReview();
  }

  async function verifyTreatmentDetailsOnReviewRequestPage() {
    const SeedReplantPage = await StepPageHelper.getSeedReplantPage();
    await SeedReplantPage.verifyTreatmentDetailsOnReviewRequestPage();
  }

  async function verifyDropdownOptionsOnSeedReplantPage() {
    const SeedReplantPage = await StepPageHelper.getSeedReplantPage();
    await SeedReplantPage.verifyFilterDropDownOptions();
  }

  async function verifyReplantRequestListInTab(tabName: string) {
    const SeedReplantPage = await StepPageHelper.getSeedReplantPage();
    await SeedReplantPage.switchToTab(tabName);
    await SeedReplantPage.verifyReplantRequestList(tabName);
  }

  async function verifySeedReplantRequestDetailsPage(requestNumber: string) {
    const SeedReplantPage = await StepPageHelper.getSeedReplantPage();
    await SeedReplantPage.verifySeedReplantRequestDetailsPage(requestNumber);
  }

  async function verifySeedReplantRequestDetails(tabName: string) {
    const SeedReplantPage = await StepPageHelper.getSeedReplantPage();
    await SeedReplantPage.verifySeedReplantRequestDetailData(tabName);
  }