import { Given, When, Then, setDefaultTimeout } from "@cucumber/cucumber";

import { expect } from "@playwright/test";
import { fixture } from "../../../../hooks/fixture";
import StepPageHelper from "../../stepPageHelper";
import DataBagKeys from "../../dataBagKeys";
import SeedFulfillment from "../../../../helpers/util/test-data/fulfillment/seedFulfillment";
import ReleasedProduct from "../../../../helpers/util/test-data/fulfillment/releasedProduct";
import StepDataHelper from "../../stepDataHelper";
import { TestDataType } from "../../../../helpers/util/test-data/TestDataType";
import JDEUser from "../../../../helpers/util/test-data/account/jdeUser";
import AccountDetailsBasic from "../../../../helpers/util/test-data/dealer/accountDetailsBasic";
import DateHelper from "../../../../helpers/types/dateHelper";
import OrderReleaseDeliveryInstructions from "../../../../helpers/util/test-data/fulfillment/orderReleaseDeliveryInstructions";
import PalletDetails from "../../../../helpers/util/test-data/fulfillment/palletDetails";
setDefaultTimeout(60 * 1000 * 5);

const shipTo = "shipTo";
const deliverTo = "deliverTo";
const branch = "branch";
const otherOrderReleaseDetails = "otherOrderReleaseDetails";

Given('user is on seed-fulfillment page', async function () {
    await navigateToSeedFulfillmentPage();
});

async function navigateToSeedFulfillmentPage() {
    const headerNavigationPage = await StepPageHelper.getHeaderNavigationPage();
    await headerNavigationPage.navigateToSeedFulfillmentPage();
}
When('user starts a new order release request', async function () {
    await startNewReleaseOrder();
});

async function startNewReleaseOrder() {
    const seedFulfillmentPage = await StepPageHelper.getSeedFulfillmentPage();
    let result = true;
    try {
        result = await seedFulfillmentPage.startNewReleaseOrder();
    }
    catch (error) {
        fixture.logger.error("Failed to start new release order (seed fulfillment). Error: " + error);
    }
    expect(result).toBeTruthy();
}

When('selects ship-to account eligible for delivery instructions', async function () {
    await selectReleaseFormItem(shipTo);
});
function initializeSeedFulfillmentReqWithDeliveryDetails(): SeedFulfillment{
    let seedFulfillmentRequest = new SeedFulfillment();
    seedFulfillmentRequest.shipTo = new AccountDetailsBasic();
    seedFulfillmentRequest.shipTo.number = (fixture.dataBag.getData(DataBagKeys.SOURCE_DEALER_ACCOUNT_NUMBER) as number).toString();
    seedFulfillmentRequest.deliverTo = new AccountDetailsBasic();
    seedFulfillmentRequest.deliverTo.number = (fixture.dataBag.getData(DataBagKeys.SOURCE_DEALER_ACCOUNT_NUMBER) as number).toString();
    seedFulfillmentRequest.branch =  fixture.dataBag.getData(DataBagKeys.BRANCH_PLANT) as string;
    seedFulfillmentRequest.requestedDate = DateHelper.getDateTimeUTC();
    seedFulfillmentRequest.freightHandlingCode = "PREPAID FREIGHT";
    seedFulfillmentRequest.requestType = "S9 order. Auto Pick Slip";
    seedFulfillmentRequest.inventoryComputeOptions = "Available to release";

    fixture.dataBag.saveData(DataBagKeys.SEED_FULFILLMENT, seedFulfillmentRequest);
    return seedFulfillmentRequest;
}
async function selectReleaseFormItem(item: string) {
    const seedFulfillmentPage = await StepPageHelper.getSeedFulfillmentPage();
    let seedFulfillmentRequest = fixture.dataBag.getData(DataBagKeys.SEED_FULFILLMENT) as SeedFulfillment;
    if(seedFulfillmentRequest === undefined || seedFulfillmentRequest === null){
        seedFulfillmentRequest = initializeSeedFulfillmentReqWithDeliveryDetails();
    }

    switch (item) {
        case shipTo:
            {
                await seedFulfillmentPage.selectShipToAccount(seedFulfillmentRequest);
            }
            break;
        case deliverTo:
            { 
                await seedFulfillmentPage.selectDeliverToAccount(seedFulfillmentRequest);
            }
            break;
        case branch:
            {
                await seedFulfillmentPage.selectBranch(seedFulfillmentRequest);
            }
            break;
        case otherOrderReleaseDetails:
            {
                await seedFulfillmentPage.fillOtherOrderReleaseDetails(seedFulfillmentRequest);
            }
            break;
    }
}

When('selects branch option', async function () {
    await selectReleaseFormItem(branch);
});

Then('Delivery Instructions option must be enabled', async function () {
    const seedFulfillmentPage = await StepPageHelper.getSeedFulfillmentPage();
    const result = await seedFulfillmentPage.isDeliveryInstructionsEditBtnEnabled();
    expect(result).toBeTruthy();
});

async function checkIfDeliveryInstructionsBtnIsEnabled(){
    const seedFulfillmentPage = await StepPageHelper.getSeedFulfillmentPage();
    let isOptionEnabled = await seedFulfillmentPage.isEditDeliveryInstructionsBtnEnabled();
    if(!isOptionEnabled){
        //const seedFulfillmentRequest = fixture.dataBag.getData(DataBagKeys.SEED_FULFILLMENT) as SeedFulfillment;
        const shipTo = fixture.dataBag.getData(DataBagKeys.SOURCE_DEALER_ACCOUNT_NUMBER);
        const branch = fixture.dataBag.getData(DataBagKeys.BRANCH_PLANT);
        fixture.logger.error(`Delivery instructions edit button is not enabled. Order related to specified ShitpTo account - ${shipTo} - and branch - ${branch} - does not have any products with 'Available to Release' property greater than zero`);
    }
    expect(isOptionEnabled).toBeTruthy();
}
Given('Delivery Instructions option is enabled', async function () {
    await startNewReleaseOrder();
    await selectReleaseFormItem(shipTo);
    await selectReleaseFormItem(branch);
    await checkIfDeliveryInstructionsBtnIsEnabled();
});

When('user opens delivery instructions page', async function () {
    const seedFulfillmentPage = await StepPageHelper.getSeedFulfillmentPage();
    await seedFulfillmentPage.clickEditDeliveryInstructionsBtn();
});

When('adds a new row for delivery instructions', async function () {
    await addNewDeliveryInstructionsRow();
});

async function addNewDeliveryInstructionsRow() {
    const seedFulfillmentPage = await StepPageHelper.getSeedFulfillmentPage();
    fixture.logger.info('before adding new records, deleting all existing delivery instructions records');
    await seedFulfillmentPage.deleteAllDeliveryInstructionRecords();
    /*let currentDeliveryInstructionsRecordsCount = await seedFulfillmentPage.getCurrentDeliveryInstructionsRecordsCount();
    fixture.dataBag.saveData(DataBagKeys.CURRENT_DELIVERY_INSTRUCTIONS_COUNT, currentDeliveryInstructionsRecordsCount);*/
    await seedFulfillmentPage.clickNewDeliveryInstructionsRowBtn();
}

When('provides all the details for a new delivery instructions record', async function () {
    await fillDeliveryInstructionsRecordDetails(true);
});
function getSeedFulfillmentRequestData(): SeedFulfillment{
    const seedFulfillmentRequest = new SeedFulfillment();
    seedFulfillmentRequest.deliveryInstructions = new OrderReleaseDeliveryInstructions();
    seedFulfillmentRequest.deliveryInstructions.contactType = "Primary";
    seedFulfillmentRequest.deliveryInstructions.deliveryInstruction = [ "Call Ahead (do not use on LTLs, if no answer the driver skips the stop) (CALL 1st)" ];
    seedFulfillmentRequest.deliveryInstructions.email = "qa@auto.com";
    seedFulfillmentRequest.deliveryInstructions.firstName = "QA";
    seedFulfillmentRequest.deliveryInstructions.lastName = "Auto";
    seedFulfillmentRequest.deliveryInstructions.phone = "123-456-7890";
    seedFulfillmentRequest.deliveryInstructions.productLine = "Alfalfa";

    return seedFulfillmentRequest;
}

async function fillDeliveryInstructionsRecordDetails(isNewRecord: boolean = false) {
    const seedFulfillmentPage = await StepPageHelper.getSeedFulfillmentPage();
    //const seedFulfillmentRequest = fixture.dataBag.getData(DataBagKeys.SEED_FULFILLMENT) as SeedFulfillment;
    const seedFulfillmentRequest = getSeedFulfillmentRequestData();
    let recordIndex = 1;
    /*if(isNewRecord){
        recordIndex = fixture.dataBag.getData(DataBagKeys.CURRENT_DELIVERY_INSTRUCTIONS_COUNT) as number;
        recordIndex = recordIndex + 1;
    }*/
    await seedFulfillmentPage.fillNewDeliveryInstructionsRowDetails(seedFulfillmentRequest, recordIndex);
}
When('saves the details', async function () {
    await saveNewDeliveryInstructionsRecord(true);
});

async function saveNewDeliveryInstructionsRecord(verifyOperationCompletionMsg: boolean) {
    const seedFulfillmentPage = await StepPageHelper.getSeedFulfillmentPage();
    let displayedMsg = "";
    try {
        displayedMsg = await seedFulfillmentPage.clickDeliveryInstrcutionsSaveBtn();
    } catch (error) {
        fixture.logger.warn('failed to get the toast message hence skipping checking it. Error: ' + error)
    }
    if (verifyOperationCompletionMsg)
        fixture.dataBag.saveData(DataBagKeys.OPERATION_COMPLETION_MESSAGE, displayedMsg);
}

Then('a new Delivery Instructions record must be created', async function () {
    await checkDeliveryInstrcutionsCreateOrUpdateOperationMsg(false);
    const seedFulfillmentPage = await StepPageHelper.getSeedFulfillmentPage();
    let currentDeliveryInstructionsRecordsCount = await seedFulfillmentPage.getCurrentDeliveryInstructionsRecordsCount();
    fixture.logger.info(`records count after adding the new instructions row is ${currentDeliveryInstructionsRecordsCount}`);
    /*let oldRecordCount = fixture.dataBag.getData(DataBagKeys.CURRENT_DELIVERY_INSTRUCTIONS_COUNT) as number;
    fixture.logger.info(`records count before adding the new instructions row is ${oldRecordCount}`);
    expect(oldRecordCount).toBeLessThan(currentDeliveryInstructionsRecordsCount);*/
    expect(currentDeliveryInstructionsRecordsCount).toBeGreaterThan(0);
});

async function createNewDeliveryInstructionRecord() {
    await addNewDeliveryInstructionsRow();
    await fillDeliveryInstructionsRecordDetails(true);
    await saveNewDeliveryInstructionsRecord(true);
}
When('selects an existing delivery instructions record for edit', async function () {
    //await createNewDeliveryInstructionsRecordIfNecessary();
    await createNewDeliveryInstructionRecord();
    const seedFulfillmentPage = await StepPageHelper.getSeedFulfillmentPage();
    const result = await seedFulfillmentPage.clickDeliveryInstructionsRecordEditBtn();
    expect(result).toBeTruthy();
});

async function createNewDeliveryInstructionsRecordIfNecessary() {
    const seedFulfillmentPage = await StepPageHelper.getSeedFulfillmentPage();
    const currentRecordCount = await seedFulfillmentPage.getCurrentDeliveryInstructionsRecordsCount();
    if (currentRecordCount == 0) {
        await addNewDeliveryInstructionsRow();
        await fillDeliveryInstructionsRecordDetails();
        await saveNewDeliveryInstructionsRecord(false);
        //const deliveryInstructionsRecordSavedMsg = seedFulfillmentPage.getDeliveryInstrcutionsCreateOrUpdateOperationMsg()[0];
        await seedFulfillmentPage.waitUntilToastMessageIsClosed();
    }
}

When('modifies contact-type', async function () {
    const seedFulfillmentPage = await StepPageHelper.getSeedFulfillmentPage();
    let contactType: string = 'Alternate 9';
    let currentContactType = await seedFulfillmentPage.getCurrentSelectedContactType(); //retrieve top record's contact type
    if(currentContactType == contactType){
        contactType = 'Primary';
    }
    fixture.logger.info(`setting contact type for the top record as ${contactType}`);
    await seedFulfillmentPage.selectDeliveryInstructionsContactType(contactType);
});

Then('the selected Delivery Instructions record must be {word}', async function (operationName: string) {
    const isDeleted = (operationName == 'deleted');
    await checkDeliveryInstrcutionsCreateOrUpdateOperationMsg(isDeleted);
});

async function checkDeliveryInstrcutionsCreateOrUpdateOperationMsg(isDeleted: boolean) {
    const seedFulfillmentPage = await StepPageHelper.getSeedFulfillmentPage();
    let actualMsg = fixture.dataBag.getData(DataBagKeys.OPERATION_COMPLETION_MESSAGE) as string;
    if(actualMsg === undefined || actualMsg === null || actualMsg.length === 0){
        fixture.logger.warn('could not retrieve toast message and hence skipping its validation');
        if(!isDeleted){
            fixture.logger.info('Checking if "Save" button is enabledd status which must be disabled');
            const saveBtnStatus = await seedFulfillmentPage.isDeliveryInstrcutionsSaveBtnEnabled();
            if(saveBtnStatus)
                fixture.logger.error(`Save button is still enabled hence earlier action failed`);
            else
                fixture.logger.info(`Save button is disabled which is expected`);

            expect(saveBtnStatus).toBeFalsy();
        }
        return;
    }
    
    const expectedMsgs = isDeleted ?
        seedFulfillmentPage.getDeliveryInstrcutionsDeleteOperationMsg() :
        seedFulfillmentPage.getDeliveryInstrcutionsCreateOrUpdateOperationMsg();
    
    actualMsg = actualMsg.trim();
    fixture.logger.info(`actual message received after saving/deleting a delivery instructions record - ${actualMsg}`);
    let msgComparisonResult = false;
    if (actualMsg == expectedMsgs[0] || actualMsg == expectedMsgs[1])
        msgComparisonResult = true;

    expect(msgComparisonResult).toBeTruthy();
}

When('deletes the top record', async function () {
    await createNewDeliveryInstructionsRecordIfNecessary(); //ensure there is a record
    const seedFulfillmentPage = await StepPageHelper.getSeedFulfillmentPage();
    let displayedMsg = await seedFulfillmentPage.deleteTopDeliveryInstructionsRecord();
    expect(displayedMsg).not.toBeNull();
    expect(displayedMsg.length).toBeGreaterThan(0);
    fixture.dataBag.saveData(DataBagKeys.OPERATION_COMPLETION_MESSAGE, displayedMsg);
});


Given('user is on seed-fulfillment new release order page', async function () {
    await navigateToSeedFulfillmentPage();
    await startNewReleaseOrder();
});

When('user provides all the delivery details', async function () {
    await enterDeliveryDetails();
});

async function enterDeliveryDetails() {
    await selectReleaseFormItem(shipTo);
    await selectReleaseFormItem(deliverTo);
    await selectReleaseFormItem(branch);
    
    await checkIfDeliveryInstructionsBtnIsEnabled();

    const seedFulfillmentPage = await StepPageHelper.getSeedFulfillmentPage();
    await seedFulfillmentPage.clickEditDeliveryInstructionsBtn();
    await createNewDeliveryInstructionsRecordIfNecessary();
    await seedFulfillmentPage.selectFirstDeliveryInstructionsRecord();
    await seedFulfillmentPage.clickSelectDeliveryInstructionsBtn();
    await seedFulfillmentPage.closeDeliveryInstructionsForm();

    await selectReleaseFormItem(otherOrderReleaseDetails);
}

When('sets product release quantities after inventory computing', async function () {
    await computeInventoryAndSetReleaseQty();
});

async function computeInventoryAndSetReleaseQty() {
    const seedFulfillmentPage = await StepPageHelper.getSeedFulfillmentPage();
    await seedFulfillmentPage.computeInventory();
    //const seedFulfillmentRequest = fixture.dataBag.getData(DataBagKeys.SEED_FULFILLMENT) as SeedFulfillment;
    const seedFulfillmentRequest = new SeedFulfillment();
    seedFulfillmentRequest.productsToRelease = getProductsToReleaseData();
    const availableQtities = await seedFulfillmentPage.setReleaseQuantities(seedFulfillmentRequest);
    fixture.dataBag.saveData(DataBagKeys.SEED_FULFILLMENT_QTY_AVAILABLE_TO_RELEASE, availableQtities);
}
function getProductsToReleaseData(): ReleasedProduct[]{
    const releaseProduct = new ReleasedProduct();
    releaseProduct.name = fixture.dataBag.getData(DataBagKeys.SOURCE_PRODUCT_ITEM_NUMBER_TO_USE) as string; //screen contains ItemNumber as part of the name
    fixture.logger.info(`getting releaseProduct.quantity`);
    releaseProduct.quantity = (fixture.dataBag.getData(DataBagKeys.PRODUCT_CONVERSION_OR_MIN_TRANSFERRABLE_QTY_OR_ORDER_QTY) as number).toString();
    fixture.logger.info(`getting releaseProduct.seedWeight`);
    releaseProduct.seedWeight = (fixture.dataBag.getData(DataBagKeys.SEED_WEIGHT) as number).toString();
    return [releaseProduct];
}
function getPalletDetailsToOverride(): PalletDetails[]{
    const result = new PalletDetails();
    //result.palletType = "PALLET NON-STOCK";
    //result.palletWeight = "45";
    result.palletType = fixture.dataBag.getData(DataBagKeys.PALLET_TYPE) as string;
    result.palletWeight = (fixture.dataBag.getData(DataBagKeys.PALLET_WEIGHT) as number).toString();
    result.quantity = "2";

    return [result];
}
When('computes default pallet charges', async function () {
    await computePalletCharges(true);
    await verifyShipmentWeightCalculations();
});

async function computePalletCharges(isDefaultSetup: boolean) {
    const seedFulfillmentPage = await StepPageHelper.getSeedFulfillmentPage();
    if (isDefaultSetup) {
        await seedFulfillmentPage.clickOnComputePalletsAndWeightBtn();
        return;
    }
}
async function verifyShipmentWeightCalculations() {
    const seedFulfillmentPage = await StepPageHelper.getSeedFulfillmentPage();
    const weights = await seedFulfillmentPage.getShipmentWeightComputationValues();
    fixture.logger.info(`pallet weights: Seed Weight = ${weights[0]}; Pallet Weight = ${weights[1]}; Total Weight = ${weights[2]}`);
    expect(weights.length).toBe(3);
    const expectedSeedWeight = fixture.dataBag.getData(DataBagKeys.SEED_WEIGHT) as number;
    const expectedPalletWeight = fixture.dataBag.getData(DataBagKeys.PALLET_WEIGHT) as number;
    /*expect(weights[0]).toBeGreaterThan(1);
    expect(weights[1]).toBeGreaterThan(1); //this can be zero also
    */
    expect(weights[0]).toBe(expectedSeedWeight);
    expect(weights[1]).toBe(expectedPalletWeight);
    expect(weights[2]).toBe(weights[0] + weights[1]);
}
When('saves the release order', async function () {
    await saveDraftReleaseOrder(false);
});

async function saveDraftReleaseOrder(checkOperationMsg: boolean) {
    const seedFulfillmentPage = await StepPageHelper.getSeedFulfillmentPage();
    let msg = "";
    try{
        msg = await seedFulfillmentPage.clickSaveReleaseOrderBtn();
        fixture.dataBag.saveData(DataBagKeys.OPERATION_COMPLETION_MESSAGE, msg);
        if (checkOperationMsg) {
            await checkSaveReleaseOrPlaceERPReleaseOrderOperationResult(
                "a new release order has been saved with the order id - ",
                "failed to verify 'Release Order #number saved successfully.' message on Order-Release Entry page. Error: ",
                true
            );
        }
    }catch(error){
        fixture.logger.error('failed to get the toast message hence skipping its validation');
    }
}

Then('a new release order must be available as unsubmitted request', async function () {
    await checkSaveReleaseOrPlaceERPReleaseOrderOperationResult(
        "a new release order has been saved with the order id - ",
        "failed to verify 'Release Order #number saved successfully.' message on Order-Release Entry page. Error: ",
        true
    );
});

async function checkSaveReleaseOrPlaceERPReleaseOrderOperationResult(successMsg: string, errorMsg: string, isDraftRelease: boolean) {
    let orderId = await releaseOrderCompletionVerification(successMsg, errorMsg);

    fixture.logger.info("message verification completed");

    const seedFulfillmentPage = await StepPageHelper.getSeedFulfillmentPage();
    const headerPage = await StepPageHelper.getHeaderNavigationPage();
    const seedFulfillmentPageURL = headerPage.getSeedFulfillmentPageURL();
    let comparisonResult = false;

    for (let i = 0; i < 10; i++) {
        const currentPageURL = seedFulfillmentPage.getCurrentPageURL();
        if (currentPageURL == seedFulfillmentPageURL) {
            comparisonResult = true;
            break;
        }
    }

    expect(comparisonResult).toBeTruthy();
    fixture.logger.info("seed-fulfillment page navigation verification completed");

    if(orderId == null || orderId.length == 0 ){
        fixture.logger.warn('order id/release number could not be retrieved from the toast message hence reading it from the table');
        const accountName = fixture.dataBag.getData(DataBagKeys.SOURCE_DEALER_NAME) as string;
        orderId = await seedFulfillmentPage.getOrderIdFromTopRow(accountName);
        fixture.dataBag.saveData(DataBagKeys.ORDER_ID, orderId);
    }
    if (!isDraftRelease) {
        await seedFulfillmentPage.switchToRequestsTab(true);
    }
    const draftReleaseOrderPresent = await seedFulfillmentPage.isReleaseOrderPresent(orderId);
    expect(draftReleaseOrderPresent).toBeTruthy();
    fixture.logger.info("draft/submitted release order verification completed");
}

async function releaseOrderCompletionVerification(successMsg: string, errorMsg: string) {
    let result = true;
    let orderId = "";
    try {
        const msg = fixture.dataBag.getData(DataBagKeys.OPERATION_COMPLETION_MESSAGE) as string;
        if (msg !== undefined && msg !== null && msg.length > 0) {
            orderId = (msg.trim().split(" ")[2]).substring(1);
            expect(orderId).not.toBeNull();
            expect(orderId.length).toBeGreaterThan(1);
            fixture.dataBag.saveData(DataBagKeys.ORDER_ID, orderId);
            fixture.logger.info(successMsg + orderId);
        } else {
            fixture.logger.warn('could not retrieve toast message and hence skipping its validation');
            return "";
        }
    } catch (error) {
        fixture.logger.error(errorMsg + error);
        result = false;
    }
    expect(result).toBeTruthy();
    return orderId;
}

Given('user is on seed-fulfillment\'s Unsubmitted-Drafts section', async function () {
    await navigateToSeedFulfillmentPage();
    const seedFulfillmentPage = await StepPageHelper.getSeedFulfillmentPage();
    await seedFulfillmentPage.switchToRequestsTab(false);
});

When('user opens a saved draft release order', async function () {
    fixture.logger.info("starting a new release order");
    await startNewReleaseOrder();
    fixture.logger.info("entering delivery details");
    await enterDeliveryDetails();
    fixture.logger.info("computing inventory and setting release quantities");
    await computeInventoryAndSetReleaseQty();
    fixture.logger.info("computing pallet charges");
    await computePalletCharges(true);
    fixture.logger.info("verifying shipment weight calculations");
    await verifyShipmentWeightCalculations();
    fixture.logger.info("saving draft release");
    await saveDraftReleaseOrder(true);
    const orderId = fixture.dataBag.getData(DataBagKeys.ORDER_ID) as string;
    const seedFulfillmentPage = await StepPageHelper.getSeedFulfillmentPage();
    fixture.logger.info("opening the newly created draft release order - "+ orderId);
    await seedFulfillmentPage.openDraftReleaseOrder(orderId);
});

When('places the ERP order',  { timeout: 1000 * 1000 }, async function () {
    const seedFulfillmentPage = await StepPageHelper.getSeedFulfillmentPage();
    const msg = await seedFulfillmentPage.clickPlaceERPOrderBtn();
    fixture.dataBag.saveData(DataBagKeys.OPERATION_COMPLETION_MESSAGE, msg);
    //after successful release, we should navigate back to seed fulfillment home page
    //we will check for some time
    let count = 0;
    let navigatedToHomePage = false;
    while (count < 200) {
        let isOnHomePage = await seedFulfillmentPage.isSeedFulfillmentHomePageDisplayed();
        if (isOnHomePage) {
            navigatedToHomePage = true;
            fixture.logger.info('navigated back to seed fulfillment home page');
            break;
        }

        count++;
    }
    if(!navigatedToHomePage)
        fixture.logger.error('failed to navigate back to seed fulfillment home page');

    expect(navigatedToHomePage).toBeTruthy();
});

Then('a new release order must be available as submitted request', async function () {
    await checkSaveReleaseOrPlaceERPReleaseOrderOperationResult(
        "a new ERP order has been placed with the order id - ",
        "failed to verify 'Release Order #number updated and released successfully.' message on Order-Release Entry page. Error: ",
        false
    );
});

Then('product available release quantity must be decremented accordingly', async function () {
    const seedFulfillmentPage = await StepPageHelper.getSeedFulfillmentPage();
    const orderId = fixture.dataBag.getData(DataBagKeys.ORDER_ID) as string;
    const availableQtitiesBeforePlacingOrder = fixture.dataBag.getData(DataBagKeys.SEED_FULFILLMENT_QTY_AVAILABLE_TO_RELEASE) as ReleasedProduct[];
    const availableQtitiesAfterPlacingOrder: string[] = [];
    //const seedFulfillmentRequest = fixture.dataBag.getData(DataBagKeys.SEED_FULFILLMENT) as SeedFulfillment;
    const seedFulfillmentRequest = initializeSeedFulfillmentReqWithDeliveryDetails();
    seedFulfillmentRequest.productsToRelease = getProductsToReleaseData();
    await seedFulfillmentPage.openSubmittedReleaseOrder(orderId);
    const erpOrderId = await seedFulfillmentPage.getERPOrderId();
    fixture.dataBag.saveData(DataBagKeys.ERP_ORDER_NUMBER, erpOrderId);

    for (let i = 0; i < seedFulfillmentRequest.productsToRelease.length; i++) {
        const val = await seedFulfillmentPage.getQtyAvailableToRelease(seedFulfillmentRequest.productsToRelease[i].name);
        availableQtitiesAfterPlacingOrder.push(val);
    }

    for (let i = 0; i < availableQtitiesBeforePlacingOrder.length; i++) {
        fixture.logger.info(`product ${availableQtitiesBeforePlacingOrder[i].name} available quantity before placing the order is ${parseInt(availableQtitiesBeforePlacingOrder[i].quantity.replaceAll(",",""))}`);
        fixture.logger.info(`product ${availableQtitiesBeforePlacingOrder[i].name} available quantity after placing the order is ${parseInt(availableQtitiesAfterPlacingOrder[i].replaceAll(",",""))}`);
        
        expect(parseInt(availableQtitiesBeforePlacingOrder[i].quantity.replaceAll(",",""))).toBeGreaterThan(parseInt(availableQtitiesAfterPlacingOrder[i].replaceAll(",","")));
    }
});

Given('scenario uses JDE log-in as {string}', async function (userDetailDataPath: string) {
    const userDetail = StepDataHelper.getSingleTestDataRecordForType(TestDataType.JDEUser, userDetailDataPath) as JDEUser;
    fixture.dataBag.saveData(DataBagKeys.JDE_USER, userDetail);
});

Then('order information must be available in the JDE', { timeout: 1000 * 1000 }, async function () {
    fixture.logger.info("JDE verification started");
    const jdeSalesAndCreditOrderEnquiryPage = await StepPageHelper.getJDESalesAndCreditOrderEnquiryPage();
    //const seedFulfillmentRequest = fixture.dataBag.getData(DataBagKeys.SEED_FULFILLMENT) as SeedFulfillment;
    const seedFulfillmentRequest = initializeSeedFulfillmentReqWithDeliveryDetails();
    seedFulfillmentRequest.productsToRelease = getProductsToReleaseData();

    await jdeSalesAndCreditOrderEnquiryPage.navigateToLoginPage();
    const jdeUser = fixture.dataBag.getData(DataBagKeys.JDE_USER) as JDEUser;
    const loginCompleted = await jdeSalesAndCreditOrderEnquiryPage.isHomePageDisplayed();
    if(loginCompleted)
    {
        fixture.logger.info("JDE navigated to Home page hence skipping login");
    } else {
        await jdeSalesAndCreditOrderEnquiryPage.loginUser(jdeUser.userID, jdeUser.password);
    }
    await jdeSalesAndCreditOrderEnquiryPage.navigateToSalesAndCreditOrderInquiryMenu();
    fixture.logger.info("navigated to 'Sales And Credit Order Inquiry' Menu");
    const customerPO = fixture.dataBag.getData(DataBagKeys.CUSTOMER_PO) as string;
    await jdeSalesAndCreditOrderEnquiryPage.searchWithCustomerPO(customerPO);
    //const orderID = fixture.dataBag.getData(DataBagKeys.ORDER_ID) as string;
    const erpOrderNumber = fixture.dataBag.getData(DataBagKeys.ERP_ORDER_NUMBER) as string;
    let result = await jdeSalesAndCreditOrderEnquiryPage.openOrder();
    expect(result).toBeTruthy();

    const actualDisplayedDetails = await jdeSalesAndCreditOrderEnquiryPage.getDisplayedOrderProperties();

    fixture.logger.info(`Ship To values - test data: ${seedFulfillmentRequest.shipTo.number} ; JDE data: ${actualDisplayedDetails.shipTo}`);
    expect(actualDisplayedDetails.shipTo).toBe(seedFulfillmentRequest.shipTo.number.trim());
    
    fixture.logger.info(`Sold To/Deliver To values - test data: ${seedFulfillmentRequest.deliverTo.number} ; JDE data: ${actualDisplayedDetails.soldTo}`);
    //expect(actualDisplayedDetails.soldTo).toBe(seedFulfillmentRequest.deliverTo.number); <<---- DON'T COMPARE THIS AS THESE VALUES IN EVOLVE & JDE WOULD BE DIFFERENT
    
    fixture.logger.info(`Branch/Plant values - test data: ${seedFulfillmentRequest.branch} ; JDE data: ${actualDisplayedDetails.branch}`);
    expect(seedFulfillmentRequest.branch.trim().startsWith(actualDisplayedDetails.branch)).toBeTruthy();
    
    fixture.logger.info(`Order Number values - test data: ${erpOrderNumber} ; JDE data: ${actualDisplayedDetails.orderNumber}`);
    
    let itemNumberFound = false;
    let qty = "";
    for (let i = 0; i < seedFulfillmentRequest.productsToRelease.length; i++) {
        const testDataItemNumber = seedFulfillmentRequest.productsToRelease[i].name.trim();
        const jdeItemNumber = actualDisplayedDetails.itemNumber.trim();
        fixture.logger.info(`Item Number values - test data: ${testDataItemNumber} ; JDE data: ${jdeItemNumber}`);
        if (testDataItemNumber.includes(jdeItemNumber)) {
            itemNumberFound = true;
            qty = seedFulfillmentRequest.productsToRelease[i].quantity.trim();
            break;
        }
    }
    
    expect(itemNumberFound).toBeTruthy();
    
    fixture.logger.info(`Quantity Ordered values - test data: ${qty} ; JDE data: ${actualDisplayedDetails.qtyOrdered}`);
    expect(parseInt(actualDisplayedDetails.qtyOrdered)).toBe(parseInt(qty));
});

When('user creates an order with all the details', async function () {
    await enterDeliveryDetails();
    fixture.logger.info('completed entering all the delivery details');
    await computeInventoryAndSetReleaseQty();
    fixture.logger.info('completed computing inventory and setting release quantities');
});

When('views product lot information', async function () {
    fixture.logger.info('starting viewing/verifying View Lots and Fulfillment Breakdown info');
    const seedFulfillmentPage = await StepPageHelper.getSeedFulfillmentPage();
    //const seedFulfillmentRequest = fixture.dataBag.getData(DataBagKeys.SEED_FULFILLMENT) as SeedFulfillment;
    const availableQtities = fixture.dataBag.getData(DataBagKeys.SEED_FULFILLMENT_QTY_AVAILABLE_TO_RELEASE) as ReleasedProduct[];
    //const verificationResult = await seedFulfillmentPage.verifyViewLotsInfo(availableQtities, seedFulfillmentRequest.productsToRelease);
    const verificationResult = await seedFulfillmentPage.verifyViewLotsInfo(availableQtities, getProductsToReleaseData());
    expect(verificationResult).toBeTruthy();
    fixture.logger.info('completed viewing/verifying View Lots and Fulfillment Breakdown info');
});

When('overrides Pallet Non-Stock quantity', async function () {
    fixture.logger.info('starting overriding pallet info');
    const seedFulfillmentPage = await StepPageHelper.getSeedFulfillmentPage();
    //const seedFulfillmentRequest = fixture.dataBag.getData(DataBagKeys.SEED_FULFILLMENT) as SeedFulfillment;
    const seedFulfillmentRequest = new SeedFulfillment();
    seedFulfillmentRequest.productsToRelease = getProductsToReleaseData();
    seedFulfillmentRequest.palletDetailsToOverride = getPalletDetailsToOverride();
    await seedFulfillmentPage.clickOnComputePalletsAndWeightBtn();
    
    let displayedInitialShipmentWeightValues = await seedFulfillmentPage.getShipmentWeightComputationValues();
    fixture.logger.info(`displayed initial shipment weight values of Seed Weight, Pallet Weight and Total Weight respectively are: ${displayedInitialShipmentWeightValues}`);
    //fixture.logger.info(`displayed initial shipment weight values of Seed Weight, Pallet Weight and Total Weight respectively are: ${displayedInitialShipmentWeightValues[0].toString()}, ${displayedInitialShipmentWeightValues[1].toString()}, ${displayedInitialShipmentWeightValues[2].toString()}`);
    
    let totalSeedWeight: number = 0;
    
    for(let i=0; i < seedFulfillmentRequest.productsToRelease.length; i++){
        //let qty = parseInt(seedFulfillmentRequest.productsToRelease[i].quantity.trim());
        //let seedWeight = parseInt(seedFulfillmentRequest.productsToRelease[i].seedWeight.trim());
        let seedWeight = parseFloat(seedFulfillmentRequest.productsToRelease[i].seedWeight.trim());

        //totalSeedWeight = totalSeedWeight + qty * seedWeight;
        totalSeedWeight = totalSeedWeight + seedWeight; //seed weight includes per release quantity so do not consider qty again
    }
    //let initialPalletWeight = parseInt(seedFulfillmentRequest.palletDetailsToOverride[0].palletWeight);
    let initialPalletWeight = parseFloat(seedFulfillmentRequest.palletDetailsToOverride[0].palletWeight);
    let expectedInitialShipmentWeightValues: number[] = [totalSeedWeight, initialPalletWeight, totalSeedWeight + initialPalletWeight];
    fixture.logger.info(`expected initial shipment weight values of Seed Weight, Pallet Weight and Total Weight respectively are: ${expectedInitialShipmentWeightValues}`);
    //fixture.logger.info(`expected initial shipment weight values of Seed Weight, Pallet Weight and Total Weight respectively are: ${expectedInitialShipmentWeightValues[0].toString()}, ${expectedInitialShipmentWeightValues[1].toString()}, ${expectedInitialShipmentWeightValues[2].toString()}`);

    expect(displayedInitialShipmentWeightValues).toEqual(expectedInitialShipmentWeightValues);

    await seedFulfillmentPage.clickOverrideCheckbox();
    await seedFulfillmentPage.overridePalletQty(seedFulfillmentRequest.palletDetailsToOverride[0].quantity);
    await seedFulfillmentPage.clickOnComputePalletsAndWeightBtn();

    let displayedUpdatedShipmentWeightValues = await seedFulfillmentPage.getShipmentWeightComputationValues();
    fixture.logger.info(`displayed updated shipment weight values of Seed Weight, Pallet Weight and Total Weight respectively are: ${displayedUpdatedShipmentWeightValues}`);
    let updatedPalletWeight = initialPalletWeight * parseFloat(seedFulfillmentRequest.palletDetailsToOverride[0].quantity);
    let expectedUpdatedShipmentWeightValues: number[] = [totalSeedWeight, updatedPalletWeight, totalSeedWeight + updatedPalletWeight];
    fixture.logger.info(`expected updated shipment weight values of Seed Weight, Pallet Weight and Total Weight respectively are: ${expectedUpdatedShipmentWeightValues}`);

    expect(displayedUpdatedShipmentWeightValues).toEqual(expectedUpdatedShipmentWeightValues);

    fixture.logger.info('completed overriding pallet info');
});
