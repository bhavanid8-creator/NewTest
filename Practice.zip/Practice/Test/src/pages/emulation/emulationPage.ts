import HtmlRoles from "../../helpers/wrapper/htmlRoles";
import { fixture } from "../../hooks/fixture";
import BasePage from "../basePage";

export default class EmulationPage extends BasePage {

    readonly accountFilterOption_accountNumber = "Account #";

    replaceAccountNumber: string = "replace-account-number";

    Elements = {
        accountCategoryFilterTestId: "ddl-account-filter",
        accountNumberFilterItemOptionName: this.accountFilterOption_accountNumber,
        accountSearchBoxPlaceholder: "Search...",
        accountFilterButtonName: "Search",
        setEmulationButtonName: "Set Emulation",
        clearEmulationButtonName: "Clear Emulation",
        emulatedUserProfileText: 'Emulated UserId:'
    }

    async isPageStable(): Promise<boolean> {
        fixture.logger.info('checking for emulation-page stability');
        
        await super.waitUntilButtonIsDisplayed(this.Elements.accountFilterButtonName);
        fixture.logger.info('checking for emulation-page stability completed');
        return true;
    }
    async clearExistingEmulation(){
        if(await this.pwWrapper.pageElement.isElementVisible(this.Elements.clearEmulationButtonName)){
            await this.clickClearEmulationButton();
        }
    }
    async clickAccountFilter() {
        await this.pwWrapper.elementAction.clickItemByTestIdAndRole(this.Elements.accountCategoryFilterTestId, HtmlRoles.COMBOBOX);
    }
    async setAccountFilterToAccountNumber() {
        await this.pwWrapper.dataWriter.selectOption(this.Elements.accountNumberFilterItemOptionName);
    }

    async filterAccount(accountValue: string) {
        await this.page.getByPlaceholder(this.Elements.accountSearchBoxPlaceholder).click();
        await this.page.getByPlaceholder(this.Elements.accountSearchBoxPlaceholder).fill(accountValue);
        await this.pwWrapper.elementAction.waitAndClickButtonByRole(this.Elements.accountFilterButtonName);
        while (await this.sharedBehavior.isOperationInProgress());
    }

    async selectAttachedAccount(accountNumber: string) {
        await this.pwWrapper.elementAction.clickItemByText(accountNumber, true);
    }

    async selectAttachedUser(userId: string) {
        await this.pwWrapper.elementAction.clickTableCell(userId);
    }
    async clickSetEmulationButton() {
        await this.pwWrapper.elementAction.waitAndClickButtonByRole(this.Elements.setEmulationButtonName);
        while(await this.sharedBehavior.isOperationInProgress());
    }
    async clickClearEmulationButton() {
        await this.pwWrapper.elementAction.waitAndClickButtonByRole(this.Elements.clearEmulationButtonName);
        while(await this.sharedBehavior.isOperationInProgress());
    }
}