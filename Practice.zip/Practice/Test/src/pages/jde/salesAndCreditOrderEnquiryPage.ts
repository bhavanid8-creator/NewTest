import { tr } from "date-fns/locale";
import HtmlRoles from "../../helpers/wrapper/htmlRoles";
import { fixture } from "../../hooks/fixture";
import BasePage from "../basePage";
import SalesOrderDetails from "../../helpers/util/test-data/jde/salesOrderDetails";

export default class SalesAndCreditOrderEnquiryPage extends BasePage {

    Elements = {
        jde_url: process.env.JDE_BASEURL,
        landingPageUri: "oti/landing-data",
        userNameInputLabel: "User ID",
        passwordInputLabel: "Password",
        loginBtnName: 'Sign In',
        signInErrorId: 'SignInError',

        progressBarXPath: `#procIndicatorFloatLyr`,

        homeItemXPath: `//td[text()='Home']`,
        
        mainMenuXPath: `#drop_mainmenu`,
        lolMenuTxt: 'LOL Menu',
        wfuMenuItemTxt: 'WinField United',
        warehouseUserMenuItemTxt: 'Warehouse User',
        orderManagementInquiriesMenuItemTxt: 'Order Management Inquiries',
        salesAndCreditOrderInquiryLinkText: 'Sales and Credit Order Inquiry',
        manageExistingOrderApplicationSideNavigationItemText: 'Manage Existing Order',
        loadingCellName: 'Loading...',

        iFrameName: `e1menuAppIframe`,
        
        customerPOFieldXPath: '#C0_378',
        searchBtnName: 'Find (Ctrl+Alt+I)',

        editSalesOrderSideNavigationLinkText: 'Edit Sales Order',

        soldToTextBoxName: 'Long Address Number Sold To',
        shipToTextBoxName: 'Long Address Number Ship To',
        branchTextBoxName: 'HdrBusinessUnit_MCU.',
        quantityOrderedXPath: '.JSTextfield',
        itemNumberXPath: 'td:nth-child(7) > div > .JSTextfield',
        orderNumberTextBoxName: 'OrderNumber',
        userProfileXPath: '#userSessionDropdownArrow',
        signOutBtnName: 'Sign Out',
    }

    async isPageStable(): Promise<boolean> {
        return true;
    }
    async navigateToLoginPage() {
        fixture.logger.info(`navigating to JDE login page`);
        await Promise.all([
            this.pwWrapper.goto(this.Elements.jde_url, 80000),
            //this.waitUntilJdeButtonIsDisplayed(this.Elements.loginBtnName)
        ]
        );
        //await this.pwWrapper.common.delay(3000);
        fixture.logger.info(`JDE login page navigation completed`);
    }

    private async waitUntilJdeButtonIsDisplayed(btnName: string, shouldRefreshPageOnRetry: boolean = false, retryCount: number = 50){
        let btnCount = 0;
        for(let index=0; index<retryCount; index++){
            btnCount = await this.pwWrapper.pageElement.getAvailableElementCountByRole(HtmlRoles.BUTTON, btnName);
            if(btnCount > 0)
                break;
            if(shouldRefreshPageOnRetry)
                await this.pwWrapper.refreshCurrentPage(2000);
        }
        if(btnCount == 1)
            await this.pwWrapper.pageElement.getButton(btnName); //wait until at least one button is displayed
        else if(btnCount > 1)
            (await this.pwWrapper.pageElement.getButton(btnName)).nth(1); //wait until at least one button is displayed
    } 
    async enterUserName(user: string) {
        await this.page.getByLabel(this.Elements.userNameInputLabel).fill(user);
    }
    
    async enterPassword(password: string) {
        await this.page.getByLabel(this.Elements.passwordInputLabel).fill(password);
    }

    async clickLoginButton() {
        //await this.pwWrapper.elementAction.waitAndClick(this.Elements.loginBtnName);
        await this.pwWrapper.elementAction.waitAndClickButtonByRole(this.Elements.loginBtnName);
    }

    async isHomePageDisplayed(): Promise<boolean>{
        let homeElementCount = 0;
        for(let retryCount = 0; retryCount < 10; retryCount++)
        {
            homeElementCount = await this.pwWrapper.pageElement.getAvailableElementCount(this.Elements.homeItemXPath);
            if (homeElementCount > 0) {
                fixture.logger.info('current displayed JDE page is : ' + this.page.url)
                break;
            }
        }
        return homeElementCount > 0;
    }

    async loginUser(user: string, password: string): Promise<boolean> {
        fixture.logger.info("attempting to login to JDE");
        await this.enterUserName(user);
        await this.enterPassword(password);
        await this.clickLoginButton();
        let isLoginSuccessful = false;
        let isLoginComplete = false;
        while(!isLoginComplete){
            const homeElementCount = await this.pwWrapper.pageElement.getAvailableElementCount(this.Elements.homeItemXPath);
            if (homeElementCount > 0) {
                isLoginSuccessful = true;
                isLoginComplete = true;
                fixture.logger.info("JDE login completed successfully");
            }
            else {
                const loginFailedElementCount = await this.pwWrapper.pageElement.getAvailableElementCountById(this.Elements.signInErrorId);
                if (loginFailedElementCount > 0) {
                    isLoginComplete = true;
                    fixture.logger.error("failed to login to JDE");
                }
            }
        }
        return isLoginSuccessful;
    }

    private async waitUntilProgressbarDisappears(){
        let operationIsInprogress = true;

        while(operationIsInprogress){
            const progressBarElement1 = await this.pwWrapper.pageElement.getVisibleIFrameElementByXPath(this.Elements.iFrameName, this.Elements.progressBarXPath);

            if(await progressBarElement1.count() == 0){
                operationIsInprogress = false;
            }else{
                const progressBarElement2Count = await progressBarElement1.getByRole(HtmlRoles.TABLE_CELL).count();
                if(progressBarElement2Count == 0){
                    operationIsInprogress = false;
                }
            }
        }
    }
    async navigateToSalesAndCreditOrderInquiryMenu(): Promise<boolean>{
        fixture.logger.info("attempting to navigate to 'Sales And Credit Order Inquiry'");

        await this.pwWrapper.elementAction.clickElement(this.Elements.mainMenuXPath);
        await this.pwWrapper.elementAction.clickElementByText(this.Elements.lolMenuTxt);
        await this.pwWrapper.elementAction.clickElementByText(this.Elements.wfuMenuItemTxt, true);
        await this.pwWrapper.elementAction.clickElementByText(this.Elements.warehouseUserMenuItemTxt);
        await this.pwWrapper.elementAction.clickElementByText(this.Elements.orderManagementInquiriesMenuItemTxt);
        await this.pwWrapper.elementAction.clickElementByRole(HtmlRoles.LINK, this.Elements.salesAndCreditOrderInquiryLinkText)

        let isAppLoadingComplete = false;
        /*let retryCount = 10;
        while(!isAppLoadingComplete && retryCount > 0){
            const appElementCount = await this.pwWrapper.pageElement.getAvailableElementCountByRole(HtmlRoles.LINK, this.Elements.manageExistingOrderApplicationSideNavigationItemText);
            if (appElementCount > 0) {
                isAppLoadingComplete = true;
                fixture.logger.info("'Sales And Credit Order Inquiry' app loaded successfully");
            }
            else {
                --retryCount;
                if(retryCount == 0)
                {
                    fixture.logger.error("'Sales And Credit Order Inquiry' app did not load");
                }
            }
        }*/
        await this.waitUntilProgressbarDisappears();

        while(!isAppLoadingComplete){
            const cellElement = await this.pwWrapper.pageElement.getElementByRole(HtmlRoles.TABLE_CELL, this.Elements.loadingCellName);
            if (await cellElement.count() == 0) {
                isAppLoadingComplete = true;
            } else {
                const progressElementCount = await cellElement.getByRole(HtmlRoles.IMG).count();
                if (progressElementCount == 0)
                    isAppLoadingComplete = true;
            }
        }

        return isAppLoadingComplete;
    }

    async searchWithCustomerPO(customerPO: string){
        fixture.logger.info(`attempting to search with Customer PO - ${customerPO}`);

        //it takes sometime to reflect data in JDE so we will delay
        await this.pwWrapper.common.delay(parseInt(process.env.JDE_SALES_ORDER_ENQUIRY_DATA_SYNC_IN_MS.replaceAll(",","")));

        const timeout = 30000; //we give large timeout for JDE
        await this.pwWrapper.dataWriter.enterValueIntoIFrameTextboxByXPath(
            this.Elements.iFrameName
            , this.Elements.customerPOFieldXPath
            , customerPO.trim()
            , false
            , timeout);
        
        fixture.logger.info(`entered Customer PO value - ${customerPO}`);
        
        await this.pwWrapper.elementAction.waitAndClickIFrameButtonByRole(
            this.Elements.iFrameName
            , this.Elements.searchBtnName
            , timeout);
        
        fixture.logger.info(`clicked Find button`);

        await this.waitUntilProgressbarDisappears();

        fixture.logger.info(`completed searching with Customer PO - ${customerPO}`);
    }

    async openOrder(): Promise<boolean> {
        fixture.logger.info('opening the JDE order');
        const element = await this.pwWrapper.pageElement.getIFrameElementByRole(
            this.Elements.iFrameName,
            HtmlRoles.TABLE_CELL,
            //orderNumber,
            //false
            ); 
        
        await element.getByRole('link').nth(3).click(); //this is clicking order number link
        
        await this.waitUntilProgressbarDisappears();

        let isOrderOpened = false;
        let retryCount = 10000;
        while(!isOrderOpened && retryCount > 0){
            const elementCount = await this.pwWrapper.pageElement.getAvailableElementCountByRole(HtmlRoles.LINK, this.Elements.editSalesOrderSideNavigationLinkText);
            if(elementCount > 0)
                isOrderOpened = true;
            else
                --retryCount;
        }
        if(isOrderOpened){
            fixture.logger.info('opening the JDE order completed');
        }else{
            fixture.logger.error('opening the JDE order FAILED');
        }
        return isOrderOpened;
    }

    async getDisplayedOrderProperties(): Promise<SalesOrderDetails>{
        const soldTo = await this.pwWrapper.dataReader.getIFrameFieldValueByRole(this.Elements.iFrameName, HtmlRoles.TEXT_BOX, this.Elements.soldToTextBoxName);
        fixture.logger.info(`Sold To is - ${soldTo}`);
        
        const shipTo = await this.pwWrapper.dataReader.getIFrameFieldValueByRole(this.Elements.iFrameName, HtmlRoles.TEXT_BOX, this.Elements.shipToTextBoxName);
        fixture.logger.info(`Ship To is - ${shipTo}`);

        const branch = await this.pwWrapper.dataReader.getIFrameFieldValueByRole(this.Elements.iFrameName, HtmlRoles.TEXT_BOX, this.Elements.branchTextBoxName);
        fixture.logger.info(`branch is - ${branch}`);

        //we will read properties such as quantity ordered, etc.,
        //for this, first we need to check relevant row so that needed properties will be loaded into DOM
        const checkBoxElement = await this.pwWrapper.pageElement.getIndexedIFrameElementByRole(this.Elements.iFrameName, HtmlRoles.CHECKBOX, 1);
        await checkBoxElement.click();
        fixture.logger.info(` clicked the first order row related checkbox`);

        const qtyOrdered = await this.pwWrapper.dataReader.getIndexedIFrameFieldValueByXPath(
            this.Elements.iFrameName
            , '.JSTextfield'
            , 0);
        fixture.logger.info(`Qty Ordered is - ${qtyOrdered}`);

        const itemNumber = await this.pwWrapper.dataReader.getIFrameFieldValueByXPath(
            this.Elements.iFrameName
            , 'td:nth-child(7) > div > .JSTextfield');
        fixture.logger.info(`Item Number is - ${itemNumber}`);

        const orderNumber = await this.pwWrapper.dataReader.getIFrameFieldValueByRole(this.Elements.iFrameName, HtmlRoles.TEXT_BOX, this.Elements.orderNumberTextBoxName);
        fixture.logger.info(`Order Number is - ${orderNumber}`);

        let result = new SalesOrderDetails();

        result.soldTo = soldTo.trim();
        result.shipTo = shipTo.trim();
        result.branch = branch.trim();
        result.qtyOrdered = qtyOrdered.trim();
        result.itemNumber = itemNumber.trim();
        result.orderNumber = orderNumber.trim();

        return result;
    }
}