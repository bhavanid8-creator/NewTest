import HtmlRoles from "../../helpers/wrapper/htmlRoles";
import BasePage from "../basePage";
import CppInoculantReturnsPage from "../cpp/returns/inoculant/inoculantReturnsPage";
import CppProductReturnsPage from "../cpp/returns/product/productReturnsPage";


export default class HeaderNavigationPage extends BasePage {
    readonly replaceItem: string = "replace-item";
    Elements = {
        emulationPageUri: "emulation",
        //accountMenuItem: "//a[@data-testid='menu-account']",
        //accountMenuItem: "(//a[text()='Account'])[2]",
        //seedMenuItem: "//a[text()='Seed']"
        accountMenuItemTestId: 'menu-account',
        accountPageUri: "account",
        seedMenuItemTestId: 'menu-seed',
        seedOrdersMenuItemTestId: 'menu-orders',
        landingDataPageUri: "landing-data",
        emulationMenuLinkName: 'Emulation',
        stockTransfersMenuItemTestId: 'menu-seed-stockTransfer',
        stockTransfersPageUri: 'sot-landing',
        seedFulfillmentMenuBtnName: 'Fulfillment',
        seedFulfillmentMenuItemLinkName: 'Seed Fulfillment',
        seedFulfillmentUri: 'seed-fulfillment',
        cropProtectionMenuItemTestId: 'menu-cropprotection1',
        cropProtectionFirstLevelMenuItemXPath: `//*[contains(@role, 'menuitem') and contains(., '${this.replaceItem}')]`, //replaceItem should be the menu item name
        cropProtectionOrdersMenuItemTestId: 'menu-crop-orders',
        cropProtectionOrdersMenuItemLandingDataPageUri: "cpp/landing-data",
        cropProtectionOrdersMenuItemLinkName: 'Orders',
        cropProtectionReturnsMenuItemLinkName: 'CPP Returns',
        cropProtectionReturnsMenuItemTestId: 'menu-cropprotectionreturns',
        cropProtectionProductReturnsMenuItemLandingDataPageUri: "cpp-returns/dashboard-products",
        seedReplantMenuName: 'Seed Replant',
        seedReplantUri: 'seed-replant-landing',
        //seedReservationMenuName: 'Seed Reservations',
        seedReservationsTestId:`menu-seed-reservation`,
        seedReservationUri: 'seed-reservation-landing',
        cropProtectionInoculantReturnsMenuItemBtnName: 'Inoculant Returns',
        cropProtectionInoculantReturnsMenuItemLandingDataPageUri: "cpp-returns/dashboard-products/Inoculant",
    }

    /*eslint @typescript-eslint/require-await: "off" */
    async canNavigateWithUrl(): Promise<boolean>{
        return false;
    }
    
    /*eslint @typescript-eslint/require-await: "off" */
    async isPageStable(): Promise<boolean> {
        return true;
    }
    async navigateToAccountPage() {
        await this.navigateToMenuItem(this.Elements.accountMenuItemTestId, this.Elements.accountPageUri);
    }
    async navigateToSeedOrdersPage() {
        await this.navigateToMenuItem(this.Elements.seedMenuItemTestId, "");
        await this.navigateToMenuItem(this.Elements.seedOrdersMenuItemTestId, this.Elements.landingDataPageUri);
    }
    async navigateToSeedFulfillmentPage() {
        await this.navigateToMenuItem(this.Elements.seedMenuItemTestId, "");
        await this.pwWrapper.elementAction.clickElementHavingText(this.Elements.seedFulfillmentMenuBtnName);
        await this.pwWrapper.elementAction.clickElementHavingText(this.Elements.seedFulfillmentMenuItemLinkName);
        await this.sharedBehavior.waitForPageNavigation(this.Elements.seedFulfillmentUri);
    }
    async navigateToStockTransfersPage() {
        await this.navigateToMenuItem(this.Elements.seedMenuItemTestId, "");
        await this.navigateToMenuItem(this.Elements.stockTransfersMenuItemTestId, this.Elements.stockTransfersPageUri);
    }

    async navigateToMenuItem(menuTestId: string, uri: string){
        await this.pwWrapper.elementAction.clickElementByTestId(menuTestId);
        if(uri.length > 0)
            await this.sharedBehavior.waitForPageNavigation(uri);
    }

    async navigateToMenuItemWithMenuAsBtn(menuBtnText: string, uri: string){
        await this.pwWrapper.elementAction.clickElementHavingText(menuBtnText);
        if(uri.length > 0)
            await this.sharedBehavior.waitForPageNavigation(uri);
    }

    async navigateToEmulationPage(){
        await (await this.pwWrapper.pageElement.getElementByRole(HtmlRoles.LINK, this.Elements.emulationMenuLinkName)).click();
        await this.sharedBehavior.waitForPageNavigation(this.Elements.emulationPageUri);
    }

    getSeedFulfillmentPageURL(): string{
        return this.getPageURL(this.Elements.seedFulfillmentUri);
    }

    async navigateToCppOrdersPage() {
        /*
        await this.navigateToMenuItem(this.Elements.cropProtectionMenuItemTestId, "");
        await this.navigateToMenuItem(this.Elements.cropProtectionOrdersMenuItemTestId, this.Elements.cropProtectionOrdersMenuItemLandingDataPageUri);
        */
        const finalCropProtectionFirstLevelMenuItemXPath = this.Elements.cropProtectionFirstLevelMenuItemXPath.replace(this.replaceItem, this.Elements.cropProtectionOrdersMenuItemLinkName);

        await this.navigateToMenu(this.Elements.cropProtectionMenuItemTestId, //'Crop Protection' header main menu item
            finalCropProtectionFirstLevelMenuItemXPath, //'Orders' link item
            this.Elements.cropProtectionOrdersMenuItemTestId, this.Elements.cropProtectionOrdersMenuItemLandingDataPageUri); //hard coded to 'CPP Order' sub menu item as this is the only one available for now
    }

    async navigateToCppReturnsPage(subMenuItem: string) {
        /*
        await this.navigateToMenuItem(this.Elements.cropProtectionMenuItemTestId, ""); //clicking 'Crop Protection' main menu item
        const finalCropProtectionFirstLevelMenuItemXPath = this.Elements.cropProtectionFirstLevelMenuItemXPath.replace(this.replaceItem, this.Elements.cropProtectionReturnsMenuItemLinkName);
        await this.pwWrapper.elementAction.clickElement(finalCropProtectionFirstLevelMenuItemXPath); //clicking 'CPP Returns' link item
        let subMenuItemTestId = "";
        let subMenuItemUri = "";
        switch (subMenuItem) {
            case CppProductReturnsPage.RETURN_TYPE:
            {
                subMenuItemTestId = this.Elements.cropProtectionReturnsMenuItemTestId;
                subMenuItemUri = this.Elements.cropProtectionProductReturnsMenuItemLandingDataPageUri;
            }
            break;
        }
        await this.navigateToMenuItem(subMenuItemTestId, subMenuItemUri); //clicking 'CPP Returns' sub menu item
        */
       const finalCropProtectionFirstLevelMenuItemXPath = this.Elements.cropProtectionFirstLevelMenuItemXPath.replace(this.replaceItem, this.Elements.cropProtectionReturnsMenuItemLinkName);
       let subMenuItemTestId = "";
        let subMenuItemUri = "";
        let isMenuBtn: boolean = false;
        switch (subMenuItem) {
            case CppProductReturnsPage.RETURN_TYPE:
            {
                subMenuItemTestId = this.Elements.cropProtectionReturnsMenuItemTestId;
                subMenuItemUri = this.Elements.cropProtectionProductReturnsMenuItemLandingDataPageUri;
            }
            break;
            case CppInoculantReturnsPage.RETURN_TYPE:
            {
                subMenuItemTestId = this.Elements.cropProtectionInoculantReturnsMenuItemBtnName;
                subMenuItemUri = this.Elements.cropProtectionInoculantReturnsMenuItemLandingDataPageUri;
                isMenuBtn = true
            }
            break;
        }
        await this.navigateToMenu(this.Elements.cropProtectionMenuItemTestId, //'Crop Protection' header main menu item
            finalCropProtectionFirstLevelMenuItemXPath, //'CPP Returns' link item
            subMenuItemTestId, subMenuItemUri, isMenuBtn); //this is the sub menu item to be clicked like 'Product Returns', 'Container Returns', 'Inoculent Returns', etc.
    }

    async navigateToMenu(headerItemTestId: string, mainMenuItemTestId: string, subMenuItemTestId: string, subMenuItemUri: string, isMenuBtn: boolean = false) {
        await this.navigateToMenuItem(headerItemTestId, ""); //clicking 'Crop Protection' main menu item
        await this.pwWrapper.elementAction.clickElement(mainMenuItemTestId); //clicking 'CPP Returns' link item
        if(isMenuBtn){
            await this.navigateToMenuItemWithMenuAsBtn(subMenuItemTestId, subMenuItemUri); //clicking 'CPP Returns' sub menu item
        }else{
            await this.navigateToMenuItem(subMenuItemTestId, subMenuItemUri); //clicking 'CPP Returns' sub menu item
        }
    }

     async navigateToSeedReservationPage() {
      await this.navigateToMenuItem(this.Elements.seedMenuItemTestId, "");
      await this.pwWrapper.elementAction.clickElementByTestId(this.Elements.seedReservationsTestId);
      await this.sharedBehavior.waitForPageNavigation(this.Elements.seedReservationUri);
    }

    async navigateToSeedReplantPage() {
      await this.navigateToMenuItem(this.Elements.seedMenuItemTestId, "");
      await this.pwWrapper.elementAction.clickElementHavingText(this.Elements.seedReplantMenuName);
      await this.sharedBehavior.waitForPageNavigation(this.Elements.seedReplantUri);
    }

    private getPageURL(uri: string): string{
        return process.env.BASEURL + uri;
    }
}