import DateHelper from "../../../helpers/types/dateHelper";
import LineItemInfo from "../../../helpers/util/db/resultSets/cpp/lineItemInfo";
import { fixture } from "../../../hooks/fixture";
import BasePage from "../../basePage";

export default class PlacedCppOrderSummaryPage extends BasePage {
    replaceData: string = "replace-data";
    static readonly Order_Summary_Status_Notice_Txt: string = `Your order has been submitted. You will receive an e-mail confirmation.`;
    static readonly Order_Summary_Status_Notice_Txt_1: string = `Your Order has been submitted and split by product. You will receive an e-mail with the updated order confirmations.`;
    static readonly Order_Summary_Status_Txt: string = `SUBMITTED`;
    
    Elements = {
        placedCppOrderSummaryPageUri: "cpp-order-summary",
        orderSummaryStatusNoticeXPath: `//*[contains(@class, 'statusNotice')]`,
        orderSummaryStatusXPath: `//*[contains(@class, 'statusBtn')]`,
        orderSummaryOrderNumberXPath: `(//span[@data-testid='lbl-ordernumb'])[1]`,
        backToOrderListBtnTxt: `Back To Order List`,
        splitOrderNumberLabelTestIdValue: `lbl-ordernumber-split_`,
        splitOrderReqArrivalDateLabelTestIdValue: `lbl-arrival-date-split_`,
        splitOrderItemNumberLabelTestIdValue: `lbl-item-number-${this.replaceData}_`, //replaceData is split order number that is displayed on the summary page. E.g., for the order number 'Order ID: 20250507411843-100', use '100'
        splitOrderNumberXPath: `//*[contains(@data-testid, '${this.replaceData}')]`, //replaceData is split order number label test id value
        splitOrderSupplierNumberXPath:`//*[contains(@data-testid, '${this.replaceData}')]/ancestor::*/following-sibling::*[contains(@class, 'summaryPage')]//*[contains(@data-supplier, 'supplier-number-')]`,
        arrivalDateByItemNumberXPath: `//*[contains(.,'${this.replaceData}')]/ancestor::div[contains(@class, 'summaryPage')]/preceding-sibling::div//*[contains(@data-testid,'lbl-arrival-date-split')]`, //replaceData is item number
    }

    private async isPageLoaded(): Promise<boolean>{
        await super.waitUntilButtonIsDisplayed(this.Elements.backToOrderListBtnTxt);
        return true;
    }

    async isPageStable(){
        const pageName = 'placed-cpp-order-summary-page';
        fixture.logger.info(`checking for ${pageName} stability`);
        const res = await this.isPageLoaded();
        fixture.logger.info(`checking for ${pageName} stability completed`);

        return res;
    }

    async getDisplayedOrderNumberOnTheSummary(): Promise<string> {
        return (await this.pwWrapper.dataReader.getElementTextByXPath(this.Elements.orderSummaryOrderNumberXPath, true)).trim();
    }

    async getDisplayedOrderSummaryStatusNoticeText(): Promise<string> {
        return (await this.pwWrapper.dataReader.getElementTextByXPath(this.Elements.orderSummaryStatusNoticeXPath, true)).trim();
    }

    //NOTE: THIS IS APPLICABLE ONLY WHEN AN ORDER IS OPENED FROM 'Placed Orders' TAB
    async getDisplayedOrderSummaryStatusText(): Promise<string>{
        return (await this.pwWrapper.dataReader.getElementTextByXPath(this.Elements.orderSummaryStatusXPath, true)).trim();
    }

    async validateOrderSplit(lineItems: LineItemInfo[]): Promise<boolean> {
        fixture.logger.info(`starting order split validation`);
        const supplierMap = new Map<string, string[]>(); //Key: supplier number, Value: array of item numbers
        for(let i=0; i<lineItems.length; i++){
            let supplierNumber = lineItems[i].SupplierNumber.trim();
            if (!supplierMap.has(supplierNumber)) {
                supplierMap.set(supplierNumber, []);
            }
            supplierMap.get(supplierNumber)?.push(lineItems[i].ItemNumber.trim());
        }
        
        const uniqueCount = supplierMap.size;
        fixture.logger.info(`Unique count of SupplierNumber returned by the stored procedure: ${uniqueCount}`);
        
        supplierMap.forEach((itemNumbers, supplierNumber) => {
            fixture.logger.info(`SupplierNumber: ${supplierNumber}, ItemNumbers: ${JSON.stringify(itemNumbers)}`);
        });
        
        for (let index = 1; index <= uniqueCount; index++) {
            let finalSplitOrderNumberLabelTestIdValue = this.Elements.splitOrderNumberLabelTestIdValue + index;
            let finalSplitOrderNumberXPath = this.Elements.splitOrderNumberXPath.replace(this.replaceData, finalSplitOrderNumberLabelTestIdValue);
            let count = await this.pwWrapper.pageElement.getAvailableElementCount(finalSplitOrderNumberXPath);
            if (count == 0) {
                fixture.logger.error(`Split Order with the XPath ${finalSplitOrderNumberXPath} could not be found`);
                return false;
            }
            if (count > 1) {
                fixture.logger.error(`Split Order with the XPath ${finalSplitOrderNumberXPath} has more than one element. Order is expected to have unique sub-order ID value`);
                return false;
            }
            let splitOrderNumber = await this.pwWrapper.dataReader.getElementTextByXPath(finalSplitOrderNumberXPath, true);
            let finalSplitOrderSupplierNumberXPath = this.Elements.splitOrderSupplierNumberXPath.replace(this.replaceData, finalSplitOrderNumberLabelTestIdValue);
            let splitOrderSupplierNumberCount = await this.pwWrapper.pageElement.getAvailableElementCount(finalSplitOrderSupplierNumberXPath);
            fixture.logger.info(`Displayed item count for the split order - ${splitOrderNumber} - is: ${splitOrderSupplierNumberCount}`);
            if (splitOrderSupplierNumberCount == 0) {
                fixture.logger.error(`Split Order Supplier Number with the XPath ${finalSplitOrderSupplierNumberXPath} could not be found`);
                return false;
            }
            
            let indexedSupplierNumber = "(" + finalSplitOrderSupplierNumberXPath + ")[1]";
            const splitOrderSupplierNumberElement = await this.pwWrapper.pageElement.getElementByXPath(indexedSupplierNumber);
            let associatedSupplierNumer = await splitOrderSupplierNumberElement.getAttribute("data-supplier");
            if(associatedSupplierNumer == null){
                fixture.logger.error(`Supplier Number could not be found for the XPath ${indexedSupplierNumber}`);
                return false;
            }
            fixture.logger.info(`Supplier Number associated with the split order - ${splitOrderNumber} - is: ${associatedSupplierNumer}`);
            let trimmedAssociatedSupplierNumer = (associatedSupplierNumer.split("-")[2]).trim();
            fixture.logger.info(`Trimmed Supplier Number associated with the split order - ${splitOrderNumber} - is: ${trimmedAssociatedSupplierNumer}`);
            if (!supplierMap.has(trimmedAssociatedSupplierNumer)) {
                fixture.logger.error(`Supplier Number ${trimmedAssociatedSupplierNumer} is not present in the stored procedure result set`);
                return false;
            }
            const itemNumbers = supplierMap.get(trimmedAssociatedSupplierNumer);
            if (itemNumbers == null) {
                fixture.logger.error(`Stored procedure did not return item numbers for the Supplier Number: ${trimmedAssociatedSupplierNumer}`);
                return false;
            }
            
            if(itemNumbers.length != splitOrderSupplierNumberCount){
                fixture.logger.error(`Mismatch in the count of item numbers returned by the stored procedure (${itemNumbers.length}) and the count of items displayed (${splitOrderSupplierNumberCount}) for the split order - ${splitOrderNumber}`);
                return false;
            }
        }
        fixture.logger.info(`Order split validation completed successfully`);
        return true;
    }

    /**
     * 
     * @param lineItems line items in the order
     * @returns true if order split validation passed else false
     * @note it is assumed, if requested date is same, all the products are from the same supplier and hence will be grouped in one single sub-order
     */
    async validateOrderSplitByRequestedArrivalDate(lineItems: LineItemInfo[]): Promise<boolean> {
        fixture.logger.info(`starting order split validation by requested arrival date`);
        const reqArrivalDateMap = new Map<string, string[]>(); //Key: date, Value: array of item numbers
        for(let i=0; i<lineItems.length; i++){
            let date = lineItems[i].RequestDeliveryDate;
            if (!reqArrivalDateMap.has(date)) {
                reqArrivalDateMap.set(date, []);
            }
            reqArrivalDateMap.get(date)?.push(lineItems[i].ItemNumber.trim());
        }
        
        const arrivalDateUniqueCount = reqArrivalDateMap.size;
        fixture.logger.info(`Unique count of RequestDeliveryDate returned by the stored procedure: ${arrivalDateUniqueCount}`);
        
        reqArrivalDateMap.forEach((itemNumbers, requestDeliveryDate) => {
            fixture.logger.info(`RequestDeliveryDate: ${requestDeliveryDate}, ItemNumbers: ${JSON.stringify(itemNumbers)}`);
        });

        let shouldSplitOrder = (arrivalDateUniqueCount > 1);
        if(arrivalDateUniqueCount == 1){
            fixture.logger.info(`As RequestDeliveryDate is same for all line items, order should not be split`);
        }else{
            fixture.logger.info(`As RequestDeliveryDate is not same for all line items, order should be split by requested arrival date. Hence skipping the validation`);
        }

        const finalSplitOrderXPath = this.Elements.splitOrderNumberXPath.replace(this.replaceData, this.Elements.splitOrderNumberLabelTestIdValue);
        const splitOrderCount = await this.pwWrapper.pageElement.getAvailableElementCount(finalSplitOrderXPath);
        fixture.logger.info(`Displayed split order count is: ${splitOrderCount}`);

        let validationResult = false;
        if (splitOrderCount == 0) {
            fixture.logger.error(`Split Order with the XPath ${finalSplitOrderXPath} could not be found`);
        }
        else if (splitOrderCount > 1 && !shouldSplitOrder) {
            fixture.logger.error(`Order is split but it is not expected to be split`);
        }else if (splitOrderCount == 1 && shouldSplitOrder) {
            fixture.logger.error(`Order is not split but it is expected to be split`);
        }else if (splitOrderCount == 1 && !shouldSplitOrder) {
            fixture.logger.info(`Order is not split hence skipping arrival date validations for item numbers`);
            validationResult = true;
        }else{
            fixture.logger.info(`Order is split hence performing arrival date validations for item numbers`);
            for (const [requestDeliveryDate, itemNumbers] of reqArrivalDateMap.entries()) {
                for (const itemNumber of itemNumbers) { 
                    let finalArrivalDateByItemNumberXPath = this.Elements.arrivalDateByItemNumberXPath.replace(this.replaceData, itemNumber);
                    fixture.logger.info(`finalArrivalDateByItemNumberXPath: ${finalArrivalDateByItemNumberXPath}`);
                    let arrivalDate = await this.pwWrapper.dataReader.getElementTextByXPath(finalArrivalDateByItemNumberXPath, false);
                    fixture.logger.info(`Displayed arrival date for the item number - ${itemNumber} - is: ${arrivalDate}`);
                    arrivalDate = arrivalDate.replace("Requested Arrival Date: ", "");
                    if (arrivalDate.trim() != requestDeliveryDate.trim()) {
                        fixture.logger.error(`Displayed arrival date ('${arrivalDate.trim()}') for the item number - ${itemNumber} - is not same as the requested arrival date provided by the stored procedure ('${requestDeliveryDate.trim()}')`);
                        validationResult = false;
                        break;
                    }
                    validationResult = true;
                }
                if (!validationResult) {
                    break;
                }
            }
        }
        fixture.logger.info(`Order split validation by requested arrival date completed`);
        return validationResult;
    }

    /**
     * Order split validation by requested arrival date for bulk product orders.
     * Note: assumptions
     * 1) for each bulk line item, there will be one sub-order created per requested arrival date
     * 2) lineItems contain only two distinct line items where one of the line items has max no of requested arrival dates
     * @param lineItems two distinct line items with same requested arrival date
     * @returns 
     */
    async validateBulkProductOrderSplitByRequestedArrivalDate(lineItems: LineItemInfo[]): Promise<boolean> {
        fixture.logger.info(`starting order split validation by requested arrival date of bulk product`);
        const subOrderInfo: SubOrderInfo[] = await this.getSplitOrderDetails();
        if (subOrderInfo.length == 0) {
            fixture.logger.error(`No split order information found`);
            return false;
        }else if (subOrderInfo.length != lineItems.length) {
            fixture.logger.error(`Split order information count (${subOrderInfo.length}) is not same as the line item count (${lineItems.length})`);
            return false;
        }
        for(let i=0; i<lineItems.length; i++){
            let itemNumber = lineItems[i].ItemNumber.trim();
            let subOrder = this.retrieveAndDeleteElement(subOrderInfo, itemNumber);
            if (subOrder == undefined) {
                fixture.logger.error(`Sub order information not found for the item number: ${itemNumber}`);
                fixture.logger.error('split order vaidation failed');
                return false;
            }
            if(subOrder.requestedArrivalDate.trim() != lineItems[i].RequestDeliveryDate.trim()){
                fixture.logger.error(`For the item number - ${itemNumber} - requested arrival date on the UI ('${subOrder.requestedArrivalDate.trim()}') is not same as the requested arrival date provided by the stored procedure ('${lineItems[i].RequestDeliveryDate.trim()}')`);
                fixture.logger.error('split order vaidation failed');
                return false;
            }
        }
        if(subOrderInfo.length > 0){
            fixture.logger.error(`Sub order information is not empty after processing all the line items`);
            fixture.logger.error('split order vaidation failed');
            return false;
        }
        fixture.logger.info(`Order split validation by requested arrival date of bulk product completed successfully`);
        return true;
    }

    private retrieveAndDeleteElement(array: SubOrderInfo[], itemNumberForComparison: string): SubOrderInfo | undefined {
        const index = array.findIndex(element => element.itemNumber === itemNumberForComparison);
        if (index !== -1) {
            const [element] = array.splice(index, 1);
            return element;
        }
        return undefined;
    }
    
    private async getSplitOrderDetails(): Promise<SubOrderInfo[]> {
        fixture.logger.info(`starting fetching order split infromation from the summary page`);
        const subOrdersInfo: SubOrderInfo[] = []; //array of sub orders
        const count = await this.pwWrapper.pageElement.getAvailableElementCountBySimilarTestId(this.Elements.splitOrderNumberLabelTestIdValue);
        if (count == 0) {
            fixture.logger.error(`Split Order with the data-testid value ${this.Elements.splitOrderNumberLabelTestIdValue} could not be found`);
            return subOrdersInfo;
        }
        for (let index = 1; index <= count; index++) {
            let subOrder = new SubOrderInfo();
            let finalSplitOrderNumberLabelTestIdValue = this.Elements.splitOrderNumberLabelTestIdValue + index;
            let splitOrderNumber = await this.pwWrapper.dataReader.getElementTextByTestId(finalSplitOrderNumberLabelTestIdValue);
            fixture.logger.info(`split order number is: ${splitOrderNumber}`);
            subOrder.orderId = splitOrderNumber;
            const subOrderUniqueIdentifier = splitOrderNumber.split("-")[1].trim(); //sub order number is the last part of the split order number. E.g., for the order number 'Order ID: 20250507411843-100', sub order number is '100'
            fixture.logger.info(`sub order number is: ${subOrderUniqueIdentifier}`);
            let finalSplitOrderReqArrivalDateLabelTestIdValue = this.Elements.splitOrderReqArrivalDateLabelTestIdValue + index;
            let requestedArrivalDate = await this.pwWrapper.dataReader.getElementTextByTestId(finalSplitOrderReqArrivalDateLabelTestIdValue);
            fixture.logger.info(`split order requested arrival date is: ${requestedArrivalDate}`);
            requestedArrivalDate = requestedArrivalDate.replace("Requested Arrival Date: ", "");
            subOrder.requestedArrivalDate = requestedArrivalDate;
            let finalSplitOrderItemNumberLabelTestIdValue = this.Elements.splitOrderItemNumberLabelTestIdValue.replace(this.replaceData, subOrderUniqueIdentifier) 
                                                + 1; //item number count in the bulk split order is always 1 hence using 1
            let itemNumber = await this.pwWrapper.dataReader.getElementTextByTestId(finalSplitOrderItemNumberLabelTestIdValue);
            fixture.logger.info(`split order item number is: ${itemNumber}`);
            subOrder.itemNumber = itemNumber;
            subOrdersInfo.push(subOrder);
        }
        fixture.logger.info(`completed fetching order split infromation from the summary page`);
        return subOrdersInfo;
    }
}

class SubOrderInfo {
    orderId: string;
    requestedArrivalDate: string;
    itemNumber: string;
}