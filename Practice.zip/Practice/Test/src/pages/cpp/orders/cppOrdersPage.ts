import HtmlRoles from "../../../helpers/wrapper/htmlRoles";
import { fixture } from "../../../hooks/fixture";
import BasePage from "../../basePage";

export default class CppOrdersPage extends BasePage {
    replaceData: string = "replace-data";
    static readonly TabName_Placed_Orders: string =  "Placed Orders";
    static readonly TabName_Draft_Orders: string = "Draft Orders";
    static readonly TabName_EA_Orders: string = "Early Advantage Orders";
    static readonly TabName_EA_Draft_Orders: string = "Early Advantage Draft Orders";
    static readonly Order_Summary_Status_Notice_Txt: string = `Your order has been submitted. You will receive an e-mail confirmation.`;
    static readonly Order_Summary_Status_Notice_Txt_1: string = `Your Order has been submitted and split by product. You will receive an e-mail with the updated order confirmations.`;
    static readonly Order_Summary_Status_Txt: string = `SUBMITTED`;
    
    Elements = {
        cppOrdersPageUri: "landing-data",
        ordersMenuButtonName: "Orders",
        activeTabNameXPath: `//*[contains(@class, 'mdc-tab-indicator--active')]//*[contains(@class, 'tab-head')]/h4`,
        createNewOrderButtonName: "Create New Order",
        draftOrderNumberOfShiptoAccountXPath: `(//td[contains(., '${this.replaceData}')]/preceding-sibling::td//a)[1]`,
        //draftOrdersTabHamburgerMenuXPath: `//td[contains(.,'Account # ${this.replaceData} ')]//following::button`,
        draftOrdersTabHamburgerMenuXPath: `//td[contains(.,'Account # ${this.replaceData} ')]//following-sibling::td//button//i[contains(@class, 'fa-ellipsis-v')]`,
        deleteDraftOrderBtnTxt: `Delete Order`,
        editDraftOrderBtnTxt: `Edit Order`,
        confirmationYesBtnTxt: 'Yes',
        customerPOBasedOrderIdXPath: `//*[contains(., '${this.replaceData}')]/ancestor::td//preceding-sibling::td//a`,
    }

    private async isPageLoaded(): Promise<boolean>{
        await super.waitUntilButtonIsDisplayed(this.Elements.createNewOrderButtonName);
        return true;
    }

    async isPageStable(){
        fixture.logger.info('checking for cpp-orders-page stability');
        const res = await this.isPageLoaded();
        fixture.logger.info('checking for cpp-orders-page stability completed');

        return res;
    }

    async clickCreateNewOrder(){
        await this.pwWrapper.elementAction.clickElementByRole(HtmlRoles.BUTTON, this.Elements.createNewOrderButtonName);
        while(await this.sharedBehavior.isOperationInProgress());
    }
    
    async switchToTab(tabNameToSwitch: string) {
        await this.sharedBehavior.clickOnTab(tabNameToSwitch, true);
    }

    async getExistingDraftOrdersCount(accountNumber: string): Promise<number>{
        fixture.logger.info(`checking existing draft orders for ${accountNumber}`);
        const hamburgerMenuXPath = this.Elements.draftOrdersTabHamburgerMenuXPath.replace(this.replaceData, accountNumber);
        const menuCount = await this.pwWrapper.pageElement.getAvailableElementCount(hamburgerMenuXPath);
        fixture.logger.info(`completed checking existing draft orders for ${accountNumber}`);
        return menuCount;
    }

    async openExistingFirstDraftOrder(accountNumber: string){
        const finalXPath = this.Elements.draftOrderNumberOfShiptoAccountXPath.replace(this.replaceData, accountNumber);
        await this.pwWrapper.elementAction.clickElement(finalXPath);
        while(await this.sharedBehavior.isOperationInProgress());
    }

    async deleteAccountDraftOrders(accountNumber: string, existingOrdersCount: number) {
        fixture.logger.info(`deleting existing draft orders for ${accountNumber}`);
        const hamburgerMenuXPath = this.Elements.draftOrdersTabHamburgerMenuXPath.replace(this.replaceData, accountNumber);
        for (let i = existingOrdersCount; i > 0; i--) {
            let finalXPath = '(' + hamburgerMenuXPath + `)[${i}]`;
            //click the hamburger menu
            await this.pwWrapper.elementAction.clickElement(finalXPath);

            //click delete
            await this.pwWrapper.elementAction.waitAndClickButtonByNonDefaultRole(this.Elements.deleteDraftOrderBtnTxt, HtmlRoles.MENU_ITEM);
            
            //click YES on the confirmation window
            await this.pwWrapper.elementAction.waitAndClickButtonByRole(this.Elements.confirmationYesBtnTxt);
            while(await this.sharedBehavior.isOperationInProgress());
        }
        fixture.logger.info(`completed deleting existing draft orders for ${accountNumber}`);
    }

    async getCurrentActiveTabName(): Promise<string>{
        return await this.pwWrapper.dataReader.getElementTextByXPath(this.Elements.activeTabNameXPath, false);
    }

    async getOrderNumberByCustomerPO(customerPO: string): Promise<string>{
        const finalXPath = this.Elements.customerPOBasedOrderIdXPath.replace(this.replaceData, customerPO);
        return await this.pwWrapper.dataReader.getElementTextByXPath(finalXPath, false);
    }    
}