const { format } = require('date-fns');
import DateHelper from "../../../helpers/types/dateHelper";
import HtmlRoles from "../../../helpers/wrapper/htmlRoles";
import KeyBoardItems from "../../../helpers/wrapper/keyBoardItems";
import { fixture } from "../../../hooks/fixture";
import DataBagKeys from "../../../tests/steps/dataBagKeys";
import BasePage from "../../basePage";

export default class CppNewOrderPage extends BasePage {

    readonly replaceValue1 = 'replace-value-1';
    readonly replaceValue2 = 'replace-value-2';
    readonly replaceValue3 = 'replace-value-3';
    readonly dateFormatInTheCalendar = `MM/dd/yyyy`;
    readonly dateConversionOptions: Intl.DateTimeFormatOptions = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    static readonly CPP_SCENARIO_BULK = 'bulk';
    Elements = {
        shipToDropdownText: 'Ship To:',
        existingDraftOrderOpenConfirmationXPath: `//button[contains(., '${this.replaceValue1}')]`,
        soldToDropdownText: 'Sold To: (Will Display after selection of Ship To):',
        soldToNameXPath: `(//*[contains(@name,'ddlSoldTo')]//span)[2]`,
        deliverToDropdownText: 'Deliver To:',
        deliverToDropdownInputXPath: `//*[contains(@placeholder, 'Deliver To:')]//input`,
        deliverToCheckboxTestId: `ddl-deliver-to-checkbox`,
        shippingInstructionsTextAreaTestId: `ddl-shipping-instruction`,
        customerPoTxtBoxTestID: 'ddl-customer-po',
        nonSubscriberEmailTestId: `ddl-cpp-email`,
        customerPickupCheckboxTestId: `ddl-customer-pickup`,
        contactNameTestId: `ddl-packaged-contact-name-search`,
        contactPhoneNumberTestId: `txt-packaged-contact-number`,
        deliveryInstructionsTestId: `ddl-delivery-instruction-search`,
        deliveryInstructionsFirstOptionTestId: `ddl-delivery-instruction-option_0`,
        addProductBtnText: 'Add Product',
        productAddedToastMsgXPath: `//*[contains(@role,'alert') and contains(., 'Product Added')]`, //multiple xpath clauses
        noDataFoundMsgXPath: `//div[text()='No items found']`,
        lineItemQtyDecreaseTestId: `btn-specific-minus_${this.replaceValue1}_`,
        lineItemQtyIncreaseTestId: `btn-specific-plus_${this.replaceValue1}_`,
        headerQuantityXpath: `//th[@role='columnheader' and text()='Quantity']`,
        lineItemQtyTxtBoxTestId: `txt-specific-qty_${this.replaceValue1}_`, //replace with item number
        lineItemTotalGallonsLabelTestId: `lbl-specific-gallon_${this.replaceValue1}_`,
        lineItemReqArrivalDateCalendarTestId: `btn-request-delivery_${this.replaceValue1}_${this.replaceValue2}`,//replace with item number and line number
        lineItemPackageSizeLabelTestId: `lbl-package-size_${this.replaceValue1}_${this.replaceValue2}`,//replace with item number and line number
        chooseYearLabel: 'Select year',
        chooseMonthLabel: 'Select month',
        viewProductDetailsTestId: `btn-show-product-details_${this.replaceValue1}_${this.replaceValue2}`, //replace with item number and line number
        productMinMaxQtyWarningMsgTestId: `lbl-warning-message_${this.replaceValue1}_${this.replaceValue2}`, //replace with item number and line number
        productMinMaxQtyErrorMsgTestId: `lbl-error-message_${this.replaceValue1}_${this.replaceValue2}`, //replace with item number and line number
        minMaxQtyWarningMsgTxt: `
            Quantities above ${this.replaceValue1} ${this.replaceValue3} will split into multiple sub-orders to facilitate transportation. 
            All sub-orders should have a minimum quantity of ${this.replaceValue2} ${this.replaceValue3}.`, //replaceValue1 = max qty; replaceValue2 = min qty; and replaceValue3 = UOM
        minMaxQtyErrorMsgTxt: `See item quantity restrictions and readjust the ordered quantity.`,        
        deliveryReasonSelectTestId: `ddl-delivery-reason_${this.replaceValue1}_`,//replace with item number
        deliveryReasonSelectXPath: `//*[contains(@name, 'reasonChange')]`,
        deliveryReasonOptionXPath: `//*[contains(@class, 'ng-option-label')]//*[contains(.,'${this.replaceValue1}')]`,//replace with reason code
        selectedDeliveryReasonOptionTestId: `ddl-delivery-reason-option_${this.replaceValue1}_`,
        saveDraftBtnText: `Save Draft`,
        placeOrderBtnText: `Place Order`,
        orderQtyInThePlacedOrderTestId: `lbl-order-quantity_${this.replaceValue1}_`, //replace with item number
        orderQtyInThePlacedOrderXPath: `//*[contains(@data-testid, 'lbl-order-quantity_${this.replaceValue1}_')]`, //replace with item number
        customerPORequiredErrorMsgXPath: `//div[contains(., 'Customer PO is required for selected account')]`,
        lineItemFavoriteBtnXPath: `//*[contains(@data-testid, 'btn-add-remove-favourite_${this.replaceValue1}_')]/i`, //star icon; replace with itemNumber
        lineItemFavoriteIconXPath:`//*[contains(@data-testid, 'btn-add-remove-favourite_${this.replaceValue1}_')]/i[contains(@class, '${this.replaceValue2}')]`, //this.replaceValue2 should be either notFavClassName or favClassName
        notFavClassName: `far`,
        favClassName: `fas`,
        allLineItemsSelectCheckBoxTestId: `chk-select-all-product`,
        deleteAllLineItemsToolTip: `Delete Items from Order`,
        additionalRequestedArrivalDateBtnTestId: `btn-additional-row_${this.replaceValue1}`, //replace with itemNumber
        continueBtnTxt: 'Continue',
    }

    private async isPageLoaded(): Promise<boolean>{
        while(await this.sharedBehavior.isOperationInProgress());
        return true;
    }

    async isPageStable(){
        fixture.logger.info('checking for cpp-new-order-page stability');
        const res = await this.isPageLoaded();
        fixture.logger.info('checking for cpp-new-order-page stability completed');

        return res;
    }

    async addNewLineItemForTheItemNumber(itemNumber: string): Promise<boolean>{
        const finalTestId = this.Elements.additionalRequestedArrivalDateBtnTestId.replace(this.replaceValue1, itemNumber);
        const count = await this.pwWrapper.pageElement.getAvailableElementCountByTestId(finalTestId);
        if(count == 0)
        {
            fixture.logger.error(`Additinal Requested Arrival Date button is not visible for the itemNumber - ${itemNumber}`);
            return false;
        }
        await this.pwWrapper.elementAction.clickElementByTestId(finalTestId);
        while(await this.sharedBehavior.isOperationInProgress());
        return true;
    }

    async deleteOrderLineItems(){
        fixture.logger.info('deleting order line items started');
        while(await this.sharedBehavior.isOperationInProgress());
        await this.pwWrapper.elementAction.clickElementByTestId(this.Elements.allLineItemsSelectCheckBoxTestId);
        while(await this.sharedBehavior.isOperationInProgress());
        await this.sharedBehavior.triggerOrderLevelActionByTooltip(this.Elements.deleteAllLineItemsToolTip);
        while(await this.sharedBehavior.isOperationInProgress());
        fixture.logger.info('deleting order line items completed');
    }

    async selectShipTo(accountNumber: string){
        await this.setShipToAccountData(accountNumber, false, true);
    }

    async selectShipToOfExistingOrder(accountNumber: string, createNewCppOrder: boolean){
        await this.setShipToAccountData(accountNumber, true, createNewCppOrder);
    }

    private async setShipToAccountData(accountNumber: string, shouldManageExistingOrder: boolean, createNewCppOrder: boolean){
        if(shouldManageExistingOrder)
            fixture.logger.info(`selecting 'Ship To' for ${accountNumber} with existing order`);
        else
            fixture.logger.info(`selecting 'Ship To' for ${accountNumber}`);

        accountNumber = accountNumber.trim();
        await this.sharedBehavior.selectAngularDropdownOptionByPlaceholder(this.Elements.shipToDropdownText, accountNumber, this.Elements.noDataFoundMsgXPath);
        if(shouldManageExistingOrder)
            await this.manageExistingOrder(accountNumber, createNewCppOrder);

        while (await this.sharedBehavior.isOperationInProgress());
        
        if(shouldManageExistingOrder)
            fixture.logger.info(`selected 'Ship To' for ${accountNumber} with existing order`);
        else
            fixture.logger.info(`selected 'Ship To' for ${accountNumber}`);
    }

    private async manageExistingOrder(accountNumber: string, createNewCppOrder: boolean){
        let path = this.Elements.existingDraftOrderOpenConfirmationXPath.replace(this.replaceValue1, 'Yes');
        const count = await this.pwWrapper.pageElement.getAvailableElementCount(path);
        if(count == 0)
        {
            const errMsg = `${accountNumber} does not have an existing order`;
            fixture.logger.error(errMsg);
            throw new Error(errMsg);
        }
 
        if(createNewCppOrder){
            path = this.Elements.existingDraftOrderOpenConfirmationXPath.replace(this.replaceValue1, 'No');
            fixture.logger.info(`new order will be created for ${accountNumber}`);
        }else{
            fixture.logger.info(`existing order will be opened for ${accountNumber}`);
        }

        await this.pwWrapper.elementAction.clickElement(path);
    }

    async getSoldToName(){
        return await this.pwWrapper.dataReader.getElementTextByXPath(this.Elements.soldToNameXPath, false);
    }

    async selectDeliverTo(accountNumber: string){
        fixture.logger.info(`selecting 'Deliver To' for ${accountNumber}`);
        accountNumber = accountNumber.trim();
        const deliverToClickable = await this.pwWrapper.pageElement.isElementClickable(this.Elements.deliverToDropdownInputXPath);
        if(!deliverToClickable)
            await this.pwWrapper.elementAction.clickElementByTestId(this.Elements.deliverToCheckboxTestId);
        await this.sharedBehavior.selectAngularDropdownOptionByPlaceholder(this.Elements.deliverToDropdownText, accountNumber, this.Elements.noDataFoundMsgXPath);
        while (await this.sharedBehavior.isOperationInProgress());
        fixture.logger.info(`selected 'Deliver To' for ${accountNumber}`);
    }

    async fillOrderDetails(isCustomerPickup: boolean = false, fillCustomerPO: boolean = true): Promise<string> {
        fixture.logger.info('entering order details started');
        //shipping instructions
        await this.pwWrapper.dataWriter.enterValueIntoTextboxByTestId(this.Elements.shippingInstructionsTextAreaTestId,"QA automation testing CPP orders shipping instructions on " + DateHelper.getDateTimeUTC());
        fixture.logger.info('entered shipping instructions');

        //customer po
        let customerPO = "";
        await this.clearCustomerPO();
        if(fillCustomerPO)
            customerPO = await this.setCustomerPO();
        else{
            fixture.logger.info('customer PO will not be filled');
        }

        //non-subscriber emails
        await this.pwWrapper.dataWriter.enterValueIntoTextboxByTestId(this.Elements.nonSubscriberEmailTestId, "testing@qa-automation.com");
        fixture.logger.info('entered non-subscriber emails');

        //customer pickup
        if (isCustomerPickup) {
            await this.pwWrapper.elementAction.clickElementByTestId(this.Elements.customerPickupCheckboxTestId);
            fixture.logger.info('completed setting customer pickup');
        }

        fixture.logger.info('entering order details completed');
        return customerPO;
    }

    async setCustomerPO(clearExistingDetails: boolean = false){
        let customerPO = "";
        if(clearExistingDetails){
            await this.clearCustomerPO();
            customerPO = ("t-" + DateHelper.getUniqueNumberBasedOnDate()).substring(0,25); //UI allows only 25 characters
        }
        else
        {
            customerPO = ("t-" + DateHelper.getUniqueNumberBasedOnDate()).substring(0,25); //UI allows only 25 characters
        }
        
        await this.pwWrapper.dataWriter.enterValueIntoTextboxByTestId(this.Elements.customerPoTxtBoxTestID, customerPO, true);
        fixture.logger.info('entered customer po');
        return customerPO;
    }

    async clearCustomerPO(){
        await this.pwWrapper.dataWriter.enterValueIntoTextboxByTestId(this.Elements.customerPoTxtBoxTestID, "", false);
        fixture.logger.info('cleared existing customer PO');
    }

    async isCustomerPOErrorMsgDisplayed(): Promise<boolean>{
        return await this.pwWrapper.pageElement.getAvailableElementCount(this.Elements.customerPORequiredErrorMsgXPath) > 0;
    }
    
    async clickAddProducts(){
        await this.pwWrapper.elementAction.waitAndClickButtonByRole(this.Elements.addProductBtnText);
        while(await this.sharedBehavior.isOperationInProgress());
    }
    
    async dismissProductAddedToastMsg(){
        const count = await this.pwWrapper.pageElement.getAvailableElementCount(this.Elements.productAddedToastMsgXPath);
        if(count > 0){
            try{
                await this.pwWrapper.elementAction.clickElement(this.Elements.productAddedToastMsgXPath);
            }catch(err){
                //ignore error and proceed
            }
        }
    }

    async fillOrderContactAndDeliveryDetails(contactName: string = ""){
        /**
         * THESE ELEMENTS WILL BE ENABLED ONLY AFTER ADDING A PRODUCT TO THE ORDER
         */
        fixture.logger.info('entering order contact and delivery details started');
        while(await this.sharedBehavior.isOperationInProgress());
        //contact name
        if(contactName.length == 0)
            contactName = 'automationContact';

        const cppScenarioType = fixture.dataBag.getData(DataBagKeys.CPP_SCENARIO) as string;
        let contactNameTestId = this.Elements.contactNameTestId;
        let contactPhoneTestId = this.Elements.contactPhoneNumberTestId;
        if(cppScenarioType != undefined && cppScenarioType == CppNewOrderPage.CPP_SCENARIO_BULK){
            fixture.logger.info('bulk scenario detected');
            contactNameTestId = contactNameTestId.replace('packaged', CppNewOrderPage.CPP_SCENARIO_BULK);
            contactPhoneTestId = contactPhoneTestId.replace('packaged', CppNewOrderPage.CPP_SCENARIO_BULK);
            fixture.logger.info(`contact name test id updated to - ${contactNameTestId}`);
            fixture.logger.info(`contact phone test id updated to - ${contactPhoneTestId}`);
        }

        const contactNameDropdown = await this.pwWrapper.pageElement.getElementByTestId(contactNameTestId);
        await this.pwWrapper.dataWriter.enterDataIntoChildInputAndPressaKey(contactNameDropdown, contactName, KeyBoardItems.ENTER);
        fixture.logger.info('entered contact name');

        //contact phone number
        await this.setContactPhoneDetails(false, contactPhoneTestId);

        //delivery instructions
        if (cppScenarioType == undefined || cppScenarioType != CppNewOrderPage.CPP_SCENARIO_BULK)
        {
            //delivery instructions are not applicable for bulk scenarios
            await this.pwWrapper.elementAction.clickElementByTestId(this.Elements.deliveryInstructionsTestId);
            const optionsCount = await this.pwWrapper.pageElement.getAvailableElementCountByTestId(this.Elements.deliveryInstructionsFirstOptionTestId);
            if (optionsCount > 0) {
                await this.pwWrapper.elementAction.clickElementByTestId(this.Elements.deliveryInstructionsFirstOptionTestId);
                fixture.logger.info('entered delivery instructions');
            }
        }
        fixture.logger.info('entering order contact and delivery details completed');
    }

    async setContactPhoneDetails(clearExistingDetails: boolean = false, contactPhoneNumberTestId: string = ""){
        //contact phone number
        let contactPhone = "";
        if(contactPhoneNumberTestId.length == 0)
            contactPhoneNumberTestId = this.Elements.contactPhoneNumberTestId;

        if(clearExistingDetails){
            await this.pwWrapper.dataWriter.enterValueIntoTextboxByTestId(contactPhoneNumberTestId, contactPhone, false);
            fixture.logger.info('cleared existing contact phone number');
            contactPhone = '9234567890';
        }
        else
        {
            contactPhone = '1234567890';
        }
        await this.pwWrapper.dataWriter.enterValueIntoTextboxByTestId(contactPhoneNumberTestId, contactPhone, true);
        fixture.logger.info('entered contact phone number');
    }

    async incrementOrDecrementLineItemQty(itemNumber: string, shouldIncrement: boolean, lineItemIndex: number){
        let testId = shouldIncrement ? this.Elements.lineItemQtyIncreaseTestId.replace(this.replaceValue1, itemNumber) :
            this.Elements.lineItemQtyDecreaseTestId.replace(this.replaceValue1, itemNumber);
        await this.pwWrapper.elementAction.clickElementByTestId(testId+lineItemIndex);
    }

    async modifyLineItemQty(itemNumber: string, lineItemIndex: number, qty: string){
        let testId = this.Elements.lineItemQtyTxtBoxTestId.replace(this.replaceValue1, itemNumber) + lineItemIndex;
        await this.pwWrapper.dataWriter.enterValueIntoTextboxByTestId(testId, qty);
        fixture.logger.info(`completed entering quantity ${qty} for the line item with itemNumber ${itemNumber}`);
    }

    async fillDeliveryDate(itemNumber: string, deliveryDate: Date, lineItemIndex: number){
        fixture.logger.info(`selecting delivery date ${deliveryDate} for the line item with itemNumber ${itemNumber}`);
        const fd = deliveryDate.toLocaleDateString('en-US', this.dateConversionOptions);
        fixture.logger.info(`full formatted date to select - ${fd}`);
        
        const finalCalendarTestId = this.Elements.lineItemReqArrivalDateCalendarTestId
                                        .replace(this.replaceValue1, itemNumber)
                                        .replace(this.replaceValue2, lineItemIndex.toString());
        await this.pwWrapper.elementAction.clickElementByTestId(finalCalendarTestId);
        const formatted = format(deliveryDate, this.dateFormatInTheCalendar);
        fixture.logger.info(`formatted delivery date - ${formatted}`);
        const splits:string[] = formatted.split("/");
        const deliveryYear = splits[2];
        if(deliveryYear != (new Date()).getFullYear().toString()){
            await this.pwWrapper.elementAction.selectDropdownOptionByParentLabel(this.Elements.chooseYearLabel, deliveryYear); //selecting year
        }
        let month = splits[0];
        if(month.startsWith("0"))
            month = month.substring(1);
        await this.pwWrapper.elementAction.selectDropdownOptionByParentLabel(this.Elements.chooseMonthLabel, month); //selecting month
        await this.pwWrapper.elementAction.clickElementByLabel(fd); //selecting week-day, month, day & year

        //if the calendar is not closed automatically, close it by clicking outside the calendar
        // const finalPackageSizeLabelTestId = this.Elements.lineItemPackageSizeLabelTestId
        //                                 .replace(this.replaceValue1, itemNumber)
        //                                 .replace(this.replaceValue2, lineItemIndex.toString());
        // await this.pwWrapper.elementAction.clickElementByTestId(finalPackageSizeLabelTestId);
        await this.pwWrapper.elementAction.clickElement(this.Elements.headerQuantityXpath);
        fixture.logger.info(`completed selecting delivery date`);
    }

    async selectArrivalDateChangeReason(itemNumber: string, reason: string, lineItemIndex: number){
        fixture.logger.info(`selecting arrival date change reason as - ${reason} for the item - ${itemNumber}`);
        const finalOptionXPath = this.Elements.deliveryReasonOptionXPath.replace(this.replaceValue1, reason);
        const finalLineItemReasonSelectTestId = this.Elements.deliveryReasonSelectTestId.replace(this.replaceValue1, itemNumber) + lineItemIndex;
        await this.pwWrapper.elementAction.clickElementByTestId(finalLineItemReasonSelectTestId);
        await this.pwWrapper.elementAction.clickElement(finalOptionXPath);
        fixture.logger.info(`completed selecting arrival date change reason as - ${reason}`);
    }
    async clickSaveDraft(){
        fixture.logger.info(`starting Save Draft Order operation`);
        const msg = await this.saveDraftOrPlaceOrder(this.Elements.saveDraftBtnText, this.Elements.saveDraftBtnText);
        if(msg !== null && msg !== "" && msg.length > 0)
            fixture.logger.info(`save-draft-order operation message is - ${msg}`);
        fixture.logger.info(`completed Save Draft Order operation`);
        return msg;
    }

    async canClickSaveDraft(){
        return await this.pwWrapper.pageElement.isElementByRoleEnabled(HtmlRoles.BUTTON, this.Elements.saveDraftBtnText);
    }

    async clickPlaceOrder(){
        fixture.logger.info(`starting Place Order operation`);
        const msg = await this.saveDraftOrPlaceOrder(this.Elements.placeOrderBtnText, this.Elements.placeOrderBtnText);
        if(msg !== null && msg !== "" && msg.length > 0)
            fixture.logger.info(`place-order operation message is - ${msg}`);
        fixture.logger.info(`completed Place Order operation`);
        return msg;
    }

    private async saveDraftOrPlaceOrder(operationMsg: string, btnName: string){
        const continueBtnCount = await this.pwWrapper.pageElement.getAvailableElementCountByText(this.Elements.continueBtnTxt, true);
        if(continueBtnCount > 0) {
            fixture.logger.info(`continue button is present, clicking on it`);
            await this.pwWrapper.elementAction.waitAndClickButtonByRole(this.Elements.continueBtnTxt);
        }
        const msg = await this.sharedBehavior.clickButtonAndInspectSuccessMessageIndependentlyForOrderUpdate(operationMsg, btnName);
        fixture.logger.info(`msg received is---${msg}`);
        while(await this.sharedBehavior.isOperationInProgress());
        fixture.logger.info(`before returing msg`);
        return msg;
    }

    async isReasonChangePresent():Promise<boolean>{
        return await this.pwWrapper.pageElement.getAvailableElementCount(this.Elements.deliveryReasonSelectXPath) > 0;
    }

    async getSelectedDeliveryReasonOptionValue(itemNumber: string, lineItemIndex: number): Promise<string>{
        const finalXPath = this.Elements.selectedDeliveryReasonOptionTestId.replace(this.replaceValue1, itemNumber) + lineItemIndex;
        fixture.logger.info(`xpath for the selected reason option - ${finalXPath}`);
        return await this.pwWrapper.dataReader.getElementTextByTestId(finalXPath);
    }

    /**
     * Clicks on the 'View Product Details' link for the given item number and line number
     * @param itemNumber item number
     * @param lineNumber line number; starts from 1
     */
    async clickViewProductDetails(itemNumber: string, lineNumber: number){
        const finalTestId = this.Elements.viewProductDetailsTestId.replace(this.replaceValue1, itemNumber).replace(this.replaceValue2, lineNumber.toString());
        await this.pwWrapper.elementAction.clickElementByTestId(finalTestId);
    }

    /**
     * 
     * @param itemNumber 
     * @param lineNumber line number; starts from 1
     * @returns warning message
     */
    async getDisplayedProductMinMaxQtyWarningMsg(itemNumber: string, lineNumber: number): Promise<string>{    
        const finalTestId = this.Elements.productMinMaxQtyWarningMsgTestId
                                    .replace(this.replaceValue1, itemNumber)
                                    .replace(this.replaceValue2, lineNumber.toString());
        return await this.pwWrapper.dataReader.getElementTextByTestId(finalTestId);
    }

    /**
     * 
     * @param maxQty 
     * @param minQty line number; starts from 1
     * @returns 
     */
    getLineItemMinMaxQtyWarningMessage(maxQty: number, minQty: number, uom: string): string{
        return this.Elements.minMaxQtyWarningMsgTxt
                                .replace(this.replaceValue1, maxQty.toString())
                                .replace(this.replaceValue2, minQty.toString())
                                .replaceAll(this.replaceValue3, uom)
                                .replaceAll(/\s+/g, ' ').trim();;
    }

    /**
     * 
     * @param itemNumber 
     * @param lineNumber line number; starts from 1
     * @returns error message
     */
    async getDisplayedProductMinMaxQtyErrorMsg(itemNumber: string, lineNumber: number): Promise<string>{    
        const finalTestId = this.Elements.productMinMaxQtyErrorMsgTestId
                                    .replace(this.replaceValue1, itemNumber)
                                    .replace(this.replaceValue2, lineNumber.toString());
        return await this.pwWrapper.dataReader.getElementTextByTestId(finalTestId);
    }

    getLineItemMinMaxQtyErrorMessage(): string {
        return this.Elements.minMaxQtyErrorMsgTxt;
    }

    async getLineItemsCountInThePlacedOrder(itemNumber: string): Promise<number>{
        const finalXPath = this.Elements.orderQtyInThePlacedOrderXPath.replace(this.replaceValue1, itemNumber);
        fixture.logger.info(`finalXPath of the item in the order is - ${finalXPath}`);
        return await this.pwWrapper.pageElement.getAvailableElementCount(finalXPath);
    }

    async getLineItemsOrderQtyInThePlacedOrder(itemNumber: string): Promise<number[]>{
        const testIdWithItemNumberOnly = this.Elements.orderQtyInThePlacedOrderTestId.replace(this.replaceValue1, itemNumber);
        const count = await this.getLineItemsCountInThePlacedOrder(itemNumber);
        let result = [];
        for(let i=1; i<=count; i++){
            const txt = await this.pwWrapper.dataReader.getElementTextByTestId(testIdWithItemNumberOnly + i);
            fixture.logger.info(`order qty for item ${itemNumber} and line ${i} is - ${txt}`);
            result.push(parseInt(txt));
        }
        return result;
    }

    getQtyDistributions(minQty: number, maxQty: number, toDistribute: number): number[]{
        if (maxQty < minQty) {
            let errorMsg = `min (${minQty}) should be less than max (${maxQty})`;
            fixture.logger.error(errorMsg);
            throw new Error(errorMsg);
        }
        if (toDistribute < minQty) {
            let errorMsg = `toDistribute (${toDistribute}) should be at least min (${minQty}})`;
            fixture.logger.error(errorMsg);
            throw new Error(errorMsg);
        }
    
        if(toDistribute == minQty || toDistribute == maxQty){
          return [toDistribute];
        }
    
        const result: number[] = [];
        let quotant = Math.floor(toDistribute / maxQty);
        //fixture.logger.info(`quotant is ${quotant}`);
        let distributedAmount = 0;
        for(let i=0; i<quotant; i++){
          result.push(maxQty);
          distributedAmount = distributedAmount + maxQty;
        }
        let finalElement = 0;
        if(distributedAmount < toDistribute){
          finalElement = toDistribute - distributedAmount;
        }
        if(finalElement == 0)
          return result;
        else{
          result.push(finalElement);
          if(finalElement < minQty){
            let toAdjust = minQty - finalElement;
            //fixture.logger.info(`toAdjust is - ${toAdjust}`);
            //fixture.logger.info(`array before adjustment is - ${result}`);
            result[result.length - 1] = result[result.length - 1] + toAdjust;
            result[result.length - 2] = result[result.length - 2] - toAdjust;
          }
           return result;
        }
    }

    async isProductMarkedAsFavInTheOrder(itemNumber: string, lineItemSeq: number): Promise<boolean>{
        let updatedXPath = this.Elements.lineItemFavoriteIconXPath.replace(this.replaceValue1, itemNumber);
        let finalXPath = updatedXPath.replace(this.replaceValue2, this.Elements.favClassName);
        fixture.logger.info(`checking for favorite product in the order with the xpath: ${finalXPath}`);
        let count = await this.pwWrapper.pageElement.getAvailableElementCount(finalXPath);
        if(count > 0){
            fixture.logger.info(`product - ${itemNumber} - is marked as favorite`);
            return true;
        }else{
            finalXPath = updatedXPath.replace(this.replaceValue2, this.Elements.notFavClassName);
            count = await this.pwWrapper.pageElement.getAvailableElementCount(finalXPath);
            if(count > 0){
                fixture.logger.info(`product - ${itemNumber} - is not marked as favorite`);
                return false;
            }else{
                //we should not get here unless the order does not include the target product
                const errorMsg = `product - ${itemNumber} - is not available in the order`;
                fixture.logger.info(errorMsg);
                throw new Error(errorMsg);
            }
        }
    }

    async markOrUnmarkProductAsFavInTheOrder(itemNumber: string, lineItemSeq: number){
        const finalXPath = this.Elements.lineItemFavoriteBtnXPath.replace(this.replaceValue1, itemNumber);
        fixture.logger.info(`started marking the product - ${finalXPath} - as favorite or not-favorite in the order`);
        await this.pwWrapper.elementAction.clickElement(finalXPath);
        while(await this.sharedBehavior.isOperationInProgress());
        fixture.logger.info(`completed marking the product - ${finalXPath} - as favorite or not-favorite in the order`);
    }
}