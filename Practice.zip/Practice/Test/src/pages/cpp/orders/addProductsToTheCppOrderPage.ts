import { Locator } from "@playwright/test";
import { fixture } from "../../../hooks/fixture";
import BasePage from "../../basePage";
import KeyBoardItems from "../../../helpers/wrapper/keyBoardItems";

export default class AddProductsToTheCppOrderPage extends BasePage {
    
    readonly replaceValue1 = 'replace-value-1';
    readonly replaceValue2 = 'replace-value-2';
    readonly replaceValue3 = 'replace-value-3';
    readonly product_search_category_product_name = 'Product Name';
    readonly replaceProductNameInSearchResult = 'product-name';
    static readonly PRODUCT_SEARCH_FILTER_OPTION_ItemNumber: 'Item Number';
     
    static readonly TabName_All_Products: string =  "All Products";
    static readonly TabName_Favorite_Products: string = "Favorite Products";

    Elements = {
        productSearchFilterDropDownTestId: "ddl-cpp-search",
        productSearchFilterItemNumberCategoryTestId: "ddl-filter-select_itemNumber",
        searchProductByItemNumberTestId: "ddl-itemnumber-search", //this is search-box related to Item Number
        searchProductByItemNumberOptionTestId: `ddl-itemnumber-option_${this.replaceValue1}`, //this is search-box option
        searchBtnTestId: "ddl-product-search",
        productNameInSearchResultTestId: `lbl-all-tab-item_${this.replaceValue1}`,
        productSelectCheckBoxInSearchResultTestId: `chk-all-product_${this.replaceValue1}`,
        searchResultItemFavoriteBtnTestId: `btn-all-tab-add-remove_${this.replaceValue1}`, //star icon
        notFavClassName: `far`,
        favClassName: `fas`,
        searchResultItemFavoriteIconXPath:`//*[contains(@data-testid, 'btn-all-tab-add-remove_${this.replaceValue1}')]/i[contains(@class, '${this.replaceValue2}')]`, //this.replaceValue2 should be either notFavClassName or favClassName
        searchResultItemCheckboxTestId: `chk-all-product_${this.replaceValue1}`,
        favProductsTabTestId: `favourite-product-tab`,
        favItemCheckboxTestId: `chk-favourite-product_${this.replaceValue1}`,
        favItemBtnTestId: `btn-favourite-tab-add-remove_${this.replaceValue1}`, //star icon
        addToOrderButtonTestId: "ddl-add-cpp-product-model",
        addToOrderButtonName: 'Add Product to Order',
        clearAllLinkText: "Clear All",//clears search text and search results; retains selected search filters
    }

    /*eslint @typescript-eslint/require-await: "off" */
    async canNavigateWithUrl(): Promise<boolean>{
        return false;
    }
    
    private async isPageLoaded(): Promise<boolean>{
        let retryCount = 5;
        let result = false;
        await this.pwWrapper.common.delay(1000);//initial delay because spinner takes sometime to show up
        while(retryCount > 0)
        {
            while (await this.sharedBehavior.isOperationInProgress());
            result = await this.pwWrapper.elementAction.canClickItemByTestId(this.Elements.favProductsTabTestId);
            if(result)
                break;
            --retryCount;
        }
        return result;
    }

    async isPageStable(){
        fixture.logger.info('checking for add-products-to-the-order-page stability');
        const result = await this.isPageLoaded();
        fixture.logger.info('checking for add-products-to-the-order-page stability completed');
        if(!result)
            fixture.logger.error('add-products-to-the-order-page stability check failed');
        return result;
    }
    async clickSearchFilterDropDown(){
        await this.pwWrapper.elementAction.clickElementByTestId(this.Elements.productSearchFilterDropDownTestId);
        //await this.pwWrapper.common.delay(1000);
    }

    private selectedProductFilterOption = '';
    async selectSearchFilterItemInTheDropDown(filterOption: string){
        //await this.pwWrapper.dataWriter.selectOption(filterOption);
        if(filterOption == AddProductsToTheCppOrderPage.PRODUCT_SEARCH_FILTER_OPTION_ItemNumber)
            await this.pwWrapper.elementAction.clickElementByTestId(this.Elements.productSearchFilterItemNumberCategoryTestId);
        else{
            fixture.logger.error(`unsupported filter option - ${filterOption}`);
            throw new Error(`${filterOption} is not supported`);
        }
        this.selectedProductFilterOption = filterOption;
        await this.pwWrapper.common.delay(500);
        while(await this.sharedBehavior.isOperationInProgress());
    }
    async searchProduct(searchItems: string[]): Promise<boolean>{
        let searchTextBox: Locator;
        let isSearchByFreeText: boolean = false; //search by item number is not searching with free text so we set this as FALSE by default
        
        fixture.logger.info(`about to get product search box`);
        if(this.selectedProductFilterOption == AddProductsToTheCppOrderPage.PRODUCT_SEARCH_FILTER_OPTION_ItemNumber)
            searchTextBox = await this.pwWrapper.pageElement.getElementByTestId(this.Elements.searchProductByItemNumberTestId);

        fixture.logger.info(`about to click product search box`);
        await searchTextBox.click({ force: true });
        if (!isSearchByFreeText) {
            fixture.logger.info(`about to select the option from the product search box`);
            try{
                for(let i=0; i<searchItems.length; i++){
                    await this.pwWrapper.dataWriter.enterDataIntoChildInputAndPressaKey(searchTextBox, searchItems[i], KeyBoardItems.ENTER);
                }
            }catch(err){
                fixture.logger.error('failed...' + err);
            }
        } else {
            await searchTextBox.fill(searchItems[0]);
        }
        const searchBtnEnabled = await this.pwWrapper.elementAction.canClickItemByTestId(this.Elements.searchBtnTestId);
        if(!searchBtnEnabled){
            const errMsg = 'Search button is not enabled. Check search input which might be invalid';
            fixture.logger.error(errMsg);
            throw new Error(errMsg);
        }
        await this.pwWrapper.elementAction.clickElementByTestId(this.Elements.searchBtnTestId);

        while(await this.sharedBehavior.isOperationInProgress());
        fixture.logger.info('completed searching for the product');
        return true;
    }

    async clearProductSearchResults(){
        await (await this.pwWrapper.pageElement.getVisibleElementByLinkName(this.Elements.clearAllLinkText)).click();
    }

    async selectProductsFromAllProductsTabByItemNumber(itemNumbersToSelect: string[]){
        fixture.logger.info(`following products are being selected from 'All Products' tab: ${itemNumbersToSelect.toString()}`);
        while(await this.sharedBehavior.isOperationInProgress());
        //await this.pwWrapper.elementAction.clickElementByTestId(this.Elements.allProductsTabTestId);
        await this.sharedBehavior.clickOnTab(AddProductsToTheCppOrderPage.TabName_All_Products);
        while(await this.sharedBehavior.isOperationInProgress());
        let checkBoxCount = 0;
        for(let index=0; index<itemNumbersToSelect.length; index++){ 
            const itemNumber = itemNumbersToSelect[index];
            const finalTestId = this.Elements.productSelectCheckBoxInSearchResultTestId.replace(this.replaceValue1, itemNumber);
            fixture.logger.info(`product selection checkbox test-id is - ${finalTestId}`);
            checkBoxCount = await this.pwWrapper.pageElement.getAvailableElementCountByTestId(finalTestId);
            if(checkBoxCount == 0){
                let errMsg = `could not find the product corresponding to ${itemNumber}`;
                fixture.logger.error(errMsg);
                throw new Error(errMsg);
            }
            await this.pwWrapper.elementAction.clickElementByTestId(finalTestId);
            fixture.logger.info(`selected product is - ${itemNumber}`);
        }
        fixture.logger.info('product selection from the "All Products" tab completed');
    }

    async isAddToOrderButtonEnabled(): Promise<boolean>{
        while(await this.sharedBehavior.isOperationInProgress());
        return (await this.pwWrapper.pageElement.getElementByTestId(this.Elements.addToOrderButtonTestId)).isEnabled();
    }

    async clickAddToOrderButton(): Promise<string> {
        while(await this.sharedBehavior.isOperationInProgress());
        const msg = await this.sharedBehavior.clickButtonAndInspectSuccessMessage("adding product(s) to the order",this.Elements.addToOrderButtonName);
        if(msg !== null && msg !== "" && msg.length > 0)
            fixture.logger.info(`product addition to the order message is - ${msg}`);
        while(await this.sharedBehavior.isOperationInProgress());
        return msg;
    }
    
    async markOrUnmarkProductAsFav(itemNumber: string){
        await this.sharedBehavior.clickOnTab(AddProductsToTheCppOrderPage.TabName_All_Products);
        const finalTestId = this.Elements.searchResultItemFavoriteBtnTestId.replace(this.replaceValue1, itemNumber);
        fixture.logger.info(`started marking the product - ${finalTestId} - as favorite or not-favorite in the product selection screen`);
        await this.pwWrapper.elementAction.clickElementByTestId(finalTestId);
        while(await this.sharedBehavior.isOperationInProgress());
        fixture.logger.info(`completed marking the product - ${finalTestId} - as favorite or not-favorite in the product selection screen`);
    }

    /**
     * Checks if the specified product is available in 'Favorite Products' tab
     * @param itemNumber product item number
     * @returns true or false depending on product marked as favorite
     */
    async isProductMarkedAsFav(itemNumber: string): Promise<boolean>{
        await this.sharedBehavior.clickOnTab(AddProductsToTheCppOrderPage.TabName_Favorite_Products);
        const finalTestId = this.Elements.favItemCheckboxTestId.replace(this.replaceValue1, itemNumber);
        fixture.logger.info(`started checking if the product - ${finalTestId} - is marked as favorite`);
        const result = await this.pwWrapper.pageElement.getAvailableElementCountByTestId(finalTestId) > 0;
        fixture.logger.info(`completed checking if the product - ${finalTestId} - is marked as favorite`);
        return result;
    }

    /**
     * Checks if the specified product is marked as favorite in 'All Products' tab
     * @param itemNumber product item number
     * @returns true or false depending on product marked as favorite
     */
    async isProductMarkedAsFavInAllProducts(itemNumber: string): Promise<boolean>{
        await this.sharedBehavior.clickOnTab(AddProductsToTheCppOrderPage.TabName_All_Products);
        let updatedXPath = this.Elements.searchResultItemFavoriteIconXPath.replace(this.replaceValue1, itemNumber);
        let finalXPath = updatedXPath.replace(this.replaceValue2, this.Elements.favClassName);
        fixture.logger.info(`checking for favorite product in All Products tab with the xpath: ${finalXPath}`);
        let count = await this.pwWrapper.pageElement.getAvailableElementCount(finalXPath);
        if(count > 0){
            fixture.logger.info(`product - ${itemNumber} - is marked as favorite`);
            return true;
        }else{
            finalXPath = updatedXPath.replace(this.replaceValue2, this.Elements.notFavClassName);
            count = await this.pwWrapper.pageElement.getAvailableElementCount(finalXPath);
            if(count > 0){
                fixture.logger.info(`product - ${itemNumber} - is not marked as favorite`);
                return false;
            }else{
                //we should not get here unless search results do not include the target product
                const errorMsg = `product - ${itemNumber} - is not available in search results`;
                fixture.logger.info(errorMsg);
                throw new Error(errorMsg);
            }
        }
    }

    async removeProductFromFavorites(itemNumber: string){
        await this.sharedBehavior.clickOnTab(AddProductsToTheCppOrderPage.TabName_Favorite_Products);
        const finalTestId = this.Elements.favItemBtnTestId.replace(this.replaceValue1, itemNumber);
        fixture.logger.info(`started removing the product - ${finalTestId} - from favorites list`);
        await this.pwWrapper.elementAction.clickElementByTestId(finalTestId);
        while(await this.sharedBehavior.isOperationInProgress());
        fixture.logger.info(`completed removing the product - ${finalTestId} - from favorites list`);
    }   
}