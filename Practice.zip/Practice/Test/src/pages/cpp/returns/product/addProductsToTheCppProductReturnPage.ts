import { fixture } from "../../../../hooks/fixture";
import AddProductsToTheCppReturnPage from "../addProductsToTheCppReturnPage";

export default class AddProductsToTheCppProductReturnPage extends AddProductsToTheCppReturnPage {
    Elements = {
        ... this.BaseElements, //coming from AddProductsToTheCppReturnPage
        
        manualProductSelectionDropDownTestId: `ddl-manual-product-item`, 
        manualSelectProductNameFromDropdownTestId: `ddl-manual-product-item-option_${this.replaceValue1}`, //replaceValue1 is item number
        manualUomSelectionDropDownTestId: `ddl-manual-product-uom`, 
        manualSelectProductUomFromDropdownTestId: `ddl-manual-product-uom-option_${this.replaceValue1}`, //replaceValue1 is UOM
        createProductButtonTestId: `btn-create-product`,
        manualCreateProductBtnText: `Create Product`,
        productSelectFromManualCreateResultTestId: `lbl-vendor-name-manual-product_${this.replaceValue1}`, //replaceValue1 is item number  
    };
 
    async selectProductFromManualEntryTab(itemNumber: string, uom: string): Promise<void> {
        fixture.logger.info(`selecting product from the 'Manually Enter Products' tab with item number - ${itemNumber} and uom - ${uom}`);
        while(await this.sharedBehavior.isOperationInProgress());
        
        fixture.logger.info(`clicking on the 'Product' dropdown to select the product`);
        await this.pwWrapper.elementAction.clickElementByTestId(this.Elements.manualProductSelectionDropDownTestId);
        
        let finalTestId = this.Elements.manualSelectProductNameFromDropdownTestId.replace(this.replaceValue1, itemNumber);
        fixture.logger.info(`clicking on the product name dropdown option with test-id - ${finalTestId}`);
        await this.pwWrapper.elementAction.clickElementByTestId(finalTestId);

        await this.pwWrapper.common.delay(500);

        fixture.logger.info(`clicking on the 'UOM' dropdown to select the product`);
        await this.pwWrapper.elementAction.clickElementByTestId(this.Elements.manualUomSelectionDropDownTestId);
        
        finalTestId = this.Elements.manualSelectProductUomFromDropdownTestId.replace(this.replaceValue1, uom);
        fixture.logger.info(`clicking on the dropdown UOM option with test-id - ${finalTestId}`);
        await this.pwWrapper.elementAction.clickElementByTestId(finalTestId);

        if(await this.isCreateProductButtonEnabled()) {
            fixture.logger.info('create product button is enabled, clicking it now');
            await this.clickCreateProductButton();
        }else{
            const errMsg = `create product button is not enabled after selecting product ${itemNumber} and uom ${uom}`;
            fixture.logger.error(errMsg);
            throw new Error(errMsg);
        }

        finalTestId = this.Elements.productSelectFromManualCreateResultTestId.replace(this.replaceValue1, itemNumber);
        await this.pwWrapper.elementAction.clickElementByTestId(finalTestId);
        fixture.logger.info(`completed selecting product from the 'Manually Enter Products' tab with item number - ${itemNumber} and uom - ${uom}`);
    }
    
    async isCreateProductButtonEnabled(): Promise<boolean>{
        fixture.logger.info('checking if create product button is enabled');
        while(await this.sharedBehavior.isOperationInProgress());
        const result = (await this.pwWrapper.pageElement.getElementByTestId(this.Elements.createProductButtonTestId)).isEnabled();
        fixture.logger.info('completed checking create product button enabled status');
        return result;
    }

    async clickCreateProductButton(): Promise<void> {
        fixture.logger.info('about to click create product button');
        await this.pwWrapper.elementAction.waitAndClickButtonByText(this.Elements.manualCreateProductBtnText, true);
        fixture.logger.info('completed clicking create product button');
    }
}