import { fixture } from "../../../../hooks/fixture";
import CppReturnsPage from "../cppReturnsPage";

export default class CppProductReturnsPage extends CppReturnsPage {
    static readonly RETURN_TYPE: string = "Product Returns";

    override get TabName_Active_Return_Requests(): string { return "Active Return Requests"; }
    override get TabName_Return_Request_Drafts(): string { return "Return Request Drafts"; }
    
    async isPageStable(){
        fixture.logger.info('checking for cpp-product-returns-page stability');
        const res = await this.isPageLoaded();
        fixture.logger.info('checking for cpp-product-returns-page stability completed');

        return res;
    }    
}