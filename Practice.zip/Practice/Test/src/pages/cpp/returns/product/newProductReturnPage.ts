import { fixture } from "../../../../hooks/fixture";
import CppNewReturnPage from "../cppNewReturnPage";

const { format } = require('date-fns');

export default class CppNewProductReturnPage extends CppNewReturnPage {
    static readonly RETURN_TYPE: string = "Product Returns";

    Elements = {
        ... super.BaseElements,
    }

    async isPageStable(){
        fixture.logger.info('checking for cpp-new-product-return-page stability');
        const res = await this.isPageLoaded();
        fixture.logger.info('checking for cpp-new-product-return-page stability completed');

        return res;
    }

    async isIPLimitExceededWarningDisplayed(_lineItemNumber: string): Promise<boolean> {
        throw new Error("IP limit exceeded warning check is not applicable and not implemented for Product Returns.");
        // This method is not applicable for Product Returns, as it is specific to Inoculant Returns.
    }

    async isIPLimitExceededErrorDisplayed(_lineItemNumber: string): Promise<boolean> {
        throw new Error("IP limit exceeded error check is not applicable and not implemented for Product Returns.");
        // This method is not applicable for Product Returns, as it is specific to Inoculant Returns.
    }
}