import HtmlRoles from "../../../helpers/wrapper/htmlRoles";
import { fixture } from "../../../hooks/fixture";
import BasePage from "../../basePage";

export default abstract class CppReturnsPage extends BasePage {
    
    readonly replaceData: string = "replace-data";
    abstract get TabName_Active_Return_Requests(): string;
    abstract get TabName_Return_Request_Drafts(): string;

    static readonly Order_Summary_Status_Notice_Txt: string = `Your order has been submitted. You will receive an e-mail confirmation.`;
    static readonly Order_Summary_Status_Notice_Txt_1: string = `Your Order has been submitted and split by product. You will receive an e-mail with the updated order confirmations.`;
    static readonly Order_Summary_Status_Txt: string = `SUBMITTED`;
    
    BaseElements = {
        activeTabNameXPath: `//*[contains(@class, 'mdc-tab-indicator--active')]//*[contains(@class, 'tab-head')]/h4`,
        createNewReturnButtonName: "New Return",
        deleteDraftRequestsTitleAttributeText: `Delete Draft`,
        draftReturnIdOfAccountXPath: `(//td[contains(., '${this.replaceData}')]/preceding-sibling::td//*[contains(@class, 'accNo')])[1]`, //replace with account number
        draftReturnIdOfCustPOXPath: `//td[contains(., '${this.replaceData}')]/preceding-sibling::td//*[contains(@class, 'accNo')]`, //replace with customer PO
        custPOBasedActiveReturnRequestStatusXPath: `//td[contains(.,'${this.replaceData}')]/following-sibling::td//*[contains(@class, 'statusMsg')]`, //replace with Customer PO
        /** xpath to get the active return request return id from the active return request table.
         * This XPath can return multiple elements which can be filtered by the customer PO number if required.
        */
        acNoBasedActiveReturnRequestReturnIdXPath: `//td[normalize-space(text())='${this.replaceData}']/preceding-sibling::td//*[contains(@class, 'accNo')]`, //replace with account number

        custPOBasedDraftReturnRequestReturnIdXPath: `//td[normalize-space(text())='${this.replaceData}']/preceding-sibling::td//*[contains(@class, 'accNo')]`, //replace with customer PO

        /**
         * replaceData should be account number.
         * This XPath can return multiple elements.
        */
        deleteDraftReturnRequestBtnXPath: `//td[normalize-space(text())='${this.replaceData}']/following-sibling::td//*[contains(@title, 'Delete Draft')]//i[contains(@class, 'fa-trash')]`
        
    }

    protected async isPageLoaded(): Promise<boolean>{
        await super.waitUntilButtonIsDisplayed(this.BaseElements.createNewReturnButtonName);
        return true;
    }
   
    async clickCreateNewReturn(){
        await this.switchToTab(this.TabName_Active_Return_Requests);
        await this.pwWrapper.elementAction.clickElementByRole(HtmlRoles.BUTTON, this.BaseElements.createNewReturnButtonName);
        while(await this.sharedBehavior.isOperationInProgress());
    }
    
    async switchToTab(tabNameToSwitch: string) {
        await this.sharedBehavior.clickOnTab(tabNameToSwitch, true, 
            true //tab contains two parts, first part is the tab name (<h4>) and second part is the tab title (<p>)
        );
    }

    async getCurrentActiveTabName(): Promise<string>{
        return await this.pwWrapper.dataReader.getElementTextByXPath(this.BaseElements.activeTabNameXPath, false);
    }

    async getReturnIdByCustomerPO(customerPO: string): Promise<string>{
        const finalXPath = this.BaseElements.draftReturnIdOfCustPOXPath.replace(this.replaceData, customerPO);
        return await this.pwWrapper.dataReader.getElementTextByXPath(finalXPath, false);
    }

    async getExistingDraftRequestsCount(accountNumber: string): Promise<number>{
        fixture.logger.info(`checking existing draft requests count for ${accountNumber}`);
        //const count = await this.pwWrapper.pageElement.getAvailableElementCountByTitle(this.BaseElements.deleteDraftRequestsTitleAttributeText);
        const count = await this.pwWrapper.pageElement.getAvailableElementCount(
            this.BaseElements.deleteDraftReturnRequestBtnXPath.replace(this.replaceData, accountNumber)
        );
        fixture.logger.info(`completed checking existing draft requests count for ${accountNumber}`);
        return count;
    }

    /**
     * Deletes the existing draft requests for the given account number.
     * @assumption This method assumes that current UI has draft requests only for the given account number.
     * @param accountNumber 
     * @param existingOrdersCount 
     */
    async deleteAccountDraftRequests(accountNumber: string, existingOrdersCount: number) {
        fixture.logger.info(`deleting existing draft return requests for ${accountNumber}`);
        for (let i = existingOrdersCount - 1; i >= 0; i--) {
            //click delete
            //await this.pwWrapper.elementAction.clickIndexedElementByTitle(i, this.BaseElements.deleteDraftRequestsTitleAttributeText);
            await this.pwWrapper.elementAction.clickIndexedElement(i,
                this.BaseElements.deleteDraftReturnRequestBtnXPath.replace(this.replaceData, accountNumber)
            );

            //click YES on the confirmation window
            await this.sharedBehavior.clickOnConfirmationButton();
        }
        fixture.logger.info(`completed deleting existing draft return requests for ${accountNumber}`);
    }
    
}