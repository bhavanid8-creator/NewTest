import HtmlRoles from "../../../helpers/wrapper/htmlRoles";
import BasePage from "../../basePage";

export default class CppSubmittedReturnSummaryPage extends BasePage {
    async isPageStable(): Promise<boolean> {
        return await this.isPageLoaded();
    }
    
    readonly replaceData: string = "replace-data";
    
    Elements = {
        backToReturnListBtnText: 'Back To Return List',
    }

    async isPageLoaded(): Promise<boolean>{
        await super.waitUntilButtonIsDisplayed(this.Elements.backToReturnListBtnText);
        return true;
    }
   
    async clickBackToReturnList(){
        await this.pwWrapper.elementAction.clickElementByRole(HtmlRoles.BUTTON, this.Elements.backToReturnListBtnText);
        while(await this.sharedBehavior.isOperationInProgress());
    } 
}