import { fixture } from "../../../../hooks/fixture";
import CppNewReturnPage from "../cppNewReturnPage";

const { format } = require('date-fns');

export default class CppNewInoculantReturnPage extends CppNewReturnPage {
    static readonly RETURN_TYPE: string = "Inoculant Returns";

    Elements = {
        ... super.BaseElements,
        lineItemWarningXPath: `//div[@id='warning_${this.replaceValue1}_']//li`, // replaceValue1 is line item number
        inventoryProtectionPercentExceededWarningTxt: `Requested Units exceed allotted inventory protection percent, WinField United Approval will be required`,
        lineItemErrorXPath: `//div[@id='error_${this.replaceValue1}_']//li`, // replaceValue1 is line item number
        inventoryProtectionPercentExceededErrorTxt: `Return Quantity Can not Exceed Invoiced Quantity.`,
    }

    async isPageStable(){
        fixture.logger.info('checking for cpp-new-inoculant-return-page stability');
        const res = await this.isPageLoaded();
        fixture.logger.info('checking for cpp-new-inoculant-return-page stability completed');

        return res;
    }

    async isIPLimitExceededWarningDisplayed(lineItemNumber: string): Promise<boolean> {
        return await this.isIPLimitExceededWarningOrErrorDisplayed(lineItemNumber, true);
    }

    async isIPLimitExceededErrorDisplayed(lineItemNumber: string): Promise<boolean> {
        return await this.isIPLimitExceededWarningOrErrorDisplayed(lineItemNumber, false);
    }

    private async isIPLimitExceededWarningOrErrorDisplayed(lineItemNumber: string, isWarningCheck: boolean): Promise<boolean> {
        fixture.logger.info(`checking if inventory protection percent exceeded warning is displayed for line item ${lineItemNumber}`);
        let warningOrErrorXPath = this.Elements.lineItemWarningXPath.replace(this.replaceValue1, lineItemNumber);
        let warningOrErrorText = this.Elements.inventoryProtectionPercentExceededWarningTxt;
        let errMsg = `inventory protection percent exceeded warning for line item ${lineItemNumber} is NOT displayed`;

        if(!isWarningCheck){
            warningOrErrorXPath = this.Elements.lineItemErrorXPath.replace(this.replaceValue1, lineItemNumber);
            warningOrErrorText = this.Elements.inventoryProtectionPercentExceededErrorTxt;
            errMsg = `inventory protection percent exceeded error for line item ${lineItemNumber} is NOT displayed`;
        }

        fixture.logger.info("warningOrErrorXPath is.." + warningOrErrorXPath);
        await this.pwWrapper.common.delay(3000); // wait for the warning or error to be displayed

        const elementCount = await this.pwWrapper.pageElement.getAvailableElementCount(warningOrErrorXPath);
        
        if( elementCount === 0) {
            fixture.logger.error(errMsg);
            return false;
        }
        const displayedWarning = await this.pwWrapper.dataReader.getElementTextByXPath(warningOrErrorXPath, false);
        let logMsg = `displayed inventory protection percent exceeded warning for line item ${lineItemNumber} is: ${displayedWarning}`;
        if(!isWarningCheck) {
            logMsg = `displayed inventory protection percent exceeded error for line item ${lineItemNumber} is: ${displayedWarning}`;
        }
        fixture.logger.info(logMsg);
        if(!displayedWarning.includes(warningOrErrorText)) {
            fixture.logger.error(errMsg);
            return false;
        }
        let logMsgSuccess = `inventory protection percent exceeded warning for line item ${lineItemNumber} is displayed successfully`;
        if(!isWarningCheck) {
            logMsgSuccess = `inventory protection percent exceeded error for line item ${lineItemNumber} is displayed successfully`;
        }
        fixture.logger.info(isWarningCheck);
        return true;
    }
}