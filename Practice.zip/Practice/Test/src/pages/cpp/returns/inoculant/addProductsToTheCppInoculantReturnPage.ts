import { fixture } from "../../../../hooks/fixture";
import AddProductsToTheCppReturnPage from "../addProductsToTheCppReturnPage";

export default class AddProductsToTheCppInoculantReturnPage extends AddProductsToTheCppReturnPage {
    Elements = {
        ... this.BaseElements, //coming from AddProductsToTheCppReturnPage
        
        manualProductSelectionDropDownTestId: `ddl-manual-product-item`, 
        manualSelectProductNameFromDropdownTestId: `ddl-manual-product-item-option_${this.replaceValue1}`, //replaceValue1 is item number
        manualUomSelectionDropDownTestId: `ddl-manual-product-uom`, 
        manualSelectProductUomFromDropdownTestId: `ddl-manual-product-uom-option_${this.replaceValue1}`, //replaceValue1 is UOM
        createProductButtonTestId: `btn-create-product`,
        manualCreateProductBtnText: `Create Product`,
        productSelectFromManualCreateResultTestId: `lbl-vendor-name-manual-product_${this.replaceValue1}`, //replaceValue1 is item number  
    };
}