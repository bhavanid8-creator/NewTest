import { fixture } from "../../../../hooks/fixture";
import CppReturnsPage from "../cppReturnsPage";

export default class CppInoculantReturnsPage extends CppReturnsPage {
    static readonly RETURN_TYPE: string = "Inoculant Returns";

    override get TabName_Active_Return_Requests(): string { return "Active Return Requests"; }
    override get TabName_Return_Request_Drafts(): string { return "Return Request Drafts"; }
    
    async isPageStable(){
        fixture.logger.info('checking for cpp-inoculant-returns-page stability');
        const res = await this.isPageLoaded();
        fixture.logger.info('checking for cpp-inoculant-returns-page stability completed');

        return res;
    }    
}