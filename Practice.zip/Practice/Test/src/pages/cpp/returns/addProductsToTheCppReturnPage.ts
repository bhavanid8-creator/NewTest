import { Locator } from "playwright";
import KeyBoardItems from "../../../helpers/wrapper/keyBoardItems";
import { fixture } from "../../../hooks/fixture";
import BasePage from "../../basePage";
import HtmlRoles from "../../../helpers/wrapper/htmlRoles";

export default class AddProductsToTheCppReturnPage extends BasePage {
    
    readonly replaceValue1 = 'replace-value-1';
    readonly replaceValue2 = 'replace-value-2';
    readonly replaceValue3 = 'replace-value-3';
    readonly product_search_category_product_name = 'Product Name';
    readonly replaceProductNameInSearchResult = 'product-name';
    static readonly PRODUCT_SEARCH_FILTER_OPTION_ItemNumber: 'Item Number';
    static readonly YOUR_ACCOUNT_INVOICED_PRODUCTS_TAB_INDEX = 1;
    static readonly PARENT_COMPANY_INVOICED_PRODUCTS_TAB_INDEX = 2;
    static readonly MANUALLY_ENTER_PRODUCTS_TAB_INDEX = 3;

    /*get TabName_Own_Account(): string {return "Your Account Invoiced Products"};
    get TabName_Parent_Account(): string {return "Parent Company Invoiced Products"};
    get TabName_Manual_Add(): string {return "Manually Enter Products"};*/

    protected currentTabName: string = '';

    BaseElements = {
        yourAccountInvoicedProductsHeadingTxt: 'Your Account Invoiced Products',
        parentAccountInvoicedProductsHeadingTxt: 'Parent Company Invoiced Products',
        exportBtnTestId: 'btn-export',
        productSearchFilterDropDownTestId: "ddl-cpp-return-search",
        productSearchFilterItemNumberCategoryTestId: "ddl-filter-select_itemNumber", 
        searchProductByItemNumberTestId: "ddl-itemnumber-search",
        searchBtnTestId: "ddl-product-search",
        //productNameInSearchResultTestId: `lbl-all-tab-item_${this.replaceValue1}`,
        productSelectFromParentSearchResultTestId: `lbl-vendor-name-parent-account_${this.replaceValue1}`, //replaceValue1 is item number
        productSelectFromOwnSearchResultTestId: `lbl-vendor-name-account_${this.replaceValue1}`, //replaceValue1 is item number
        //searchResultItemCheckboxTestId: `chk-all-product_${this.replaceValue1}`,
        addToRequestButtonTestId: "btn-addtoreturn",
        addToRequestButtonName: 'Add To Request',
        clearAllLinkText: "Clear All",//clears search text and search results; retains selected search filters
        
        // applicable to PRODUCT RETURNS only
        manuallyEnterProductHeadingTxt: `Manually Enter Products`,
        showNonReturnableProductsOwnAccountCheckBoxTestId: `chk-non-return-product-account`,
        showNonReturnableProductsParentAccountCheckBoxTestId: `chk-non-return-product-parent-account`,
        
    }

    /*eslint @typescript-eslint/require-await: "off" */
    async canNavigateWithUrl(): Promise<boolean>{
        return false;
    }
    
    private async isPageLoaded(): Promise<boolean>{
        let retryCount = 5;
        let result = false;
        await this.pwWrapper.common.delay(1000);//initial delay because spinner takes sometime to show up
        while(retryCount > 0)
        {
            while (await this.sharedBehavior.isOperationInProgress());
            result = await this.pwWrapper.elementAction.canClickItemByTestId(this.BaseElements.exportBtnTestId);
            if(result)
                break;
            --retryCount;
        }
        return result;
    }

    async isPageStable(){
        fixture.logger.info('checking for add-products-to-the-return-page stability');
        const result = await this.isPageLoaded();
        fixture.logger.info('checking for add-products-to-the-return-page stability completed');
        if(!result)
            fixture.logger.error('add-products-to-the-return-page stability check failed');
        return result;
    }

    /**
     * 
     * @param tabIndex - 1 for Your Account Invoiced Products, 2 for Parent Company Invoiced Products, 3 for Manually Enter Products
     * @throws Error if tabIndex is not supported
     */
    async clickProductSelectionTab(tabIndex: number): Promise<void> {
        let tabName = this.getProductSelectionTabName(tabIndex)
        while(await this.sharedBehavior.isOperationInProgress());
        fixture.logger.info(`products will be searched and selected from '${tabName}' tab`);
        await this.pwWrapper.elementAction.clickElementByRole(HtmlRoles.HEADING, tabName);
        this.currentTabName = tabName;
        while(await this.sharedBehavior.isOperationInProgress());

        fixture.logger.info(`completed clicking on the '${tabName}' tab`);
    }

    getProductSelectionTabName(tabIndex: number): string {
        let tabName = '';
        switch(tabIndex) {
            case AddProductsToTheCppReturnPage.YOUR_ACCOUNT_INVOICED_PRODUCTS_TAB_INDEX:
                tabName = this.BaseElements.yourAccountInvoicedProductsHeadingTxt;
                break;
            case AddProductsToTheCppReturnPage.PARENT_COMPANY_INVOICED_PRODUCTS_TAB_INDEX:
                tabName = this.BaseElements.parentAccountInvoicedProductsHeadingTxt;
                break;
            case AddProductsToTheCppReturnPage.MANUALLY_ENTER_PRODUCTS_TAB_INDEX:
                tabName = this.BaseElements.manuallyEnterProductHeadingTxt;
                break;
            default:
                fixture.logger.error(`tab index ${tabIndex} is not supported`);
                throw new Error(`tab index ${tabIndex} is not supported`);
        }
        return tabName;
    }

    async clickSearchFilterDropDown(){
        await this.pwWrapper.elementAction.clickElementByTestId(this.BaseElements.productSearchFilterDropDownTestId);
    }

    private selectedProductFilterOption = '';
    async selectSearchFilterItemInTheDropDown(filterOption: string){
        if(filterOption == AddProductsToTheCppReturnPage.PRODUCT_SEARCH_FILTER_OPTION_ItemNumber)
            await this.pwWrapper.elementAction.clickElementByTestId(this.BaseElements.productSearchFilterItemNumberCategoryTestId);
        else{
            fixture.logger.error(`unsupported filter option - ${filterOption}`);
            throw new Error(`${filterOption} is not supported`);
        }
        this.selectedProductFilterOption = filterOption;
        await this.pwWrapper.common.delay(500);
        while(await this.sharedBehavior.isOperationInProgress());
    }

    async searchProduct(searchItems: string[]): Promise<boolean>{
        let searchTextBox: Locator;
        let isSearchByFreeText: boolean = false; //search by item number is not searching with free text so we set this as FALSE by default
        
        fixture.logger.info(`about to get product search box`);
        if(this.selectedProductFilterOption == AddProductsToTheCppReturnPage.PRODUCT_SEARCH_FILTER_OPTION_ItemNumber)
            searchTextBox = await this.pwWrapper.pageElement.getElementByTestId(this.BaseElements.searchProductByItemNumberTestId);

        fixture.logger.info(`about to click product search box`);
        await searchTextBox.click({ force: true });
        if (!isSearchByFreeText) {
            fixture.logger.info(`about to select the option from the product search box`);
            try{
                for(let i=0; i<searchItems.length; i++){
                    await this.pwWrapper.dataWriter.enterDataIntoChildInputAndPressaKey(searchTextBox, searchItems[i], KeyBoardItems.ENTER);
                }
            }catch(err){
                fixture.logger.error('failed...' + err);
            }
        } else {
            await searchTextBox.fill(searchItems[0]);
        }
        const searchBtnEnabled = await this.pwWrapper.elementAction.canClickItemByTestId(this.BaseElements.searchBtnTestId);
        if(!searchBtnEnabled){
            const errMsg = 'Search button is not enabled. Check search input which might be invalid';
            fixture.logger.error(errMsg);
            throw new Error(errMsg);
        }
        await this.pwWrapper.elementAction.clickElementByTestId(this.BaseElements.searchBtnTestId);

        while(await this.sharedBehavior.isOperationInProgress());
        fixture.logger.info('completed searching for the product');
        return true;
    }

    async clearProductSearchResults(){
        await (await this.pwWrapper.pageElement.getVisibleElementByLinkName(this.BaseElements.clearAllLinkText)).click();
    }

    async selectProductsFromOwnOrParentAccountTabByItemNumber(itemNumbersToSelect: string[], searchAsNonReturningProduct: boolean = false): Promise<void> {
        while(await this.sharedBehavior.isOperationInProgress());
        let searchResultCount = 0;
        for(let index=0; index<itemNumbersToSelect.length; index++){ 
            const itemNumber = itemNumbersToSelect[index];
            let finalTestId = this.BaseElements.productSelectFromOwnSearchResultTestId.replace(this.replaceValue1, itemNumber);
            if(this.currentTabName == this.BaseElements.parentAccountInvoicedProductsHeadingTxt){
                finalTestId = this.BaseElements.productSelectFromParentSearchResultTestId.replace(this.replaceValue1, itemNumber);
            }
            fixture.logger.info(`product selection checkbox test-id is - ${finalTestId}`);
            searchResultCount = await this.pwWrapper.pageElement.getAvailableElementCountByTestId(finalTestId);
            if (searchResultCount == 0) {
                if (searchAsNonReturningProduct) {
                    fixture.logger.info(`searching for the product ${itemNumber} in Non-Returnable Products section`);
                    if(this.currentTabName == this.BaseElements.parentAccountInvoicedProductsHeadingTxt){
                        fixture.logger.info(`clicking on the 'Show Non-Returnable Products' checkbox for the Parent Account tab`);
                        await this.pwWrapper.elementAction.clickElementByTestId(this.BaseElements.showNonReturnableProductsParentAccountCheckBoxTestId);
                    } else {
                        fixture.logger.info(`clicking on the 'Show Non-Returnable Products' checkbox for the Own Account tab`);
                        await this.pwWrapper.elementAction.clickElementByTestId(this.BaseElements.showNonReturnableProductsOwnAccountCheckBoxTestId);
                    }
                    searchResultCount = await this.pwWrapper.pageElement.getAvailableElementCountByTestId(finalTestId);
                }
                if (searchResultCount == 0) {
                    let errMsg = `could not find the product corresponding to ${itemNumber}`;
                    fixture.logger.error(errMsg);
                    throw new Error(errMsg);
                }
            }
            await this.pwWrapper.elementAction.clickElementByTestId(finalTestId);
            fixture.logger.info(`selected product is - ${itemNumber}`);
        }
        
    }

    async isAddToRequestButtonEnabled(): Promise<boolean>{
        while(await this.sharedBehavior.isOperationInProgress());
        return (await this.pwWrapper.pageElement.getElementByTestId(this.BaseElements.addToRequestButtonTestId)).isEnabled();
    }

    async clickAddToRequestButton(): Promise<string> {
        while(await this.sharedBehavior.isOperationInProgress());
        const msg = await this.sharedBehavior.clickButtonAndInspectSuccessMessage("adding product(s) to the request",this.BaseElements.addToRequestButtonName);
        if(msg !== null && msg !== "" && msg.length > 0)
            fixture.logger.info(`product addition to the request message is - ${msg}`);
        while(await this.sharedBehavior.isOperationInProgress());
        return msg;
    }
}