import { fi } from "date-fns/locale";
import DateHelper from "../../../helpers/types/dateHelper";
import HtmlRoles from "../../../helpers/wrapper/htmlRoles";
import { fixture } from "../../../hooks/fixture";
import BasePage from "../../basePage";
import DataBagKeys from "../../../tests/steps/dataBagKeys";

export default abstract class CppNewReturnPage extends BasePage {
    readonly replaceValue1 = 'replace-value-1';
    static readonly RETURNING_PRODUCT_TYPE_ACCOUNT_RETURNABLE = 'AccountReturnable';
    static readonly RETURNING_PRODUCT_TYPE_ACCOUNT_NON_RETURNABLE = 'AccountNonReturnable';
    static readonly RETURNING_PRODUCT_TYPE_PARENT_ACCOUNT_RETURNABLE = 'ParentAccountReturnable';
    static readonly RETURNING_PRODUCT_TYPE_PARENT_ACCOUNT_NON_RETURNABLE = 'ParentAccountNonReturnable';
    static readonly RETURNING_PRODUCT_TYPE_MANUAL_RETURNABLE = 'ManualReturnable';

    get BaseElements() {
        return {
            draftRequestSavedMsgTxt: `CPP return request saved successfully.`,
            shipToDropdownText: 'Ship To:',
            existingDraftReturnOpenConfirmationXPath: `//button[contains(., '${this.replaceValue1}')]`,
            soldToDropdownText: 'Sold To: (Will Display after selection of Ship To):',
            soldToNumberXPath: `//*[contains(@data-testid,'ddl-sold-to')]//*[normalize-space(text())='Account To #: ${this.replaceValue1}']`, //replace with account number
            shippingInstructionsTextAreaTestId: `ddl-shipping-instructions`,
            customerPoTxtBoxTestID: 'txt-customerpo',
            differentPickupLocationCheckboxTestId: `ddl-deliverto-checkbox-return`,
            contactNameTestId: `txt-contact-name`,
            contactPhoneNumberTestId: `txt-contact-number`,
            driverAssistanceRequiredBtnTestId: `ddl-freightins-option_0`,
            palletJackRequiredBtnTestId: `ddl-freightins-option_1`,

            /**
             * Applicable only for Product and Inoculant Returns but not for Container Returns
             */
            pickupLocationDropdownText: 'Pickup Location:',
            palletCountTextBoxTestId: `ddl-pallet-count`,
            addProductBtnText: 'Add Product',

            productAddedToastMsgXPath: `//*[contains(@role,'alert') and contains(., 'Product Added')]`, //multiple xpath clauses
            noDataFoundMsgXPath: `//div[text()='No items found']`,
            lineItemQtyDecreaseTestId: `btn-specific-minus_${this.replaceValue1}`, //replace with item number
            lineItemQtyIncreaseTestId: `btn-specific-plus_${this.replaceValue1}`, //replace with item number
            lineItemQtyTxtBoxTestId: `txt-specific-qty_${this.replaceValue1}`, //replace with item number
            lineItemCustomerNotesTxtBoxTestId: `txt-custnotes_${this.replaceValue1}`, //replace with item number
            desiredPickupDateTestId: `txt-pickup-date`,
            chooseMonthAndYearBtnAriaLabel: `Choose month and year`,
            saveDraftBtnText: `Save Draft`,
            reviewRequestBtnText: `Review Request`,
            orderQtyInThePlacedOrderTestId: `lbl-order-quantity_${this.replaceValue1}`, //replace with item number
            orderQtyInThePlacedOrderXPath: `//*[contains(@data-testid, 'lbl-order-quantity_${this.replaceValue1}')]`, //replace with item number
            customerPORequiredErrorMsgXPath: `//div[contains(., 'Customer PO is required for selected account')]`,

            reviewRequestMessage: "CPP return request saved successfully.",
            submitRequestMessage: "Return Request submitted successfully.",
            backToReturnRequestBtnText: "Back To Request",
            submitToReturnBtnText: 'Submit Return',
        }
    }

    abstract isIPLimitExceededWarningDisplayed(lineItemNumber: string): Promise<boolean>;

    abstract isIPLimitExceededErrorDisplayed(lineItemNumber: string): Promise<boolean>;

    protected async isPageLoaded(): Promise<boolean>{
        while(await this.sharedBehavior.isOperationInProgress());
        return true;
    }

    async selectShipTo(accountNumber: string){
        await this.setShipToAccountData(accountNumber, false, true);
    }

    async selectShipToOfExistingOrder(accountNumber: string, createNewCppReturn: boolean){
        await this.setShipToAccountData(accountNumber, true, createNewCppReturn);
    }

    private async setShipToAccountData(accountNumber: string, shouldManageExistingRequest: boolean, createNewCppReturn: boolean){
        if(shouldManageExistingRequest)
            fixture.logger.info(`selecting 'Ship To' for ${accountNumber} with existing return`);
        else
            fixture.logger.info(`selecting 'Ship To' for ${accountNumber}`);

        accountNumber = accountNumber.trim();
        await this.sharedBehavior.selectAngularDropdownOptionByPlaceholder(this.BaseElements.shipToDropdownText, accountNumber, this.BaseElements.noDataFoundMsgXPath);
        if(shouldManageExistingRequest)
            await this.manageExistingReturn(accountNumber, createNewCppReturn);

        while (await this.sharedBehavior.isOperationInProgress());
        
        if(shouldManageExistingRequest)
            fixture.logger.info(`selected 'Ship To' for ${accountNumber} with existing request`);
        else
            fixture.logger.info(`selected 'Ship To' for ${accountNumber}`);
    }

    private async manageExistingReturn(accountNumber: string, createNewCppReturn: boolean){
        let path = this.BaseElements.existingDraftReturnOpenConfirmationXPath.replace(this.replaceValue1, 'Yes');
        const count = await this.pwWrapper.pageElement.getAvailableElementCount(path);
        if(count == 0)
        {
            const errMsg = `${accountNumber} does not have an existing return`;
            fixture.logger.error(errMsg);
            throw new Error(errMsg);
        }
 
        if(createNewCppReturn){
            path = this.BaseElements.existingDraftReturnOpenConfirmationXPath.replace(this.replaceValue1, 'No');
            fixture.logger.info(`new return will be created for ${accountNumber}`);
        }else{
            fixture.logger.info(`existing return will be opened for ${accountNumber}`);
        }

        await this.pwWrapper.elementAction.clickElement(path);
    }

    async getSoldToName(soldToAccountNumber: string): Promise<string> {
        const finalXPath = this.BaseElements.soldToNumberXPath.replace(this.replaceValue1, soldToAccountNumber);
        fixture.logger.info(`getting Sold To name for account number ${finalXPath}`);
        return await this.pwWrapper.dataReader.getElementTextByXPath(finalXPath, false);
    }

    async selectPickupLocation(accountNumber: string){
        fixture.logger.info(`selecting 'Pickup Location' account ${accountNumber}`);

        accountNumber = accountNumber.trim();
        await this.sharedBehavior.selectAngularDropdownOptionByPlaceholder(this.BaseElements.pickupLocationDropdownText, accountNumber, this.BaseElements.noDataFoundMsgXPath);

        while (await this.sharedBehavior.isOperationInProgress());

        fixture.logger.info(`selected 'Pickup Location' account ${accountNumber}`);
    }

    async fillReturnHeaderDetails(fillPalletCountDetails: boolean, isPickupLocationDifferentFromShipTo: boolean = false, fillCustomerPO: boolean = true, pickupDate?: Date, pickupFromAccount: string = ""): Promise<string> {
        fixture.logger.info('entering new return details started');
        //desired pickup date
        if(pickupDate !== undefined && pickupDate !== null)
        {
            await this.sharedBehavior.fillDeliveryOrPickupDate(-1, pickupDate.toString());
        }

        //contact name
        await this.pwWrapper.dataWriter.enterValueIntoTextboxByTestId(this.BaseElements.contactNameTestId,"QA-automation");
        fixture.logger.info('entered contact name');

        //contact number
        await this.pwWrapper.dataWriter.enterValueIntoTextboxByTestId(this.BaseElements.contactPhoneNumberTestId,"1234567890", true);
        fixture.logger.info('entered contact number');
        
        //customer po
        let customerPO = "";
        await this.clearCustomerPO();
        if(fillCustomerPO)
            customerPO = await this.setCustomerPO();
        else{
            fixture.logger.info('customer PO will not be filled');
        }

        //pickup location checkbox
        if (isPickupLocationDifferentFromShipTo) {
            await this.pwWrapper.elementAction.clickElementByTestId(this.BaseElements.differentPickupLocationCheckboxTestId);
            fixture.logger.info('set customer pickup location checkbox');
        }

        //pickup location account selection
        // If pickupFromAccount is not provided, setting the above checkbox state will not have any effect
        const usePickupFromAccount = fixture.dataBag.getData(DataBagKeys.USE_PICKUP_LOCATION) as boolean;
        if( usePickupFromAccount && pickupFromAccount && pickupFromAccount.trim().length > 0){
            await this.selectPickupLocation(pickupFromAccount);
        }

        //shipping instructions
        await this.pwWrapper.dataWriter.enterValueIntoTextboxByTestId(this.BaseElements.shippingInstructionsTextAreaTestId,"QA automation testing CPP product return shipping instructions on " + DateHelper.getDateTimeUTC());
        fixture.logger.info('entered shipping instructions');
        
        //NOTE: UI SOMETIMES IS NOT DISPLAYING THESE OPTIONS
        //driver assistance required
        await this.pwWrapper.elementAction.clickElementByTestId(this.BaseElements.driverAssistanceRequiredBtnTestId);
        fixture.logger.info('set driver assistance required');

        //pallet jack required
        await this.pwWrapper.elementAction.clickElementByTestId(this.BaseElements.palletJackRequiredBtnTestId);
        fixture.logger.info('set pallet jack required');
        
        //pallet count
        if (fillPalletCountDetails) {
            await this.pwWrapper.dataWriter.enterValueIntoTextboxByTestId(this.BaseElements.palletCountTextBoxTestId, "1", true);
            fixture.logger.info('entered pallet count');
        }
        fixture.logger.info('entering new return details completed');
        return customerPO;
    }

    async setCustomerPO(clearExistingDetails: boolean = false){
        let customerPO = "";
        if(clearExistingDetails){
            await this.clearCustomerPO();
            customerPO = ("qa-auto-" + DateHelper.getUniqueNumberBasedOnDate()).substring(0,25); //UI allows only 25 characters
        }
        else
        {
            customerPO = ("qa-auto-" + DateHelper.getUniqueNumberBasedOnDate()).substring(0,25); //UI allows only 25 characters
        }
        
        await this.pwWrapper.dataWriter.enterValueIntoTextboxByTestId(this.BaseElements.customerPoTxtBoxTestID, customerPO, true);
        fixture.logger.info('entered customer po');
        return customerPO;
    }

    async clearCustomerPO(){
        await this.pwWrapper.dataWriter.enterValueIntoTextboxByTestId(this.BaseElements.customerPoTxtBoxTestID, "", false);
        fixture.logger.info('cleared existing customer PO');
    }

    async clickAddProducts(){
        await this.pwWrapper.elementAction.waitAndClickButtonByRole(this.BaseElements.addProductBtnText);
        while(await this.sharedBehavior.isOperationInProgress());
    }
    
    async dismissProductAddedToastMsg(){
        const count = await this.pwWrapper.pageElement.getAvailableElementCount(this.BaseElements.productAddedToastMsgXPath);
        if(count > 0){
            try{
                await this.pwWrapper.elementAction.clickElement(this.BaseElements.productAddedToastMsgXPath);
            }catch(err){
                //ignore error and proceed
            }
        }
    }

    async incrementOrDecrementLineItemQty(itemNumber: string, shouldIncrement: boolean){
        let testId = shouldIncrement ? this.BaseElements.lineItemQtyIncreaseTestId.replace(this.replaceValue1, itemNumber) :
            this.BaseElements.lineItemQtyDecreaseTestId.replace(this.replaceValue1, itemNumber);
        await this.pwWrapper.elementAction.clickElementByTestId(testId);
    }

    async modifyLineItemQty(itemNumber: string, qty: string){
        let testId = this.BaseElements.lineItemQtyTxtBoxTestId.replace(this.replaceValue1, itemNumber);
        await this.pwWrapper.dataWriter.enterValueIntoTextboxByTestId(testId, qty);
        await this.pwWrapper.common.delay(1500); //wait for the UI to update
        fixture.logger.info(`completed entering quantity ${qty} for the line item with itemNumber ${itemNumber}`);
    }

    async setLineItemCustomerNotes(itemNumber: string){
        let testId = this.BaseElements.lineItemCustomerNotesTxtBoxTestId.replace(this.replaceValue1, itemNumber);
        const customerNotes = `QA automation testing CPP product return customer notes on ${DateHelper.getDateTimeUTC()} for item ${itemNumber}`;
        await this.pwWrapper.dataWriter.enterValueIntoTextboxByTestId(testId, customerNotes);
        fixture.logger.info(`completed entering customer notes for the line item with itemNumber ${itemNumber}`);
    }

    async clickSaveDraft(){
        fixture.logger.info(`starting Save Draft return operation`);
        const msg = await this.saveDraftOrReviewRequestOrSubmitReturn(this.BaseElements.saveDraftBtnText, this.BaseElements.saveDraftBtnText);
        if(msg !== null && msg !== "" && msg.length > 0)
            fixture.logger.info(`save-draft-order operation message is - ${msg}`);
        fixture.logger.info(`completed Save Draft return operation`);
        return msg;
    }

    async canClickSaveDraft(){
        return await this.pwWrapper.pageElement.isElementByRoleEnabled(HtmlRoles.BUTTON, this.BaseElements.saveDraftBtnText);
    }

    async clickReviewRequest(){
        fixture.logger.info(`starting Review Request operation`);
        const msg = await this.saveDraftOrReviewRequestOrSubmitReturn(this.BaseElements.reviewRequestBtnText, this.BaseElements.reviewRequestBtnText);
        if(msg !== null && msg !== "" && msg.length > 0)
            fixture.logger.info(`review-request operation message is - ${msg}`);
        fixture.logger.info(`completed Review Request operation`);
        return msg;
    }

    async clickSubmitReturn(){
        fixture.logger.info(`starting Submit Return operation`);
        const msg = await this.saveDraftOrReviewRequestOrSubmitReturn(this.BaseElements.submitToReturnBtnText, this.BaseElements.submitToReturnBtnText);
        if(msg !== null && msg !== "" && msg.length > 0)
            fixture.logger.info(`submit-return operation message is - ${msg}`);
        fixture.logger.info(`completed Submit Return operation`);
        return msg;
    }

    private async saveDraftOrReviewRequestOrSubmitReturn(operationMsg: string, btnName: string){
        const msg = await this.sharedBehavior.clickButtonAndInspectSuccessMessageIndependentlyForOrderUpdate(operationMsg, btnName);
        fixture.logger.info(`msg received is---${msg}`);
        while(await this.sharedBehavior.isOperationInProgress());
        return msg;
    }
}