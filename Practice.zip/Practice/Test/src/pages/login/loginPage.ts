import ApiManager from "../../helpers/util/api/apiManager";
import AuthHeaders from "../../helpers/util/api/authHeaders";
import ProductAvailabilityRequest from "../../helpers/util/api/models/requests/productAvailabilityRequest";
import HtmlRoles from "../../helpers/wrapper/htmlRoles";
import { fixture } from "../../hooks/fixture";
import DataBagKeys from "../../tests/steps/dataBagKeys";
import BasePage from "../basePage";

export default class LoginPage extends BasePage {

    Elements = {
        url: process.env.BASEURL,
        authorization_url: process.env.AUTHORIZATION_URL,
        //landingPageUri: "oti/landing-data",
        landingPageUri: "cc/landing-data",
        userNameInput: "Username",
        passwordInput: "Password",
        loginBtnXPath: "//button[@class='loginButton' and contains(text(),'Sign In')]",
        loginBtn: 'Sign In',
        errorMessage: "alert",
        loggedInUser: "//span[contains(@class,'userName')]",
        failedLoginErr: "div.invalidLoginMsg",
        emulatedUser: "//div[contains(@class,'emulatedUserBox')]",
        searchBtnTxtOnLandingPage: 'Search',
        logoutBtnTxt: 'Logout',
    }

    async isPageStable(): Promise<boolean> {
        return true;
    }
    async navigateToLoginPage_obsolete() {
        fixture.logger.info(`navigating to login page`);
        fixture.page.on('console', msg => fixture.logger.info('PAGE LOG:', msg.text()));
        fixture.page.on('pageerror', error => fixture.logger.error('PAGE ERROR:', error));

        await Promise.all([
            this.pwWrapper.goto(this.Elements.url, 50000),
            //this.page.waitForURL(this.Elements.authorization_url), //NOTE: this will throw error because the actual URL also will have query parameters; however waiting for this URL will delay below operation giving more chances to succeed
            //super.waitUntilButtonIsDisplayed(this.Elements.loginBtn, false, 30)
        ]
        );
        // IT IS OBSERVED THAT NAVIGATION PAGE IS LOADING BLANK SOMETIMES SO WE REFRESH THE PAGE TO ENSURE IT IS LOADING PROPERLY
        await this.pwWrapper.common.delay(10000);
        await this.pwWrapper.refreshCurrentPage(30000, 1000);
        await super.waitUntilButtonIsDisplayed(this.Elements.loginBtn, false, 30)
        fixture.logger.info(`login page navigation completed`);
    }

    async navigateToAppLandingPage(retries = 3, isNavigationForFreshLogin: boolean) {
        //fixture.page.on('console', msg => fixture.logger.info('PAGE LOG:', msg.text()));
        //fixture.page.on('pageerror', error => fixture.logger.error('PAGE ERROR:', error));

        const consoleListener = (msg: { text: () => any; }) => fixture.logger.info('PAGE LOG:', msg.text());
        const pageErrorListener = (error: any) => fixture.logger.error('PAGE ERROR:', error);

        fixture.page.on('console', consoleListener);
        fixture.page.on('pageerror', pageErrorListener);
        console.log("BASEURL:",process.env.BASEURL)
        console.log("ElementsURL:",this.Elements.url)
        for (let i = 0; i < retries; i++) {
            try {
                await this.pwWrapper.gotoFullPageLoading(this.Elements.url, 60000);
                // Wait for a specific element that indicates the page has loaded
                await this.page.waitForSelector('body', { state: 'attached', timeout: 60000 });
                if (await this.isPageWhite()) {
                    throw new Error('Page loaded but content is empty');
                }
               if(isNavigationForFreshLogin)
                await this.page.waitForSelector(`text=${this.Elements.loginBtn}`, { state: 'visible', timeout: 60000 });

                return; // Exit if navigation is successful and page is not white
            } catch (error) {
                console.error(`Navigation attempt ${i + 1} failed: `, error.message);
                if (i === retries - 1) throw error; // Rethrow error after final attempt
            }
        }

        // Unsubscribe from events after login
        fixture.page.removeListener('console', consoleListener);
        fixture.page.removeListener('pageerror', pageErrorListener);
    }
    async isPageWhite() {
        const content = await fixture.page.content();
        return content.trim() === '';
    }

    async getPageCurrentTitle(): Promise<string> {
        return await this.page.title();
    }

    /*eslint @typescript-eslint/require-await: "off" */
    async getLoginPageTitle(): Promise<string> {
        return "Sign In - Winfield United Evolve Login";
        await this.page.waitForTimeout(7000)
    }

    /*eslint @typescript-eslint/require-await: "off" */
    async getLoggedInPageTitle(): Promise<string> {
        return "evolve";
    }

    async enterUserName(user: string) {
        this.page.waitForSelector
        await this.page.getByPlaceholder(this.Elements.userNameInput).fill(user);
    }

    async getUserName() {
        return await this.page.getByPlaceholder(this.Elements.userNameInput).inputValue();
    }
    async enterPassword(password: string) {
         await this.page.waitForTimeout(3000)
        await this.page.getByPlaceholder(this.Elements.passwordInput).fill(password);
    }

    async getPassword() {
        return await this.page.getByPlaceholder(this.Elements.passwordInput).inputValue();
    }

    async clickLoginButton(checkHomePageNavigation: boolean = true) {
        await this.pwWrapper.elementAction.waitAndClick(this.Elements.loginBtnXPath);
        if (checkHomePageNavigation) {
            const loggedInUserHomePageUrl = `${process.env.BASEURL}` + `${this.Elements.landingPageUri}`;
            console.log("BASEURL:",process.env.BASEURL)
            console.log("ElementsURL:",this.Elements.url)
            await this.pwWrapper.waitForNavigation(loggedInUserHomePageUrl, 90000);
            await this.page.locator(this.Elements.loggedInUser).waitFor({ state: "visible", timeout: 90000 });
        }
        //await this.refreshLandingPage(); //NOTE: UNCOMMENT THIS IF EMULATION SCENARIOS ARE TESTED
    }

    async getLoggedInUserName(): Promise<string> {
        let userName = "";
        try {
            //await this.pwWrapper.refreshCurrentPage(30000, 3000);
            userName = await this.page.locator(this.Elements.loggedInUser).textContent({timeout: 120000});
        } catch (error) {
            fixture.logger.error("failed to get the content of the element - " + this.Elements.loggedInUser);
            fixture.logger.error(error);
        }
        return userName;
    }

    async isEmulationAccountPresent(): Promise<boolean> {
        //await this.refreshLandingPage();
        const count = await this.pwWrapper.pageElement.getAvailableElementCount(this.Elements.emulatedUser);
        return count > 0;
    }
    async getEmulatedUserName(): Promise<string> {
        //await this.refreshLandingPage();
        return await this.pwWrapper.dataReader.getElementTextByXPath(this.Elements.emulatedUser, true);
    }

    async refreshLandingPage() {
        // Emulation does not work if set in one browsing context and next browsing context is opened in private mode.
        // For this, we need to refresh page
        await this.pwWrapper.refreshCurrentPage(90000, 3000);
        while(await this.sharedBehavior.isOperationInProgress());
        await super.waitUntilButtonIsDisplayed(this.Elements.searchBtnTxtOnLandingPage, false, 30)
        //await this.page.waitForResponse(process.env.BASEURL + '/api/OTI/get-order-to-invoice-order', {timeout: 60000});
    }

    /*eslint @typescript-eslint/require-await: "off" */
    async getErrorMessage() {
        return this.page.locator(this.Elements.failedLoginErr);
    }

    async loginUser(user: string, password: string) {
        await this.enterUserName(user);
        await this.enterPassword(password);
        await this.clickLoginButton();
    }

    async logout(){
        const currentLoggedInUser = await this.getLoggedInUserName();
        (await this.pwWrapper.pageElement.getElementByRole(HtmlRoles.NAVIGATION))
            .locator('div').filter({ hasText: `${currentLoggedInUser}` }).locator('i').click();
        await this.pwWrapper.elementAction.clickElementByText(this.Elements.logoutBtnTxt);
    }

    async initializeOAuthToken(): Promise<boolean>{
        while(await this.sharedBehavior.isOperationInProgress());
        try {
          const storedData = await this.page.evaluate((key) => {
            return localStorage.getItem(key);
        }, "token"); // "token" is the key name used to store OAuth token in the localStorage by the UI app
     
          if (storedData) {
            //fixture.logger.info('Key found in local storage: ' + storedData);
            let authHeaders = new AuthHeaders();
            authHeaders.Token = storedData;
            fixture.dataBag.saveData(DataBagKeys.AUTH_HEADERS, authHeaders);
            /*fixture.logger.info(storedData);
            
            let request = new ProductAvailabilityRequest();
            request.AccountNumber = 7025693;
            request.MarketingBrandList = ["ARMOR"];
            const res = await ApiManager.getAvailableProducts(request);
            fixture.logger.info("products length is.."+ res.length);*/

            return true;
          } else {
            fixture.logger.info('OAuth Key not found in local storage: ');
            return false;
          }
        }
         catch (error) {
          fixture.logger.error('Error retrieving token from session storage:', error);
          throw false;
        }
    }
    
    async saveLoggedInUserAuthInfo(){
        await fixture.page.context().storageState({ path: 'auth.json' });
    }
}