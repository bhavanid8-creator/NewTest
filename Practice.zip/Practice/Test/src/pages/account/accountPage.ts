import HtmlRoles from "../../helpers/wrapper/htmlRoles";
import BasePage from "../basePage";
import { fixture } from "../../hooks/fixture";

export enum AccountFilterOption {
    ACCOUNT_NUMBER = "Account Number",
    ACCOUNT_NAME = "Account Name"
}

export default class AccountPage extends BasePage {
    
    replaceAccountNumber: string = "replace-account-number";

    Elements = {
        accountCategoryFilterTestId: "ddl-account-filter",
        accountSearchBoxPlaceholder: "Search...",
        accountFilterButtonTestId: "ddl-filter",
        accountSelectionCheckboxToggleXPath: "//mat-checkbox>>nth=0",
        accountFilteredItemCheckBoxXPath: `//div[text()=' ${this.replaceAccountNumber} ']/../../td[1]/div[1]/mat-checkbox[1]/label[1]/span[1]`,
        accountSelectionButtonXPath: "//span[text()='Select Account']",
        accountSelectionButtonTxt: "Select Account",
        accountSelectionButtonTestId: "ddl-select-account",
        accountAdditionButtonXPath: "//span[text()='Add Account']",
        updateAccountConfirmation_YES_XPath: "//button/span[text()='Yes']",
        updateAccountConfirmation_NO_XPath: "//button/span[text()='No']",
        //selectAllAccountsCheckboxXPath: "(//span[@class='mat-checkbox-inner-container mat-checkbox-inner-container-no-side-margin'])[1]",
        selectAllAccountsCheckboxTestId:`ddl-select-all`,
        chipTextXPath: `//mat-chip`,
        noRecordsSelectedWarningMsgXPath: `//*[text() = 'No record selected, do you want to update it.']`,
        accountSelectionConfirmationMsgXPath: `//*[contains(.,'Do you want to update')]`,
        noSearchResultsMsgXPath: `//*[contains(@class,'noRecordMsg')]`,
    }

    async isPageStable(): Promise<boolean> {
        fixture.logger.info('checking for account-page stability');
        //await this.pwWrapper.refreshCurrentPage(90000, 3000);
        //for(let i=0; i<3; i++)
            while(await this.sharedBehavior.isOperationInProgress());
        await super.waitUntilButtonIsDisplayed(this.Elements.accountAdditionButtonXPath);
        fixture.logger.info('checking for account-page stability completed');
        return true;
    }
    async clearExistingAccounts(){
        while (await this.sharedBehavior.isOperationInProgress());
        let dataNotAvailable = await this.sharedBehavior.isNoDataAvailable();
        if (dataNotAvailable) {
            fixture.logger.info(`cleared existing account setting context`);
            return;
        }
        /*await this.pwWrapper.elementAction.clickElement(this.Elements.accountSelectionCheckboxToggleXPath);
        await this.pwWrapper.elementAction.clickElement(this.Elements.accountSelectionCheckboxToggleXPath);//we click the checkbox again to deselect accounts
        */

        await this.pwWrapper.elementAction.clickElementByTestId(this.Elements.selectAllAccountsCheckboxTestId);
        await this.pwWrapper.common.delay(500);
        await this.pwWrapper.elementAction.clickElementByTestId(this.Elements.selectAllAccountsCheckboxTestId);//we click the checkbox again to deselect accounts
        await this.pwWrapper.common.delay(500);
        //await this.pwWrapper.elementAction.clickElementByTestId(this.Elements.accountSelectionButtonTestId);
        await this.pwWrapper.elementAction.clickElement(this.Elements.accountSelectionButtonXPath);
        //await this.tryClickSelectOrAddAccountButton(this.Elements.accountSelectionButtonTxt);
        await this.confirmAccountUpdate();
    }
    async clickAccountFilter() {
        //await this.pwWrapper.elementAction.clickItemByTestIdAndRole(this.Elements.accountCategoryFilterTestId, HtmlRoles.COMBOBOX);
        await this.pwWrapper.elementAction.clickElementByTestId(this.Elements.accountCategoryFilterTestId);
    }
    async setAccountFilter(accountFilterOption: AccountFilterOption) {
        await this.pwWrapper.dataWriter.selectOption(accountFilterOption);
    }

    async filterAccount(accountValue: string) {
        await this.pwWrapper.dataWriter.enterValueIntoTextboxByPlaceholder(this.Elements.accountSearchBoxPlaceholder, accountValue)
        await this.pwWrapper.elementAction.clickElementByTestId(this.Elements.accountFilterButtonTestId);
        while (await this.sharedBehavior.isOperationInProgress());
    }

    async getChipText(): Promise<string>{
        return await this.pwWrapper.dataReader.getElementTextByXPath(this.Elements.chipTextXPath, false);
    }

    async selectFilteredAccounts(accountNumbers: string[], selectAllAccounts: boolean = false): Promise<boolean> {
        while (await this.sharedBehavior.isOperationInProgress());
        const noRecordsFoundMsgCount = await this.pwWrapper.pageElement.getAvailableElementCount(this.Elements.noSearchResultsMsgXPath, 500);
        if(noRecordsFoundMsgCount > 0) {
            fixture.logger.error(`No records found for the account filter`);
            return false;
        }
        if(selectAllAccounts){
            //await this.pwWrapper.dataWriter.checkCheckBox(this.Elements.selectAllAccountsCheckboxXPath);
            await this.pwWrapper.elementAction.clickElementByTestId(this.Elements.selectAllAccountsCheckboxTestId);
        }else{
        for (let index = 0; index < accountNumbers.length; index++) {
            const finalXPath = this.Elements.accountFilteredItemCheckBoxXPath.replace(this.replaceAccountNumber, accountNumbers[index]);
            await this.pwWrapper.dataWriter.checkCheckBox(finalXPath);
        }}
        await this.pwWrapper.common.delay(500);
        return true;
    }

    async clickAddAccountButton() {
        //await this.tryClickSelectOrAddAccountButton(this.Elements.accountAdditionButtonXPath);
        await this.pwWrapper.elementAction.clickElement(this.Elements.accountAdditionButtonXPath);
    }

    /**
     * @Note this method is designed to check if no record is selected and if so, it will click on the button again to try again. When it retries, it assumes that the user has selected a record but this method does not perform selecting records.
     */
    private async tryClickSelectOrAddAccountButton(btnXPath: string) {
        let isNoRecordsSelectedWarningMsgDisplayed = 0;
        while (true) {
            await this.pwWrapper.elementAction.clickElement(btnXPath);
            isNoRecordsSelectedWarningMsgDisplayed = await this.pwWrapper.pageElement.getAvailableElementCount(this.Elements.noRecordsSelectedWarningMsgXPath, 500);
            if (isNoRecordsSelectedWarningMsgDisplayed > 0) {
                fixture.logger.warn(`No record selected, do you want to update it. message is displayed; so we will try again`);
                await this.pwWrapper.elementAction.clickElement(this.Elements.updateAccountConfirmation_NO_XPath);//dismiss it by clicking on NO before retry
                await this.pwWrapper.common.delay(500);
            } else {
                break;
            }
        }
    }

    async confirmAccountUpdate() {
        await this.pwWrapper.elementAction.clickElement(this.Elements.updateAccountConfirmation_YES_XPath);
        await this.pwWrapper.common.delay(500);
        while (await this.sharedBehavior.isOperationInProgress());
        await this.pwWrapper.common.delay(500);
    }
}