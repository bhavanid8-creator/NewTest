/*eslint @typescript-eslint/no-unsafe-argument: "off" */
/*eslint @typescript-eslint/no-unsafe-assignment: "off" */
/*eslint @typescript-eslint/no-unsafe-call: "off" */
/*eslint @typescript-eslint/no-unsafe-member-access: "off" */
const { format } = require('date-fns');

import HtmlRoles from "../../../helpers/wrapper/htmlRoles";
import { fixture } from "../../../hooks/fixture";
import BasePage from "../../basePage";
import SeedFulfillment from "../../../helpers/util/test-data/fulfillment/seedFulfillment";
import ReleasedProduct from "../../../helpers/util/test-data/fulfillment/releasedProduct";
import DataBagKeys from "../../../tests/steps/dataBagKeys";

export default class SeedFulfillmentPage extends BasePage {

    readonly replaceBtnClassName = 'replace-btn-class';
    readonly replaceProductName = 'replace-product-name';
    readonly dateFormatInTheCalendar: string = 'MMMM d, yyyy';
    readonly replaceIndex = 'replace-index';
    readonly replaceShipmentItemCategory = 'replace-shipment-item-category';
    readonly replaceReleaseOrder = 'replace-release-order-number';
    readonly replaceAccountName = 'replace-account-name';

    Elements = {
        submittedRequestsTabName: 'Submitted Requests Requests already submitted',
        draftsRequestsTabName: 'Unsubmitted Drafts Requests not submitted for dispatch',
        requestReleaseOrderValueXPath: `//td[contains(@class,'mat-column-dealerReleaseNumber') and contains(., '${this.replaceReleaseOrder}')]`,
        requestProductNameXPath: `//td[contains(@class,'mat-column-dealerReleaseNumber') and contains(., '${this.replaceReleaseOrder}')]/ancestor::tr//a`,
        newOrderReleaseBtnName: 'Create Order Release',
        shipToDropDownText: 'Ship To:',
        deliverToDropDownText: 'Deliver To:',
        branchDropDownText: 'Branch:',
        calendarLabelName: 'Open calendar',
        chooseMonthYearLabel: 'Choose month and year',
        freightHandlingCodeDropDownText: 'Freight Handling Code',
        requestTypeDropDownText: 'Request Type',
        inventoryComputeOptionsDropDownText: 'Inventory Compute options',
        computeInventoryBtnName: 'Compute Inventory',
        computeInventoryBtnTestId: 'btn-compute-inventory2',
        customerPOTextBoxLablelTxt: 'Customer PO:',
        showProductsWithInventoryAvailabilityCheckBoxXPath: `//div[text()=' Show products with inventory availability ']/mat-checkbox`,
        plusBtnClassName: 'plusBtn',
        minusBtnClassName: 'minusBtn',
        //productReleaseQtyBtnXPath: `//p[text()=' ${this.replaceProductName}']/ancestor::tr//button[contains(@class,'${this.replaceBtnClassName}')]`,
        productReleaseQtyBtnXPath: `//p[contains(., '${this.replaceProductName}')]/ancestor::tr//button[contains(@class,'${this.replaceBtnClassName}')]`,
        //productReleaseQtyTextBoxXPath: `//p[text()='${this.replaceProductName}']/ancestor::tr//input`,
        productReleaseQtyTextBoxXPath: `//p[contains(., '${this.replaceProductName}')]/ancestor::tr//input`,
        qtyAvailableToReleaseXPath: `//p[contains(., '${this.replaceProductName}')]/ancestor::tr/td[contains(@class, 'mat-column-availableToRelease')]//span`,
        inventoryAvailableXPath: `//p[contains(., '${this.replaceProductName}')]/ancestor::tr/td[contains(@class, 'mat-column-inventory')]//span`,
        deliveryInstructionsEditBtnXPath: `//*[@title='Edit']`,
        deliveryInstructionsAddRowBtnTxt: 'Add Row',
        deliveryInstructionsDeleteRowBtnTitleXPath: `//*[@title='delete']`,
        deliveryInstructionsFormCloseBtnTxt: ' Close ',
        deliveryInstructionsProductLineDropdownXPath: `(//ng-select[@name='ddlProductLine'])[${this.replaceIndex}]`,
        deliveryInstructionsContactTypeDropdownXPath: `(//ng-select[@name='ddlContactType'])[${this.replaceIndex}]`,
        deliveryInstructionsFirstNameTxtBoxXPath: `(//input[@name='firstName'])[${this.replaceIndex}]`,
        deliveryInstructionsLastNameTxtBoxXPath: `(//input[@name='lastName'])[${this.replaceIndex}]`,
        deliveryInstructionsPhoneTxtBoxXPath: `(//input[@name='phone'])[${this.replaceIndex}]`,
        deliveryInstructionsEmailTxtBoxXPath: `(//input[@name='emailAddress'])[${this.replaceIndex}]`,
        deliveryInstructionsTypeDropdownXPath: `(//ng-select[@name='ddlDeliveryInstrucion'])[${this.replaceIndex}]`,
        deliveryInstructionsCurrentContactTypeXPath: `(//ng-select[@data-testid='ddl-contact-type-search']//span[contains(@class,'ng-value-label')])[${this.replaceIndex}]`,
        deliveryInstructionsSaveBtnTxt: 'Save',
        deliveryInstructionsSaveBtnTestId: 'btn-save-delivery-instructions',
        deliveryInstructionsRecordSaveOrUpdateErrorMsg: 'Same contact type can not be added in one product line',
        deliveryInstructionsRecordSelectRadioXPath: `(//input[@name='item-di'])[${this.replaceIndex}]`,
        deliveryInstructionsRecrodEditBtnXPath: `//*[@title='Edit Delivery Instruction']`,
        selectDeliveryInstrctionsRecordBtnName: 'Select Delivery Instruction',

        viewLotsEllipsisIconXPath: `//i[contains(@class,'fas fa-ellipsis-v')]`,
        //viewLotsBtnTxt: `View Lots`,
        viewLotsBtnXPath: `//button[contains(.,'View Lots')]`,
        viewFulfillmentBreakdownHeaderXPath: `//div[contains(@class, 'seed-return-add-prod')]/div[2]/div/div/div/h6`,
        viewFulfillmentBreakdownProductNameXPath: `//td[contains(@class, 'cdk-column-itemDescription')]/div/p[1]`,
        returnToFulfillmentBtnTxt: 'Return to Fulfillment',

        //overridePalletsRadioBtnXPath: `//div[contains(@class, 'showChangesSection')]//input`,
        overridePalletsRadioBtnXPath: `.slider`,
        overridePalletQtyTxtBoxXPath: `//input[contains(@class, 'geu-txt')]`,
        shipmentItemWeightValueXPath: `(//*[text()=' ${this.replaceShipmentItemCategory} ']/following-sibling::*)[1]`,
        computePalletsAndWeightBtnName: 'Compute Pallets and Weight',
        computePalletsAndWeightBtnTestId: 'btn-compute-pallets',
        saveReleaseBtnName: 'Save Release',
        saveReleaseBtnTestId: 'btn-save-release',
        placeERPOrderBtnName: 'Place ERP Order',
        confirmReleaseBtnName: 'Confirm',
        erpOrderNumberXPath: `//span[contains(., '[ERPOrder#')]`,
        releaseNumberXPath: `(//a[contains(., '${this.replaceAccountName}')]/ancestor::tr/td[contains(@class, 'mat-column-dealerReleaseNumber')])[1]`,
    }

    /*eslint @typescript-eslint/require-await: "off" */
    async canNavigateWithUrl(): Promise<boolean> {
        return true;
    }

    private async isPageLoaded(): Promise<boolean> {
        while (await this.sharedBehavior.isOperationInProgress());
        await super.waitUntilButtonIsDisplayed(this.Elements.newOrderReleaseBtnName);
        return true;
    }

    async isSeedFulfillmentHomePageDisplayed(): Promise<boolean>{
        //if we are on home page, then 'Create Order Release' button must be displayed
        const count = await this.pwWrapper.pageElement.getAvailableElementCountByRole(HtmlRoles.BUTTON, this.Elements.newOrderReleaseBtnName);
        return count > 0;
    }

    async isPageStable() {
        fixture.logger.info('checking for seed-fulfillment-page stability');
        await this.isPageLoaded();

        fixture.logger.info('checking for seed-fulfillment-page stability completed');
        return true;
    }

    async getOrderIdFromTopRow(accountName: string): Promise<string>{
        const finalXPath = this.Elements.releaseNumberXPath.replace(this.replaceAccountName, accountName);
        const releaseNumber = await this.pwWrapper.dataReader.getElementTextByXPath(finalXPath, false);
        fixture.logger.info(`Release Number/Order Id from the Unsubmitted Drafts section is - ${releaseNumber}`);
        return releaseNumber;
    }
    async switchToRequestsTab(swithToSubmittedRequests: boolean) {
        const tabName = swithToSubmittedRequests ? this.Elements.submittedRequestsTabName : this.Elements.draftsRequestsTabName;
        await this.sharedBehavior.clickOnTab(tabName);
    }

    async isReleaseOrderPresent(releaseOrderNumber: string) {
        while (await this.sharedBehavior.isOperationInProgress());
        const finalXPath = this.Elements.requestReleaseOrderValueXPath.replace(this.replaceReleaseOrder, releaseOrderNumber);
        const count = await this.pwWrapper.pageElement.getAvailableElementCount(finalXPath);
        fixture.logger.info(`count of draft/submitted Release Order for the order number ${releaseOrderNumber} is ${count}`);
        return count == 1;
    }

    getReleaseOrder(){
        const customerPO = fixture.dataBag.getData(DataBagKeys.CUSTOMER_PO) as string;
    }

    async openDraftReleaseOrder(releaseOrderNumber: string) {
        await this.openReleaseOrderForm(true, releaseOrderNumber);
    }

    async openSubmittedReleaseOrder(releaseOrderNumber: string) {
        await this.openReleaseOrderForm(false, releaseOrderNumber);
    }

    private async openReleaseOrderForm(isDraftOrder: boolean, releaseOrderNumber: string) {
        while (await this.sharedBehavior.isOperationInProgress());
        const finalXPath = this.Elements.requestProductNameXPath.replace(this.replaceReleaseOrder, releaseOrderNumber);
        let msg = "opened submitted release for the order number ";
        if (isDraftOrder) {
            msg = "opened draft release for the order number ";
        }
        await this.pwWrapper.elementAction.clickElement(finalXPath);
        while (await this.sharedBehavior.isOperationInProgress());
        fixture.logger.info(msg + releaseOrderNumber);
    }
    async startNewReleaseOrder(): Promise<boolean> {
        await (await this.pwWrapper.pageElement.getElementByRole(HtmlRoles.BUTTON, this.Elements.newOrderReleaseBtnName)).click();
        while (await this.sharedBehavior.isOperationInProgress());
        const placeErpBtnCount = await this.pwWrapper.pageElement.getAvailableElementCountByRole(HtmlRoles.BUTTON, this.Elements.placeERPOrderBtnName);
        if (placeErpBtnCount > 0) {
            fixture.logger.info('opened new seed-fulfillment-release page');
            return true;
        } else {
            fixture.logger.info(`failed to open new seed-fulfillment-release page; could not find ${this.Elements.placeERPOrderBtnName} button`);
            return false;
        }
    }

    /**
     * Fills Shipto, DeliverTo and Branch details
     */
    async fillShippingDetails(seedFulfillment: SeedFulfillment) {
        await this.selectShipToAccount(seedFulfillment);
        await this.selectDeliverToAccount(seedFulfillment);
        await this.selectBranch(seedFulfillment);
    }

    async selectShipToAccount(seedFulfillment: SeedFulfillment) { 
        await this.sharedBehavior.selectAngularDropdownOptionByPlaceholder(this.Elements.shipToDropDownText, seedFulfillment.shipTo.number);
        /*
        const shipToDropdownOption = seedFulfillment.shipTo.number.trim();
        await this.pwWrapper.dataWriter.selectAngularDropdownOption(this.Elements.shipToDropDownText, shipToDropdownOption);
        while(await this.sharedBehavior.isOperationInProgress());
        const selector = this.pwWrapper.common.getSelectorWithPlaceholderText(this.Elements.shipToDropDownText);
        const resCheck = await this.pwWrapper.dataReader.isDropdownItemSelected(selector, shipToDropdownOption);
        if(resCheck)
            fixture.logger.info(`ShipTo - ${seedFulfillment.shipTo.number} - has been selected`);
        else
            throw new Error(`specified account - ${shipToDropdownOption} - could not be selected in the 'Ship To:' dropdown`);
        */
    }

    async selectDeliverToAccount(seedFulfillment: SeedFulfillment) {
        /*
        await this.pwWrapper.dataWriter.selectAngularDropdownOption(this.Elements.deliverToDropDownText, seedFulfillment.deliverTo.number.trim());
        fixture.logger.info(`DeliverTo - ${seedFulfillment.deliverTo.number} - has been selected`);*/
        await this.sharedBehavior.selectAngularDropdownOptionByPlaceholder(this.Elements.deliverToDropDownText, seedFulfillment.deliverTo.number);
    }

    async selectBranch(seedFulfillment: SeedFulfillment) {
        /*await this.pwWrapper.dataWriter.selectAngularDropdownOption(this.Elements.branchDropDownText, seedFulfillment.branch.trim());
        fixture.logger.info(`Branch - ${seedFulfillment.branch} - has been selected`);*/
        await this.sharedBehavior.selectAngularDropdownOptionByPlaceholder(this.Elements.branchDropDownText, seedFulfillment.branch);
    }
    /**
     * Fills Requested Date, Freight Handling Code, Request Type, Customer PO, Inventory Compute Options
     * @param seedFulfillment 
     */
    async fillOtherOrderReleaseDetails(seedFulfillment: SeedFulfillment) {
        await this.fillRequestedDate(seedFulfillment.requestedDate);
        /*
                await this.pwWrapper.dataWriter.selectAngularDropdownOption(this.Elements.freightHandlingCodeDropDownText, seedFulfillment.freightHandlingCode.trim());
                fixture.logger.info(`Freight Handling Code - ${seedFulfillment.freightHandlingCode} - has been selected`);
        
                await this.pwWrapper.dataWriter.selectAngularDropdownOption(this.Elements.requestTypeDropDownText, seedFulfillment.requestType.trim());
                fixture.logger.info(`Request Type - ${seedFulfillment.requestType} - has been selected`);
        */
        await this.sharedBehavior.selectAngularDropdownOptionByPlaceholder(this.Elements.freightHandlingCodeDropDownText, seedFulfillment.freightHandlingCode);
        await this.sharedBehavior.selectAngularDropdownOptionByPlaceholder(this.Elements.requestTypeDropDownText, seedFulfillment.requestType);

        const customerPO = "qa-auto-" + (new Date()).getTime();
        await this.pwWrapper.dataWriter.enterValueIntoTextboxByLabel(this.Elements.customerPOTextBoxLablelTxt, customerPO);
        fixture.logger.info(`Customer PO - ${customerPO} - has been set`);

        fixture.dataBag.saveData(DataBagKeys.CUSTOMER_PO, customerPO);
        /*
        await this.pwWrapper.dataWriter.selectAngularDropdownOption(this.Elements.inventoryComputeOptionsDropDownText, seedFulfillment.inventoryComputeOptions.trim());
        fixture.logger.info(`Inventory Compute Options - ${seedFulfillment.inventoryComputeOptions} - has been selected`);*/
        await this.sharedBehavior.selectAngularDropdownOptionByPlaceholder(this.Elements.inventoryComputeOptionsDropDownText, seedFulfillment.inventoryComputeOptions);
    }

    private async fillRequestedDate(date: string) {
        const calendarElement = await this.pwWrapper.pageElement.getElementByLabel(this.Elements.calendarLabelName);
        await calendarElement.click();
        const today = new Date();
        let requestedDate = new Date(date);
        if (requestedDate < today)
            requestedDate = today; // if requested date is in the past, make today as the requested date

        await this.pwWrapper.elementAction.clickElementByLabel(this.Elements.chooseMonthYearLabel);
        const formatted = format(requestedDate, this.dateFormatInTheCalendar);
        const splits = formatted.split(" ");
        await this.pwWrapper.elementAction.clickElementByRole(HtmlRoles.BUTTON, splits[2]); // selecting year
        await this.pwWrapper.elementAction.clickElementByLabel(`${splits[0]} ${splits[2]}`); //selecting month & year
        const tempEle = await this.pwWrapper.pageElement.getElementByLabel(formatted);
        await tempEle.click(); //selecting day, month & year
        await this.pwWrapper.common.delay(2000);
        fixture.logger.info(`Requested Date - ${requestedDate} - has been set`);
    }

    async isDeliveryInstructionsEditBtnEnabled(): Promise<boolean> {
        await this.clickEditDeliveryInstructionsBtn();
        const result = await this.pwWrapper.elementAction.canClickButton(this.Elements.deliveryInstructionsAddRowBtnTxt);
        await this.closeDeliveryInstructionsForm();
        return result;
    }

    async closeDeliveryInstructionsForm() {
        await this.pwWrapper.elementAction.clickElementHavingText(this.Elements.deliveryInstructionsFormCloseBtnTxt);
    }

    async isEditDeliveryInstructionsBtnEnabled() {
        const count = await this.pwWrapper.pageElement.getAvailableElementCount(`//i[contains(@class,'enableBlue')]`);
        return count > 0;
    }

    async clickEditDeliveryInstructionsBtn() {
        await this.pwWrapper.elementAction.clickElement(this.Elements.deliveryInstructionsEditBtnXPath);
        await super.waitUntilButtonIsDisplayed(this.Elements.deliveryInstructionsAddRowBtnTxt, false, 5); //spinner is not working properly so we will wait for the button
    }

    async clickNewDeliveryInstructionsRowBtn() {
        await this.pwWrapper.elementAction.clickElementHavingText(this.Elements.deliveryInstructionsAddRowBtnTxt);
    }

    async clickDeliveryInstructionsRecordEditBtn(): Promise<boolean> {
        const elementCount = await this.pwWrapper.pageElement.getAvailableElementCount(this.Elements.deliveryInstructionsRecrodEditBtnXPath);
        if (elementCount == 0) {
            fixture.logger.error("No delivery instructions records found");
            return false;
        } else if (elementCount == 1) {
            await this.pwWrapper.elementAction.clickElement(this.Elements.deliveryInstructionsRecrodEditBtnXPath);
        } else {
            fixture.logger.warn("More than one delivery instructions records found; hence using the top record");
            const finalXPath = "(" + this.Elements.deliveryInstructionsRecrodEditBtnXPath + ")[1]";
            await this.pwWrapper.elementAction.clickElement(finalXPath);
        }
        while (await this.sharedBehavior.isOperationInProgress());
        return true;
    }

    async fillNewDeliveryInstructionsRowDetails(seedFulfillment: SeedFulfillment, recordIndexToUpdate: number = 1) {
        await this.selectDeliveryInstructionDropdownItem(this.Elements.deliveryInstructionsProductLineDropdownXPath, recordIndexToUpdate, seedFulfillment.deliveryInstructions.productLine);
        await this.selectDeliveryInstructionDropdownItem(this.Elements.deliveryInstructionsContactTypeDropdownXPath, recordIndexToUpdate, seedFulfillment.deliveryInstructions.contactType);
        await this.enterDeliveryInstructionsItemValue(this.Elements.deliveryInstructionsFirstNameTxtBoxXPath, recordIndexToUpdate, seedFulfillment.deliveryInstructions.firstName);
        await this.enterDeliveryInstructionsItemValue(this.Elements.deliveryInstructionsLastNameTxtBoxXPath, recordIndexToUpdate, seedFulfillment.deliveryInstructions.lastName);
        await this.enterDeliveryInstructionsItemValue(this.Elements.deliveryInstructionsPhoneTxtBoxXPath, recordIndexToUpdate, seedFulfillment.deliveryInstructions.phone);
        await this.enterDeliveryInstructionsItemValue(this.Elements.deliveryInstructionsEmailTxtBoxXPath, recordIndexToUpdate, seedFulfillment.deliveryInstructions.email);
        for (let i = 0; i < seedFulfillment.deliveryInstructions.deliveryInstruction.length; i++) {
            await this.selectDeliveryInstructionDropdownItem(this.Elements.deliveryInstructionsTypeDropdownXPath, recordIndexToUpdate, seedFulfillment.deliveryInstructions.deliveryInstruction[i]);
        }
    }

    /**
     * 
     * @param recordIndexToUpdate delivery instructions row number
     * @returns returns current selected contact type for the specified delivery instructions row
     */
    async getCurrentSelectedContactType(recordIndexToUpdate: number = 1): Promise<string> {
        const finalXPath = this.Elements.deliveryInstructionsCurrentContactTypeXPath.replace(this.replaceIndex, recordIndexToUpdate.toString());
        return await this.pwWrapper.dataReader.getElementTextByXPath(finalXPath, false);
    }
    async selectDeliveryInstructionsContactType(option: string) {
        const count = await this.getCurrentDeliveryInstructionsRecordsCount();
        await this.selectDeliveryInstructionDropdownItem(this.Elements.deliveryInstructionsContactTypeDropdownXPath, count, option);
    }

    // async getToastMsg(){
    //     //const msg = await this.pwWrapper.dataReader.getElementTextById('toast-container');
    //     await this.pwWrapper.elementAction.clickElementByLabel('Delivery Instructions deleted successfully.');
    //     const msg = await (await this.pwWrapper.pageElement.getElementById('toast-container')).innerText();
    //     fixture.logger.info(`toast msg is...${msg}`);
    //     return msg;
    // }
    async getCurrentDeliveryInstructionsRecordsCount(): Promise<number> {
        let tempXPath = this.Elements.deliveryInstructionsProductLineDropdownXPath.replace(`[${this.replaceIndex}]`, '');
        await this.pwWrapper.common.delay(1000); //sometimes UI is loading slowly so we will wait
        return await this.pwWrapper.pageElement.getAvailableElementCount(tempXPath);
    }
    async clickDeliveryInstrcutionsSaveBtn(): Promise<string> {
        //return await this.sharedBehavior.clickButtonAndInspectSuccessMessage("save delivery instructions record", this.Elements.deliveryInstructionsSaveBtnTxt, true);
        return await this.sharedBehavior.clickButtonByTestIdAndInspectSuccessMessage("save delivery instructions record", this.Elements.deliveryInstructionsSaveBtnTestId);
    }

    async isDeliveryInstrcutionsSaveBtnEnabled(): Promise<boolean>{
        while(await this.sharedBehavior.isOperationInProgress());
        //return await this.pwWrapper.elementAction.canClickButton(this.Elements.deliveryInstructionsSaveBtnTxt);
        return await this.pwWrapper.elementAction.canClickItemByTestId(this.Elements.deliveryInstructionsSaveBtnTestId);
    }

    async deleteAllDeliveryInstructionRecords(){
        const elementCount = await this.pwWrapper.pageElement.getAvailableElementCount(this.Elements.deliveryInstructionsDeleteRowBtnTitleXPath);
        for(let index=elementCount-1; index >= 0; index--){
            let deleteBtn = await this.pwWrapper.pageElement.getIndexedElementByRole(index, HtmlRoles.TABLE_CELL, 'E', true);
            await deleteBtn.click();
            await this.pwWrapper.elementAction.clickElementByRole(HtmlRoles.BUTTON, 'Yes');
            while(await this.sharedBehavior.isOperationInProgress());
            await this.pwWrapper.common.delay(10000);//toast message is displayed for prolonged time so we will delay
        }
    }

    async deleteTopDeliveryInstructionsRecord(): Promise<string> {
        const elementCount = await this.pwWrapper.pageElement.getAvailableElementCount(this.Elements.deliveryInstructionsDeleteRowBtnTitleXPath);
        if (elementCount == 0) {
            fixture.logger.error("No delivery instructions records found");
            return "";
        } else if (elementCount == 1) {
            await this.pwWrapper.elementAction.clickElement(this.Elements.deliveryInstructionsDeleteRowBtnTitleXPath);
        } else {
            fixture.logger.warn("More than one delivery instructions records found; hence using the top record");
            const finalXPath = "(" + this.Elements.deliveryInstructionsDeleteRowBtnTitleXPath + ")[1]";
            await this.pwWrapper.elementAction.clickElement(finalXPath);
        }
        return await this.sharedBehavior.clickButtonAndInspectSuccessMessage("delete delivery instructions record", 'Yes', true);
    }

    getDeliveryInstrcutionsCreateOrUpdateOperationMsg(): string[] {
        return ["Delivery Instructions saved successfully.", this.Elements.deliveryInstructionsRecordSaveOrUpdateErrorMsg];
    }

    getDeliveryInstrcutionsDeleteOperationMsg(): string[] {
        return ["Delivery Instructions deleted successfully."];
    }

    async selectFirstDeliveryInstructionsRecord() {
        const finalXPath = this.Elements.deliveryInstructionsRecordSelectRadioXPath.replace(this.replaceIndex, "1");
        await this.pwWrapper.elementAction.clickElement(finalXPath);
        fixture.logger.info('attempted to select the first delivery instructions record');
    }

    async clickSelectDeliveryInstructionsBtn() {
        await this.pwWrapper.elementAction.clickElementByRole(HtmlRoles.BUTTON, this.Elements.selectDeliveryInstrctionsRecordBtnName);
        fixture.logger.info(`clicked on ${this.Elements.selectDeliveryInstrctionsRecordBtnName} button`);
    }
    private async selectDeliveryInstructionDropdownItem(xpath: string, index: number, option: string) {
        const finalXPath = this.getFinalXPathForDeliveryInstructionsItem(xpath, index);
        await this.pwWrapper.elementAction.clickElement(finalXPath);
        await this.pwWrapper.dataWriter.selectOption(option);
    }

    private async enterDeliveryInstructionsItemValue(xpath: string, index: number, value: string) {
        const finalXPath = this.getFinalXPathForDeliveryInstructionsItem(xpath, index);
        await this.pwWrapper.dataWriter.enterValueIntoTextboxByXPath(finalXPath, value);
    }
    private getFinalXPathForDeliveryInstructionsItem(xpath: string, index: number) {
        return xpath.replace(this.replaceIndex, index.toString());
    }

    async computeInventory() {
        //await this.pwWrapper.elementAction.clickElementByRole(HtmlRoles.BUTTON, this.Elements.computeInventoryBtnName);
        await this.pwWrapper.elementAction.clickElementByTestId(this.Elements.computeInventoryBtnTestId)
        while (await this.sharedBehavior.isOperationInProgress());
    }

    async setReleaseQuantities(seedFulfillment: SeedFulfillment): Promise<ReleasedProduct[]> {
        await this.pwWrapper.elementAction.clickElement(this.Elements.showProductsWithInventoryAvailabilityCheckBoxXPath);
        while (await this.sharedBehavior.isOperationInProgress());

        let currentAvailableReleaseQuantities: ReleasedProduct[] = [];
        for (let i = 0; i < seedFulfillment.productsToRelease.length; i++) {
            const productName = seedFulfillment.productsToRelease[i].name;
            const qty = await this.getQtyAvailableToRelease(productName);
            const inventory = await this.getInventoryAvailable(productName);
            let pInfo = new ReleasedProduct();
            pInfo.name = productName;
            pInfo.quantity = qty;
            pInfo.inventory = inventory;
            currentAvailableReleaseQuantities.push(pInfo);

            let finalXPath = this.Elements.productReleaseQtyBtnXPath.replace(this.replaceProductName, productName);
            finalXPath = finalXPath.replace(this.replaceBtnClassName, this.Elements.plusBtnClassName);
            await this.pwWrapper.elementAction.clickElement(finalXPath);
        }

        return currentAvailableReleaseQuantities;
    }

    async clickOverrideCheckbox() {
        fixture.logger.info('about to change Override status');
        await this.pwWrapper.elementAction.clickElement(this.Elements.overridePalletsRadioBtnXPath);
        fixture.logger.info('changed Override status');
    }

    async overridePalletQty(qty: string) {
        fixture.logger.info('about to enter overriding quantity');
        const totalTxtBoxesCount = await this.pwWrapper.pageElement.getAvailableElementCount(this.Elements.overridePalletQtyTxtBoxXPath);
        const finalXPath = "(" + this.Elements.overridePalletQtyTxtBoxXPath + ")[" + totalTxtBoxesCount.toString() + "]";
        fixture.logger.info(`finalXPath in overridePalletQty is ${finalXPath}`);
        await this.pwWrapper.dataWriter.enterValueIntoTextboxByXPath(finalXPath, qty);
        fixture.logger.info('completed entering overriding quantity');
    }

    async clickOnComputePalletsAndWeightBtn() {
        const enabled = await this.pwWrapper.pageElement.isElementByRoleEnabled(HtmlRoles.BUTTON, this.Elements.computePalletsAndWeightBtnName);
        if (!enabled) {
            fixture.logger.warn(`${this.Elements.computePalletsAndWeightBtnName} is not enabled`);
            return;
        }
        //await this.pwWrapper.elementAction.clickElementByRole(HtmlRoles.BUTTON, this.Elements.computePalletsAndWeightBtnName);
        await this.pwWrapper.elementAction.clickElementByTestId(this.Elements.computePalletsAndWeightBtnTestId);
        while (await this.sharedBehavior.isOperationInProgress());
    }

    async getShipmentWeightComputationValues(): Promise<number[]> {
        const seedWeightValue = await this.getShipmentItemWeight('Seed Weight');
        const palletWeightValue = await this.getShipmentItemWeight('Pallet Weight');
        const totalWeightValue = await this.getShipmentItemWeight('Total Weight');

        return [seedWeightValue, palletWeightValue, totalWeightValue];
    }

    private async getShipmentItemWeight(shipmentItemCategory: string) {
        let finalXPath = this.Elements.shipmentItemWeightValueXPath.replace(this.replaceShipmentItemCategory, shipmentItemCategory);
        const weight = await this.pwWrapper.dataReader.getElementTextByXPath(finalXPath, false);
        //return parseInt(weight.replaceAll(",", ""));
        return parseFloat(weight.replaceAll(",", ""));
    }

    async clickSaveReleaseOrderBtn() {
        //await this.pwWrapper.elementAction.clickElementByRole(HtmlRoles.BUTTON, this.Elements.saveReleaseBtnName);
        await this.pwWrapper.elementAction.clickElementByTestId(this.Elements.saveReleaseBtnTestId);
        return await this.sharedBehavior.clickButtonAndInspectSuccessMessage("save release", this.Elements.confirmReleaseBtnName, true);
    }

    async clickPlaceERPOrderBtn() {
        await this.clickOnComputePalletsAndWeightBtn();
        await this.pwWrapper.elementAction.clickElementByRole(HtmlRoles.BUTTON, this.Elements.placeERPOrderBtnName);
        //return await this.sharedBehavior.clickButtonAndInspectSuccessMessage("place ERP release order",this.Elements.confirmReleaseBtnName, true);
        return await this.sharedBehavior.clickButtonAndInspectSuccessMessageIndependently("place ERP release order", this.Elements.confirmReleaseBtnName, "", true, 80000);
    }

    async getERPOrderId(): Promise<string>{
        let erpOrderText = await this.pwWrapper.dataReader.getElementTextByXPath(this.Elements.erpOrderNumberXPath, false);
        fixture.logger.info(`displayed ERP Order value is - ${erpOrderText}`);
        return erpOrderText.replace(/\[ERPOrder#\s*|\s*\]/g, '').trim();
    }

    async getQtyAvailableToRelease(productName: string): Promise<string> {
        return await this.getProductQty(productName, this.Elements.qtyAvailableToReleaseXPath);
        /*const finalXPath = this.Elements.qtyAvailableToReleaseXPath.replace(this.replaceProductName, productName);
        const count = await this.pwWrapper.pageElement.getAvailableElementCount(finalXPath);
        let errorMsg = ``;
        if (count > 0) {
            const qty = await this.pwWrapper.dataReader.getElementTextByXPath(finalXPath, false);
            const qtyVal = parseInt(qty);
            if (qtyVal > 0)
                fixture.logger.info(`available quantity to release for the product '${productName}' is - ${qty}`);
            else {
                errorMsg = `available quantity - ${qty} - to release for the product '${productName}' is not sufficient`;
                fixture.logger.error(errorMsg);
                throw new Error(errorMsg);
            }
            return qty;
        }
        else {
            errorMsg = `product '${productName}' is - not available for selection`
            fixture.logger.error(errorMsg);
            throw new Error(errorMsg);
        }*/
    }

    async getInventoryAvailable(productName: string): Promise<string> {
        /*const finalXPath = this.Elements.inventoryAvailableXPath.replace(this.replaceProductName, productName);
        const qty = await this.pwWrapper.dataReader.getElementTextByXPath(finalXPath, false);
        fixture.logger.info(`available inventory for the product '${productName}' is - ${qty}`);
        return qty;*/
        return await this.getProductQty(productName, this.Elements.inventoryAvailableXPath);
    }

    async getProductQty(productName: string, qtyXPathTemplate: string): Promise<string> {
        const finalXPath = qtyXPathTemplate.replace(this.replaceProductName, productName);
        const count = await this.pwWrapper.pageElement.getAvailableElementCount(finalXPath);
        let errorMsg = ``;
        if (count > 0) {
            const qty = await this.pwWrapper.dataReader.getElementTextByXPath(finalXPath, false);
            const qtyVal = parseInt(qty);
            if (qtyVal > 0)
                fixture.logger.info(`available quantity to release or inventory for the product '${productName}' is - ${qty}`);
            else {
                errorMsg = `available quantity - ${qty} - to release or inventory for the product '${productName}' is not sufficient`;
                fixture.logger.error(errorMsg);
                throw new Error(errorMsg);
            }
            return qty;
        }
        else {
            errorMsg = `product '${productName}' is - not available for selection`
            fixture.logger.error(errorMsg);
            throw new Error(errorMsg);
        }
    }

    async verifyViewLotsInfo(currentAvailableReleaseQuantities: ReleasedProduct[], productsToRelease: ReleasedProduct[]): Promise<boolean> {
        for (let i = 0; i < productsToRelease.length; i++) {
            //click on the ellipse that opens the context menu having 'View Lots' option
            let finalViewLotsEllipsisIconXPath = "(" + this.Elements.viewLotsEllipsisIconXPath + ")[" + (i + 1).toString() + "]";
            fixture.logger.info(`finalViewLotsEllipsisIconXPath value is ${finalViewLotsEllipsisIconXPath}`);

            await this.pwWrapper.elementAction.clickElement(finalViewLotsEllipsisIconXPath);
            fixture.logger.info('View Lots context menu opened');
            //click on the context menu that opens 'View Fulfillment Breakdown' screen
            await this.pwWrapper.elementAction.clickElement(this.Elements.viewLotsBtnXPath);

            while (await this.sharedBehavior.isOperationInProgress());

            //check Release Qty from the header
            let releaseQtyXPath = "(" + this.Elements.viewFulfillmentBreakdownHeaderXPath + ")[1]";
            fixture.logger.info(`releaseQtyXPath value is ${releaseQtyXPath}`);
            let releaseQty = await this.pwWrapper.dataReader.getElementTextByXPath(releaseQtyXPath, false);
            fixture.logger.info(`release quantity displayed for the product - ${productsToRelease[i].name} - is ${releaseQty}`);
            releaseQty = (releaseQty.split(":")[1]).trim();
            if (productsToRelease[i].quantity != releaseQty) {
                fixture.logger.error(`for the product ${productsToRelease[i].name} selected release quantity - ${productsToRelease[i].quantity} - and displayed release quantity - ${releaseQty} - do not match`);
                return false;
            }

            //check Total Inventory from the header
            let totalInventoryXPath = "(" + this.Elements.viewFulfillmentBreakdownHeaderXPath + ")[2]";
            fixture.logger.info(`totalInventoryXPath value is ${totalInventoryXPath}`);
            let totalInventory = await this.pwWrapper.dataReader.getElementTextByXPath(totalInventoryXPath, false);
            fixture.logger.info(`total inventory displayed for the product - ${productsToRelease[i].name} - is ${totalInventory}`);
            totalInventory = (totalInventory.split(":")[1]).trim();
            totalInventory = totalInventory.replace(',', '');
            const availableInventory = currentAvailableReleaseQuantities[i].inventory.replace(',', '');
            if (availableInventory != totalInventory) {
                fixture.logger.error(`for the product ${productsToRelease[i].name} available inventory - ${currentAvailableReleaseQuantities[i].inventory} - and displayed inventory - ${totalInventory} - do not match`);
                return false;
            }

            //check displayed product name
            const elementCount = await this.pwWrapper.pageElement.getAvailableElementCount(this.Elements.viewFulfillmentBreakdownProductNameXPath);
            let displayedProductName = "";
            if (elementCount === 1)
                displayedProductName = await this.pwWrapper.dataReader.getElementTextByXPath(this.Elements.viewFulfillmentBreakdownProductNameXPath, false);
            else {
                let finalXPath = "(" + this.Elements.viewFulfillmentBreakdownProductNameXPath + ")[1]";
                displayedProductName = await this.pwWrapper.dataReader.getElementTextByXPath(finalXPath, false);
            }
            fixture.logger.info(`displayed product name is ${displayedProductName}`);
            displayedProductName = displayedProductName.replace("[", " [");
            //if (productsToRelease[i].name != displayedProductName.trim()) {
            if (!displayedProductName.trim().includes(productsToRelease[i].name.trim())) {
                fixture.logger.error(`expected product name ${productsToRelease[i].name} and displayed product name - ${displayedProductName} - do not match`);
                return false;
            }

            //closing the fulfillment breakdown page
            await this.pwWrapper.elementAction.waitAndClickButtonByRole(this.Elements.returnToFulfillmentBtnTxt);
        }

        return true;
    }
}