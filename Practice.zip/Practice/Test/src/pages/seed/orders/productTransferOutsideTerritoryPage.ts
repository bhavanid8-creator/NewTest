import { fixture } from "../../../hooks/fixture";
import ProductOrderInfo from "../../../helpers/util/test-data/productOrder/productOrderInfo";
import BasePage from "../../basePage";
import ProductTransferPage from "./productTransferPage";

//export default class ProductTransferOutsideTerritoryPage extends BasePage {
    export default class ProductTransferOutsideTerritoryPage extends ProductTransferPage {
    displayedOrderTransferMsgLabelTxt: string;

    Elements_1 = {
        clickToSelectAccountLinkTxt: 'Click to Select Account',
        //accountNumberLabelTxt: 'Account No.',
        accountNumberPlaceholder: 'Account No.',
        searchBtnTxt: 'Search',
    }
    
    /*async canNavigateWithUrl(): Promise<boolean>{
        return false;
    }
    
    async isPageStable(){
        fixture.logger.info('checking for product-transfer-page stability');
        await super.waitUntilButtonIsDisplayed(this.Elements.closeBtnTxt);
        fixture.logger.info('checking for product-transfer-page stability completed');
        return true;
    }
    
    protected async selectUpdatedSeller(sellerName: string){
        await this.pwWrapper.dataWriter.selectAngularDropdownOption(this.Elements.updateSellerTxt, sellerName.trim());
        fixture.logger.info(`the seller - ${sellerName} - has been selected`);
    }

    protected async selectTargetDealerOrGrower(dropdownSearchText: string, primarySelectionText: string, secondarySelectionText: string = ""){
        if (secondarySelectionText.trim().length > 0) {
            await this.pwWrapper.dataWriter.selectAngularDropdownOptionWithAdditionalSearch(dropdownSearchText, primarySelectionText.trim(), secondarySelectionText.trim());
            fixture.logger.info(`new grower/dealer - ${primarySelectionText} - with the order-id - ${secondarySelectionText} - has been selected`);
        } 
        else
        { 
            await this.pwWrapper.dataWriter.selectAngularDropdownOption(dropdownSearchText, primarySelectionText.trim()); 
            fixture.logger.info(`new grower/dealer - ${primarySelectionText} - for NEW order - has been selected`);
        }
        while(await this.sharedBehavior.isOperationInProgress());
    }

    
    async fillOrderOtherDetails(){
        //fill non-subscriber email
        await this.sharedBehavior.fillNonSubscriberEmail();
    }

    
    async fillLineItemDetails(existingProductRowCount: number, transferringProductNames: string[], transferModifications: ProductOrderInfo){
        await this.completeLineItemsAction(existingProductRowCount, transferringProductNames.length, transferModifications.units, transferModifications.deliveryDate, false);
    }

    private getUnitsDecreaseBtnXPath(){
        return this.sharedBehavior.getUnitsDecreaseBtnXPath();
    }
    async clickTransfer(): Promise<string>{
        fixture.logger.info(`transfer product action has started`);
        const allPromise = await Promise.all([
            this.pwWrapper.elementAction.waitAndClickButtonByRole(this.Elements.transferUnitsBtnTxt),
            this.pwWrapper.dataReader.getElementTextById(this.Elements.successfulOrderTransferMsgId)  //toast success message on transfer successfully
        ]);
        try {
            const values = allPromise;
            this.displayedOrderTransferMsgLabelTxt = values[1].trim();
            fixture.logger.info(`transfer product action has completed with the message - "${this.displayedOrderTransferMsgLabelTxt}"`);
        } catch (error) {
            fixture.logger.error(`failed to resolve promises during product transfer...${error}`);
        }
        return this.displayedOrderTransferMsgLabelTxt;
    }

    
    async checkProductTransferMessageDisplay(msgToCheck: string): Promise<boolean>{
        fixture.logger.info(`expected msg is ${msgToCheck}`);
        return this.displayedOrderTransferMsgLabelTxt == msgToCheck;
    }

    private getUnitsTxtBoxXPath(decreaseBtnXPath: string, unitsBtnIndexPosition: number): string{
        return "((" + decreaseBtnXPath + ")[" + unitsBtnIndexPosition + "])/following-sibling::input";
    }

    async verifyOrderIdsDisplay(fromOrder: string, toOrder: string = ""){
        fixture.logger.info(`order IDs display validation on transfer product page has started`);
        const options = {timeout: 2000};
        let result = await (await this.pwWrapper.pageElement.getElementByPara(fromOrder)).isVisible(options);
        if(!result)
        {
            fixture.logger.error(`From order ID - ${fromOrder} - is not displayed on transfer product page`);
            return result;
        }

        if(toOrder.length == 0)
            toOrder = 'New Order';

        result = await (await this.pwWrapper.pageElement.getElementByPara(toOrder)).isVisible(options);

        if(!result)
        {
            fixture.logger.error(`To order ID - ${toOrder} - is not displayed on transfer product page`);
            return result;
        }
        fixture.logger.info(`order IDs display validation on transfer product page has completed`);

        return result;
    }
    async verifyLineItemsButtonsFunctionality(existingProductRowCount: number, transferringProductCount: number, deliveryDateAvailable: boolean = false): Promise<boolean>{
        fixture.logger.info(`line item fields like units, delivery date, etc., validation on transfer product page has started`);
        
        let deliveryDate = "";
        if(deliveryDateAvailable)
            deliveryDate = new Date().toString();

        const result = await this.completeLineItemsAction(existingProductRowCount, transferringProductCount, "10", deliveryDate, true);

        fixture.logger.info(`line item fields like units, delivery date, etc., validation on transfer product page has completed`);

        return result;
    }

    private async completeLineItemsAction(existingProductRowCount: number, transferringProductRowCount: number, units: string, deliveryDate: string, checkBtnActions: boolean): Promise<boolean>{
        const decreaseBtnXPath = this.getUnitsDecreaseBtnXPath();
        const increaseBtnXPath = this.sharedBehavior.getUnitsIncreaseBtnXPath();

        let expectedUnitsBtnCount = existingProductRowCount + transferringProductRowCount;

        fixture.logger.info(`decreaseBtnXPath value is ${decreaseBtnXPath}`);
        let unitsBtnIndexPosition = await this.pwWrapper.pageElement.getAvailableElementCount(decreaseBtnXPath); //this gets count on both Order Page & Product Transfer Page (if available)
        fixture.logger.info(`unitsBtnIndexPosition value is ${unitsBtnIndexPosition}`);
        if(unitsBtnIndexPosition < expectedUnitsBtnCount)
        {
            fixture.logger.error('units related element is not found on the page; either there is no single product to transfer or remaining quanity of available products is zero');
            return false;
        }
       
        for(let index=0; index<transferringProductRowCount; index++){
            //check if we can enter value into text box
            const unitsTxtBoxXPath = this.getUnitsTxtBoxXPath(decreaseBtnXPath, unitsBtnIndexPosition); //we fill values in reverse order
            fixture.logger.info(`unitsTxtBoxXPath value is ${unitsTxtBoxXPath}`);
            const count = await this.pwWrapper.pageElement.getAvailableElementCount(unitsTxtBoxXPath);
            fixture.logger.info(`count value is ${count}`);
            if(count == 0)//this will happen when we reach 2 invisible extra elements
                break;
            await this.pwWrapper.dataWriter.enterValueIntoTextboxByXPath(unitsTxtBoxXPath, units, true);
            
            if(checkBtnActions){
                //check if we can use increase button
                await this.pwWrapper.elementAction.clickIndexedElement(unitsBtnIndexPosition - 1, increaseBtnXPath);

                //check if we can use decrease button
                await this.pwWrapper.elementAction.clickIndexedElement(unitsBtnIndexPosition - 1, decreaseBtnXPath);
            }

            if(deliveryDate.length > 0){
                await this.sharedBehavior.fillDeliveryDate(unitsBtnIndexPosition - 1, deliveryDate);
            }
            unitsBtnIndexPosition--; //we fill the value in reverse order
        }

        const attemptedTrnsferQty = parseInt(units.replaceAll(",","")) * transferringProductRowCount;
        const displayedTrnsferredQty = await this.pwWrapper.dataReader.getElementTextByXPath(this.Elements.displayedTransferredQtyXPath, true);
        fixture.logger.info(`displayed transferred-units text is - ${displayedTrnsferredQty}`);

        const qty = parseInt(displayedTrnsferredQty.split("/")[0].replaceAll(",",""));

        return attemptedTrnsferQty == qty;
    }
    async canClickTransfer(): Promise<boolean>{
        fixture.logger.info(`transfer product button validation has started`);
        const result = await this.pwWrapper.elementAction.canClickButton(this.Elements.transferUnitsBtnTxt);
        fixture.logger.info(`transfer product button enabled status is: ${result}`);
        return result;
    }

    async closeTransferProductsPage(){
        await this.pwWrapper.elementAction.clickElementHavingText(this.Elements.closeBtnTxt);
    }
    */

    async selectOutsideTerritoryDealer(targetAccountNumber: string){
        targetAccountNumber = targetAccountNumber.trim();
        fixture.logger.info(`navigating to search-and-select-account page to select target dealer`);
        await this.pwWrapper.elementAction.clickElementByText(this.Elements_1.clickToSelectAccountLinkTxt);
        fixture.logger.info(`entering account number in the Account No. search field`);
        //await this.pwWrapper.dataWriter.enterValueIntoTextboxByLabel(this.Elements_1.accountNumberLabelTxt, targetAccountNumber);
        await this.pwWrapper.dataWriter.enterValueIntoTextboxByPlaceholder(this.Elements_1.accountNumberPlaceholder, targetAccountNumber);
        fixture.logger.info(`performing search with account number for the dealer - ${targetAccountNumber}`);
        await this.pwWrapper.elementAction.waitAndClickButtonByRole(this.Elements_1.searchBtnTxt);
        while(await this.sharedBehavior.isOperationInProgress());
        fixture.logger.info(`selecting `);
        await this.pwWrapper.elementAction.clickElementByText(targetAccountNumber,true);
        fixture.logger.info(`selecting target dealer is done`);
    }
}