import { Locator } from "@playwright/test";
import { fixture } from "../../../hooks/fixture";
import BasePage from "../../basePage";
import HtmlRoles from "../../../helpers/wrapper/htmlRoles";
import ProductChangeInfo from "../../../helpers/util/api/models/productChangeInfo";

export default class ReplaceOrderProductPage extends BasePage {
    
    replaceAccountNumber: string = "replace-account-number";
    replaceProductDescription: string = "replace-product-description";
    replaceTestIdValue: string = "replace-testId-value";

    Elements = {
        unitsToBeModifiedElementXPath: `((((//tr[@class='mat-row'])[2])/td)[7])//input`,
        unitsToBeModifiedElementXPathNew: `//tr/td/p[contains(text(),'${this.replaceProductDescription}')]/ancestor::tr//input`,
        //unitsToBeModifiedElementXPathByTestId: `//*[@data-testid='${this.replaceTestIdValue}']/ancestor::tr/td//input`,
        unitsToBeModifiedElementXPathByTestId: `//*[@data-testid='${this.replaceTestIdValue}']/following-sibling::td//input`,
        minusBtnXPath: `//*[@data-testid='${this.replaceTestIdValue}']//ancestor::tr//button[contains(@class, 'minusBtn')]`,
        qtyRelatedErrorTxt: `Units should be less/Equal to 'FromProduct' Units`,
        previewChangeBtnTxt: 'Preview Change',
        appProductChangeXPath: 'app-product-change',
        nextLineItemBtnName: 'Next Line Item',
        goBackToOrderBtnName: 'Preview Change',
        errorListXPath: `//*[@class='error-list']`,
    }

    /*eslint @typescript-eslint/require-await: "off" */
    async canNavigateWithUrl(): Promise<boolean>{
        return false;
    }
    
    async isPageStable(): Promise<boolean> {
        fixture.logger.info('checking for modify-product/replace-order-product-page stability');
        await super.waitUntilButtonIsDisplayed(this.Elements.previewChangeBtnTxt);
        fixture.logger.info('checking for modify-product/replace-order-product-page stability completed');
        return true;
    }
    
    /**
     * Returns true if at least one product is found
     * @param units 
     * @returns 
     */
    async setTopReplaceableProductQtyIfFound(units: string): Promise<boolean> {
        const replaceableProductsCount = await this.pwWrapper.pageElement.getAvailableElementCount(this.Elements.unitsToBeModifiedElementXPath);
        if (replaceableProductsCount == 0) {
            fixture.logger.info(`could not find any replaceable products`);
            return false;
        }

        let unitsElement: Locator;

        if (replaceableProductsCount == 1) {
            fixture.logger.info(`found one replaceable product`);
            unitsElement = await this.pwWrapper.elementAction.clickElement(this.Elements.unitsToBeModifiedElementXPath);
            const validationMsg = await this.fillQtyAndCheckValidity(unitsElement, units);
            let result = true;
            if (validationMsg.length > 0) {
                fixture.logger.error('there was error in updating the quantity:' + validationMsg);
                result = false;
            } else {
                fixture.logger.info(`updated units of the new replaced product`);
            }
            return result;
        }
        else {
            fixture.logger.info(`found multiple replaceable products`);
            let atleastOneProductIsSelected = false;
            for (let index = 0; index < replaceableProductsCount; index++) {
                unitsElement = await this.pwWrapper.elementAction.clickIndexedElement(index, this.Elements.unitsToBeModifiedElementXPath);
                const validationMsg = await this.fillQtyAndCheckValidity(unitsElement, units);
                if (validationMsg.length == 0) {
                    atleastOneProductIsSelected = true;
                    fixture.logger.info(`updated units of the new replaced product`);
                    break;
                } else {
                    fixture.logger.error('there was error in updating the quantity:' + validationMsg);
                }
            }
            return atleastOneProductIsSelected;
        }
    }

    async setReplaceableProductQty_obsolete(productChangeInfo: ProductChangeInfo): Promise<boolean> {
        const finalXPath = this.Elements.unitsToBeModifiedElementXPathNew.replace(this.replaceProductDescription, productChangeInfo.itemDescription);
        const replaceableProductsCount = await this.pwWrapper.pageElement.getAvailableElementCount(finalXPath);
        if (replaceableProductsCount == 0) {
            fixture.logger.info(`could not find any replaceable products`);
            return false;
        }

        let unitsElement: Locator;

        if (replaceableProductsCount == 1) {
            fixture.logger.info(`found one replaceable product`);
            unitsElement = await this.pwWrapper.elementAction.clickElement(finalXPath);
            const validationMsg = await this.fillQtyAndCheckValidity(unitsElement, productChangeInfo.conv.toString());
            let result = true;
            if (validationMsg.length > 0) {
                fixture.logger.error('there was error in updating the quantity:' + validationMsg);
                result = false;
            } else {
                fixture.logger.info(`updated units of the new replaced product`);
            }
            return result;
        }
        else {
            fixture.logger.info(`found multiple replaceable products`);
            let atleastOneProductIsSelected = false;
            for (let index = 0; index < replaceableProductsCount; index++) {
                unitsElement = await this.pwWrapper.elementAction.clickIndexedElement(index, finalXPath);
                const validationMsg = await this.fillQtyAndCheckValidity(unitsElement, productChangeInfo.conv.toString());
                if (validationMsg.length == 0) {
                    atleastOneProductIsSelected = true;
                    fixture.logger.info(`updated units of the new replaced product`);
                    break;
                } else {
                    fixture.logger.error('there was error in updating the quantity:' + validationMsg);
                }
            }
            return atleastOneProductIsSelected;
        }
    }

    async setReplaceableProductQty(productChangeInfo: ProductChangeInfo): Promise<boolean> {
        const finalXPath = this.Elements.unitsToBeModifiedElementXPathByTestId.replace(this.replaceTestIdValue, productChangeInfo.itemNumber);
        const finalMinusBtnXPath = this.Elements.minusBtnXPath.replace(this.replaceTestIdValue, productChangeInfo.itemNumber)
        const replaceableProductsCount = await this.pwWrapper.pageElement.getAvailableElementCount(finalXPath);
        if (replaceableProductsCount == 0) {
            fixture.logger.info(`could not find any replaceable products`);
            return false;
        }

        let unitsElement: Locator;

        if (replaceableProductsCount == 1) {
            fixture.logger.info(`found one replaceable product`);
            unitsElement = await this.pwWrapper.elementAction.clickElement(finalXPath);
            const validationMsg = await this.fillQtyAndCheckValidity(unitsElement, productChangeInfo.conv.toString());
            let result = true;
            if (validationMsg.length > 0) {
                fixture.logger.error('there was error in updating the quantity:' + validationMsg);
                if(validationMsg.trim() == this.Elements.qtyRelatedErrorTxt.trim())
                {
                    fixture.logger.info('attempting to revert the quantity');
                    //error was due to target product conversion qty is greater than source product available qty.
                    //hence we revert the qty that we entered using the minus button
                    await this.pwWrapper.elementAction.clickElement(finalMinusBtnXPath);
                }
                result = false;
            } else {
                fixture.logger.info(`updated units of the new replaced product`);
            }
            return result;
        }
        else {
            fixture.logger.info(`found multiple replaceable products`);
            let atleastOneProductIsSelected = false;
            for (let index = 0; index < replaceableProductsCount; index++) {
                unitsElement = await this.pwWrapper.elementAction.clickIndexedElement(index, finalXPath);
                const validationMsg = await this.fillQtyAndCheckValidity(unitsElement, productChangeInfo.conv.toString());
                if (validationMsg.length == 0) {
                    atleastOneProductIsSelected = true;
                    fixture.logger.info(`updated units of the new replaced product`);
                    break;
                } else { 
                    fixture.logger.warn('there was error in updating the quantity:' + validationMsg);
                    if(validationMsg.trim() == this.Elements.qtyRelatedErrorTxt.trim())
                    {
                        fixture.logger.info('attempting to revert the quantity');
                        //error was due to target product conversion qty is greater than source product available qty.
                        //hence we revert the qty that we entered using the minus button
                        await this.pwWrapper.elementAction.clickIndexedElement(index, finalMinusBtnXPath);
                    }
                }
            }
            return atleastOneProductIsSelected;
        }
    }
    private async fillQtyAndCheckValidity(unitsElement: Locator, units: string): Promise<string>{
        fixture.logger.info(`about to fill units`);
        await unitsElement.fill(units.trim());
        await this.pwWrapper.keyBoard.tabOutToNextElement();
        //if replaceble product available qty is zero then page will display errors
        const errorMsgCount = await this.pwWrapper.pageElement.getAvailableElementCount(this.Elements.errorListXPath);
        let qtyValidationMsg = "";
        if(errorMsgCount > 0)
        {
            qtyValidationMsg = await this.pwWrapper.dataReader.getElementTextByXPath(this.Elements.errorListXPath, true);
        }
        return qtyValidationMsg;
    }
    async isAnotherLineItemAvailable(): Promise<boolean>{
        //return await (await this.pwWrapper.pageElement.getButton(this.Elements.nextLineItemBtnName)).count() > 0;
        return await this.pwWrapper.pageElement.getAvailableElementCountByRole(HtmlRoles.BUTTON, this.Elements.nextLineItemBtnName) > 0;
    }

    async moveToNextLineItem(){
        await (await this.pwWrapper.pageElement.getButton(this.Elements.nextLineItemBtnName)).click();
        while(await this.sharedBehavior.isOperationInProgress());
    }

    async goBackToOrder(){
        await (await this.pwWrapper.pageElement.getButton(this.Elements.goBackToOrderBtnName)).click();
        while(await this.sharedBehavior.isOperationInProgress());
    }
}