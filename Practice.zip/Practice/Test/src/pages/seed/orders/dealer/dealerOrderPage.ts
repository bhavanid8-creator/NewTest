import ProductOrderInfo from "../../../../helpers/util/test-data/productOrder/productOrderInfo";
import ProductOrderLineItemInfo from "../../../../helpers/util/test-data/productOrder/productOrderLineItemInfo";
import HtmlRoles from "../../../../helpers/wrapper/htmlRoles";
import { fixture } from "../../../../hooks/fixture";
import AngularElements from "../../../angularElements";
import BasePage from "../../../basePage";

export default class DealerOrderPage extends BasePage {

    //replaceUnitsIndex: string = "replaceUnitsIndex";
    replaceProductName: string = "replaceProductName";
    replaceItemId: string = "replaceItemId";
    repalceIndex: string = "replaceIndex";
    replaceTestIdValue = 'replace-testId-value';

    Elements = {
        createNewGrowerOrderBtnTxt: 'Create New Grower Order',
        addProductBtnName: "Add Product",
        addEAProductBtnName: "Add EA Product",
        productOrderUnitCssId: '#txtUnits',
        successfulButtonClickActionMsgId: 'toast-container',
        productAddedLabelTxt: 'Product Added',
        //unitsInputXPath: `(//input[@type='text'])[${this.replaceUnitsIndex}]`,
        unitsInputXPath: `(//div[text()=' ${this.replaceProductName} ']/../../../../../td//input)[2]`,
        placeOrderSuccessfulMessageText_beginning: "Dealer Order #",
        placeOrderSuccessfulMessageText_ending: " saved successfully.",
        transferProductBtnTooltip: 'Transfer Product',
        transferProductOutsideTerritoryBtnTooltip: 'Transfer Outside Territory',
        eaProductRowOnOrderPageXPath: `(//div[text()='${this.replaceItemId}']/ancestor::tr/td)[${this.repalceIndex}]`,
        eaOrderLevelBtnTxt: 'EA',
        modityEAUnitsBtnTxt: 'Modify EA Units',
        //qtyUpdateButtonsContainerSelector: `#modifyTableContainer`,
        swapEAProductBtnTxt: 'Swap EA Product',
        decreaseEAProductUnitsBtnTxt: 'Decrease EA Units',
        //modifyEAProductQtyInputXPath: `(//td[contains(@class, 'eaModifiableUnits')]//input)[2]`,
        lineItemWithTestIdXPath: `//*[contains(@data-testid, '${this.replaceTestIdValue}')]/ancestor::td/following-sibling::td//input`,
        productDetailRowXPath: `//tr[contains(@class, 'example-element-row')]`,
        productByTestIdXPath: `//*[@data-testid='${this.replaceTestIdValue}']`,
        eaUnitsTxtXPath: `//div[contains(@data-testid, '${this.replaceTestIdValue}')]/ancestor::tr//div[contains(@class, 'eaUnitsColumn')]//span`,
        lineItemCheckboxXPath: `(//div[contains(@data-testid, '${this.replaceTestIdValue}')]/ancestor::tr/td)[1]`,
        lineItemQtyXPath: `//input[contains(@data-testid, 'qty-${this.replaceTestIdValue}')]`,
    }

    async isPageStable() {
        fixture.logger.info('checking for order-page stability');
        await super.waitUntilButtonIsDisplayed(this.Elements.createNewGrowerOrderBtnTxt);
        fixture.logger.info('checking for order-page stability completed');
        return true;
    }

    async isOrderEditable():Promise<boolean>{
        const count = await this.pwWrapper.pageElement.getAvailableElementCountByRole(HtmlRoles.BUTTON, this.Elements.addProductBtnName);
        return count > 0;
    }

    async clickAddProductBtn(){
        await this.pwWrapper.elementAction.waitAndClickButtonByRole(this.Elements.addProductBtnName);
        while (await this.sharedBehavior.isOperationInProgress());
        //if account is not eligible for ordering, clicking on Add-Product will result in a toast message
        const count = await this.pwWrapper.pageElement.getAvailableElementCountById(this.Elements.successfulButtonClickActionMsgId);
        return count == 0;
    }

    private async getEAProductRowCellElementXPath(itemNumber: string, cellIndex: string): Promise<string>{
        let eaProductRowOnOrderPageXPath = this.Elements.eaProductRowOnOrderPageXPath.replace(this.replaceItemId, itemNumber);
        eaProductRowOnOrderPageXPath = eaProductRowOnOrderPageXPath.replace(this.repalceIndex, cellIndex);
        const productRowCount = await this.pwWrapper.pageElement.getAvailableElementCount(eaProductRowOnOrderPageXPath);
        if(productRowCount === 0)
            return ""; //order does not have products matching with the item number
        else
            return eaProductRowOnOrderPageXPath;
    }
    async calculateCurrentEAProductCount_obsolete(itemNumber: string): Promise<number>{
        while (await this.sharedBehavior.isOperationInProgress());
        let eaUnitsOnOrderPageXPath = await this.getEAProductRowCellElementXPath(itemNumber, "9")
        if(eaUnitsOnOrderPageXPath.length === 0)
            return 0; //order does not have products matching with the item number
        let eaUnitsValue = await this.pwWrapper.dataReader.getElementTextByXPath(eaUnitsOnOrderPageXPath,true);
        fixture.logger.info(`eaUnitsValue is---${eaUnitsValue}`);
        eaUnitsValue = eaUnitsValue.replace("EA Units","");
        eaUnitsValue = eaUnitsValue.replace(",","");
        return parseInt(eaUnitsValue);
    }

    async getEAUnitsValue(itemNumber: string): Promise<number>{
        while (await this.sharedBehavior.isOperationInProgress());
        let eaUnitsOnOrderPageXPath = this.Elements.eaUnitsTxtXPath.replace(this.replaceTestIdValue, itemNumber);
        let eaUnitsValue = await this.pwWrapper.dataReader.getElementTextByXPath(eaUnitsOnOrderPageXPath,true);
        eaUnitsValue = eaUnitsValue.replace(",", "");
        fixture.logger.info(`displayed EA Units Value is---${eaUnitsValue}`);
        return parseInt(eaUnitsValue);
    }

    async clickAddEAProductBtn(){
        await this.pwWrapper.elementAction.waitAndClickButtonByRole(this.Elements.addEAProductBtnName);
        while (await this.sharedBehavior.isOperationInProgress());
        //if account is not eligible for ordering, clicking on Add-Product will result in a toast message
        const count = await this.pwWrapper.pageElement.getAvailableElementCountById(this.Elements.successfulButtonClickActionMsgId);
        return count == 0;
    }

    async checkProductsAddedMessageDisplay(){
        while (await this.sharedBehavior.isOperationInProgress());
        await this.pwWrapper.elementAction.clickElementByLabel(this.Elements.productAddedLabelTxt);
    }
    async fillProductOrderDetails_obsolete(productOrdersInfo: ProductOrderLineItemInfo[], isNewOrder: boolean){
        for(let index=0; index<productOrdersInfo.length; index++){
            await this.fillOrderLineItemDetails_obsolete(productOrdersInfo[index].productInfo.name
            , productOrdersInfo[index].productOrderInfo, 2000);
            await this.pwWrapper.keyBoard.tabOutToNextElement();
        }
    }

    async fillProductOrderDetails(productOrdersInfo: ProductOrderLineItemInfo[]){
        for(let index=0; index<productOrdersInfo.length; index++){
            await this.fillOrderLineItemDetails(productOrdersInfo[index].productInfo.itemNumber
            , productOrdersInfo[index].productOrderInfo, 5000);
            await this.pwWrapper.keyBoard.tabOutToNextElement();
        }
    }
    async delayOrderPageOperation(delayOperationUntilMillSec: number = 0){
        if(delayOperationUntilMillSec > 0)
            await this.pwWrapper.common.delay(delayOperationUntilMillSec);
    }
    // /**
    //  * zero-based indexed method to fill top line item details
    //  * @param index 
    //  * @param productOrderInfo 
    //  * @param delayOperationUntilMillSec 
    //  */
    // async fillIndexedOrderLineItemDetails(index: number, productOrderInfo: ProductOrderInfo, delayOperationUntilMillSec: number = 0){
    //     await this.delayOrderPageOperation(delayOperationUntilMillSec);

    //     const finalUnitsXPath = this.Elements.unitsInputXPath.replace(this.replaceUnitsIndex, index.toString());
    //     await this.pwWrapper.dataWriter.enterValueIntoTextboxByXPath(finalUnitsXPath, "");
    //     await this.pwWrapper.dataWriter.enterValueIntoTextboxByXPath(finalUnitsXPath, productOrderInfo.units);
    // }

    async fillOrderLineItemDetails_obsolete(productName: string, productOrderInfo: ProductOrderInfo, delayOperationUntilMillSec: number = 0){
        await this.delayOrderPageOperation(delayOperationUntilMillSec);

        const finalUnitsXPath = this.Elements.unitsInputXPath.replace(this.replaceProductName, productName);
        const count = await this.pwWrapper.pageElement.getAvailableElementCount(finalUnitsXPath);
        if (count == 1) {
            await this.pwWrapper.dataWriter.enterValueIntoTextboxByXPath(finalUnitsXPath, "");
            await this.pwWrapper.dataWriter.enterValueIntoTextboxByXPath(finalUnitsXPath, productOrderInfo.units);
        }else if (count > 1) {
            await this.pwWrapper.dataWriter.enterValueIntoIndexedTextboxByXPath(0, finalUnitsXPath, "");
            await this.pwWrapper.dataWriter.enterValueIntoIndexedTextboxByXPath(0, finalUnitsXPath, productOrderInfo.units);
        }else{
            throw new Error("could not find units field for the specified product " + productName);
        }
    }

    async fillOrderLineItemDetails(productItemNumber: string, productOrderInfo: ProductOrderInfo, delayOperationUntilMillSec: number = 0){
        await this.delayOrderPageOperation(delayOperationUntilMillSec);

        /*let rowIndex = 0;
        const allRowLocators = await this.page.locator(this.Elements.productDetailRowXPath).all(); //retrieve all rows
        const targetRowXPath = this.Elements.productByTestIdXPath.replace(this.replaceTestIdValue, productItemNumber);
        let rowFound = false;
        for(; rowIndex < allRowLocators.length; rowIndex++){
            const count = await allRowLocators[rowIndex].locator(targetRowXPath).count(); // check for specific element 
            if (count > 0) {
                rowFound = true;
                break; //we found the specific row
            }
        }
        if(!rowFound)
            throw new Error(`could not find a line item row in the order matching the product description ${productItemNumber}`);

        const unitsElement = this.page.locator(this.Elements.productOrderUnitCssId).nth(rowIndex);*/
        const finalXPath = this.Elements.lineItemQtyXPath.replace(this.replaceTestIdValue, productItemNumber);
        const unitsElement = await this.pwWrapper.pageElement.getElementByXPath(finalXPath);
        await this.sharedBehavior.fillUnits(unitsElement, productOrderInfo.units);
    }
    async selectLineitem(productName: string){
        //when units field is clicked for a line item then that line item will be automatically selected 
        fixture.logger.info(`selecting the product - ${productName}`);
        const finalUnitsXPath = this.Elements.unitsInputXPath.replace(this.replaceProductName, productName);
        const count = await this.pwWrapper.pageElement.getAvailableElementCount(finalUnitsXPath);
        fixture.logger.info(`finalUnitsXPath is ${finalUnitsXPath}`);
        fixture.logger.info(`count is ${count}`);
        if (count == 1) {
            await this.pwWrapper.elementAction.clickElement(finalUnitsXPath);
        }else if (count > 1) {
            await this.pwWrapper.elementAction.clickIndexedElement(0, finalUnitsXPath);
        }else{
            throw new Error("could not find lineitem for the specified product " + productName);
        }
    }

    private async triggerOrderLevelActionByTooltip(toolTipText: string){
        await this.pwWrapper.elementAction.clickElementByNameAndAttributeValue(HtmlRoles.LIST_ITEM, AngularElements.matTooltip, toolTipText);
        while(await this.sharedBehavior.isOperationInProgress());
    }
 
    async navigateToTransferProduct(){
        await this.triggerOrderLevelActionByTooltip(this.Elements.transferProductBtnTooltip);
        fixture.logger.info('navigated to transfer-product page');
    }

    async navigateToTransferProductOutsideTerritory(){
        await this.triggerOrderLevelActionByTooltip(this.Elements.transferProductOutsideTerritoryBtnTooltip);
        fixture.logger.info('navigated to transfer-product-outside-territory page');
    }

    /**
     * This method assumes specified product EXISTS on the order 
     * If the product does not exists, this method will throw error because it is trying to perform an operation on an element that is NULL
     * @param itemNumber 
     */
    async selectEAProductRow(itemNumber: string){
        //let rowCheckboxOnOrderPageXPath = await this.getEAProductRowCellElementXPath(itemNumber, "1")
        let rowCheckboxOnOrderPageXPath = this.Elements.lineItemCheckboxXPath.replace(this.replaceTestIdValue, itemNumber);
        await this.pwWrapper.elementAction.clickElement(rowCheckboxOnOrderPageXPath);
    }

    async openModifyEAUnitsPage(){
        await this.openEAFeaturePage(this.Elements.modityEAUnitsBtnTxt);
    }

    async openDecreaseEAUnitsPage(){
        await this.openEAFeaturePage(this.Elements.decreaseEAProductUnitsBtnTxt);
    }

    async openSwapEAUnitsPage(){
        await this.openEAFeaturePage(this.Elements.swapEAProductBtnTxt);
    }

    private async openEAFeaturePage(featureBtnTxt: string){
        await this.pwWrapper.elementAction.waitAndClickButtonByText(this.Elements.eaOrderLevelBtnTxt, true);
        await this.pwWrapper.elementAction.waitAndClickButtonByRole(featureBtnTxt);
        while (await this.sharedBehavior.isOperationInProgress());
    }

    async incrementUnitsIfLineItemAvailable(itemNumber: string, unitsValue: string): Promise<{orderContainsTheProduct: boolean, qtyIncremented?: boolean}>{
        const finalXPath = this.Elements.lineItemWithTestIdXPath.replace(this.replaceTestIdValue, itemNumber);
        return await this.sharedBehavior.incrementProductUnitsIfLineItemAvailable(finalXPath, itemNumber, unitsValue, false);
    }
}