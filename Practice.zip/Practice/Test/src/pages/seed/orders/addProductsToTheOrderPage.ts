import { Locator } from "@playwright/test";
import AngularElements from "../../angularElements";
import HtmlRoles from "../../../helpers/wrapper/htmlRoles";
import { fixture } from "../../../hooks/fixture";
import BasePage from "../../basePage";

export default class AddProductsToTheOrderPage extends BasePage {
    
    readonly replaceTestIdValue = 'replace-testId-value';
    readonly product_search_category_product_name = 'Product Name';
    readonly replaceProductNameInSearchResult = 'product-name';
    
    Elements = {
        productSearchFilterDropDownTestId: "ddl-itemNumber-search",
        searchProductDropDownText: "Search Product",
        searchBtnTestId: "btn-orderfilter-search",
        productNameInSearchResultXPath: `//p[contains(@class,'grower-name')]/a[contains(text(),'${this.replaceProductNameInSearchResult}')]`,//`//a[contains(text(),'${this.replaceProductNameInSearchResult}')]`,
        addToOrderButtonId: "btn-add-to-order",
        addToOrderButtonName: 'Add to Order',
        onlyShowProductWithAvailabilityXPath: "//div[text()='Only show product with availability']/../mat-checkbox",
        onlyShowProductOnDealerOrderXPath: "//div[text()='Only show product on Dealer Order']/../mat-checkbox",
        clearAllLinkText: "Clear All",//clears search text and search results; retains selected search filters
        productsNotFoundXPath: `//*[contains(text(), ' Product(s) not found for the selected criteria ')]`,
        searchResultTestIdXPath: `//td[@data-testid='${this.replaceTestIdValue}']`,
    }

    /*eslint @typescript-eslint/require-await: "off" */
    async canNavigateWithUrl(): Promise<boolean>{
        return false;
    }
    
    private async isPageLoaded(): Promise<boolean>{
        while (await this.sharedBehavior.isOperationInProgress());
        /*await this.pwWrapper.pageElement.getSearchableDropDownHavingText(
            AngularElements.ng_select,this.Elements.searchProductDropDownText);*/
        await super.waitUntilPlaceholderIsDisplayed(this.Elements.searchProductDropDownText);
        return true;
    }

    async isPageStable(){
        fixture.logger.info('checking for add-products-to-the-order-page stability');
        await this.isPageLoaded();

        fixture.logger.info('checking for add-products-to-the-order-page stability completed');
        return true;
    }
    async clickSearchFilterDropDown(){
        //await this.pwWrapper.elementAction.clickItemByTestIdAndRole(this.Elements.productSearchFilterDropDownTestId, HtmlRoles.COMBOBOX);
        await this.pwWrapper.elementAction.clickElementByTestId(this.Elements.productSearchFilterDropDownTestId);
        await this.pwWrapper.common.delay(1000);
    }

    async selectSearchFilterItemInTheDropDown(filterOption: string){
        await this.pwWrapper.dataWriter.selectOption(filterOption);
        await this.pwWrapper.common.delay(1000);
    }
    async searchProduct(//isFirstSearch: boolean, 
        searchText: string, isSearchByFreeText: boolean, onlyShowProductOnDealerOrder: boolean = false
            , onlyShowProductWithAvailability: boolean = false): Promise<boolean>{
        if (onlyShowProductOnDealerOrder) {
            const checkBox1 = this.page.locator(this.Elements.onlyShowProductOnDealerOrderXPath);
            await checkBox1.click();
        }

        fixture.logger.info("onlyShowProductOnDealerOrder - check is over");
        
        if (onlyShowProductWithAvailability) {
            const checkBox2 = this.page.locator(this.Elements.onlyShowProductWithAvailabilityXPath);
            await checkBox2.click();
        }

        fixture.logger.info("onlyShowProductWithAvailability - check is over");
        
        let searchTextBox: Locator;
        try{
            fixture.logger.info(`about to click product search box`);
            searchTextBox = this.page.getByPlaceholder(this.Elements.searchProductDropDownText);
        }catch(error){
            fixture.logger.info(`failed to click product search box first time. Error: ${error}`);
            try{
                searchTextBox = this.page.locator('ng-select').filter({ hasText: 'Search Product' }).getByRole('textbox');
            }catch(err){
                fixture.logger.info(`failed to click product search box second time. Error: ${err}`);
                searchTextBox = this.page.locator('div').filter({ hasText: /^Search Product$/ }).nth(3);
                fixture.logger.info(`completed clicking product search box third time.`);
            }
        }
        await searchTextBox.click({ force: true });
        if (!isSearchByFreeText) {
            try{
                //await this.sharedBehavior.selectAngularDropdownOptionByPlaceholder(this.Elements.searchProductDropDownText, searchText);
                await this.sharedBehavior.selectAngularDropdownOptionByPlaceholderFromPanel(this.Elements.searchProductDropDownText, searchText);
            }catch(err){
                fixture.logger.error('failed...' + err);
            }
        } else {
            await searchTextBox.fill(searchText);
        }

        await this.pwWrapper.elementAction.clickElementByTestId(this.Elements.searchBtnTestId);

        while(await this.sharedBehavior.isOperationInProgress());
        const resultCount = await this.pwWrapper.pageElement.getAvailableElementCount(this.Elements.productsNotFoundXPath);
        if(resultCount != 0){
            fixture.logger.error(`search returned zero products`);
            return false;
        }else{
            return true;
        }
    }

    async clearProductSearchResults(){
        await (await this.pwWrapper.pageElement.getVisibleElementByLinkName(this.Elements.clearAllLinkText)).click();
    }
    async selectProductsFromSearchResult(productNamesToSelect: string[]){
        fixture.logger.info(`following products are being selected: ${productNamesToSelect.toString()}`);
        while(await this.sharedBehavior.isOperationInProgress());

        for(let index=0; index<productNamesToSelect.length; index++){
            //await this.page.locator('a').filter({ hasText: `${productNamesToSelect[index]}`}).first().click();
            const finalXPath = this.Elements.productNameInSearchResultXPath.replace(this.replaceProductNameInSearchResult, productNamesToSelect[index]);
            fixture.logger.info(`product selection XPath is - ${finalXPath}`);
            await this.page.locator(finalXPath).first().click();
            fixture.logger.info(`selected product is - ${productNamesToSelect[index]}`);
        }
    }

    async selectProductsFromSearchResultByTestId(testIdValuesToSelect: string[]){
        fixture.logger.info(`following products are being selected: ${testIdValuesToSelect.toString()}`);
        while(await this.sharedBehavior.isOperationInProgress());

        for(let index=0; index<testIdValuesToSelect.length; index++){
            const finalXPath = this.Elements.searchResultTestIdXPath.replace(this.replaceTestIdValue, testIdValuesToSelect[index]);
            fixture.logger.info(`product selection XPath is - ${finalXPath}`);
            await this.page.locator(finalXPath).first().click();
            fixture.logger.info(`selected product is - ${testIdValuesToSelect[index]}`);
        }
    }

    async isAddToOrderButtonEnabled(): Promise<boolean>{
        while(await this.sharedBehavior.isOperationInProgress());
        return (await this.pwWrapper.pageElement.getElementById(this.Elements.addToOrderButtonId)).isEnabled();
    }
    async clickAddToOrderButton(): Promise<string> {
        
        while(await this.sharedBehavior.isOperationInProgress());

        //await this.pwWrapper.elementAction.clickElementById(this.Elements.addToOrderButtonName);
        const msg = await this.sharedBehavior.clickButtonAndInspectSuccessMessage("adding product(s) to the order",this.Elements.addToOrderButtonName);
        while(await this.sharedBehavior.isOperationInProgress());
        return msg;
    }
    
}