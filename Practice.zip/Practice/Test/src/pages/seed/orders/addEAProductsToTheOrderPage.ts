import { Locator } from "@playwright/test";
import AngularElements from "../../angularElements";
import HtmlRoles from "../../../helpers/wrapper/htmlRoles";
import { fixture } from "../../../hooks/fixture";
import BasePage from "../../basePage";
import ProductInfo from "../../../helpers/util/test-data/product/productInfo";
import KeyBoardItems from "../../../helpers/wrapper/keyBoardItems";

export default class AddEAProductsToTheOrderPage extends BasePage {
    
    readonly product_search_category_item_number = 'Item Number';
    readonly product_search_category_product_name = 'Product Name';
    readonly replaceProductName = 'replace-product-name';
    readonly replaceProductItemNumber = 'replace-product-item-number';
    
    Elements = {
        productSearchFilterDropDownTestId: "ddl-itemNumber-search",
        //eaProductSearchParentElementXPath: 'app-filter',
        eaProductSearchParentElementXPath: `//ng-select[contains(@name,'ddlOptions')]`,
        searchEAProductFieldPlaceholderText: "Search...",
        searchBtnTestId: "btn-filter-search",
        //productNameInSearchResultXPath: `//a[contains(text(),'${this.replaceProductNameInSearchResult}')]`,
        updateOrderButtonXPath: `//*[text()='Update Order']`,
        updateOrderButtonName: 'Update Order',
        displayDealerOrderEarlyAdvantageUnitsXPath: "//div[text()='Display Dealer Order Early Advantage Units']/../mat-checkbox",
        clearAllLinkText: "Clear All",//clears search text and search results; retains selected search filters
        productQtyInputXPath_obsolete: `//app-ea-add-product//*[contains(text(), ' ${this.replaceProductName} ')]/../../../../..//input`,
        productsNotFoundXPath: `//*[contains(text(), 'No Record Found')]`,
        qtyUpdateButtonsContainerSelector: `#modifyTableContainer`,
        modifyEAProductQtyInputXPath: `(//td[contains(@class, 'eaModifiableUnits')]//input)[2]`,
        swappingProductQtyInputXPath_obsolete: `//div[contains(@class, 'shipToLocation')]//div[contains(text(),'${this.replaceProductName}')]/ancestor::tr/td[last()]//input`,
        productQtyInputXPath: `//*[contains(@data-testid, 'qty-ea-${this.replaceProductItemNumber}')]`
    }

    /*eslint @typescript-eslint/require-await: "off" */
    async canNavigateWithUrl(): Promise<boolean>{
        return false;
    }
    
    private async isPageLoaded(): Promise<boolean>{
        while (await this.sharedBehavior.isOperationInProgress());
        //await super.waitUntilPlaceholderIsDisplayed(this.Elements.searchEAProductFieldPlaceholderText);
        //await super.waitUntilButtonIsDisplayed(this.Elements.updateOrderButtonName);
        return true;
    }

    async isPageStable(){
        fixture.logger.info('checking for add-ea-products-to-the-order-page stability');
        await this.isPageLoaded();

        fixture.logger.info('checking for add-ea-products-to-the-order-page stability completed');
        return true;
    }

    async clickEASearchFilterDropDown(){
        //await this.pwWrapper.elementAction.clickItemByLocatorAndRole(this.Elements.eaProductSearchParentElementXPath, HtmlRoles.COMBOBOX);
        await this.pwWrapper.elementAction.clickElement(this.Elements.eaProductSearchParentElementXPath);
    }

    async selectSearchFilterItemInTheDropDown(filterOption: string){
        await this.pwWrapper.dataWriter.selectOption(filterOption);
    }
    
    async searchEAProduct(searchText: string, isSearchByFreeText: boolean, displayDealerOrderEarlyAdvantageUnits: boolean): Promise<boolean>{
        if (!displayDealerOrderEarlyAdvantageUnits) //by default this option is in CHECKED state; so click it only when displayDealerOrderEarlyAdvantageUnits is false
        {
            const checkBox1 = this.page.locator(this.Elements.displayDealerOrderEarlyAdvantageUnitsXPath);
            await checkBox1.click();
        }

        fixture.logger.info("displayDealerOrderEarlyAdvantageUnits - check is over");
        
        let searchTextBox: Locator;
        try{
            searchTextBox = this.page.getByPlaceholder(this.Elements.searchEAProductFieldPlaceholderText);
        }catch(error){
            try{
                searchTextBox = this.page.locator('ng-select').filter({ hasText: 'Search...' }).getByRole('textbox');
            }catch(err){
                searchTextBox = this.page.locator('div').filter({ hasText: /^Search...$/ }).nth(3);
            }
        }
        
        await searchTextBox.click({ force: true });
        if (!isSearchByFreeText) {
            //await this.pwWrapper.dataWriter.enterValueIntoTextboxByTestIdAndRole(this.Elements.productSearchFilterDropDownTestId, searchText); 
            await this.pwWrapper.dataWriter.selectAngularDropdownOptionFromPanel(this.Elements.searchEAProductFieldPlaceholderText, searchText);
        } else {
            await searchTextBox.fill(searchText);
        }
        // await searchTextBox.fill(searchText.trim());
        // if (!isSearchByFreeText) {
        //     await searchTextBox.press(KeyBoardItems.ENTER);
        // }
        await this.pwWrapper.elementAction.clickElementByTestId(this.Elements.searchBtnTestId);

        while(await this.sharedBehavior.isOperationInProgress());
        const resultCount = await this.pwWrapper.pageElement.getAvailableElementCount(this.Elements.productsNotFoundXPath);
        if(resultCount != 0){
            fixture.logger.error(`search returned zero EA products`);
            return false;
        }else{
            return true;
        }
    }
    
    async clearProductSearchResults(){
        await (await this.pwWrapper.pageElement.getVisibleElementByLinkName(this.Elements.clearAllLinkText)).click();
    }
    async selectProductsFromSearchResult(productNamesToSelect: string[], productQuantites: string[]){
        while(await this.sharedBehavior.isOperationInProgress());

        let finalXPath = "";
        for(let index=0; index<productNamesToSelect.length; index++){
            finalXPath = this.Elements.productQtyInputXPath_obsolete.replace(this.replaceProductName, productNamesToSelect[index].trim());
            await this.pwWrapper.dataWriter.enterValueIntoTextboxByXPath(finalXPath, productQuantites[index], true);
        }
    }

    async selectProductsByItemNumberFromSearchResult(productItemNumbersToSelect: string[], productQuantites: string[]){
        while(await this.sharedBehavior.isOperationInProgress());

        let finalXPath = "";
        for(let index=0; index<productItemNumbersToSelect.length; index++){
            finalXPath = this.Elements.productQtyInputXPath.replace(this.replaceProductItemNumber, productItemNumbersToSelect[index].trim());
            await this.pwWrapper.dataWriter.enterValueIntoTextboxByXPath(finalXPath, productQuantites[index], true);
        }
    }
    async isUpdateOrderButtonEnabled(): Promise<boolean>{
        while(await this.sharedBehavior.isOperationInProgress());
        //let xpath = this.Elements.updateOrderButtonXPath;
        //if(!isPageAddProducts)
        //return (await this.pwWrapper.pageElement.getElementByXPath(xpath)).isEnabled();
        return await (await this.pwWrapper.pageElement.getButton(this.Elements.updateOrderButtonName)).isEnabled();
    }
    async clickUpdateOrderButton(): Promise<string> {
        while(await this.sharedBehavior.isOperationInProgress());

        //await this.pwWrapper.elementAction.clickElementById(this.Elements.addToOrderButtonName);
        const msg = await this.sharedBehavior.clickButtonAndInspectSuccessMessage("updating order with EA product(s)",this.Elements.updateOrderButtonName);
        while(await this.sharedBehavior.isOperationInProgress());
        return msg;
    }
    
    /**
     * This method assumes there is only ONE product to modify quantity.
     * If there are multiple products, this method will throw error because there will be multiple "+" and "-" buttons
     * @param shouldReduceQty 
     */
    async modifyEAUnitsWithButtons(shouldReduceQty: boolean){
        const qtyUpdateBtnName = shouldReduceQty ? "-" : "+";
        await this.pwWrapper.elementAction.clickChildElementByRole(
            this.Elements.qtyUpdateButtonsContainerSelector,HtmlRoles.BUTTON,qtyUpdateBtnName);
    }

    async swapEAUnitsWithInput_obsolete(targetProduct: ProductInfo, units: string): Promise<boolean>{
        const finalXPath = this.Elements.swappingProductQtyInputXPath_obsolete.replace(this.replaceProductName, targetProduct.name);
        const count = await this.pwWrapper.pageElement.getAvailableElementCount(finalXPath);
        if(count === 0){
            fixture.logger.error(`could not find the product - ${targetProduct.name} - in the 'Early Advantage Swap Product' page`);
            return false;
        }else if(count > 1){
            fixture.logger.error(`found multiple products with the name - ${targetProduct.name} - in the 'Early Advantage Swap Product' page`);
            return false;
        }

        await this.pwWrapper.dataWriter.enterValueIntoTextboxByXPath(finalXPath, units.toString(), true);
        return true;
    }

    async modifyEAUnitsWithInput(qtyToUpdateBy: number = 1, increaseQty: boolean = true){
        let currentQtyStr = await this.pwWrapper.dataReader.getInputFieldValueByXPath(this.Elements.modifyEAProductQtyInputXPath);
        fixture.logger.info(`qty before updating...${currentQtyStr}`);
        currentQtyStr = currentQtyStr.replace(",","");
        let qty = parseInt(currentQtyStr);
        
        qty = increaseQty ? qty + qtyToUpdateBy : qty - qtyToUpdateBy;

        await this.pwWrapper.dataWriter.enterValueIntoTextboxByXPath(this.Elements.modifyEAProductQtyInputXPath, qty.toString(), true)
    }
}