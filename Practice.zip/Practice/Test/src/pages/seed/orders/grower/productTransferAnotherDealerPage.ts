import GrowerDetails from "../../../../helpers/util/test-data/grower/growerDetails";
import ProductTransferPage from "../productTransferPage";
import AccountDetailsForOrderModification from "../../../../helpers/util/test-data/grower/accountDetailsForOrderModification";


export default class ProductTransferAnotherDealerPage extends ProductTransferPage {
    displayedOrderTransferMsgLabelTxt: string;
    
    Elements_AnotherDealer = {
        destinationDealerDropdownFilterTxt: 'Dealer To: ',
        destinationGrowerDropdownFilterTxt: 'Grower To:',
        //customerPOLabelTxt: 'Customer PO#:',
        customerPOPlaceholder: 'Customer PO#:',
        destinationDealerDropdownFilterTxt1: 'Type here to find a transfer target',
    }
    async isPageStable(): Promise<boolean> {
       await super.initialize();
       return await super.isPageStable();
    }
    async selectTargetDealer(dealer: AccountDetailsForOrderModification, isProductTransferFromDealerToDealer: boolean = false) {
        let tempDropdownSearchTxt = isProductTransferFromDealerToDealer ?
            this.Elements_AnotherDealer.destinationDealerDropdownFilterTxt1 :
            this.Elements_AnotherDealer.destinationDealerDropdownFilterTxt;

        if(dealer.name != null)
            await super.selectTargetDealerOrGrower(tempDropdownSearchTxt, dealer.name);
        else
            await super.selectTargetDealerOrGrower(tempDropdownSearchTxt, dealer.number.toString());
    }

    async selectTargetGrower(grower: GrowerDetails, targetOrderId: string = "") {
        await super.selectTargetDealerOrGrower(this.Elements_AnotherDealer.destinationGrowerDropdownFilterTxt, grower.name, targetOrderId);
    }

    async selectUpdatedSeller(sellerName: string){
        await super.selectUpdatedSeller(sellerName);
    }

    async fillCustomerPO(po: string){
        //await this.pwWrapper.dataWriter.enterValueIntoTextboxByLabel(this.Elements_AnotherDealer.customerPOLabelTxt, po.trim());
        await this.pwWrapper.dataWriter.enterValueIntoTextboxByPlaceholder(this.Elements_AnotherDealer.customerPOPlaceholder, po.trim());
    }
}