import GrowerDetails from "../../../../helpers/util/test-data/grower/growerDetails";
import { fixture } from "../../../../hooks/fixture";
import ProductTransferPage from "../productTransferPage";

export default class ProductTransferSameDealerPage extends ProductTransferPage {
    displayedOrderTransferMsgLabelTxt: string;

    Elements_SameDealer = {
        destinationGrowerDropdownFilterTxt: 'Type here to find a transfer target',
    }

    async initialize(): Promise<boolean> {
        return await super.initialize();
    }
    async isPageStable(){
        return await super.isPageStable();
    }
    
    async selectUpdatedSeller(sellerName: string){
        if(sellerName == null || sellerName.length == 0)
            fixture.logger.warn('skipping selecting a seller because seller data could not be found');
        else
            await super.selectUpdatedSeller(sellerName);
    }

    async selectTargetGrower(grower: GrowerDetails, targetOrderId: string = "") {
        await super.selectTargetDealerOrGrower(this.Elements_SameDealer.destinationGrowerDropdownFilterTxt, grower.name, targetOrderId);
    }
}