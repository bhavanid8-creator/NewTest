/*eslint @typescript-eslint/no-unsafe-argument: "off" */
/*eslint @typescript-eslint/no-unsafe-assignment: "off" */
/*eslint @typescript-eslint/no-unsafe-call: "off" */
/*eslint @typescript-eslint/no-unsafe-member-access: "off" */
const { format } = require('date-fns');

import { Locator } from "@playwright/test";
import HtmlRoles from "../../../../helpers/wrapper/htmlRoles";
import ProductOrderLineItemInfo from "../../../../helpers/util/test-data/productOrder/productOrderLineItemInfo";
import AccountDetails from "../../../../helpers/util/test-data/dealer/accountDetails";
import GrowerDetails from "../../../../helpers/util/test-data/grower/growerDetails";
import AngularElements from "../../../angularElements";
import { fixture } from "../../../../hooks/fixture";
import ProductOrderInfo from "../../../../helpers/util/test-data/productOrder/productOrderInfo";
import PageConstants from "../../../pageConstants";
import DataBagKeys from "../../../../tests/steps/dataBagKeys";
import KeyBoardItems from "../../../../helpers/wrapper/keyBoardItems";
import AccountDetailsForOrderModification from "../../../../helpers/util/test-data/grower/accountDetailsForOrderModification";
import DateHelper from "../../../../helpers/types/dateHelper";
import BasePage from "../../../basePage";


export default class GrowerOrderPage extends BasePage {
    
    replaceAccountNumber: string = "replace-account-number";
    replaceProductName: string = "replace-product-name";
    replaceDealerAccount: string = "replace-dealer-account";
    replaceOrderId: string = "replace-order-last-4-digits";
    replaceLineItemSequenceNumber: string = "replace-line-item-seq-number";
    replaceDisplayedGrowerNameOnGrowerDetailsPage: string = "replace-displayed-grower-name-on-grower-details-page";
    dateFormatInTheCalendar: string = 'MMMM d, yyyy';
    replaceSearchText: string = "replace-search-text";
    replaceTestIdValue = 'replace-testId-value';
    replaceFullDateValue = 'repalce-full-date-value';
    replaceDayValue = 'repalce-day-value';

    Elements = {
        selectAccountDropdownPlaceholder: 'Account:',
        selectGrowerDropdownPlaceholder: 'Grower:',
        productAddedLabelTxt: 'Product Added',
        growerSelectionTestId: "ddl-grower-to-search",
        addProductBtnName: "Add Product",
        productOrderUnitCssId: '#txtUnits',
        lineItemWithTestIdAndUnitCssIdXPath: `//*[contains(@data-testid, '${this.replaceTestIdValue}')]/ancestor::td/following-sibling::td//input[@id='txtUnits']`,
        calendarLabelName: 'Open calendar',
        chooseMonthYearLabel: 'Choose month and year',
        placeOrderBtnName: 'Place Order',
        updateOrderBtnName: 'Update Order',
        orderedProductsTableRowsXPath: "//table[contains(@class,'mat-table cdk-table')]/tbody/tr",

        gloabalSetDeliveryDateBtnXPath: "#btnSetDeliveryDate",
        gloabalSetDeliveryDateSaveBtnName: "Save",
        placeOrderSuccessfulMessageText_beginning: "Grower Order #",
        placeOrderSuccessfulMessageText_ending: " updated successfully.",        
        updateOrderPageUri: `orders/grower-order-detail/${this.replaceDealerAccount}/${this.replaceOrderId}`, //NOTE: GIVEN ORDER ID MUST FIRST BE INCREMENTED BY 1 AND THEN LAST 4 DIGITS SHOULD BE CONSIDERED
        productSelectionCheckbox: `(//span[@class='mat-checkbox-inner-container mat-checkbox-inner-container-no-side-margin'])[${this.replaceLineItemSequenceNumber}]`,
        deleteItemsFromOrderBtnId: 'deleteItemsfromOrder',
        //deleteItemsFromOrderConfirmationBtnId: `//button/*[text()='Yes']`,
        deleteItemsFromOrderConfirmationBtnId: 'btnDeleteItemsFromOrder',
        displayedGrowerNameOnGrowerDetailsPageXPath: '//app-growerorderdetail/div/div[2]/div/div[2]/div/div/div[2]/span',
        orderAllLineItemsQtyDisplayedInLeftPanelGrowerOrdersXPath: `//div[text()=' ${this.replaceDisplayedGrowerNameOnGrowerDetailsPage} ']/following-sibling::div`,
        //orderLineItemSelectionCheckboxXPath: 'mat-checkbox', //there can be couple of elements matching this; first one will be gloabl selection checkbox 
        orderLineItemSelectionCheckboxXPath: '.mat-checkbox-inner-container', //there can be couple of elements matching this; first one will be gloabl selection checkbox 
        orderLevelUpdateDeliveryDateBtnId: 'btnSetDeliveryDate',
        orderLevelUpdateDeliveryDateYearLabel: 'Select year',
        orderLevelUpdateDeliveryDateMonthLabel: 'Select month',
        orderLevelUpdateDeliveryDateFinalSaveBtnTxt: 'Save',
        orderLevelUpdateSellerBtnId: 'updateSeller',
        orderLevelSearchForSellerTxtboxXPath: `(//div[text()='Search for Seller']/../div/input)[1]`,
        orderLevelUpdateCustomerPOBtnId: 'UpdateCustomerPO',
        orderLevelUpdateCustomerPOTxtboxPlaceholder: 'Enter PO No.',
        orderLevelSaveCustomerPOBtnId: 'btnSaveCustomerPO',
        nonSubscriberEmailName: 'accountEmail',
        modifyProductBtnTooltip: 'Modify Product',
        modifyProductPackageSizeBtnName: 'Package Size',
        modifyProductSeedSizeBtnName: 'Seed Size',
        modifyProductTreatmentBtnName: 'Treatment',
        //orderUpdateConfirmationDueToProductModificationBtnXPath: `//button/span[text()='OK to Continue']`,
        orderUpdateConfirmationDueToProductModificationBtnName: 'OK to Continue',
        //growerOrderIdXPath: `//div[text()=' Grower Order# : ']/following-sibling::div/span`,
        growerOrderIdXPath: `(//div[text()=' Grower Order# : ']/../div)[2]`,
        dealerOrderIdXPath: `(//div[text()=' Dealer Order#: ']/../div)[2]`,
        dealerAccountDetailsXPath: `(//div[text()='Account: ']/../div)[2]`,
        transferProductSameDealerBtnTooltip: 'Transfer Product on Same Dealer',
        successfulOperationCompletionMsgId: 'toast-container',
        successfulOrderTransferMsgLabelTxt: 'Your order has been saved',
        transferProductToDifferentDealerBtnTooltip: 'Transfer Product to Different Dealer',
        orderSearchBtnPlaceholder: 'Search Order',
        createNewGrowerOrderBtnTxt: 'Create New Grower Order',
        noDataFoundMsgXPath: `//div[text()=' No data found for "${this.replaceSearchText}" ']`,
        productDetailRowXPath: `//tr[contains(@class, 'example-element-row')]`,
        productNameCellXPath: `//div[contains(text(), '${this.replaceProductName}')]`,
        productByTestIdXPath: `//*[@data-testid='${this.replaceTestIdValue}']`,
        //dateAtOrderLevelXPath: `//*[contains(@aria-label, '${this.replaceFullDateValue}')]/span[contains(.,' ${this.replaceDayValue} ')]`
        dateAtOrderLevelXPath: `//*[contains(@aria-label, '${this.replaceFullDateValue}')]`,
        selectAllLinesCheckboxXPath: `//*[contains(@mattooltip, 'Select All Lines')]//input`,
    }

    async isPageStable(){
        fixture.logger.info('checking for grower-order-page stability');
        await super.waitUntilButtonIsDisplayed(this.Elements.createNewGrowerOrderBtnTxt);
        fixture.logger.info('checking for grower-order-page stability completed');
        return true;
    }
    async selectAccountFromDropDown(accountDetails: AccountDetails | AccountDetailsForOrderModification){
        fixture.logger.info(`selecting account - ${accountDetails.number} on order page`);
        const finalNoDataFoundMsgXPath = this.Elements.noDataFoundMsgXPath.replace(this.replaceSearchText, accountDetails.number);
        await this.sharedBehavior.selectAngularDropdownOptionByPlaceholder(this.Elements.selectAccountDropdownPlaceholder, accountDetails.number, finalNoDataFoundMsgXPath);
    }
    
    async selectAngularDropdownItem(placeholderText: string, searchKey: string, itemToSelect: string){
        const growerDropdown = this.page.locator(AngularElements.ng_select).filter({ hasText: `${placeholderText}` }).getByRole(HtmlRoles.TEXT_BOX);
        await growerDropdown.click();
        await growerDropdown.fill(searchKey.trim());
        const element = this.page.getByText(itemToSelect);
        await element.click();
    }
    async isAccountSelectable(accountDetails: AccountDetails | AccountDetailsForOrderModification): Promise<boolean>{
        let result = true;

        try{
        await this.selectAccountFromDropDown(accountDetails);
        }catch(error){
            result = false;
            fixture.logger.error(`account selection on Create-New-Grower-Order page failed for the account - ${accountDetails.name}; either it does not exist or dealer account is locked`);
        }
        return result;
    }
    async selectGrowerFromDropDown(growerDetails: GrowerDetails){
        fixture.logger.info(`selecting grower - ${growerDetails.name} on order page`);
        const finalNoDataFoundMsgXPath = this.Elements.noDataFoundMsgXPath.replace(this.replaceSearchText, growerDetails.name);
        await this.sharedBehavior.selectAngularDropdownOptionByPlaceholder(this.Elements.selectGrowerDropdownPlaceholder, growerDetails.name, finalNoDataFoundMsgXPath);
    }

    async isGrowerSelectable(growerDetails: GrowerDetails): Promise<boolean>{
        let result = true;

        try{
        await this.selectGrowerFromDropDown(growerDetails);
        }catch(error){
            result = false;
            fixture.logger.error(`grower selection on Create-New-Grower-Order page failed for the grower - ${growerDetails.name}`);
        }
        return result;
    }

    async navigateToAddProductsPage(){
        while (await this.sharedBehavior.isOperationInProgress());
        await this.pwWrapper.elementAction.waitAndClickButtonByRole(this.Elements.addProductBtnName, 60000, true);
    }

    async checkProductsAddedMessageDisplay(){
        while (await this.sharedBehavior.isOperationInProgress());
        await this.pwWrapper.elementAction.clickElementByLabel(this.Elements.productAddedLabelTxt);
    }

    async fillOrderTopLineItemDetails(productOrderInfo: ProductOrderInfo, delayOperationUntilMillSec: number = 0){
        await this.fillIndexedOrderLineItemDetails(0 //for top line item, this value must be zero
            , productOrderInfo, delayOperationUntilMillSec);
    }

    async fillLineItemDetails_obsolete(itemDescription: string, productOrderInfo: ProductOrderInfo, delayOperationUntilMillSec: number = 0){
        let rowIndex = 0;
        const allRowLocators = await this.page.locator(this.Elements.productDetailRowXPath).all(); //retrieve all rows
        const targetRowXPath = this.Elements.productNameCellXPath.replace(this.replaceProductName, itemDescription);
        let rowFound = false;
        for(; rowIndex < allRowLocators.length; rowIndex++){
            const count = await allRowLocators[rowIndex].locator(targetRowXPath).count(); // check for specific element 
            if (count > 0) {
                rowFound = true;
                break; //we found the specific row
            }
        }
        if(!rowFound)
            throw new Error(`could not find a line item row in the order matching the product description ${itemDescription}`);

        await this.fillIndexedOrderLineItemDetails(rowIndex
            , productOrderInfo, delayOperationUntilMillSec);
    }

    async fillLineItemDetails(productItemNumber: string, productOrderInfo: ProductOrderInfo, delayOperationUntilMillSec: number = 0){
        let rowIndex = 0;
        const allRowLocators = await this.page.locator(this.Elements.productDetailRowXPath).all(); //retrieve all rows
        const targetRowXPath = this.Elements.productByTestIdXPath.replace(this.replaceTestIdValue, productItemNumber);
        let rowFound = false;
        for(; rowIndex < allRowLocators.length; rowIndex++){
            const count = await allRowLocators[rowIndex].locator(targetRowXPath).count(); // check for specific element 
            if (count > 0) {
                rowFound = true;
                break; //we found the specific row
            }
        }
        if(!rowFound)
            throw new Error(`could not find a line item row in the order matching the product description ${productItemNumber}`);

        await this.fillIndexedOrderLineItemDetails(rowIndex
            , productOrderInfo, delayOperationUntilMillSec);
    }

    async delayGrowerOrderPageOperation(delayOperationUntilMillSec: number = 0){
        if(delayOperationUntilMillSec > 0)
            await this.pwWrapper.common.delay(delayOperationUntilMillSec);
    }
    /**
     * zero-based indexed method to fill top line item details
     * @param index 
     * @param productOrderInfo 
     * @param delayOperationUntilMillSec 
     */
    async fillIndexedOrderLineItemDetails(index: number, productOrderInfo: ProductOrderInfo, delayOperationUntilMillSec: number = 0){
        await this.delayGrowerOrderPageOperation(delayOperationUntilMillSec);

        const unitsElement = this.page.locator(this.Elements.productOrderUnitCssId).nth(index);
        await this.sharedBehavior.fillUnits(unitsElement, productOrderInfo.units);

        const calendarElement = this.page.getByLabel(this.Elements.calendarLabelName).nth(index);
        await calendarElement.click();
        const today = new Date();
        let deliveryDate = new Date(productOrderInfo.deliveryDate);
        if(deliveryDate < today)
            deliveryDate = today; // if delivery date is in the past, make today as the delivery date

        await this.page.getByLabel(this.Elements.chooseMonthYearLabel).click();
        fixture.logger.info("Clicked calendar control");

        //let formatted = format(today, this.dateFormatInTheCalendar);
        const formatted = format(deliveryDate, this.dateFormatInTheCalendar);
        const splits = formatted.split(" ");
        const year = splits[2];
        await this.pwWrapper.elementAction.clickElement(`//button[@aria-label='${year}']`, undefined, undefined, undefined, 60000 );
        //await this.page.getByLabel(splits[2]).click(); // selecting year
        //await this.page.getByRole(HtmlRoles.BUTTON, splits[2]).click(); // selecting year
        //await this.page.locator(`//button[@aria-label='${splits[2]}']`).click(); // selecting year
        fixture.logger.info("Selected year");

        await this.page.getByLabel(`${splits[0]} ${splits[2]}`).click(); //selecting month & year
        fixture.logger.info("Selected month and year");

        const tempEle = this.page.getByLabel(formatted);
        await tempEle.click(); //selecting day, month & year
        fixture.logger.info("Selected date, month and year");

        await this.pwWrapper.common.delay(2000);
        //fixture.logger.info("before tabbing out from calendar");
        const sellerElement = await this.pwWrapper.keyBoard.tabOutFromCurrentAndGetFocusedElement("", 1);
        await this.pwWrapper.common.delay(2000);
        
        await this.fillSellerDetails(sellerElement, productOrderInfo.seller);
        fixture.logger.info("Selected seller");

        await this.pwWrapper.common.delay(2000);
        //fixture.logger.info("before tabbing out from seller --- 2");
        const customerPOElement = await this.pwWrapper.keyBoard.tabOutFromCurrentAndGetFocusedElement("", 1);
        await this.pwWrapper.common.delay(2000);
        
        await this.fillCustomerPODetails(customerPOElement, productOrderInfo.customerPO);
        fixture.logger.info("Selected Customer PO");
    }

    async fillSellerDetails(sellerElement: Locator, sellerSearch: string){
        if (sellerSearch == null || sellerSearch.length == 0) {
            fixture.logger.warn("skipping selecting seller as data could not be found");
            return;
        }

        await sellerElement.click();
        await sellerElement.fill(sellerSearch.trim());
        await sellerElement.press(KeyBoardItems.ENTER);
    }

    async fillCustomerPODetails(customerPOElement: Locator, customerPO: string){
        await customerPOElement.click();
        await customerPOElement.fill(customerPO);
    }

    async incrementUnitsIfLineItemAvailable(itemNumber: string, unitsValue: string): Promise<{orderContainsTheProduct: boolean, qtyIncremented: boolean}>{
        //lineItemWithTestIdAndUnitCssIdXPath: `//*[contains(@data-testid, '${this.replaceTestIdValue}')]/ancestor::td/following-sibling::td//input[@id='txtUnits']`,
        const finalXPath = this.Elements.lineItemWithTestIdAndUnitCssIdXPath.replace(this.replaceTestIdValue, itemNumber);
        return await this.sharedBehavior.incrementProductUnitsIfLineItemAvailable(finalXPath, itemNumber, unitsValue);
    }

    /*private async fillUnits(unitsElement: Locator, units: string){
        await unitsElement.click();
        await unitsElement.fill("");
        await unitsElement.fill(units);
        fixture.logger.info("Units filled");
    }*/
    /**
     * this method verifies if the opened order has at least one product
     * Note: if an order does not have a product, user can't navigate to that order. However, this method is useful in below scenario
     * - Order has exactly one line item
     * - User opened the order and deleted that line item
     * @returns 
     */
    async doesOrderHaveAtleastOneLineItem(){
        return await this.page.locator(this.Elements.orderLineItemSelectionCheckboxXPath).nth(1).isVisible();
    }
    async deleteOrderTopLineItem(){
        await this.page.locator(this.Elements.orderLineItemSelectionCheckboxXPath).nth(1).click();

        await this.pwWrapper.elementAction.clickElementById(this.Elements.deleteItemsFromOrderBtnId);
        await this.pwWrapper.elementAction.clickElementById(this.Elements.deleteItemsFromOrderConfirmationBtnId);
        while(await this.sharedBehavior.isOperationInProgress()); 
    }

    async fillOrderOtherDetails(){
        //fill non-subscriber email
        await this.sharedBehavior.fillNonSubscriberEmail();
    }
    async fillProductOrderDetails(productOrdersInfo: ProductOrderLineItemInfo[]){
        for(let index=0; index<productOrdersInfo.length; index++){
            await this.fillIndexedOrderLineItemDetails(index
            , productOrdersInfo[index].productOrderInfo, 2000);
        }
    }

    async selectOrderLevelSelectionCheckbox(){
        fixture.logger.info("attempting to select order level checkbox");
        //await this.page.locator(this.Elements.orderLineItemSelectionCheckboxXPath).nth(0).click();
        //const checkboxElement = this.page.locator(this.Elements.orderLineItemSelectionCheckboxXPath).first();
        const checkboxElement = this.page.locator(this.Elements.selectAllLinesCheckboxXPath); 
        fixture.logger.info("verifying if order level checkbox is checked or not");
        if(!await checkboxElement.isChecked())
        {
            fixture.logger.info("order level checkbox is not checked");
            await checkboxElement.click();
            fixture.logger.info("order level checkbox is checked now");
        }else{
            fixture.logger.info("order level checkbox is already checked");
        }
    }

    async fillLineItemDetailsWithOrderLevelControls(globalOrderInfo: ProductOrderInfo) {
        // step 0:check global selection checkbox
        await this.selectOrderLevelSelectionCheckbox();

        // step 1: updating delivery date
        fixture.logger.info(`provided delivery date is ${globalOrderInfo.deliveryDate}`)
        const deliveryDate = new Date(globalOrderInfo.deliveryDate);
        fixture.logger.info(`provided delivery date in Date object format is ${deliveryDate.toString()}`)
        const today = new Date();
        const year = deliveryDate.getFullYear() < today.getFullYear() ? today.getFullYear().toString() : deliveryDate.getFullYear().toString();
        let monthInNumberForm = "";
        let monthInNameForm = "";
        let weekDay = 0;
        let day = "";
        const dateFormatOption = 'MMMM yyyy';
        if(deliveryDate.getMonth() < today.getMonth()){
            monthInNumberForm = (today.getMonth() + 1).toString();
            monthInNameForm = format(today, dateFormatOption).split(" ")[0];
            weekDay = today.getDay();
            day = today.getDate().toString();
        }else{
            monthInNumberForm = (deliveryDate.getMonth() + 1).toString();
            monthInNameForm = format(deliveryDate, dateFormatOption).split(" ")[0];
            weekDay = deliveryDate.getDay();
            day = deliveryDate.getDate().toString();
        }

        await this.pwWrapper.elementAction.clickElementById(this.Elements.orderLevelUpdateDeliveryDateBtnId);
        await this.pwWrapper.dataWriter.selectLabelledDropdownOption(this.Elements.orderLevelUpdateDeliveryDateYearLabel, year);
        await this.pwWrapper.dataWriter.selectLabelledDropdownOption(this.Elements.orderLevelUpdateDeliveryDateMonthLabel, monthInNumberForm);
        const finalDate = DateHelper.getWeekDayName(weekDay) + ", " + monthInNameForm + " " + day + ", " + year;
        fixture.logger.info(`final date to be selected is ${finalDate}`);
        //await this.pwWrapper.elementAction.clickLabelledTextElement(finalDate, day);
        let finalXPath = this.Elements.dateAtOrderLevelXPath.replace(this.replaceFullDateValue, finalDate);
        //finalXPath = finalXPath.replace(this.replaceDayValue, day);
        await this.pwWrapper.elementAction.clickElement(finalXPath, true);
        await this.pwWrapper.elementAction.waitAndClickButtonByRole(this.Elements.orderLevelUpdateDeliveryDateFinalSaveBtnTxt);

        // step 2: updating seller here
        await this.pwWrapper.elementAction.clickElementById(this.Elements.orderLevelUpdateSellerBtnId);
        const sellerElement = this.page.locator(this.Elements.orderLevelSearchForSellerTxtboxXPath);
        await this.fillSellerDetails(sellerElement, globalOrderInfo.seller);

        // step 3: updating customer PO
        await this.pwWrapper.elementAction.clickElementById(this.Elements.orderLevelUpdateCustomerPOBtnId);
        const customerPOElement = await this.pwWrapper.pageElement.getElementByPlaceholder(this.Elements.orderLevelUpdateCustomerPOTxtboxPlaceholder);
        await this.fillCustomerPODetails(customerPOElement, globalOrderInfo.customerPO);
        await this.pwWrapper.elementAction.clickElementById(this.Elements.orderLevelSaveCustomerPOBtnId);
    }

    async placeOrUpdateOrder(isNewOrder: boolean): Promise<string> {
        /*const element: Locator = await this.getPlaceOrUpdateOrderBtn();
        await element.click();
        const btnCount = await this.pwWrapper.pageElement.getAvailableElementCount(this.Elements.orderUpdateConfirmationDueToProductModificationBtnXPath);
        if(btnCount > 0)
            await this.pwWrapper.elementAction.clickElement(this.Elements.orderUpdateConfirmationDueToProductModificationBtnXPath);
        while(await this.sharedBehavior.isOperationInProgress());
        */
        let operationMsg = "new order request";
        let btnName = this.Elements.placeOrderBtnName;
        let operationConfirmationBtnName = "";
        if(!isNewOrder)
        {
            operationMsg = "update order request";
            btnName = this.Elements.updateOrderBtnName;
            operationConfirmationBtnName = this.Elements.orderUpdateConfirmationDueToProductModificationBtnName;
        }
        const msg = await this.sharedBehavior.clickButtonAndInspectSuccessMessageIndependentlyForOrderUpdate(operationMsg, btnName, operationConfirmationBtnName);
        fixture.logger.info(`msg received is---${msg}`);
        while(await this.sharedBehavior.isOperationInProgress());
        fixture.logger.info(`before returing msg`);
        return msg;
    }

    async checkOrderPlacedOrUpdatedMessageDisplay(): Promise<boolean>{
        const expectedMsg = this.Elements.placeOrderSuccessfulMessageText_beginning + fixture.dataBag.getData(DataBagKeys.ORDER_ID) + this.Elements.placeOrderSuccessfulMessageText_ending;
        return await this.sharedBehavior.checkLabelPresence(expectedMsg);
    }

    async isPlaceOrUpdateOrderBtnEnabled(): Promise<boolean> {
        const element: Locator = await this.getPlaceOrUpdateOrderBtn();
        return await element.isEnabled();
    }

    async isPlaceOrUpdateOrderBtnAvailable(): Promise<boolean> {
        let count = 0;
        try {
            await this.pwWrapper.common.delay(500);
            count = await this.pwWrapper.pageElement.getAvailableElementCountByRole(HtmlRoles.BUTTON, this.Elements.updateOrderBtnName);
            if (count == 0)
                count = await this.pwWrapper.pageElement.getAvailableElementCountByRole(HtmlRoles.BUTTON, this.Elements.placeOrderBtnName);
        } catch (err) {
            fixture.logger.error(`Failed to get the count of Place Order/Update Order button. Error: ${err}`);
        }
        return count > 0;
    }

    private async getPlaceOrUpdateOrderBtn() {
        let element: Locator = null;
        try {
            element = await this.pwWrapper.pageElement.getButton(this.Elements.updateOrderBtnName, 6000);
        } catch (err) {
            try{
            if (err.name === PageConstants.TIMEOUT_ERROR) {
                element = await this.pwWrapper.pageElement.getButton(this.Elements.placeOrderBtnName, 6000);
            }
            }catch(error){
                if (error.name === PageConstants.TIMEOUT_ERROR) {
                    return null;
                }   
            }
        }
        return element;
    }

    async goToUpdateOrderPageWithDynamicUrl(dealerAccount: string, orderId: string): Promise<void>{
        let incrementedOrderId = (parseInt(orderId) + 1).toString();
        
        if (incrementedOrderId.length > 5) {
            incrementedOrderId = incrementedOrderId.substring(incrementedOrderId.length - 5);
        }
        let updateOrderUri = this.Elements.updateOrderPageUri.replace(this.replaceDealerAccount, dealerAccount);
        updateOrderUri = updateOrderUri.replace(this.replaceOrderId, incrementedOrderId);

        const updateOrderUrl = process.env.BASEURL + updateOrderUri;
        fixture.logger.info(`constructed update-order-page-url is ${updateOrderUrl}`);

        await this.pwWrapper.goto(updateOrderUrl, 10000);
        await this.pwWrapper.waitForPageStability(20000);
    }

    async isOrderEditable(): Promise<boolean>{
        let result = true;
        try{
            //while (await this.sharedBehavior.isOperationInProgress("//div[@class='loaderWhiteOuter']"));
            await this.pwWrapper.common.delay(1000);
            while (await this.sharedBehavior.isOperationInProgress());
            const btn = await this.pwWrapper.pageElement.getButton(this.Elements.addProductBtnName, 3000, true);
            result = await btn.isEnabled();
        }catch(error){
            result = false;
            fixture.logger.error(`Order is not editable because unable to get visible ${this.Elements.addProductBtnName} button`);
        }
        return result;
    }  

    private async triggerOrderLevelActionByTooltip(toolTipText: string){
        await this.pwWrapper.elementAction.clickElementByNameAndAttributeValue(HtmlRoles.LIST_ITEM, AngularElements.matTooltip, toolTipText);
        while(await this.sharedBehavior.isOperationInProgress());
    }
    async navigateToReplaceProductPage(productModificationOption: string, delayOperationUntilMillSec: number = 0, checkOrderLevelSelection: boolean = true){
        await this.delayGrowerOrderPageOperation(delayOperationUntilMillSec);
        if(checkOrderLevelSelection)
            await this.selectOrderLevelSelectionCheckbox();
        await this.triggerOrderLevelActionByTooltip(this.Elements.modifyProductBtnTooltip);
        if(productModificationOption != this.Elements.modifyProductPackageSizeBtnName &&
            productModificationOption != this.Elements.modifyProductSeedSizeBtnName &&
            productModificationOption != this.Elements.modifyProductTreatmentBtnName)
            throw new Error(`invalid product modification option - ${productModificationOption}`);

        await this.pwWrapper.elementAction.waitAndClickButtonByRole(productModificationOption, 90000, true);//this screen is sometimes taking more than 1 min
        while(await this.sharedBehavior.isOperationInProgress());
    }

    async navigateToTransferProductOnSameDealer(){
        await this.triggerOrderLevelActionByTooltip(this.Elements.transferProductSameDealerBtnTooltip);
        fixture.logger.info('navigated to transfer-product page');
    }
    async getCurrentDisplayedGrowerOrderId(): Promise<string>{
        return await this.getDisplayedDetails(this.Elements.growerOrderIdXPath);
    }

    async getCurrentDisplayedDealerOrderId(): Promise<string>{
        return await this.getDisplayedDetails(this.Elements.dealerOrderIdXPath);
    }
    async getCurrentDisplayedAccountDetails(){
        return await this.getDisplayedDetails(this.Elements.dealerAccountDetailsXPath);
    }
    
    private async getDisplayedDetails(xpath: string): Promise<string>{
        while(await this.sharedBehavior.isOperationInProgress());
        return await this.pwWrapper.dataReader.getElementTextByXPath(xpath, true);
    }
    async navigateToTransferProductToDifferentDealer(){
        await this.triggerOrderLevelActionByTooltip(this.Elements.transferProductToDifferentDealerBtnTooltip);
        fixture.logger.info('navigated to transfer-product page');
    }
}