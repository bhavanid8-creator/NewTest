import { fixture } from "../../../hooks/fixture";
import ProductOrderInfo from "../../../helpers/util/test-data/productOrder/productOrderInfo";
import BasePage from "../../basePage";

export default class ProductTransferPage extends BasePage {
    displayedOrderTransferMsgLabelTxt: string = "";

    protected Elements = {
        updateSellerTxt: 'Updated Seller:',
        transferUnitsBtnTxt: 'Transfer Units',
        successfulOrderTransferMsgLabelTxt: 'Your order has been saved',
        successfulOrderTransferMsgId: 'toast-container',
        displayedTransferredQtyXPath: `//*[text()=' Transferred Units: ']/span`,
        closeBtnTxt: ' Close ',
        closeBtnXPath: `//a[contains(.,'Close')]`,
        transferConfirmationWarningBtnXPath: `//span[text()='OK to continue']`,
        previewTransferChangesBtnText: "Preview Change",
    }

    async canNavigateWithUrl(): Promise<boolean>{
        return false;
    }
    
    async isPageStable(){
        fixture.logger.info('checking for product-transfer-page stability');
        await super.waitUntilButtonIsDisplayed(this.Elements.closeBtnTxt);
        fixture.logger.info('checking for product-transfer-page stability completed');
        return true;
    }
    
    protected async selectUpdatedSeller(sellerName: string){
        await this.pwWrapper.dataWriter.selectAngularDropdownOption(this.Elements.updateSellerTxt, sellerName.trim());
        fixture.logger.info(`the seller - ${sellerName} - has been selected`);
    }

    protected async selectTargetDealerOrGrower(dropdownSearchText: string, primarySelectionText: string, secondarySelectionText: string = ""){
        if (secondarySelectionText.trim().length > 0) {
            await this.pwWrapper.dataWriter.selectAngularDropdownOptionWithAdditionalSearch(dropdownSearchText, primarySelectionText.trim(), secondarySelectionText.trim());
            fixture.logger.info(`new grower/dealer - ${primarySelectionText} - with the order-id - ${secondarySelectionText} - has been selected`);
        } 
        else
        { 
            await this.pwWrapper.dataWriter.selectAngularDropdownOption(dropdownSearchText, primarySelectionText.trim());
            fixture.logger.info(`new grower/dealer - ${primarySelectionText} - for NEW order - has been selected`);
        }
        while(await this.sharedBehavior.isOperationInProgress());
    }
    async fillOrderOtherDetails(){
        //fill non-subscriber email
        await this.sharedBehavior.fillNonSubscriberEmail();
    }

    /**
     * 
     * @param transferringProductNames 
     * @param transferModifications 
     */
    async fillLineItemDetails_obsolete(existingProductRowCount: number, transferringProductNames: string[], transferModifications: ProductOrderInfo){
        await this.completeLineItemsAction(existingProductRowCount, transferringProductNames.length, transferModifications.units, transferModifications.deliveryDate, false);
    }

    /**
     * 
     * @param transferringProductsCount 
     * @param transferModifications 
     */
    async fillLineItemDetails(existingProductRowCount: number, transferringProductsCount: number, transferModifications: ProductOrderInfo){
        await this.completeLineItemsAction(existingProductRowCount, transferringProductsCount, transferModifications.units, transferModifications.deliveryDate, false);
    }

    private getUnitsDecreaseBtnXPath(){
        return this.sharedBehavior.getUnitsDecreaseBtnXPath();
    }
    async clickTransfer(): Promise<string>{
        fixture.logger.info(`transfer product action has started`);
        /*TODO: NEED TO HANDLE transferConfirmationWarningBtnXPath DIALGO */
        const allPromise = await Promise.all([
            this.pwWrapper.elementAction.waitAndClickButtonByRole(this.Elements.transferUnitsBtnTxt),
            this.retryPromise(() => this.pwWrapper.dataReader.getVisibleElementTextById(this.Elements.successfulOrderTransferMsgId))  //toast success message on transfer successfully
        ]);
        try {
            const values = allPromise;
            this.displayedOrderTransferMsgLabelTxt = values[1].trim();
            fixture.logger.info(`transfer product action has completed with the message - "${this.displayedOrderTransferMsgLabelTxt}"`);
        } catch (error) {
            fixture.logger.error(`failed to resolve promises during product transfer...${error}`);
        }
        return this.displayedOrderTransferMsgLabelTxt;
    }

    async previewChangesForTransfer() {
        fixture.logger.info(`preview change of transfer product action has started`);
        try {
            await this.pwWrapper.elementAction.waitAndClickButtonByRole(this.Elements.previewTransferChangesBtnText);
            while(await this.sharedBehavior.isOperationInProgress());
            fixture.logger.info(`preview changes done"`);
        } catch (error) {
            fixture.logger.error(`failed to preview changes during transfer...${error}`);
        }
    }
    async retryPromise(func: () => Promise<any>, retries: number = 3): Promise<any> {
        for (let i = 0; i < retries; i++) {
            try {
                return await func();
            } catch (error) {
                if (i === retries - 1) throw error;
                await new Promise(resolve => setTimeout(resolve, 500)); // wait for 0.5 second before retrying
            }
        }
    }
    /*eslint @typescript-eslint/require-await: "off" */
    async checkProductTransferMessageDisplay(msgToCheck: string): Promise<boolean>{
        fixture.logger.info(`expected msg is ${msgToCheck}`);
        return this.displayedOrderTransferMsgLabelTxt == msgToCheck;
    }

    private getUnitsTxtBoxXPath(decreaseBtnXPath: string, unitsBtnIndexPosition: number): string{
        return "((" + decreaseBtnXPath + ")[" + unitsBtnIndexPosition + "])/following-sibling::input";
    }

    async verifyOrderIdsDisplay(fromOrder: string, toOrder: string = ""){
        fixture.logger.info(`order IDs display validation on transfer product page has started`);
        const options = {timeout: 2000};
        let result = await (await this.pwWrapper.pageElement.getElementByPara(fromOrder)).isVisible(options);
        if(!result)
        {
            fixture.logger.error(`From order ID - ${fromOrder} - is not displayed on transfer product page`);
            return result;
        }

        if(toOrder.length == 0)
            toOrder = 'New Order';

        result = await (await this.pwWrapper.pageElement.getElementByPara(toOrder)).isVisible(options);

        if(!result)
        {
            fixture.logger.error(`To order ID - ${toOrder} - is not displayed on transfer product page`);
            return result;
        }
        fixture.logger.info(`order IDs display validation on transfer product page has completed`);

        return result;
    }
    async verifyLineItemsButtonsFunctionality(existingProductRowCount: number, transferringProductCount: number, deliveryDateAvailable: boolean = false): Promise<boolean>{
        fixture.logger.info(`line item fields like units, delivery date, etc., validation on transfer product page has started`);
        
        let deliveryDate = "";
        if(deliveryDateAvailable)
            deliveryDate = new Date().toString();

        const result = await this.completeLineItemsAction(existingProductRowCount, transferringProductCount, "1", deliveryDate, true);

        fixture.logger.info(`line item fields like units, delivery date, etc., validation on transfer product page has completed`);

        return result;
    }

    private async completeLineItemsAction(existingProductRowCount: number, transferringProductRowCount: number, units: string, deliveryDate: string, checkBtnActions: boolean): Promise<boolean>{
        const decreaseBtnXPath = this.getUnitsDecreaseBtnXPath();
        const increaseBtnXPath = this.sharedBehavior.getUnitsIncreaseBtnXPath();

        let expectedUnitsBtnCount = existingProductRowCount + transferringProductRowCount;
        fixture.logger.info(`sum of existingProductRowCount (${existingProductRowCount}) and transferringProductRowCount (${transferringProductRowCount}) is ${expectedUnitsBtnCount}`);

        fixture.logger.info(`decreaseBtnXPath value is ${decreaseBtnXPath}`);
        let unitsBtnIndexPosition = await this.pwWrapper.pageElement.getAvailableElementCount(decreaseBtnXPath); //this gets count on both Order Page & Product Transfer Page (if available)
        fixture.logger.info(`unitsBtnIndexPosition value is ${unitsBtnIndexPosition}`);
        if(unitsBtnIndexPosition < expectedUnitsBtnCount)
        {
            fixture.logger.error('units related element is not found on the page; either there is no single product to transfer or remaining quanity of available products is zero');
            return false;
        }
       
        for(let index=0; index<transferringProductRowCount; index++){
            //check if we can enter value into text box
            const unitsTxtBoxXPath = this.getUnitsTxtBoxXPath(decreaseBtnXPath, unitsBtnIndexPosition); //we fill values in reverse order
            fixture.logger.info(`unitsTxtBoxXPath value is ${unitsTxtBoxXPath}`);
            const count = await this.pwWrapper.pageElement.getAvailableElementCount(unitsTxtBoxXPath);
            fixture.logger.info(`count value is ${count}`);
            if(count == 0)
                break;
            await this.pwWrapper.dataWriter.enterValueIntoTextboxByXPath(unitsTxtBoxXPath, units, true);
            await this.pwWrapper.keyBoard.tabOutToNextElement();

            if(checkBtnActions){
                //check if we can use increase button
                await this.pwWrapper.elementAction.clickIndexedElement(unitsBtnIndexPosition - 1, increaseBtnXPath);

                //check if we can use decrease button
                await this.pwWrapper.elementAction.clickIndexedElement(unitsBtnIndexPosition - 1, decreaseBtnXPath);
            }

            if(deliveryDate != null && deliveryDate.length > 0){
                await this.sharedBehavior.fillDeliveryOrPickupDate(unitsBtnIndexPosition - 1, deliveryDate);
            }
            unitsBtnIndexPosition--; //we fill the value in reverse order
        }
        await this.pwWrapper.common.delay(1000); //Transfer button is not working in a reliable manner on 'Outside territory' case so DO NOT DELETE this delay
        //sometimes 'transfer' button is not getting enabled; to overcome this issue, we click on both Units buttons
        const btnIndex = unitsBtnIndexPosition + 1;
        const finalDecreaseBtnXPath = decreaseBtnXPath + "[" + btnIndex + "]";
        const finalIncreaseBtnXPath = increaseBtnXPath + "[" + btnIndex + "]";
        await this.pwWrapper.elementAction.clickElement(finalIncreaseBtnXPath);
        await this.pwWrapper.elementAction.clickElement(finalDecreaseBtnXPath);
        await this.pwWrapper.elementAction.clickElement(finalIncreaseBtnXPath);//if transfer qty is just 1, then above two actions would not make any difference and hence let us do this also

        //checking displayed transfer details
        const attemptedTrnsferQty = parseInt(units.replaceAll(",","")) * transferringProductRowCount;
        const displayedTrnsferredQty = await this.pwWrapper.dataReader.getElementTextByXPath(this.Elements.displayedTransferredQtyXPath, true);
        fixture.logger.info(`displayed transferred-units text is - ${displayedTrnsferredQty}`);

        const qty = parseInt(displayedTrnsferredQty.split("/")[0].replaceAll(",",""));

        return attemptedTrnsferQty == (qty - 1);
    }
    async canClickTransfer(): Promise<boolean>{
        fixture.logger.info(`transfer product button validation has started`);
        const result = await this.pwWrapper.elementAction.canClickButton(this.Elements.transferUnitsBtnTxt);
        fixture.logger.info(`transfer product button enabled status is: ${result}`);
        return result;
    }

    async isTransferButtonVisible(): Promise<boolean>{
        const result = await this.pwWrapper.pageElement.getAvailableElementCountByText(this.Elements.transferUnitsBtnTxt);
        return result > 0;
    }

    async closeTransferProductsPage(isTrasferOutsideTerritory: boolean = false) {
        if (isTrasferOutsideTerritory)
            await this.pwWrapper.elementAction.clickElement(this.Elements.closeBtnXPath);
        else
            await this.pwWrapper.elementAction.clickElementHavingText(this.Elements.closeBtnTxt);
    }
}