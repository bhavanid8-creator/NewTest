import AccountDetails from "../../../helpers/util/test-data/dealer/accountDetails";
import AngularElements from "../../angularElements";
import GrowerDetails from "../../../helpers/util/test-data/grower/growerDetails";
import { fixture } from "../../../hooks/fixture";
import AccountDetailsForOrderModification from "../../../helpers/util/test-data/grower/accountDetailsForOrderModification";
import BasePage from "../../basePage";
import HtmlRoles from "../../../helpers/wrapper/htmlRoles";

export default class SeedOrdersPage extends BasePage {
    replaceAccountNumber: string = "replace-account-number";
    replaceOrderId: string = "replace-order-id";
    replaceDealerName: string = "replace-dealer-name";
    replaceGrowerOrDealerName: string = "replace-grower-or-dealer-name";
    replaceGrowerGMK: string = "replace-grower-gmk";
    replaceSearchText: string = "replace-search-text";

    Elements = {
        seedOrdersPageUri: "landing-data",
        ordersMenuButtonName: "Orders",
        manageYourGrowerOrdersTabName: "Manage your Grower Orders",
        manageYourDealerOrdersTabName: "Manage your Dealer Orders",
        createNewGrowerOrderButtonName: "Create New Grower Order",
        selectAccountDropdownText: 'Select Account',
        selectGrowerDropdownText: 'Select Grower',
        selectAccountDropdownClearButtonText: 'Clear all',
        growerOrdersCountLabelClass: 'mat-paginator-range-label',
        //orderGrowerTableRowXPath: `(//*[@class='d-none d-md-block' and text()='${this.replaceOrderId}']/../../td)[1]`
        //orderGrowerTableRowXPath: `(((//*[text()='${this.replaceOrderId}'])[2])/../../td)[1]`,
        growerNameFromDropdownXPath: `//span[contains(., '${this.replaceGrowerGMK}')]/../../h4`,
        growerNameCellXPath: `//tbody/tr//*[contains(@class, 'order-info')]`,
        growerNameItemXPath: `//tbody/tr//*[contains(@class, 'order-info')]/p/a`,
        //growerNameInGrowerOrderTableRowXPath: `//tbody/tr//*[contains(@class, 'grower-name') and contains(.,' ${this.replaceGrowerOrDealerName} ')]`,
        //growerNameInGrowerOrderTableRowXPath: `//tbody/tr//*[contains(@class, 'grower-name')]//*[contains(translate(., 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), ' ${this.replaceGrowerOrDealerName} ')]`, <--- this does case insensitive XPath search
        growerNameInGrowerOrderTableRowXPath: `//tbody/tr//*[contains(@class, 'grower-name')]`,
        growerOrderIdInGrowerOrderTableRowXPath:`//tbody/tr//*[contains(@class, 'grower-name') and contains(.,' ${this.replaceGrowerOrDealerName} ')]/../../..//td[contains(@class, 'mat-column-orderID')]/span`,
        dealerOrderIdInDealerOrderTableRowXPath:`//tbody/tr//*[contains(@class, 'grower-name') and contains(.,' ${this.replaceGrowerOrDealerName} ')]/../../..//td[contains(@class, 'mat-column-orderId')]`,
        dealerOrderTableRowXPath: `//a[text()=' ${this.replaceDealerName} ']`,
        dealerOrderTableRowXPath1: `//p[contains(text(),'Dealer')]/following-sibling::p/a`,
        dealerOrdersHeadingTxt: 'Dealer Orders',
        noDataFoundMsgXPath: `//div[text()=' No data found for "${this.replaceSearchText}" ']`,
    }

    private async isPageLoaded(): Promise<boolean>{
        await super.waitUntilButtonIsDisplayed(this.Elements.createNewGrowerOrderButtonName);
        return true;
    }

    async isPageStable(){
        fixture.logger.info('checking for seed-order-page stability');
        const res = await this.isPageLoaded();
        fixture.logger.info('checking for seed-order-page stability completed');

        return res;
    }
    async clickGrowerOrdersTab() {
        await this.pwWrapper.elementAction.clickItemByText(this.Elements.manageYourGrowerOrdersTabName);
    }
    async clickCreateNewGrowerOrderButton() {
        await this.pwWrapper.elementAction.waitAndClickButtonByRole(this.Elements.createNewGrowerOrderButtonName);
    }
    
    /** verifications - begin */

    async isAccountSelectable(account: AccountDetails): Promise<boolean> {
        
        let result: boolean = true;
        try{
            //await this.selectDealer(account.name);
            await this.selectDealer(account.number);
        }catch(error){
            result = false;
        }

        return result;
    }
    async areGrowersSelectable(relatedGrowers: GrowerDetails[]): Promise<boolean> {
        let result: boolean = true;
        try{
            await Promise.all(
            relatedGrowers.map(async(grower) => {
                //await this.selectGrower(grower.name);
                await this.selectGrower(grower.growerGMK);
            }));
        }catch(error){
            result = false;
        }

        return result;
    }

    async clearAccountSelection(){
        await this.page.locator(AngularElements.ng_select).filter({ hasText: `${this.Elements.selectAccountDropdownText}` }).getByTitle(this.Elements.selectAccountDropdownClearButtonText).click();
    }
    /** verifications - end */

    async getCurrentGrowerOrdersCount(): Promise<number>{
       const ordersLabel = await (await this.pwWrapper.pageElement.getElementByClass(this.Elements.growerOrdersCountLabelClass)).textContent();
       const totalOrdersCount = parseInt(ordersLabel.split("of")[1].replaceAll(",","").trim());
       return totalOrdersCount;
    }

    //async selectDealer(accountName: string){
    async selectDealer(accountNumber: string){
        //await this.pwWrapper.dataWriter.selectAngularDropdownOption(this.Elements.selectAccountDropdownText, accountName.trim());
        accountNumber = accountNumber.trim();
        const finalNoDataFoundMsgXPath = this.Elements.noDataFoundMsgXPath.replace(this.replaceSearchText, accountNumber);
        await this.sharedBehavior.selectAngularDropdownOptionByPlaceholder(this.Elements.selectAccountDropdownText, accountNumber, finalNoDataFoundMsgXPath);
        while (await this.sharedBehavior.isOperationInProgress());
    }

    //async selectGrower(growerName: string){
    async selectGrower(growerGMK: string){
        //await this.pwWrapper.dataWriter.selectAngularDropdownOption(this.Elements.selectGrowerDropdownText, growerName.trim());
        growerGMK = growerGMK.trim();
        const finalNoDataFoundMsgXPath = this.Elements.noDataFoundMsgXPath.replace(this.replaceSearchText, growerGMK);
        const growerFilterText = `Grower GMK: ${growerGMK}`;
        await this.sharedBehavior.selectAngularDropdownOptionByPlaceholder(this.Elements.selectGrowerDropdownText, growerGMK, finalNoDataFoundMsgXPath, growerFilterText);
        while (await this.sharedBehavior.isOperationInProgress());
    }

    //async canNavigateToOrder(orderId: string):Promise<boolean>{
    async canNavigateToOrder(growerName: string):Promise<boolean>{
        //return (await this.pwWrapper.pageElement.getAvailableElementCount(this.getOrderRowFirstCellXPath(growerName))) > 0;
        const finalXPath = this.getOrderRowFirstCellXPath(growerName);
        fixture.logger.info(`xpath on orders table is...${finalXPath}`);
        const rowCount = await this.pwWrapper.pageElement.getAvailableElementCount(this.getOrderRowFirstCellXPath(growerName));
        fixture.logger.info(`rowCount is...${rowCount}`);
        return rowCount > 0;
    }

    async getGrowerNameFromTheDropdown(growerGMK: string): Promise<string> {
        let growerName = "";
        growerGMK = growerGMK.trim();
        const dropDown = await this.pwWrapper.dataWriter.clickAngularDropdownOption(this.Elements.selectGrowerDropdownText, growerGMK);
        const finalXPath = this.Elements.growerNameFromDropdownXPath.replace(this.replaceGrowerGMK, growerGMK);
        growerName = await this.pwWrapper.dataReader.getElementTextByXPath(finalXPath, false);
        await this.pwWrapper.keyBoard.tabOutFromCurrentElement(dropDown);
        return growerName.trim();
    }

    //private getOrderRowFirstCellXPath(orderId: string): string{
    private getOrderRowFirstCellXPath(growerName: string): string{
        return this.Elements.growerNameInGrowerOrderTableRowXPath.replace(this.replaceGrowerOrDealerName, growerName.trim());
    }
    async getGrowerOrderIdFromTheSeedOrderPageTable(growerName: string): Promise<string>{
        return await this.getGrowerOrDealerOrderIdFromTheSeedOrderPageTable(growerName, true);
    }

    async getDealerOrderIdFromTheSeedOrderPageTable(dealerName: string): Promise<string>{
        return await this.getGrowerOrDealerOrderIdFromTheSeedOrderPageTable(dealerName, false);
    }

    private async getGrowerOrDealerOrderIdFromTheSeedOrderPageTable(growerOrDealerName: string, isGrower: boolean): Promise<string>{
        while(await this.sharedBehavior.isOperationInProgress());
        let finalXPath = this.Elements.growerOrderIdInGrowerOrderTableRowXPath.replace(this.replaceGrowerOrDealerName, growerOrDealerName.trim());

        if(!isGrower){
            finalXPath = this.Elements.dealerOrderIdInDealerOrderTableRowXPath.replace(this.replaceGrowerOrDealerName, growerOrDealerName.trim());
        }
        const rowPresent = await this.pwWrapper.pageElement.isElementVisible(finalXPath);
        if (!rowPresent) {
        
            if(!isGrower)
                fixture.logger.error(`could not find dealer order for ${growerOrDealerName}`);
            else
                fixture.logger.error(`could not find grower order for ${growerOrDealerName}`);
            return "";
        }
        else
            return await this.pwWrapper.dataReader.getElementTextByXPath(finalXPath, false);
    }
    async goToUpdateOrderPage(accountDetailsForOrderModification: AccountDetailsForOrderModification): Promise<void>{
        fixture.logger.info(`navigating to order page: Dealer Account - ${accountDetailsForOrderModification.number} & Order Id: ${accountDetailsForOrderModification.orderIdToUpdate}`);
        //await this.pwWrapper.elementAction.clickElement(this.getOrderRowFirstCellXPath(accountDetailsForOrderModification.orderIdToUpdate));
        await this.pwWrapper.elementAction.clickElement(this.getOrderRowFirstCellXPath(accountDetailsForOrderModification.relatedGrower.name));
        fixture.logger.info(`order page navigation completed: Dealer Account - ${accountDetailsForOrderModification.number} & Order Id: ${accountDetailsForOrderModification.orderIdToUpdate}`);
    }

    async clickDealerOrdersTab(){
        await this.pwWrapper.elementAction.clickElementByRole(HtmlRoles.HEADING, this.Elements.dealerOrdersHeadingTxt);
    }

    private getDealerOrderRowFirstCellXPath(dealerName: string): string{
        if(dealerName != null && dealerName.length > 0)
            return this.Elements.dealerOrderTableRowXPath.replace(this.replaceDealerName, dealerName);
        else
            return this.Elements.dealerOrderTableRowXPath1; //this assumes there is only one row
    }
    async clickDealerOrder(name: string){
        await this.pwWrapper.elementAction.clickElement(this.getDealerOrderRowFirstCellXPath(name));
        while(await this.sharedBehavior.isOperationInProgress());
    }
}