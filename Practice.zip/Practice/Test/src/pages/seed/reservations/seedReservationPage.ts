import { fixture } from "../../../hooks/fixture";
import BasePage from "../../basePage";
import HtmlRoles from "../../../helpers/wrapper/htmlRoles";

export default class SeedReservationPage extends BasePage {
    replaceAccountNumber: string = "replace-account-number";
    replaceReservationId: string = "replace-reservation-id";
    replaceGrowerGMK: string = "replace-grower-gmk";

    Elements = {
        seedReservationsPageUri: "seed-reservation/seed-reservation-create",
        selectAccountDropdownPlaceholder: 'Account:',
        selectSellerDropdownPlaceholder: 'Seller:',
        selectGrowerDropdownPlaceholder: 'Grower:',
        addReservationButtonName: 'Add Reservation',
        submitReservationButtonName: 'Submit Reservation',
        updateReservationButtonName: 'Update Reservation',
        cancelButtonName: 'Cancel',
        clearAllButtonXPath: `//span[@title='Clear all']`,
        productLineText: `Product Line×`, 
        noItemsFoundMsgXPath: `//div[text()='No items found']`,
        productLineTestId: 'ddl-product-line-search',
        selectProductLineCellText: 'Select Product Line',
        marketingBrandTestId: 'ddl-marketing-brand-search',
        selectMarketingBrandCellText: 'Select Marketing Brand',
        increaseQtyTestId: 'increase-undefined',
        decreaseQtyTestId: 'decrease-undefined',
        retailerIDXPath:`//div[contains(concat(' ', normalize-space(@class), ' '), ' seedCreateInput ')]//input[@name='account']`,
        emailXPath:`//div[contains(concat(' ', normalize-space(@class), ' '), ' seedCreateInput ')]//input[@name='accountEmail']`,
        yesConfirmationButtonName: 'Yes',
        backToReservationListButtonName: 'Back To Reservation List',
        deleteButtonXPath: `//li[@mattooltip='Delete Items from Reservation']`,
    }

    private async isPageLoaded(): Promise<boolean>{
        await super.waitUntilButtonIsDisplayed(this.Elements.addReservationButtonName);
        return true;
    }

    async isPageStable(){
        fixture.logger.info('checking for seed-reservation-page stability');
        const res = await this.isPageLoaded();
        fixture.logger.info('checking for seed-reservation-page stability completed');

        return res;
    }

    async selectAccountFromDropDown(accountNumber: string){
        fixture.logger.info(`selecting account - ${accountNumber} on seed reservation page`);
        await this.sharedBehavior.selectAngularDropdownOptionByPlaceholder(this.Elements.selectAccountDropdownPlaceholder, accountNumber, this.Elements.noItemsFoundMsgXPath);
        await this.pwWrapper.common.delay(2000); // it can take time to populate seller and grower related to selected account so wait for the page to load after selecting account
    }
        
    async selectSellerFromDropDown(sellerName: string){
        fixture.logger.info(`selecting seller - ${sellerName} on seed reservation page`);
        await this.sharedBehavior.selectAngularDropdownOptionByPlaceholder(this.Elements.selectSellerDropdownPlaceholder, sellerName, this.Elements.noItemsFoundMsgXPath);
    }
    
    async selectGrowerFromDropDown(growerName: string){
        fixture.logger.info(`selecting grower - ${growerName} on seed reservation page`);
        await this.sharedBehavior.selectAngularDropdownOptionByPlaceholder(this.Elements.selectGrowerDropdownPlaceholder, growerName, this.Elements.noItemsFoundMsgXPath);
    }

    async fillRetailerInfo(){
        fixture.logger.info('filling retailer ID');
        await this.pwWrapper.dataWriter.enterValueIntoTextboxByXPath(this.Elements.retailerIDXPath, "qa-123456");
        fixture.logger.info('filling retailer email');
        await this.pwWrapper.dataWriter.enterValueIntoTextboxByXPath(this.Elements.emailXPath, "qa@auto.test");
    }

    async isAddReservationButtonEnabled(): Promise<boolean>{
        fixture.logger.info('checking for add reservation button enabled status');
        const isEnabled = await this.pwWrapper.pageElement.isElementByRoleEnabled(HtmlRoles.BUTTON, this.Elements.addReservationButtonName);
        fixture.logger.info(`add reservation button enabled status is - ${isEnabled}`);
        return isEnabled;
    }

    async clickOnAddReservationButton(){
        fixture.logger.info('clicking on add reservation button');
        await this.pwWrapper.elementAction.waitAndClickButtonByRole(this.Elements.addReservationButtonName, 60000, true);
    }

    async selectProductLineForANewReservation(productLine: string){
        fixture.logger.info(`selecting product line - ${productLine} on seed reservation page for a new reservation`);
        await this.pwWrapper.elementAction.clickElementByRole(HtmlRoles.TABLE_CELL, this.Elements.selectProductLineCellText);
        await this.pwWrapper.dataWriter.enterValueIntoElementByTestIdAndRole(this.Elements.productLineTestId, HtmlRoles.COMBOBOX, productLine);
    }
    async selectMarketingBrandForANewReservation(marketingBrand: string){
        fixture.logger.info(`selecting marketing brand - ${marketingBrand} on seed reservation page for a new reservation`);
        await this.pwWrapper.elementAction.clickElementByRole(HtmlRoles.TABLE_CELL, this.Elements.selectMarketingBrandCellText);
        await this.pwWrapper.dataWriter.enterValueIntoElementByTestIdAndRole(this.Elements.marketingBrandTestId, HtmlRoles.COMBOBOX, marketingBrand);
    }

    async selectProductLineForAnExistingReservation(productLine: string){
        fixture.logger.info(`selecting product line - ${productLine} on seed reservation page for an existing reservation`);
        await this.pwWrapper.elementAction.clickElementByText(this.Elements.productLineText, false);
        await this.pwWrapper.elementAction.clickLabelledTextElement(HtmlRoles.OPTIONS_LIST, productLine);
    }
    
    async selectMarketingBrandForAnExistingReservation(marketingBrand: string){
        fixture.logger.info(`selecting marketing brand - ${marketingBrand} on seed reservation page for an existing reservation`);
        await this.pwWrapper.elementAction.clickElementByRole(HtmlRoles.TABLE_CELL, this.Elements.selectMarketingBrandCellText);
        await this.pwWrapper.elementAction.clickElementByRole(HtmlRoles.OPTION, marketingBrand);
    }

    async increaseReservationQty(){
        fixture.logger.info('increasing reservation quantity');
        await this.pwWrapper.elementAction.clickElementByTestId(this.Elements.increaseQtyTestId);
    }

    async decreaseReservationQty(){
        fixture.logger.info('decreasing reservation quantity');
        await this.pwWrapper.elementAction.clickElementByTestId(this.Elements.decreaseQtyTestId);
    }

    async isSubmitReservationButtonEnabled(): Promise<boolean>{
        fixture.logger.info('checking for submit reservation button enabled status');
        const isEnabled = await this.pwWrapper.pageElement.isElementByRoleEnabled(HtmlRoles.BUTTON, this.Elements.submitReservationButtonName);
        fixture.logger.info(`submit reservation button enabled status is - ${isEnabled}`);
        return isEnabled;
    }

    async clickOnSubmitReservationButton(confirmRetailerDetails: boolean = true){
        fixture.logger.info('clicking on submit reservation button');
        await this.pwWrapper.elementAction.waitAndClickButtonByRole(this.Elements.submitReservationButtonName, 60000, true);
        if(confirmRetailerDetails){
            fixture.logger.info('clicking on Yes confirmation button');
            await this.pwWrapper.elementAction.waitAndClickButtonByRole(this.Elements.yesConfirmationButtonName, 60000, true);
        }
        await super.waitUntilButtonIsDisplayed(this.Elements.backToReservationListButtonName);
    }
    
    async selectReservationLineItem(productLine: string, marketingBrand: string){
        fixture.logger.info(`checking/selecting reservation line item for product line - ${productLine}, and marketing brand - ${marketingBrand}`);
        const roleName = productLine + " " + marketingBrand;
        const rowElement = await this.pwWrapper.pageElement.getElementByRole(HtmlRoles.TABLE_ROW_ROLE, roleName);
        await this.pwWrapper.elementAction.checkChildElementByLabel(rowElement, '', true);
    }

    async isBackToReservationListButtonEnabled(): Promise<boolean>{
        fixture.logger.info('checking for back to reservation list button enabled status');
        const isEnabled = await this.pwWrapper.pageElement.isElementByRoleEnabled(HtmlRoles.BUTTON, this.Elements.backToReservationListButtonName);
        fixture.logger.info(`back to reservation list button enabled status is - ${isEnabled}`);
        return isEnabled;
    }

    async clickOnBackToReservationListButton(){
        fixture.logger.info('clicking on back to reservation list button');
        await this.pwWrapper.elementAction.waitAndClickButtonByRole(this.Elements.backToReservationListButtonName, 60000, true);
    }

    async isUpdateReservationButtonEnabled(): Promise<boolean>{
        fixture.logger.info('checking for update reservation button enabled status');
        const isEnabled = await this.pwWrapper.pageElement.isElementByRoleEnabled(HtmlRoles.BUTTON, this.Elements.updateReservationButtonName);
        fixture.logger.info(`update reservation button enabled status is - ${isEnabled}`);
        return isEnabled;
    }

    async clickOnUpdateReservationButton(){
        fixture.logger.info('clicking on update reservation button');
        await this.pwWrapper.elementAction.waitAndClickButtonByRole(this.Elements.updateReservationButtonName, 60000, true);
        await super.waitUntilButtonIsDisplayed(this.Elements.backToReservationListButtonName);
    }

    async clickOnClearAllButton(){
        const count = await this.pwWrapper.pageElement.getAvailableElementCount(this.Elements.clearAllButtonXPath);
        if(count > 0){
            fixture.logger.info('clicking on clear all button');
            await this.pwWrapper.elementAction.clickElement(this.Elements.clearAllButtonXPath);
        }
    }

    async clickOnDeleteButton(confirmDeletion: boolean = true){
        fixture.logger.info('clicking on delete button');
        await this.pwWrapper.elementAction.clickElement(this.Elements.deleteButtonXPath);
        if(confirmDeletion){
            fixture.logger.info('clicking on Yes confirmation button');
            await this.pwWrapper.elementAction.waitAndClickButtonByRole(this.Elements.yesConfirmationButtonName, 60000, true);
        }
    }
}