import { fixture } from "../../../hooks/fixture";
import BasePage from "../../basePage";
import HtmlRoles from "../../../helpers/wrapper/htmlRoles";

export default class SeedReservationsListPage extends BasePage {
    replaceAccountNumber: string = "replace-account-number";
    replaceReservationId: string = "replace-reservation-id";
    replaceGrowerGMK: string = "replace-grower-gmk";
    replaceSearchText: string = "replace-search-text";

    Elements = {
        seedReservationsPageUri: "seed-reservation-landing",
        createNewReservationButtonName: "Create New Reservation",
        selectAccountDropdownPlaceholder: 'Select Account',
        selectGrowerDropdownPlaceholder: 'Select Grower',
        noDataFoundMsgXPath: `//div[text()=' No data found for "${this.replaceSearchText}" ']`,
        reservationRowTestId: `btn-context-menu-${this.replaceReservationId}`,
        editReservationContextMenuItemName: 'Edit Reservation',
        deleteReservationContextMenuItemName: 'Delete Reservation',
        convertReconcileReservationContextMenuItemName: 'Convert/Reconcile Reservation',
        yesConfirmationButtonName: 'Yes',
        noConfirmationButtonName: 'No',
    }

    private async isPageLoaded(): Promise<boolean> {
        await super.waitUntilButtonIsDisplayed(this.Elements.createNewReservationButtonName);
        return true;
    }

    async isPageStable() {
        fixture.logger.info('checking for seed-reservations-list-page stability');
        const res = await this.isPageLoaded();
        fixture.logger.info('checking for seed-reservations-list-page stability completed');

        return res;
    }

    async clickOnNewReservationButton() {
        fixture.logger.info('clicking on create new reservation button');
        await this.pwWrapper.elementAction.waitAndClickButtonByRole(this.Elements.createNewReservationButtonName, 60000, true);
    }

    async isReservationAvailable(accountNumber: string, growerGMK: string): Promise<boolean> {
        let finalNoDataFoundMsgXPath = this.Elements.noDataFoundMsgXPath.replace(this.replaceSearchText, accountNumber);
        await this.sharedBehavior.selectAngularDropdownOptionByPlaceholder(this.Elements.selectAccountDropdownPlaceholder, accountNumber, finalNoDataFoundMsgXPath);
        finalNoDataFoundMsgXPath = this.Elements.noDataFoundMsgXPath.replace(this.replaceSearchText, growerGMK);
        await this.sharedBehavior.selectAngularDropdownOptionByPlaceholder(this.Elements.selectGrowerDropdownPlaceholder, growerGMK, finalNoDataFoundMsgXPath);
        await this.pwWrapper.common.delay(500); // it can take time to populate the grid after selecting account and grower so wait for the page to load after selecting account and grower
        const count = await this.pwWrapper.pageElement.getAvailableElementCountByTestId(accountNumber);
        fixture.logger.info(`reservation count for account number - ${accountNumber} and grower GMK - ${growerGMK} is ${count}`);
        return count > 0;
    }

    async selectAccountFromDropDown(accountNumber: string) {
        fixture.logger.info(`selecting account - ${accountNumber} on seed reservation page`);
        const finalNoDataFoundMsgXPath = this.Elements.noDataFoundMsgXPath.replace(this.replaceSearchText, accountNumber);
        await this.sharedBehavior.selectAngularDropdownOptionByPlaceholder(this.Elements.selectAccountDropdownPlaceholder, accountNumber, finalNoDataFoundMsgXPath);
    }

    async selectGrowerFromDropDown(growerGMK: string) {
        fixture.logger.info(`selecting grower - ${growerGMK} on seed reservation page`);
        const finalNoDataFoundMsgXPath = this.Elements.noDataFoundMsgXPath.replace(this.replaceSearchText, growerGMK);
        await this.sharedBehavior.selectAngularDropdownOptionByPlaceholder(this.Elements.selectGrowerDropdownPlaceholder, growerGMK, finalNoDataFoundMsgXPath);
    }

    async clickOnReservationContextMenu(reservationId: string) {
        const finalReservationRowTestId = this.Elements.reservationRowTestId.replace(this.replaceReservationId, reservationId);
        fixture.logger.info(`clicking on reservation context menu for reservation id - ${reservationId}`);
        await this.pwWrapper.elementAction.clickElementByTestId(finalReservationRowTestId);
    }

    async clickOnEditReservationContextMenuItem() {
        fixture.logger.info(`clicking on edit reservation context menu item`);
        await this.pwWrapper.elementAction.waitAndClickButtonByNonDefaultRole(this.Elements.editReservationContextMenuItemName, HtmlRoles.MENU_ITEM, 60000);
    }

    async clickOnDeleteReservationContextMenuItem() {
        fixture.logger.info(`clicking on delete reservation context menu item`);
        await this.pwWrapper.elementAction.waitAndClickButtonByNonDefaultRole(this.Elements.deleteReservationContextMenuItemName, HtmlRoles.MENU_ITEM, 60000);
    }

    async clickOnConvertReconcileReservationContextMenuItem() {
        fixture.logger.info(`clicking on convert/reconcile reservation context menu item`);
        await this.pwWrapper.elementAction.waitAndClickButtonByNonDefaultRole(this.Elements.convertReconcileReservationContextMenuItemName, HtmlRoles.MENU_ITEM, 60000);
    }

    async confirmOperationOnConfirmationDialog(confirm: boolean) {
        fixture.logger.info(`confirming operation on confirmation dialog with confirm value - ${confirm}`);
        if (confirm) {
            await this.pwWrapper.elementAction.waitAndClickButtonByRole(this.Elements.yesConfirmationButtonName, 60000, true);
        } else {
            await this.pwWrapper.elementAction.waitAndClickButtonByRole(this.Elements.noConfirmationButtonName, 60000, true);
        }
    }
}