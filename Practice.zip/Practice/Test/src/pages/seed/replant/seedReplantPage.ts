const { format } = require('date-fns');
import * as fs from "fs";
import * as path from "path";
import { expect, Locator } from "@playwright/test";
import * as XLSX from "xlsx";
const { PDFParse } = require("pdf-parse");
import HtmlRoles from "../../../helpers/wrapper/htmlRoles";
import { fixture } from "../../../hooks/fixture";
import BasePage from "../../basePage";
import { ActionUtility } from "../../../helpers/util/actionUtility";
import { DateTimeUtility } from "../../../helpers/util/date-time-utility";
import DataBagKeys from "../../../tests/steps/dataBagKeys";
import EvolveDbManager from "../../../helpers/util/db/evolveDbManager";
import SeedReplantRequestGetOrCreateSpResult from "../../../helpers/util/db/resultSets/seed/seedReplantGetOrCreateSpResult";
import { fi, is } from "date-fns/locale";
import  seedReplantContants  from "../../../helpers/util/test-data/seedReplant/seedReplantContants";
import { SkipScenarioError } from "../../../helpers/util/errorHandler";

const userName = process.env.EvolveUserName as string;

export default class SeedReplantPage extends BasePage {
  actionUtility: ActionUtility = new ActionUtility(this.page);
  dateTimeUtility: DateTimeUtility = new DateTimeUtility();

  protected checkBoxToEnableCreditAccount: Locator = this.page.locator("//input[@type='checkbox' and contains(@id, 'mat-mdc-checkbox')]");
  protected nonSubscriberEmailXpath: Locator = this.page.locator ("//input[@name='emailAddress']");
  readonly tabName = 'tab-name';
  
  protected Elements = {
    seedMenuItemTestId: 'menu-seed',
    seedReplantMenuName: 'Seed Replant',
    seedReplantUri: 'seed-replant-landing',
    statusNoticeBar: `//div[@class='status-bar']//span[text()='Status Notice:']/following-sibling::span`,
    //statusBarExpectedMessage: 'Replants are now open for all Crops. If you have any questions or concerns, contact WinfieldCustomerService@landolakes.com or call 855-494-6343.',
    statusBarExpectedMessage1: 'Replants are now closed for all Crops except Alfalfa. If you have any questions or concerns, contact WinfieldCustomerService@landolakes.com or call 855-494-6343.',
    search: "Search",
    exportbtn: "Export",
    exportToExcel: "Export to Excel",
    createNewRequestbtn: "Create New Request",
    headerFilter: "//ng-select[@name='ddlOptions']",
    headerFilterXpath:"//ng-dropdown-panel[@role='listbox']/div/div[@class='scrollable-content']",
    replantRequestOrderIdXpath: `//div[contains(@class,'${this.tabName}ReturnRequest')]//tbody[@role='rowgroup']/tr/td[contains(@class,'column-webOrderNumber')]`,
    replantRequestStatusXpath: `//div[contains(@class,'activeReturnRequest')]//tbody[@role='rowgroup']/tr/td[contains(@class,'column-status')]`,
    searchBox: "//input[@placeholder='Search...' and @type='text']",
    activeReplantRequestTab: "//div[@id='activeTab']/h4[text()=' Active Replant Requests ']",
    replantRequestDraftTab: "//div[@id='draftTab']/h4[text()=' Replant Request Drafts ']",
    shipToDropDown: 'Ship To: *',
    shipToAccount: '7025364',
    creditToAccount: 'Credit to Account:',
    creditAccountNumber: '7025369',
    grower: 'Grower:',
    growerGMK: '636',
    nonSubscriberEmail: 'testevolveautomation@test.com',
    accountinvoicedTab: 'Your Account Invoiced Products ',
    parentCompanyInvoicedTab: 'Parent Company Invoiced Products',
    invoicedProductXpath: `//td[@id='td-ProductName']`,
    selectedProductCountXpath: `//span[@class='count' and text()='Product selected ']/span`,
    addToRequestButton: `//span[contains(@class,'mdc-button') and text()='Add To Request']`,
    orderedAccountNumber: `//td[contains(@class,'mat-column-accountNumber')]`,
    draftedOrderDate: `//td[contains(@class,'mat-column-draftDate')]`,
    orderRequestDate: `//td[contains(@class,'mat-column-requestDate')]`,
    firstSeedReplantRequestInList: `//tbody/tr[1]/td[2]`,
    toastMessageXpath: `//div[@role='alert' and contains(@class,'toast-message') and @aria-label='Seed Replant saved successfully.']`,
    inlineErrorMessageXpath: `//div[contains(@class, 'inline-error')]//ol[@class='error-list']/li`,
    expectedToastMessage: 'Seed Replant saved successfully.',
    expectedErrorForUnlicensedGrower: "This grower’s record is currently unlicensed. Contact WinField United Customer Service at winfieldcustomerservice@landolakes.com or 855-494-6343 for assistance and note the Request and Account Number.",
    plusButtonForUnitSoldToGrover: `//input[contains(@id,'txtUnitsSoldToGrower')]/following-sibling::button[contains(@class,'plusBtn')]`,
    plusButtonForFailedUnit: `//input[contains(@id, 'txtFailedUnits')]/following-sibling::button[contains(@class,'plusBtn')]`,
    descriptionOfTheProblem: `//div/textarea[contains(@id, 'txtProblemDescription')]`,
    plusButtonForReplantUnit: `//input[contains(@id, 'txtUnitsCredited')]/following-sibling::button[contains(@class,'plusBtn')]`,
    customerNotes: `//div/textarea[contains(@id, 'txtCustomerNotes')]`,
    originalGrowerInoiceXpath: `//div[@id='failedProductTbl']//input[contains(@id,'txtGrowerInvoice')]`,
    replantGrowerInvoiceXpath: `//div[@id='replantProductTbl']//input[contains(@id,'txtReplantGrowerInvoice')]`,
    originalPlantingDateXpath: `//div/span[text()='Original Planting Date:']/parent::div//button[@aria-label='Open calendar']`,
    replantDateXpath: `//div/span[text()='Replant Date:']/parent::div//button[@aria-label='Open calendar']`,
    calendarPreviourButton: `//button[contains(@class, 'mat-calendar-previous-button')]`,
    submitForApproval: 'Submit for Approval',
    editRequest: 'Edit Request',
    advanceSearchBtnXpath: `//span[text()='Advanced Search']`,
    seedReplantReviewPageBreadcrumb: `//li[@class='breadcrumb-item active']/a[text()='Seed Replant']/parent::li/following-sibling::li/span[@id='spnBreadcrum']`,
    checkBoxOnReviewPage: `//mat-checkbox[@id='chkAgree']`,
    aggrementConfirmationStatement: `//mat-checkbox[@id='chkAgree']/following-sibling::span[text()='I Agree to the above terms and conditions. ']`,
    fullAggrementMessage: 'If a CROPLAN® customer follows proper management practices and does not get a satisfactory stand using qualifying CROPLAN® corn, soybean, canola, grain sorghum and approved alfalfas. CROPLAN® will provide seed for replanting at a discounted price as shown in the current SEED Program Guide. To qualify for the Replant Program any field that is to be replanted must be inspected by your District Manager or Seller before it is replanted. No replant credits will be issued for replanted fields that are not inspected before they are replanted. Replant credit will be given for fields replanted in current year and will not be issued for future years. I agree that the seed I have received is accepted in full satisfaction and extinguishment of all claims and causes faction against CROPLAN®, its sellers, employees and/or agents, arising out of any damage or loss, present or future, to crops, plants or land, direct or indirect, known or unknown, sustained by the undersigned during the current crop season. It is agreed that this is a compromise of a disputed claim and that the making of this payment is not an admission of liability on the part of CROPLAN®. All requests for replant are pending until final approval by the appropriate CROPLAN® product manager.',
    aggrementMessageXpath: `//div[contains(@class,'SeedReplantReview')]//p/span`,
    toastMessageXpathForSubmitApproval: `//div[@role='alert' and contains(@class,'toast-message') and @aria-label='Seed Replant Review request saved successfully.']`,
    expectedToastMessageForSubmitApproval: 'Seed Replant Review request saved successfully.',
    eligibleUnitInFailedProduct: `//td[contains(@class, 'mat-column-eligibleUnits') and contains(@id, 'failedProductTbl')]//div[contains(@class, 'measureUnit')]/p`,
    eligibleUnitInReplantProduct: `//td[contains(@class, 'mat-column-eligibleUnits') and contains(@id, 'replantProductTbl')]//div[contains(@class, 'measureUnit')]/p`,
    viewAsPdfBtn: `//div[text()=' View PDF to Print ']/span[contains(@class, 'round-icon')]`,
    failedProductTreatment: `//td[contains(@class,'column-treatment') and contains(@id,'failedProductTbl')]`,
    replantProductTreatment: `//td[contains(@class,'column-treatment') and contains(@id,'replantProductTbl')]`,
    failedProductTreatmentOnReview: `//p[normalize-space(text())='Failed Product']/ancestor::div[contains(@class,'OrderReleaseTop')]/following-sibling::div[1]//tbody/tr/td[contains(@class,'column-treatment')]`,
    replantProductTreatmentOnReview: `//p[normalize-space(text())='Replant Product']/ancestor::div[contains(@class,'OrderReleaseTop')]/following-sibling::div[1]//tbody/tr/td[contains(@class,'column-treatment')]`,
    requestDetailsRoot: `//app-seed-replant-review`,
  };

  protected get seedReplantActiveOrDraftspResultData() { return fixture.dataBag.getData(DataBagKeys.SEED_REPLANT_ACTIVE_OR_DRAFT); }
  // Use a getter so we always read the latest value from the DataBag (it may be populated after page object construction)
  protected get seedReplantCreatespResultDataLicensed() { return fixture.dataBag.getData(DataBagKeys.SEED_REPLANT_CREATE_LICENSED); }
  protected get seedReplantCreatespResultDataUnlicensed() { return fixture.dataBag.getData(DataBagKeys.SEED_REPLANT_CREATE_UNLICENSED); }
  protected get seedReplantDetailspResultDataFailedProduct() { return fixture.dataBag.getData(DataBagKeys.SEED_REPLANT_DETAIL_FAILED); }
  protected get seedReplantDetailspResultDataReplantProduct() { return fixture.dataBag.getData(DataBagKeys.SEED_REPLANT_DETAIL_REPLANT); }

  private ensureSeedReplantCreateData(isGrowerLicensed: string) {
    const licensedData = this.seedReplantCreatespResultDataLicensed;
    const unlicensedData = this.seedReplantCreatespResultDataUnlicensed;
    if (isGrowerLicensed.toLowerCase() === 'yes') {
      if (!licensedData || licensedData.ShipToAccount == null || licensedData.ShipToAccount == undefined) {
        throw new Error('Seed replant create result data is missing (DataBag key: SEED_REPLANT_CREATE_LICENSED). Ensure the setup step saved the data before calling this method.');
      }
      fixture.logger.info("licensed Grower Data received from DB :" , licensedData);
      return licensedData;
    } 
    if (isGrowerLicensed.toLowerCase() === 'no') {
      if (!unlicensedData || unlicensedData.ShipToAccount == null || unlicensedData.ShipToAccount == undefined) {
        throw new Error('Seed replant create result data is missing (DataBag key: SEED_REPLANT_CREATE_UNLICENSED). Ensure the setup step saved the data before calling this method.');
      }
      fixture.logger.info("unlicensed Grower Data received from DB :" , unlicensedData);
      return unlicensedData;
    }
  }

  async getDropDownXpath(dropDownName: String): Promise<string> {
    return `//input[@aria-autocomplete='list']/ancestor::div/preceding-sibling::div[contains(@class, 'ng-placeholder') and contains(text(), '${dropDownName}')]`;
  }

  async getButtonXpathOnSeedReplantPage(buttonName: string): Promise<string> {
    const buttonXpath = `//button[.//span[@class='mdc-button__label' and text()='${buttonName}']]`;
    const searchBtnXpath = `//button[@type='submit']/span[contains(text(), 'Search')]`;
    return buttonXpath;
  }

  async getButtonXpathOnSeedReplantPageAdvanceSearch(buttonName: string): Promise<string> {
    const BtnXpath = `//button[@type='submit']/span[contains(text(), '${buttonName}')]`;
    return BtnXpath;
  }

  async getTabXpathForFailedAndReplantProduct(type: string, tabName: string): Promise<string> {
    // Use normalize-space contain to be resilient to whitespace/formatting differences
    return `//div[@id='${type}AccountTab']/h4[contains(normalize-space(.), '${tabName}')]`;
  }

  async getXpathForDateToBeSelected(numberOfDaysFromTodaysDate: number = 0): Promise<Locator> {
    const dateToBeSelected = this.dateTimeUtility.getFormattedDate_MMMM_D_YYYY(numberOfDaysFromTodaysDate);
    return this.page.locator(`//button[@aria-label='${dateToBeSelected}']`);
  }

  async verifyPageAndItsHeader(pagePath: string, selector: string): Promise<string> {
    await expect(this.page).toHaveURL(new RegExp(`.*${pagePath}`));
    const header = await this.page.locator(selector).innerText();
    return (header?.trim()) as string;
  }

  async getStatusNoticeMessageFromDB(): Promise<string> {
    let evolveDbManager = new EvolveDbManager();
    const statusNoticeMessage = await evolveDbManager.getDataFromDBForSpecificCondition(
      'ConfigIDValue',
      'Replant_AdminConfig',
      "ConfigIDName='SeedReplantLandingPageStatusNotice'"
    );
    return statusNoticeMessage.trim();
  }

  async getStatusBarMessage(): Promise<string> {
    const statusBarMessage = await this.actionUtility.getTextFromLocator(this.page.locator(this.Elements.statusNoticeBar));
    return statusBarMessage.trim();
  }

  async switchToTab(tabName: string): Promise<void> {
    if (tabName.toLowerCase() === 'active') {
    await this.page.click(this.Elements.activeReplantRequestTab);
    } else if (tabName.toLowerCase() === 'draft') { 
    await this.page.click(this.Elements.replantRequestDraftTab);
    }
  }

  async isElementPresent(selector: string): Promise<boolean> {
    try {
        const element = this.page.locator(selector);
        return await element.count() > 0;
    } catch (error) {
        console.error(`Error checking element presence for selector: ${selector}`, error);
        return false;
    }
  }

  async verifyElementVisibility() {
    await this.waitForPageLoad(this.page);
    const isSearchButtonPresent = await this.isElementPresent(await this.getButtonXpathOnSeedReplantPage(this.Elements.search));
    expect(isSearchButtonPresent).toBe(true);
    const isExportButtonPresent = await this.isElementPresent(await this.getButtonXpathOnSeedReplantPage(this.Elements.exportbtn));
    expect(isExportButtonPresent).toBe(true);
    const isExporttoExcelButtonPresent = await this.isElementPresent(await this.getButtonXpathOnSeedReplantPage(this.Elements.exportToExcel));
    expect(isExporttoExcelButtonPresent).toBe(true);
    const isCreateNewRequestButtonPresent = await this.isElementPresent(await this.getButtonXpathOnSeedReplantPage(this.Elements.createNewRequestbtn));
    expect(isCreateNewRequestButtonPresent).toBe(true);
    const isHeaderFilterPresent = await this.isElementPresent(this.Elements.headerFilter);
    expect(isHeaderFilterPresent).toBe(true);
    const isSearchBoxPresent = await this.isElementPresent(this.Elements.searchBox);
    expect(isSearchBoxPresent).toBe(true);
    const isReplantRequestDraftTabPresent = await this.isElementPresent(this.Elements.replantRequestDraftTab);
    expect(isReplantRequestDraftTabPresent).toBe(true);
    const isActiveReplantRequestTabPresent = await this.isElementPresent(this.Elements.activeReplantRequestTab);
    expect(isActiveReplantRequestTabPresent).toBe(true);
    const statusBarMessage = await this.actionUtility.normaliseTheText(await this.getStatusBarMessage());
    const expected1 = await fixture.dataBag.getData(DataBagKeys.SEED_REPLANT_STATUS_NOTICE_MESSAGE);
    //const expected1 = await this.actionUtility.normaliseTheText(this.Elements.statusBarExpectedMessage);
    const expected2 = await this.actionUtility.normaliseTheText(this.Elements.statusBarExpectedMessage1);
    expect([expected1, expected2]).toContain(statusBarMessage);
  }

  async verifyElementsVisibilityOnSeedReplantRequestReview() {
    await this.waitForPageLoad(this.page);
    //const errorForUnlicensedGrower = await this.isElementPresent(this.Elements.inlineErrorMessageXpath);
    await this.verifyPageAndItsHeader("seed-replant-review", this.Elements.seedReplantReviewPageBreadcrumb);
    await expect(this.page.locator(this.Elements.seedReplantReviewPageBreadcrumb)).toHaveText(/Review Request \[\d+\]/);
    const isSubmitForApproval = await this.isElementPresent(await this.getButtonXpathOnSeedReplantPage(this.Elements.submitForApproval));
    expect(isSubmitForApproval).toBe(true);
    const isEditRequest = await this.isElementPresent(await this.getButtonXpathOnSeedReplantPage(this.Elements.editRequest));
    expect(isEditRequest).toBe(true);
    await expect(this.page.locator(this.Elements.checkBoxOnReviewPage)).toBeVisible();
    await expect(this.page.locator(this.Elements.aggrementConfirmationStatement)).toBeVisible();
    const aggrementMessage = await this.actionUtility.getTextFromLocator(this.page.locator(this.Elements.aggrementMessageXpath));
    expect(aggrementMessage.trim()).toBe(this.Elements.fullAggrementMessage);
  }

  async selectShipToAccount(isGrowerLicensed: string) {
    const data = this.ensureSeedReplantCreateData(isGrowerLicensed);
    const shipToAccount = data.ShipToAccount.toString();
    await this.sharedBehavior.selectDropdownOptionByPlaceholder(this.Elements.shipToDropDown, shipToAccount);
  }

  async verifyFilterDropDownOptions(): Promise<void> {
    await this.pwWrapper.elementAction.clickElement(this.Elements.headerFilter);
    const actualOptions: string[] = await this.actionUtility.getAllCustomDropdownOptions(this.Elements.headerFilterXpath) as string[];
    fixture.logger.info(`Actual dropdown options retrieved: ${actualOptions.join(', ')}`);
    const expectedOptions: string[] = seedReplantContants.filterOptionsOnSeedReplantPage as string[];
    await this.actionUtility.verifyArrayValues(expectedOptions, actualOptions);
  }

  /**
   * Opens Header filter dropdown and returns available options.
   * If expectedOptions are provided, verifies that each expected option is present.
   */
  async getHeaderFilterOption(expectedOptions?: string[]): Promise<string[]> {
    const input = this.page.locator(this.Elements.headerFilterXpath);
    await input.click();

    const panel = this.page.locator('ng-dropdown-panel');
    await panel.waitFor({ state: 'visible', timeout: 5000 });

    const optionLocator = this.page.locator('ng-dropdown-panel .ng-option');
    await optionLocator.first().waitFor({ state: 'visible', timeout: 5000 });

    const count = await optionLocator.count();
    const options: string[] = [];
    for (let i = 0; i < count; i++) {
      const text = (await optionLocator.nth(i).innerText()).replace(/\s+/g, ' ').trim();
      if (text.length > 0) {
        options.push(text);
      }
    }

    const uniqueOptions = [...new Set(options)];

    if (expectedOptions && expectedOptions.length > 0) {
      const normalizedExpected = expectedOptions.map(opt => opt.replace(/\s+/g, ' ').trim());
      for (const expected of normalizedExpected) {
        expect(uniqueOptions).toEqual(expect.arrayContaining([expected]));
      }
    }

    await this.page.keyboard.press('Escape');
    return uniqueOptions;
  }

  /**
   * Backward compatible wrapper for existing usages.
   */
  async getHeaderFilterOptions(): Promise<string[]> {
    return this.getHeaderFilterOption();
  }

  /**
   * Returns the visible rows' innerText from the seed replant list table
   */
  async getAllRowTexts(): Promise<string[]> {
    const rows = this.page.locator('tbody tr');
    const count = await rows.count();
    const arr: string[] = [];
    for (let i = 0; i < count; i++) {
      arr.push((await rows.nth(i).innerText()).trim());
    }
    return arr;
  }

  /**
   * Validates Order Numbers from SP result against Order Number column (td[2]) on Seed Replant grid.
   * If SP returns no rows, UI should also show no order-number cells.
   * If SP returns rows, UI count must match and values must match irrespective of order.
   */
  async validateOrderNumbersFromSpResult(expectedOrderNumbers: Array<string | number>): Promise<void> {
    const orderNumberCells = this.page.locator("//tbody[@role='rowgroup']/tr/td[2]");
    const normalizedExpectedInput = expectedOrderNumbers ?? [];

    const normalize = (value: string | number): string =>
      value
        .toString()
        .replace(/,/g, '')
        .replace(/\s+/g, '')
        .trim();

    const expectedSorted = normalizedExpectedInput
      .map(normalize)
      .filter(v => v.length > 0)
      .sort();

    const uiCount = await orderNumberCells.count();

    if (expectedSorted.length === 0) {
      expect(uiCount, 'UI should not display any order numbers when SP returns 0 results.').toBe(0);
      return;
    }

    expect(uiCount, `Order number count mismatch. UI count: ${uiCount}, SP count: ${expectedSorted.length}`).toBe(expectedSorted.length);

    const uiOrderNumbersRaw = await orderNumberCells.allInnerTexts();

    const uiSorted = uiOrderNumbersRaw
      .map(normalize)
      .filter(v => v.length > 0)
      .sort();

    expect(uiSorted, `UI order numbers mismatch. UI: [${uiSorted.join(', ')}], Expected: [${expectedSorted.join(', ')}]`).toEqual(expectedSorted);
  }

  /**
   * Reads Active/Draft SP result from DataBag, extracts request/order numbers and validates them against UI.
   */
  async validateOrderNumbersFromStoredSpResult(): Promise<void> {
    const spResultData = this.seedReplantActiveOrDraftspResultData;

    if (spResultData == null) {
      throw new Error('Seed replant Active/Draft SP result data is missing (DataBag key: SEED_REPLANT_ACTIVE_OR_DRAFT).');
    }

    const spRows = Array.isArray(spResultData) ? spResultData : [spResultData];
    const expectedOrderNumbers = spRows
      .map(row => row?.RequestNumber)
      .filter(value => value !== null && value !== undefined && value.toString().trim().length > 0);

    await this.validateOrderNumbersFromSpResult(expectedOrderNumbers);
  }

  async selectCheckBoxToEnableCreditToAccount(): Promise<boolean> {
      await this.checkBoxToEnableCreditAccount.click();
      const isCheckboxChecked = await this.checkBoxToEnableCreditAccount.isChecked();
      return isCheckboxChecked;
  }

  async selectCreditAccount(isGrowerLicensed: string, isCheckboxChecked: boolean) {
    const data = this.ensureSeedReplantCreateData(isGrowerLicensed);
      if(isCheckboxChecked){
        let creditToAccount = data.CreditToAccount.toString();
        try {
          await this.sharedBehavior.selectDropdownOptionByPlaceholder(this.Elements.creditToAccount, creditToAccount);
        } catch (err) {
          fixture.logger.warn(`selectCreditAccount: failed to select via dropdown - ${err}. Attempting to select first available option.`);
          try {
            const ngSelectLocator = this.page.locator(`ng-select[placeholder="${this.Elements.creditToAccount}"]`);
            await ngSelectLocator.click();
            const firstOption = this.page.locator('ng-dropdown-panel .ng-option').first();
            await firstOption.waitFor({ state: 'visible', timeout: 5000 });
            await firstOption.click();
            fixture.logger.info(`selectCreditAccount: selected first option from dropdown for placeholder ${this.Elements.creditToAccount}`);
          } catch (innerErr) {
            fixture.logger.error(`selectCreditAccount: selecting first option failed - ${innerErr}`);
            throw innerErr;
          }
        }
    }
  }

  async selectGrower(isGrowerLicensed: string) {
    const data = this.ensureSeedReplantCreateData(isGrowerLicensed);
    let growerAccount = data.GrowerGMK.toString();
    try {
      await this.sharedBehavior.selectDropdownOptionByPlaceholder(this.Elements.grower, growerAccount);
    } catch (err) {
      fixture.logger.warn(`selectGrower: failed to select via dropdown - ${err}. Attempting via advance search.`);
      try {
        let GrowerFirstName = data.GrowerFirstName;
        let GrowerLastName = data.GrowerLastName;
        if (GrowerFirstName && GrowerLastName) {
          GrowerFirstName = GrowerFirstName.toString().trim();
          GrowerLastName = GrowerLastName.toString().trim();
        }
        let growerBusinessName = data.GrowerBusinessName;
        if (growerBusinessName) {
          growerBusinessName = growerBusinessName.toString().trim();
        }
        await this.sharedBehavior.selectGrowerByAdvanceSearch(this.Elements.advanceSearchBtnXpath,
        GrowerFirstName, GrowerLastName, await this.getButtonXpathOnSeedReplantPageAdvanceSearch("Search"), growerBusinessName);
        fixture.logger.info(`selectGrower via advance search is succeeded for ${growerAccount}`);
      } catch (innerErr) {
        fixture.logger.error(`selectGrower via advance search is failed - ${innerErr}`);
        throw innerErr;
      }
    }
  }

  async fillNonSubscriberEmail(xpath: Locator, email: string) {
    await this.actionUtility.click(xpath);
    await this.actionUtility.inputValue(xpath, email);
  }

  async openCreateNewSeedReplantPage() {
    const createNewRequestButton = this.page.locator(await this.getButtonXpathOnSeedReplantPage("Create New Request"));
    await createNewRequestButton.waitFor({ state: 'visible' });
    await createNewRequestButton.click();
    await this.waitForPageLoad(this.page);
  }

  async exportSeedReplantDataToExcel(): Promise<{ filePath: string; fileName: string; rowCount: number; sampledOrderNumbers: string[] }> {
    await this.waitForPageLoad(this.page);

    const normalizeText = (value: string | number): string =>
      value
        .toString()
        .replace(/,/g, '')
        .replace(/\s+/g, ' ')
        .trim();

    const orderNumberCells = this.page.locator(this.Elements.replantRequestOrderIdXpath.replace(this.tabName, 'active'));
    const availableRequestCount = await orderNumberCells.count();
      if (availableRequestCount === 0) {
        fixture.logger.info('No order numbers found in UI to validate against exported data.');
        const exportButton = this.page.locator(await this.getButtonXpathOnSeedReplantPage(this.Elements.exportbtn));
        await expect(exportButton).toHaveAttribute('disabled', 'true');
        return { filePath: '', fileName: '', rowCount: 0, sampledOrderNumbers: [] };
      } else {
        const uiOrderNumbers = (await orderNumberCells.allInnerTexts())
          .map(normalizeText)
          .filter(value => value.length > 0);

        const exportButton = this.page.locator(await this.getButtonXpathOnSeedReplantPage(this.Elements.exportbtn));
        await exportButton.waitFor({ state: 'visible', timeout: 10000 });

        const [download] = await Promise.all([
          this.page.waitForEvent('download'),
          exportButton.click(),
        ]);

        const downloadFailure = await download.failure();
        expect(downloadFailure, `Download failed: ${downloadFailure}`).toBeNull();

        const fileName = download.suggestedFilename();
        expect(fileName).toMatch(/\.xlsx$/i);

        const scenarioName = (fixture.dataBag.getData(DataBagKeys.SCENARIO_NAME) ?? 'seed-replant-export').toString();
        const safeScenarioName = scenarioName.replace(/[<>:"/\\|?*\x00-\x1F]/g, '_');
        const downloadDir = path.join(process.cwd(), 'test-results', 'downloads', safeScenarioName);
        fs.mkdirSync(downloadDir, { recursive: true });

        const filePath = path.join(downloadDir, `${Date.now()}-${fileName}`);
        await download.saveAs(filePath);

        expect(fs.existsSync(filePath)).toBeTruthy();

        const fileStats = fs.statSync(filePath);
        expect(fileStats.size).toBeGreaterThan(0);

        const workbook = XLSX.readFile(filePath);
        expect(workbook.SheetNames.length).toBeGreaterThan(0);

        const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
        const sheetRows = XLSX.utils.sheet_to_json<Array<string | number>>(firstSheet, {
          header: 1,
          defval: '',
          raw: false,
        });

        const nonEmptyRows = sheetRows.filter((row) => Array.isArray(row) && row.some((cell) => normalizeText(cell).length > 0));
        expect(nonEmptyRows.length).toBeGreaterThan(1);

        const exportedText = nonEmptyRows
          .flat()
          .map(normalizeText)
          .filter(value => value.length > 0)
          .join(' ');

        const sampledOrderNumbers = uiOrderNumbers.slice(0, Math.min(3, uiOrderNumbers.length));
        for (const orderNumber of sampledOrderNumbers) {
          expect(exportedText).toContain(orderNumber);
        }

        return {
          filePath,
          fileName,
          rowCount: nonEmptyRows.length,
          sampledOrderNumbers,
        };
      }
}

  async enterDataInHeaderFields(isLicensedGrower: string, isCreditAccountDifferentThanShipTo?: boolean) {
    await this.selectShipToAccount(isLicensedGrower);
    if (isCreditAccountDifferentThanShipTo) {
      const isCheckboxChecked = await this.selectCheckBoxToEnableCreditToAccount();
      await this.selectCreditAccount(isLicensedGrower, isCheckboxChecked);
    }
    await this.selectGrower(isLicensedGrower);
  }

  async addFailedProductDetails(isLicensedGrower: string  = "Yes") {
    const addFailedProduct = this.page.locator(await this.getButtonXpathOnSeedReplantPage("Add Failed Product"));
    await addFailedProduct.waitFor({ state: 'visible' });
    await addFailedProduct.click();
    await this.waitForPageLoad(this.page);
    let availableProductCount = await this.page.locator(this.Elements.invoicedProductXpath).count();
    if (availableProductCount <= 0) {
      // switch to parent company invoiced tab and wait for products to appear
      const failedTabXpath = await this.getTabXpathForFailedAndReplantProduct("failedParent", this.Elements.parentCompanyInvoicedTab);
      const parentCompanyInvoicedTab = this.page.locator(failedTabXpath);
      await parentCompanyInvoicedTab.waitFor({ state: 'visible', timeout: 5000 }).catch(() => null);
      await parentCompanyInvoicedTab.click();
      await this.page.waitForSelector(this.Elements.invoicedProductXpath, { state: 'visible', timeout: 5000 }).catch(() => null);
      availableProductCount = await this.page.locator(this.Elements.invoicedProductXpath).count();
      if (availableProductCount <= 0) {
        throw new Error('No invoiced products available to add for failed product');
      }
    }
    const firstProduct = this.page.locator(this.Elements.invoicedProductXpath).first();
    await firstProduct.click();
      expect(await this.page.locator(this.Elements.selectedProductCountXpath).textContent()).toBe("1");
      await this.page.locator(this.Elements.addToRequestButton).click();
      await this.waitForPageLoad(this.page);
      const originalGrowerInvoice = this.page.locator(this.Elements.originalGrowerInoiceXpath);
      await originalGrowerInvoice.fill('INV' + await this.actionUtility.generateRandomNumber());
  }

  async addReplantProductDetails(isLicensedGrower: string = "Yes") {
    const addReplantProduct = this.page.locator(await this.getButtonXpathOnSeedReplantPage("Add Replant Product"));
    await addReplantProduct.waitFor({ state: 'visible' });
    await addReplantProduct.click();
    await this.waitForPageLoad(this.page);
    let availableProductCount = await this.page.locator(this.Elements.invoicedProductXpath).count();
    if (availableProductCount <= 0) {
      // switch to parent company invoiced tab and wait for products to appear
      const replantTabXpath = await this.getTabXpathForFailedAndReplantProduct("replantParent", this.Elements.parentCompanyInvoicedTab);
      const parentCompanyInvoicedTab = this.page.locator(replantTabXpath);
      await parentCompanyInvoicedTab.waitFor({ state: 'visible', timeout: 5000 }).catch(() => null);
      await parentCompanyInvoicedTab.click();
      await this.page.waitForSelector(this.Elements.invoicedProductXpath, { state: 'visible', timeout: 5000 }).catch(() => null);
      availableProductCount = await this.page.locator(this.Elements.invoicedProductXpath).count();
      if (availableProductCount <= 0) {
        throw new Error('No invoiced products available to add for replant product');
      }
    }
    const firstProduct = this.page.locator(this.Elements.invoicedProductXpath).first();
    await firstProduct.click();
      expect(await this.page.locator(this.Elements.selectedProductCountXpath).textContent()).toBe("1");
      await this.page.locator(this.Elements.addToRequestButton).click();
      await this.waitForPageLoad(this.page);
      const replantGrowerInvoice = this.page.locator(this.Elements.replantGrowerInvoiceXpath);
      await replantGrowerInvoice.fill('INV' + await this.actionUtility.generateRandomNumber());
  }

  async selectOriginalPlantingDate(numberOfDaysFromTodaysDate: number = 0) {
    await this.page.locator(this.Elements.originalPlantingDateXpath).click();
    const originalPlantingDateCalendar = await this.getXpathForDateToBeSelected(numberOfDaysFromTodaysDate);
    while(!await originalPlantingDateCalendar.isVisible()) {
      await this.page.locator(this.Elements.calendarPreviourButton).click();
    }
    await originalPlantingDateCalendar.click();
  }

  async selectReplantDate(numberOfDaysFromTodaysDate: number = 0) {
    await this.page.locator(this.Elements.replantDateXpath).click();
    const replantDateCalendar = await this.getXpathForDateToBeSelected(numberOfDaysFromTodaysDate);
    while(!await replantDateCalendar.isVisible()) {
      await this.page.locator(this.Elements.calendarPreviourButton).click();
    }
    await replantDateCalendar.click();
  }

  async addUnitsInFailedProduct(soldToGroverUnit: number = 1, failedUnit: number =1, problemDescription: string = "Problem is for testing purpose") {
    const eligibleUnit = await this.actionUtility.getTextFromLocator(this.page.locator(this.Elements.eligibleUnitInFailedProduct));
    const addUnitForSoldToGrower = this.page.locator(this.Elements.plusButtonForUnitSoldToGrover);
    const addFailedUnit = this.page.locator(this.Elements.plusButtonForFailedUnit);
    if(Number(eligibleUnit) > 0) {
      if(Number(eligibleUnit) < soldToGroverUnit) {
        console.error("Sold to Grover unit:", soldToGroverUnit, ", should not be greater than Eligibile unit:", eligibleUnit);
      } else {
        for (let i=0; i < soldToGroverUnit; i++) {
          await addUnitForSoldToGrower.click();
          await this.page.waitForTimeout(100);
          await addFailedUnit.click();
        }
        const descriptionOfTheProblem = this.page.locator(this.Elements.descriptionOfTheProblem);
        await descriptionOfTheProblem.fill(problemDescription);
        }
    }
    else {
      console.error("Eligible unit is 0, hence replant request can not be submitted");
    }
  }

  async addUnitsInReplantProduct(replantUnit: number = 1, customerNotes: string = "Automation Testing") {
    const eligibleUnit = await this.actionUtility.getTextFromLocator(this.page.locator(this.Elements.eligibleUnitInReplantProduct));
    const addReplantUnit = this.page.locator(this.Elements.plusButtonForReplantUnit);
    if(Number(eligibleUnit) > 0) {
      if(Number(eligibleUnit) < replantUnit) {
        console.error("Replant unit:", replantUnit, ", should not be greater than Eligibile unit:", eligibleUnit);
      } else {
        for (let i=0; i < replantUnit; i++) {
          await addReplantUnit.click();
          await this.page.waitForTimeout(100);
        }
        const addCustomerNotes = this.page.locator(this.Elements.customerNotes);
        await addCustomerNotes.fill(customerNotes);
        }
    }
    else {
      console.error("Eligible unit is 0, hence replant request can not be submitted");
    }
  }

  async createNewSeedReplantDraft(isGrowerLicensed: string) {
    await this.selectShipToAccount(isGrowerLicensed);
    await this.selectGrower(isGrowerLicensed);
    await this.addFailedProductDetails(isGrowerLicensed);
    await this.addUnitsInFailedProduct();
    await this.addReplantProductDetails(isGrowerLicensed);
    await this.addUnitsInReplantProduct();
    const saveDraft = this.page.locator(await this.getButtonXpathOnSeedReplantPage("Save Draft"));
    await saveDraft.click();
    const actualToastMessage = await this.actionUtility.getTextFromLocator(this.page.locator(this.Elements.toastMessageXpath));
    expect(actualToastMessage.trim()).toBe(this.Elements.expectedToastMessage);
  }

  async createNewSeedReplantRequest(isGrowerLicensed: string) {
    await this.pwWrapper.waitForPageStability();
    await this.selectShipToAccount(isGrowerLicensed);
//    await this.selectCheckBoxToEnableCreditToAccount();
    await this.selectGrower(isGrowerLicensed);
    await this.fillNonSubscriberEmail(this.nonSubscriberEmailXpath,this.Elements.nonSubscriberEmail);
    await this.addFailedProductDetails(isGrowerLicensed);
    await this.addUnitsInFailedProduct();
    await this.selectOriginalPlantingDate(-7);
    await this.addReplantProductDetails(isGrowerLicensed);
    await this.addUnitsInReplantProduct();
    await this.selectReplantDate(0);
    await this.getTreamentDetails();
    const reviewRequestBtn = this.page.locator(await this.getButtonXpathOnSeedReplantPage("Review Request"));
    await reviewRequestBtn.click();
    if (isGrowerLicensed.toLowerCase() === 'yes') {
      await this.page.waitForSelector(this.Elements.toastMessageXpath, { state: 'visible', timeout: 10000 });
      const actualToastMessage = await this.actionUtility.getTextFromLocator(this.page.locator(this.Elements.toastMessageXpath));
      fixture.logger.info("Actual toast message: " + actualToastMessage);
      fixture.logger.info("Expected toast message: " + this.Elements.expectedToastMessage);
      expect(actualToastMessage.trim()).toBe(this.Elements.expectedToastMessage);
    }
  }

  async getTreamentDetails() {
    const failedTreatment = await this.actionUtility.getTextByXpath(this.Elements.failedProductTreatment);
    const replantTreatment = await this.actionUtility.getTextByXpath(this.Elements.replantProductTreatment);
    fixture.dataBag.saveData(DataBagKeys.FAILED_TREATMENT, failedTreatment);
    fixture.dataBag.saveData(DataBagKeys.REPLANT_TREATMENT, replantTreatment);
  }

  async verifyErrorMessageForUnlicensedGrower() {
      const isErrorMessageVisible = await this.page.locator(this.Elements.inlineErrorMessageXpath).first().isVisible({ timeout: 5000 });
      if (isErrorMessageVisible) {
      const actualToastMessage = await this.actionUtility.getTextFromLocator(this.page.locator(this.Elements.inlineErrorMessageXpath).first());
      fixture.logger.info("Actual inline error message: " + actualToastMessage);
      fixture.logger.info("Expected inline error message: " + this.Elements.expectedErrorForUnlicensedGrower);
      expect(actualToastMessage.trim()).toBe(this.Elements.expectedErrorForUnlicensedGrower);
      const currentPageURL = this.getCurrentPageURL();
      fixture.logger.info("Current page URL: " + currentPageURL);
      expect(currentPageURL).toBe(process.env.BASEURL + "seed-replant-request-entry");
      } else {
        await this.verifyElementsVisibilityOnSeedReplantRequestReview();
      }
  }

  async submitApprovalForSeedReplantRequest() {
    await this.page.locator(this.Elements.checkBoxOnReviewPage).click();
    const submitForApproval = await this.getButtonXpathOnSeedReplantPage(this.Elements.submitForApproval);
    await this.page.locator(submitForApproval).click();
    const toast = this.page.locator(this.Elements.toastMessageXpathForSubmitApproval);
    await toast.waitFor({ state: 'visible' }); 
    const actualToastMessage = await this.actionUtility.getTextFromLocator(this.page.locator(this.Elements.toastMessageXpathForSubmitApproval));
    fixture.logger.info("Actual toast message for submit approval: " + actualToastMessage);
    fixture.logger.info("Expected toast message for submit approval: " + this.Elements.expectedToastMessageForSubmitApproval);
    expect(actualToastMessage.trim()).toBe(this.Elements.expectedToastMessageForSubmitApproval);
  }

  async verifyTreatmentDetailsOnReviewRequestPage(): Promise<{ failedTreatmentCount: number; replantTreatmentCount: number; failedTreatment: string; replantTreatment: string }> {
    const normalize = (value: string): string => value.replace(/\s+/g, ' ').trim();
    const expectedFailedTreatment = (fixture.dataBag.getData(DataBagKeys.FAILED_TREATMENT) ?? '').toString().trim();
    const expectedReplantTreatment = (fixture.dataBag.getData(DataBagKeys.REPLANT_TREATMENT) ?? '').toString().trim();

    expect(expectedFailedTreatment.length, 'Expected failed product treatment is empty in DataBag.').toBeGreaterThan(0);
    expect(expectedReplantTreatment.length, 'Expected replant product treatment is empty in DataBag.').toBeGreaterThan(0);

    const failedLocator = this.page.locator(this.Elements.failedProductTreatmentOnReview);
    const replantLocator = this.page.locator(this.Elements.replantProductTreatmentOnReview);

    const failedTreatmentValues = (await failedLocator.allInnerTexts())
      .map(value => normalize(value))
      .filter(value => value.length > 0);
    const replantTreatmentValues = (await replantLocator.allInnerTexts())
      .map(value => normalize(value))
      .filter(value => value.length > 0);

    expect(failedTreatmentValues.length, 'No treatment value found in Failed Product section on review page.').toBeGreaterThan(0);
    expect(replantTreatmentValues.length, 'No treatment value found in Replant Product section on review page.').toBeGreaterThan(0);

    const failedExistsOnReview = failedTreatmentValues.some(value => normalize(value).includes(normalize(expectedFailedTreatment)) || normalize(expectedFailedTreatment).includes(normalize(value)));
    const replantExistsOnReview = replantTreatmentValues.some(value => normalize(value).includes(normalize(expectedReplantTreatment)) || normalize(expectedReplantTreatment).includes(normalize(value)));

    expect(failedExistsOnReview, `Failed treatment '${expectedFailedTreatment}' not found on review page. Actual: [${failedTreatmentValues.join(', ')}]`).toBeTruthy();
    expect(replantExistsOnReview, `Replant treatment '${expectedReplantTreatment}' not found on review page. Actual: [${replantTreatmentValues.join(', ')}]`).toBeTruthy();

    return {
      failedTreatmentCount: failedTreatmentValues.length,
      replantTreatmentCount: replantTreatmentValues.length,
      failedTreatment: expectedFailedTreatment,
      replantTreatment: expectedReplantTreatment,
    };
  }

  async viewRequestAsPdf(): Promise<{ filePath: string; fileName: string; fileSize: number; failedTreatmentCount: number; replantTreatmentCount: number }> {
    await this.waitForPageLoad(this.page);

    const treatmentDetails = await this.verifyTreatmentDetailsOnReviewRequestPage();
    const pdfButton = this.page.locator(this.Elements.viewAsPdfBtn).first();
    await pdfButton.waitFor({ state: 'visible', timeout: 15000 });

    const [download] = await Promise.all([
      this.page.waitForEvent('download'),
      pdfButton.click(),
    ]);

    const fileName = download.suggestedFilename();
    expect(fileName).toMatch(/\.pdf$/i);

    const scenarioName = (fixture.dataBag.getData(DataBagKeys.SCENARIO_NAME) ?? 'seed-replant-pdf').toString();
    const safeScenarioName = scenarioName.replace(/[<>:"/\\|?*\x00-\x1F]/g, '_');
    const downloadDir = path.join(process.cwd(), 'test-results', 'downloads', safeScenarioName);
    fs.mkdirSync(downloadDir, { recursive: true });

    const filePath = path.join(downloadDir, `${Date.now()}-${fileName}`);
    await download.saveAs(filePath);
    expect(fs.existsSync(filePath)).toBeTruthy();

    const fileStats = fs.statSync(filePath);
    expect(fileStats.size).toBeGreaterThan(0);

    const normalize = (value: string): string => value.replace(/\s+/g, ' ').trim().toLowerCase();
    const pdfBuffer = fs.readFileSync(filePath);
    const parser = new PDFParse({ data: pdfBuffer });
    const parsedPdf = await parser.getText();
    await parser.destroy();
    const pdfText = normalize((parsedPdf?.text ?? '').toString());
    expect(pdfText.length, 'Downloaded PDF text content is empty.').toBeGreaterThan(0);

    expect(
      pdfText.includes(normalize(treatmentDetails.failedTreatment)),
      `Failed product treatment '${treatmentDetails.failedTreatment}' not found in downloaded PDF.`
    ).toBeTruthy();

    expect(
      pdfText.includes(normalize(treatmentDetails.replantTreatment)),
      `Replant product treatment '${treatmentDetails.replantTreatment}' not found in downloaded PDF.`
    ).toBeTruthy();

    return {
      filePath,
      fileName,
      fileSize: fileStats.size,
      failedTreatmentCount: treatmentDetails.failedTreatmentCount,
      replantTreatmentCount: treatmentDetails.replantTreatmentCount,
    };
  }

  private async waitForReplantListReady(tabName: "active" | "draft"): Promise<void> {
    while (await this.sharedBehavior.isOperationInProgress());
    const requestCells = this.page.locator(this.Elements.replantRequestOrderIdXpath.replace(this.tabName, tabName));
    await requestCells.first().waitFor({ state: 'visible', timeout: 15000 });
    while (await this.sharedBehavior.isOperationInProgress());
  }

  async verifyCreatedOrderIsInDraftTab(isGrowerLicensed: string) {
    const draftTab = this.page.locator(this.Elements.replantRequestDraftTab);
    await draftTab.click();
    await this.waitForReplantListReady("draft");
    const actualAccountNumber = await this.actionUtility.getTextFromLocator(this.page.locator(this.Elements.orderedAccountNumber).first());
    const data = this.ensureSeedReplantCreateData(isGrowerLicensed);
    const expectedAccount = data.ShipToAccount.toString();
    expect(actualAccountNumber.trim()).toBe(expectedAccount);
    const today = new Date();
    const currentDate = await this.dateTimeUtility.formatDate(today, "MM/DD/YYYY");
    const dateText = await this.actionUtility.getTextFromLocator(this.page.locator(this.Elements.draftedOrderDate).first());
    expect(dateText.trim()).toBe(currentDate);
  }

  async verifySubmitedRequestIsInActiveReplantRequestTab() {
    await this.pwWrapper.waitForPageStability();
    const activeTab = this.page.locator(this.Elements.activeReplantRequestTab);
    await expect(activeTab).toBeVisible();
    fixture.logger.info("Active tab is visible");
    await this.waitForReplantListReady("active");
    const actualAccountNumber = await this.actionUtility.getTextFromLocator(this.page.locator(this.Elements.orderedAccountNumber).first());
    const data = this.ensureSeedReplantCreateData("No");
    const expectedAccountForActive = data.ShipToAccount.toString();
    expect(actualAccountNumber.trim()).toBe(expectedAccountForActive);
    const currentDateInUTC = this.dateTimeUtility.getCurrentDateTimeInDesiredTimeZone("UTC", "MM/dd/yyyy");
    console.log(currentDateInUTC);
    const dateText = await this.actionUtility.getTextFromLocator(this.page.locator(this.Elements.orderRequestDate).first());
    expect(dateText.trim()).toBe(currentDateInUTC);
  }

  async isPageStable() {
    fixture.logger.info('checking for seed-replant-page stability');
    await this.waitForPageLoad(this.page);
    fixture.logger.info('checking for seed-replant-page stability completed');
    return true;
  }

  private normalizeComparableText(value: unknown): string {
    if (value === null || value === undefined) {
      return '';
    }

    return value
      .toString()
      .replace(/,/g, '')
      .replace(/\s+/g, ' ')
      .trim();
  }

  async openRequestDetailsByRequestId(tabName: string): Promise<string> {
    await this.switchToTab(tabName);
    await this.waitForPageLoad(this.page);

    const requestIdCell = this.page.locator(this.Elements.replantRequestOrderIdXpath.replace(this.tabName, tabName.toLowerCase())).first();

    await expect(requestIdCell).toBeVisible();
    const requestNumber = this.normalizeComparableText(await this.actionUtility.getTextFromLocator(requestIdCell));
    expect(requestNumber.length, `No request number found on ${tabName} tab.`).toBeGreaterThan(0);

   // await this.getDetailForSeedReplantRequest(tabName, requestNumber);
    await requestIdCell.click();
    await this.waitForPageLoad(this.page);
    return requestNumber;
  }

  async verifySeedReplantRequestDetailsPage(requestNumber: string): Promise<void> {
    await this.waitForPageLoad(this.page);
    const bredcrumbValue = await this.verifyPageAndItsHeader("seed-replant-view-request", this.Elements.seedReplantReviewPageBreadcrumb);
    await expect(bredcrumbValue).toContain(requestNumber);
  }

  async verifySeedReplantRequestDetailData(tabName: string): Promise<void> {
    const seedReplantDetailsFailedProduct = this.seedReplantDetailspResultDataFailedProduct;
    const seedReplantDetailsReplantProduct = this.seedReplantDetailspResultDataReplantProduct;
    expect(seedReplantDetailsFailedProduct, 'Seed replant detail data is missing from DataBag.').toBeDefined();
    expect(seedReplantDetailsReplantProduct, 'Seed replant detail data for replant product is missing from DataBag.').toBeDefined();
    expect(seedReplantDetailsFailedProduct).not.toBeNull();
    expect(seedReplantDetailsReplantProduct).not.toBeNull();

    const detailPageText = this.normalizeComparableText(
      await this.actionUtility.getInnerTextValue(this.page.locator(this.Elements.requestDetailsRoot)),
    );
    console.log("Detail page text: ", detailPageText);

    const expectedFieldValues = [
      { fieldName: 'Request Number', value: seedReplantDetailsFailedProduct.RequestNumber, required: true },
      { fieldName: 'Account Number', value: seedReplantDetailsFailedProduct.AccountNumber, required: true },
      { fieldName: 'Account Name', value: seedReplantDetailsFailedProduct.AccountName, required: false },
      { fieldName: 'Grower GMK', value: seedReplantDetailsFailedProduct.GrowerGMK, required: false },
      { fieldName: 'Customer PO', value: seedReplantDetailsFailedProduct.CustomerPO, required: false },
      { fieldName: 'Product Item Number', value: seedReplantDetailsFailedProduct.ProductItemNumber, required: true },
      { fieldName: 'Product Description', value: seedReplantDetailsFailedProduct.ProductDescription, required: true },
      { fieldName: 'Lot Number', value: seedReplantDetailsFailedProduct.LotNumber, required: false },
      { fieldName: 'Units', value: seedReplantDetailsFailedProduct.Units, required: false },
      { fieldName: 'Product Type', value: seedReplantDetailsFailedProduct.ProductType, required: false },
      { fieldName: 'Status', value: seedReplantDetailsFailedProduct.Status, required: true },
    ];

    for (const field of expectedFieldValues) {
      const normalizedValue = this.normalizeComparableText(field.value);
      if (!normalizedValue) {
        continue;
      }

      const isValueDisplayed = detailPageText.includes(normalizedValue);
      if (field.required) {
        expect(
          isValueDisplayed,
          `${field.fieldName} with value '${normalizedValue}' was not found on the Seed Replant detail page.`,
        ).toBe(true);
      } else if (!isValueDisplayed) {
        fixture.logger.warn(`${field.fieldName} with value '${normalizedValue}' was not found on the Seed Replant detail page.`);
      }
    }
    const expectedActionButtons = ['Approve','Reject','Edit Request', 'Save'];

    for (const actionButton of expectedActionButtons) {
      const actionButtonLocator = this.page.locator(
        `//button[normalize-space(.)='${actionButton}' or .//span[normalize-space(text())='${actionButton}']]`,
      ).first();
      await expect(actionButtonLocator).toBeVisible();
    }
  }

  async verifySeedReplantDetails() {
    const seedReplantDetailsFailedProduct = fixture.dataBag.getData(DataBagKeys.SEED_REPLANT_DETAIL);
    const requestNumber = await this.actionUtility.getTextFromLocator(this.page.locator(this.Elements.firstSeedReplantRequestInList));
    requestNumber.trim
    const actualAccountNumber = await this.actionUtility.getTextFromLocator(this.page.locator(this.Elements.orderedAccountNumber).first());
    const expectedAccount = seedReplantDetailsFailedProduct.AccountNumber.toString();
    expect(actualAccountNumber.trim()).toBe(expectedAccount);
  }

  async verifyReplantRequestList(tabName: string) {
    const spResultData = this.seedReplantActiveOrDraftspResultData;
    const isSpResultArray = Array.isArray(spResultData);
    fixture.logger.info(`SP result data type: ${typeof spResultData}, isArray: ${isSpResultArray}`);
    const spResultRowCount = spResultData == null ? 0 : (isSpResultArray ? spResultData.length : 1);
    const replantRequestCountInUI = await this.page.locator(this.Elements.replantRequestOrderIdXpath.replace(this.tabName, tabName.toLowerCase())).count();
    
    if (spResultRowCount === 0) {
      expect(replantRequestCountInUI).toBe(0);
    } 
    else if (spResultRowCount > 0) {
      expect(replantRequestCountInUI).toBe(spResultRowCount);
      const expectedRequestNumbers = isSpResultArray
        ? spResultData.map(row => row.RequestNumber.toString().trim())
        : [spResultData.RequestNumber.toString().trim()];
      const actualRequestNumbers = [];
      for (let i = 0; i < replantRequestCountInUI; i++) {
        const requestNumber = await this.actionUtility.getTextFromLocator(this.page.locator(this.Elements.replantRequestOrderIdXpath.replace(this.tabName, tabName.toLowerCase())).nth(i));
        actualRequestNumbers.push(requestNumber.trim());
      }
      await this.actionUtility.verifyArrayValues(expectedRequestNumbers, actualRequestNumbers);
      } else {
      throw new Error('Unexpected SP result data format for Active/Draft seed replant requests.');
    }
  }

  async verifyColumsAvailabilityOnSeedReplantRequest(tabName: string) {
    if (tabName.toLowerCase() === 'active') {
      const expectedColumns = seedReplantContants.expectedColumnsOnActiveTab as string[];
      for (const columnName of expectedColumns) {
        const columnHeaderXpath = `//thead[@role='rowgroup']//div[text()='${columnName}']`;  
        const isColumnPresent = await this.isElementPresent(columnHeaderXpath);
        expect(isColumnPresent).toBe(true);
      }
    }
    else if (tabName.toLowerCase() === 'draft') {
      const expectedColumns: string[] = seedReplantContants.expectedColumnsOnDraftTab as string[];
      for (const columnName of expectedColumns) {
        const columnHeaderXpath = `//thead[@role='rowgroup']//div[text()='${columnName}']`;  
        const isColumnPresent = await this.isElementPresent(columnHeaderXpath);
        expect(isColumnPresent).toBe(true);
      }
    }
  }

  async getDataForSeedReplantRequestUsingSP(requestType: string, requestNumber?: string) {

        fixture.logger.info(`seed replant request type is - ${requestType}`);    
        fixture.logger.info("getting data for the scenario using stored procedure");
        let result = true;
        let spResult: SeedReplantRequestGetOrCreateSpResult;
        try {
            let evolveDbManager = new EvolveDbManager();
            if(requestType == "Active" || requestType == "Draft"){
                const dbResult = await evolveDbManager.getDataForSeedReplantRequestGetOrCreate(requestType, userName);
                expect(dbResult.operationResult).toBeTruthy();
                expect(dbResult.operationData).toBeDefined();
                expect(dbResult.operationData).not.toBeNull();
                spResult = dbResult.operationData;
                const activeOrDraftRows = Array.isArray(spResult.SeedReplantRequestActiveOrDraft)
                        ? spResult.SeedReplantRequestActiveOrDraft
                        : [spResult.SeedReplantRequestActiveOrDraft];
                fixture.dataBag.saveData(DataBagKeys.SEED_REPLANT_ACTIVE_OR_DRAFT, activeOrDraftRows);
                fixture.logger.info(`Saved to DataBag with key ${DataBagKeys.SEED_REPLANT_ACTIVE_OR_DRAFT}`);
            }
            if (requestType == "Detail") {
                const dbResult = await evolveDbManager.getDataForSeedReplantRequestGetOrCreate(requestType, userName, requestNumber);
                expect(dbResult.operationResult).toBeTruthy();
                expect(dbResult.operationData).toBeDefined();
                expect(dbResult.operationData).not.toBeNull();
                spResult = dbResult.operationData;
                const detailRows = Array.isArray(spResult.SeedReplantRequestDetail)
                    ? spResult.SeedReplantRequestDetail
                    : [spResult.SeedReplantRequestDetail];
                const failedProductRow = detailRows.find(r => {
                    const v = r?.GrowerHaveLicense;
                    fixture.logger.info(`Checking row for licensed: GrowerHaveLicense = ${v} (type: ${typeof v})`);
                    return v === true || v === 'Yes' || v === 'Y' || (typeof v === 'string' && v.toLowerCase() === 'yes');
                });
                const replantProductRow = detailRows.find(r => {
                    const v = r?.GrowerHaveLicense;
                    fixture.logger.info(`Checking row for unlicensed: GrowerHaveLicense = ${v} (type: ${typeof v})`);
                    return v === false || v === 'No' || v === 'N' || (typeof v === 'string' && v.toLowerCase() === 'no');
                });

                if (failedProductRow) fixture.dataBag.saveData(DataBagKeys.SEED_REPLANT_DETAIL_FAILED, failedProductRow);
                if (replantProductRow) fixture.dataBag.saveData(DataBagKeys.SEED_REPLANT_DETAIL_REPLANT, replantProductRow);
                fixture.logger.info(`Seed replant detail rows found: Failed - ${failedProductRow ? 'Yes' : 'No'})`);
                fixture.logger.info(`Seed replant detail rows found: Replant - ${replantProductRow ? 'Yes' : 'No'}`);
            }
        } catch (error) {
            if (error instanceof SkipScenarioError) {
                fixture.logger.info("Skipping scenario due to SkipScenarioError.");
                //this.skip(); // ✅ This tells Cucumber to skip the scenario
                return; // stop further processing after skipping
            } else {
            fixture.logger.error("Getting Seed replant data from SP is failed. Error: " + error);
            result = false;
            }
        }
       expect(result).toBeTruthy();
    }
  }