import PickupOrDeliveryInfo from "../../../helpers/util/test-data/dealer/pickupOrDeliveryInfo";
import StockTransferQuantity from "../../../helpers/util/test-data/dealer/stockTransferQuantity";
import ProductsSelection from "../../../helpers/util/test-data/product/productsSelection";
import HtmlRoles from "../../../helpers/wrapper/htmlRoles";
import RegExHelper from "../../../helpers/wrapper/regExHelper";
import { fixture } from "../../../hooks/fixture";
import DataBagKeys from "../../../tests/steps/dataBagKeys";
import BasePage from "../../basePage";

export enum DealerRoleInStockTransfer{
    Receiving_Dealer = 'Receiving Dealer',
    Sending_Dealer = 'Sending Dealer'
}
export default class StockTransfersPage extends BasePage {
    replace_request_ID = "replace_request_ID";
    replace_customer_PO = "replace_customer_PO";
    replace_item_id = "replace-item-id";

    Elements = {
        newStockTransferBtnName: 'New Stock Transfer',
        newStockTransferUri: 'sot-request-entry',
        transferFromDropdownTxt: 'Transfer From Account:*',
        clickToSelectAccountLinkTxt: 'Click to Select Account',
        accountNameTxtBoxLabelName: 'Account Name',
        accountSearchBtnName: 'Search',
        /*contactNameLabelTxt: 'Contact Name : *',
        contactNumberLabelTxt: 'Contact Number : *',*/
        contactNameLabelTxt: 'Contact Name :',
        contactNumberLabelTxt: 'Contact Number :',
        customerPOLabelTxt: 'Customer PO Number :',
        //shippingInstructionsLabelTxt: 'up to 500 characters',
        shippingInstructionsLabelTxt: 'Shipping Instructions:',
        shippingInstructionsId: 'txtShippingInstructions',
        driverAssistanceRequiredOptionTxt: 'Driver Assistance Required',
        palletJackRequiredOptionTxt: 'Pallet Jack Required',
        /*nonStockPalletCount: 'Non Stock Pallet : *',
        stockPalletCount: 'Stock Pallet : *',
        emptyCBox: 'Empty CBox : *',*/
        nonStockPalletCount: 'Non Stock Pallet :',
        stockPalletCount: 'Stock Pallet :',
        emptyCBox: 'Empty CBox :',
        addProductBtnName: 'Add Product',
        productFilterElementName: 'app-filter',
        searchFieldPlaceholderTxt: 'Search...',
        searchBtnTestId: 'btn-filter-search',
        filteredProductNameXPath: "(//tr/td/div[text()='Product Name']/following-sibling::p)",
        filteredProductItemXPath: `//tr/td/div[text()='Product Name']/following-sibling::p[contains(text(), '${this.replace_item_id}')]`,
        yourAccountInvoicedProductsHeadingTxt: 'Your Account Invoiced Products',
        parentAccountInvoicedProductsHeadingTxt: 'Parent Account Invoiced Products',
        addProductsToRequestBtnName: 'Add To Request',
        qtyClassIdXPath: '#txtRequestedQty_',
        submitRequestBtnTxt: 'Submit Request',
        requestStatusCellXPath: `//a[text()=' ${this.replace_request_ID}']/../../../td/div[text()=' Status']/following-sibling::div`,
        requestIDCellXPath: `//a[contains(., '${this.replace_request_ID}')]`,
        approveRequestBtnTxt: ' Approve',
        rejectRequestBtnTxt: 'Reject',
        rejectionOrResolvedReasonPlaceholderTxt: '3000 character limit',
        continueBtnTxt: 'Continue',
        rejectionOrResolvedReasonTxtareaXPath: `//label[text()='This request has been rejected for the following reason:']/following::textarea`,//'(//textarea)[2]',
        successfulButtonClickActionMsgId: 'toast-container',
        closeBtnTxt: 'Close',
        addProductsScreenCloseBtnParentXPath: `mat-sidenav`,
        transferFromTabRequestIdXPath: `//div[text()=' ${this.replace_customer_PO} ']/../../td/div/a`,
        noRecordFoundMsgXPath: `//*[text()=' No record Found. ']`,
        productFilterOptionTestId_ProductLine: 'ddl-productLine-search',
        productFilterOptionTestId_Item: 'ddl-itemNumber-search',
        productFilterOptionTestId_PackageSize: 'ddl-packageSize-search',
        productFilterOptionTestId_Treatment: 'ddl-treatment-search',
        productFilterOptionTestId_MarketingBrand: 'ddl-marketingBrand-search',
    }

    private async isPageLoaded(): Promise<boolean> {
        await super.waitUntilButtonIsDisplayed(this.Elements.newStockTransferBtnName);
        return true;
    }

    async isPageStable() {
        fixture.logger.info('checking for stock-transfers-page stability');
        const res = await this.isPageLoaded();
        fixture.logger.info('checking for stock-transfers-page stability completed');

        return res;
    }

    async clickNewStockTransferBtn(): Promise<void> {
        fixture.logger.info('navigating to new-stock-transfers-page');
        await this.pwWrapper.elementAction.waitAndClickButtonByRole(this.Elements.newStockTransferBtnName);
        while (await this.sharedBehavior.isOperationInProgress());
        /*await this.sharedBehavior.waitForPageNavigation(this.Elements.newStockTransferUri);
        //await super.waitUntilButtonIsDisplayed(this.Elements.closeBtnTxt);
        await this.pwWrapper.refreshCurrentPage(5000);*/
        fixture.logger.info('navigating to new-stock-transfers-page completed');
    }

    async selectTransferFromAccount(accountName: string) {
        fixture.logger.info('selecting from-dealer-account on stock-transfers-page');
        await this.sharedBehavior.selectDealer(this.Elements.transferFromDropdownTxt, accountName);
        fixture.logger.info('selecting from-dealer-account on stock-transfers-page completed');
    }

    async selectTransferToAccount(accountName: string, accountNumber: string) {
        fixture.logger.info('selecting to-dealer-account on stock-transfers-page');
        await this.pwWrapper.elementAction.clickLinkElement(this.Elements.clickToSelectAccountLinkTxt);
        fixture.logger.info('navigated to search-and-select-account-page');
        while (await this.sharedBehavior.isOperationInProgress());
        await this.pwWrapper.dataWriter.enterValueIntoTextboxByLabel(this.Elements.accountNameTxtBoxLabelName, accountName);
        fixture.logger.info(`searching for ${accountName}`);
        await this.pwWrapper.elementAction.waitAndClickButtonByRole(this.Elements.accountSearchBtnName);
        while (await this.sharedBehavior.isOperationInProgress());
        
        let count = await this.pwWrapper.pageElement.getAvailableElementCount(this.Elements.noRecordFoundMsgXPath);
        let errorMsg = `no search results found for the account name - ${accountName}`;
        this.sharedBehavior.throwErrorIfCountIsNotEmpty(count, errorMsg);
        
        fixture.logger.info(`selecting ${accountNumber}`);
        count = await this.pwWrapper.pageElement.getAvailableElementCountByText(accountNumber);
        errorMsg = `search results do not include the account number - ${accountNumber}`;
        this.sharedBehavior.throwErrorIfCountIsEmpty(count, errorMsg);

        await this.pwWrapper.elementAction.clickLinkElement(accountNumber, true);
        fixture.logger.info('selecting to-dealer-account on stock-transfers-page completed');
    }

    async selectDeliveryOption(option: string) {
        fixture.logger.info('selecting delivery option on stock-transfers-page');
        let tempOption = option.trim();
        tempOption = " " + tempOption + " ";
        const element = await this.pwWrapper.elementAction.clickRadioButtonOption(tempOption);
        if(element !== null)
            fixture.logger.info(`selecting delivery option - ${option} -on stock-transfers-page completed`);
        else{
            const errorMsg = `failed to check/select delivery option - ${option} - on stock-transfers-page`;
            this.sharedBehavior.logAndThrowError(errorMsg);
        }
    }

    async fillPickupOrDeliveryInfo(info: PickupOrDeliveryInfo) {
        //pickup or delivery date
        await this.sharedBehavior.fillDeliveryOrPickupDate(-1, info.desiredDate);
        fixture.logger.info('delivery date selected');

        //contact name
        await this.pwWrapper.dataWriter.enterValueIntoTextboxByLabel(this.Elements.contactNameLabelTxt, info.contactName);

        //contact number
        await this.pwWrapper.dataWriter.enterValueIntoTextboxByLabel(this.Elements.contactNumberLabelTxt, info.contactNumber);
        fixture.logger.info('contact details entered');

        //customer PO
        const customerPO = this.sharedBehavior.getCustomerPO();
        await this.pwWrapper.dataWriter.enterValueIntoTextboxByLabel(this.Elements.customerPOLabelTxt, customerPO);
        fixture.dataBag.saveData(DataBagKeys.CUSTOMER_PO, customerPO);
        fixture.logger.info('customer PO entered');

        //pickup/delivery location
        if (info.isLocationDifferentThanDealerLocation) {
            await this.pwWrapper.dataWriter.selectIndexedAngularCheckboxOption(1)
        }

        //shipping instructions
        //await this.pwWrapper.dataWriter.enterValueIntoTextboxByLabel(this.Elements.shippingInstructionsLabelTxt, info.shippingInstructions);
        await this.pwWrapper.dataWriter.enterValueIntoTextAreaById(this.Elements.shippingInstructionsId, info.shippingInstructions);

        fixture.logger.info('shipping instructions provided');

        if (info.freightInstructions != null) {
            //driver assistance required
            if (info.freightInstructions.driverAssistanceRequired)
                await this.pwWrapper.dataWriter.selectOption(this.Elements.driverAssistanceRequiredOptionTxt);

            //pallet jack required
            if (info.freightInstructions.palletJackRequired)
                await this.pwWrapper.dataWriter.selectOption(this.Elements.palletJackRequiredOptionTxt);

            await this.pwWrapper.dataWriter.enterValueIntoTextboxByLabel(this.Elements.nonStockPalletCount, info.freightInstructions.nonStockPallet.trim(),false, true);

            await this.pwWrapper.dataWriter.enterValueIntoTextboxByLabel(this.Elements.stockPalletCount, info.freightInstructions.stockPallet.trim(), false, true);

            await this.pwWrapper.dataWriter.enterValueIntoTextboxByLabel(this.Elements.emptyCBox, info.freightInstructions.emptyCBox.trim(), false, true);
            
            fixture.logger.info('freight instructions provided');
        }
    }

    async addProducts(productsSelection: ProductsSelection[]) {
        fixture.logger.info(`adding products to the request started`);
        /**
         * unique filters can be added in the array; for the same fiters, they must be specified with comma separated
         * Example: unique filters:
          "filters": [
                {
                    "filterCategory": "Lot #",
                    "searchKey": "13FR6058"
                },
                {
                    "filterCategory": "Product Name",
                    "searchKey": "CN CP4188VT2P/RIB FPCPR80M"
                }
            ]
        
            Example: same filters:
            "filters": [
                    {
                        "filterCategory": "Lot #",
                        "searchKey": "13FR6058, 23FM6092"
                    }
                ]
         * 
         */
        let atleastOneProductWasFound = false;
        for (let index = 0; index < productsSelection.length; index++) {

            //open "Add Product(s) to the Request" page
            await this.pwWrapper.elementAction.waitAndClickButtonByRole(this.Elements.addProductBtnName);
            while (await this.sharedBehavior.isOperationInProgress());
            const selection = productsSelection[index];
            const closeBtnPrefix = '×'; //this prefix is included inside but not visible to the user
            let displayedOptionName = closeBtnPrefix + 'Product Name'; //first item in the list is Product Name
            let elementIndex = 1; //the very first item will be like Select Category×Product Name which is not visible to the user and the first visible item to the user is Product Name
            for (let filterIndex = 0; filterIndex < selection.filters.length; filterIndex++) {
                fixture.logger.info(`filter option is....${selection.filters[filterIndex].filterCategory}`);
                fixture.logger.info(`search key is....${selection.filters[filterIndex].searchKey}`);
                //await this.pwWrapper.elementAction.clickChildElementByRole(this.Elements.productFilterElementName, HtmlRoles.COMBOBOX);
                //await this.pwWrapper.dataWriter.selectOption(selection.filters[filterIndex].filterCategory.trim());
                let optionToSelect = selection.filters[filterIndex].filterCategory.trim();
                
                if(filterIndex != 0)
                    elementIndex = 0;

                await this.pwWrapper.dataWriter.selectOptionFromAngularDropdownHavingNoName(displayedOptionName, optionToSelect, elementIndex);
                if(optionToSelect == 'Product Name' || optionToSelect == 'Lot #')
                {
                    //for product name and lot #, search is by free text
                    await this.pwWrapper.elementAction.clickChildElementByPlaceholder(this.Elements.productFilterElementName, this.Elements.searchFieldPlaceholderTxt);
                    await this.pwWrapper.dataWriter.enterValueIntoChildTextboxByPlaceholder(this.Elements.productFilterElementName, this.Elements.searchFieldPlaceholderTxt, selection.filters[filterIndex].searchKey.trim());
                }else{
                    //for other filter options, search is by dropdown
                    let testId = '';
                    switch (optionToSelect) {
                        case 'Product Line':
                            testId = this.Elements.productFilterOptionTestId_ProductLine;
                            break;
                        case 'Item #':
                            testId = this.Elements.productFilterOptionTestId_Item;
                            break;
                        case 'Package Size':
                            testId = this.Elements.productFilterOptionTestId_PackageSize;
                            break;
                        case 'Treatment':
                            testId = this.Elements.productFilterOptionTestId_Treatment;
                            break;
                        case 'Marketing Brand':
                            testId = this.Elements.productFilterOptionTestId_MarketingBrand;
                            break;
                    }
                    await this.pwWrapper.elementAction.clickItemByTestIdAndRole(testId, HtmlRoles.COMBOBOX);
                    await this.pwWrapper.dataWriter.selectOption(selection.filters[filterIndex].searchKey.trim());
                }
                //await this.pwWrapper.dataWriter.enterValueIntoTextboxByPlaceholder(this.Elements.searchFieldPlaceholderTxt, selection.filters[filterIndex].searchKey.trim());

                await this.pwWrapper.elementAction.clickElementByTestId(this.Elements.searchBtnTestId);
                while (await this.sharedBehavior.isOperationInProgress());
                displayedOptionName = closeBtnPrefix + optionToSelect;
            }

            await this.pwWrapper.elementAction.clickElementByRole(HtmlRoles.HEADING, this.Elements.yourAccountInvoicedProductsHeadingTxt);
            fixture.logger.info(`checking products from the tab - ${this.Elements.yourAccountInvoicedProductsHeadingTxt}`);
            let count = await this.pwWrapper.pageElement.getAvailableElementCount(this.Elements.filteredProductNameXPath);

            if (count < 3) {
                await this.pwWrapper.elementAction.clickElementByRole(HtmlRoles.HEADING, this.Elements.parentAccountInvoicedProductsHeadingTxt);
                fixture.logger.info(`checking products from the tab - ${this.Elements.parentAccountInvoicedProductsHeadingTxt}`);
                count = await this.pwWrapper.pageElement.getAvailableElementCount(this.Elements.filteredProductNameXPath);
            }

            if (count < 3) {
                await this.pwWrapper.elementAction.clickElementById(this.Elements.successfulButtonClickActionMsgId);
                fixture.logger.warn("products were not found for the specified filters hence ignoring adding products with this filter");
                await this.pwWrapper.elementAction.clickChildElementByText(this.Elements.addProductsScreenCloseBtnParentXPath, this.Elements.closeBtnTxt);
                continue;
            }
            else {
                atleastOneProductWasFound = true;
                /*let rowIndex = 1;
                while (rowIndex < count) {
                    const finalXpath = this.Elements.filteredProductNameXPath + `[${rowIndex}]`;
                    await this.pwWrapper.elementAction.clickElement(finalXpath);
                    rowIndex = rowIndex + 3;
                }*/
               for(let selectionIndex = 0; selectionIndex < selection.expectedProducts.length; selectionIndex++){
                let finalSelectionXPath = this.Elements.filteredProductItemXPath.replace(this.replace_item_id, selection.expectedProducts[selectionIndex].itemNumber);
                await this.pwWrapper.elementAction.clickElement(finalSelectionXPath);
               }
            }

            //go back to transfer page by clicking on "Add to Request" button

            await this.pwWrapper.elementAction.waitAndClickButtonByRole(this.Elements.addProductsToRequestBtnName);
            while (await this.sharedBehavior.isOperationInProgress());
        }

        if (atleastOneProductWasFound) {
            for (let index = 0; index < productsSelection.length; index++) {
                await this.addProductOtherDetails(productsSelection[index].transferQuantities);
            }
        }
        else {
            const errMsg = "not a single product is available with the provided selection hence transfer request can't be performed";
            fixture.logger.error(errMsg);
            throw new Error(errMsg);
        }

        fixture.logger.info(`adding products to the request completed`);
    }

    async addProductOtherDetails(transferQuantities: StockTransferQuantity[]){
        fixture.logger.info(`adding product other details such as quantity started`);
        //add quantity
        for(let index=0; index<transferQuantities.length; index++){
            const qtyClassIdXPathFinal = this.Elements.qtyClassIdXPath + transferQuantities[index].productId;
            fixture.logger.info(`qtyClassIdXPathFinal is ${qtyClassIdXPathFinal}`);
            let count = await this.pwWrapper.pageElement.getAvailableElementCount(qtyClassIdXPathFinal);
            if(count > 0)//COUNT = 0 means, product was not found and hence not added. So, we ignore that product here as well
                await this.pwWrapper.dataWriter.enterValueIntoTextboxByXPath(qtyClassIdXPathFinal, transferQuantities[index].qty);
        }
        fixture.logger.info(`adding product other details such as quantity completed`);
    }

    async submitRequest(): Promise<string>{
        const msg = await this.sharedBehavior.clickButtonAndInspectSuccessMessage("submitting stock transfer request",this.Elements.submitRequestBtnTxt);
        while(await this.sharedBehavior.isOperationInProgress());
        await this.pwWrapper.elementAction.waitAndClickButtonByRole(this.Elements.closeBtnTxt);
        let newStockTransferRequestId = "";
        if (msg !== undefined && msg !== null && msg.length > 0) //it is noticed sometimes toast message disappears so fast; in that case this msg will be undefined
        {
            //sample message: 'Order #20231205004416 submitted successfully.'
            newStockTransferRequestId = (msg.split(" ")[1]).substring(1);
        }else{
            //if we could not retrieve req id from toast msg, we will try to get it from 'Transfer From' tab
            fixture.logger.warn(`submitting request succeeded but toast message could not be retrieved`);
            await this.pwWrapper.elementAction.clickItemByText(DealerRoleInStockTransfer.Sending_Dealer);
            while(await this.sharedBehavior.isOperationInProgress());
            const customerPO = fixture.dataBag.getData(DataBagKeys.CUSTOMER_PO) as string;
            const finalXPath = this.Elements.transferFromTabRequestIdXPath.replace(this.replace_customer_PO, customerPO);
            newStockTransferRequestId = await this.pwWrapper.dataReader.getElementTextByXPath(finalXPath, false);
            fixture.logger.warn(`submitting request id - ${newStockTransferRequestId} - retrieved from 'Transfer From' tab`);
        }
        fixture.dataBag.saveData(DataBagKeys.STOCK_TRANSFER_REQUEST_ID, newStockTransferRequestId);
        fixture.logger.info(`submitting request completed with the request id- ${newStockTransferRequestId}`);
        return newStockTransferRequestId;
    }

    async resubmitRequest(){
        await this.pwWrapper.elementAction.waitAndClickButtonByRole(this.Elements.continueBtnTxt);
        await this.pwWrapper.dataWriter.enterValueIntoTextboxByPlaceholder(this.Elements.rejectionOrResolvedReasonPlaceholderTxt, "resubmitting again for qa-automation-testing");
        await this.sharedBehavior.clickButtonAndInspectSuccessMessage("resubmitting stock transfer request",this.Elements.submitRequestBtnTxt);
        while(await this.sharedBehavior.isOperationInProgress()); 
        await this.pwWrapper.elementAction.waitAndClickButtonByRole(this.Elements.closeBtnTxt);       
    }

    async approveRequest(){
        await this.sharedBehavior.clickButtonAndInspectSuccessMessage("approving stock transfer request",this.Elements.approveRequestBtnTxt);
        while(await this.sharedBehavior.isOperationInProgress());
        await this.pwWrapper.elementAction.waitAndClickButtonByRole(this.Elements.closeBtnTxt);
    }

    async rejectRequest(){
        await this.pwWrapper.elementAction.waitAndClickButtonByRole(this.Elements.rejectRequestBtnTxt);
        await this.pwWrapper.dataWriter.enterValueIntoTextboxByPlaceholder(this.Elements.rejectionOrResolvedReasonPlaceholderTxt, "qa-automation-testing");
        await this.sharedBehavior.clickButtonAndInspectSuccessMessage("rejecting stock transfer request",this.Elements.submitRequestBtnTxt);
        while(await this.sharedBehavior.isOperationInProgress());
        await this.pwWrapper.elementAction.waitAndClickButtonByRole(this.Elements.closeBtnTxt);
    }

    async getRequestStatus(dealerTab: DealerRoleInStockTransfer, reqId: string): Promise<string>{
        fixture.logger.info(`getting the status request - ${reqId} - from '${dealerTab}' section started`);
        await this.pwWrapper.elementAction.clickItemByText(dealerTab);
        while(await this.sharedBehavior.isOperationInProgress());
        const statusElemnentXPathFinal = this.Elements.requestStatusCellXPath.replace(this.replace_request_ID, reqId);
        const statusValue = await this.pwWrapper.dataReader.getElementTextByXPath(statusElemnentXPathFinal, false);
        fixture.logger.info(`getting the status request - ${reqId} - from '${dealerTab}' section completed with the value - ${statusValue}`);
        return statusValue.trim();
    }

    async openRequest(dealerTab: DealerRoleInStockTransfer, requestId: string, delayInMs:number = 0){
        fixture.logger.info(`opening the request - ${requestId} - from '${dealerTab}' section started`);
        await this.pwWrapper.elementAction.clickItemByText(dealerTab);
        while(await this.sharedBehavior.isOperationInProgress());

        if(delayInMs > 0)
            await this.pwWrapper.common.delay(delayInMs);
        fixture.logger.info('about to open the request');
        //await this.pwWrapper.elementAction.clickItemByText(requestId);
        const finalXPath = this.Elements.requestIDCellXPath.replace(this.replace_request_ID, requestId);
        await this.pwWrapper.elementAction.clickElement(finalXPath);
        while(await this.sharedBehavior.isOperationInProgress());
        fixture.logger.info(`opening the request - ${requestId} - from '${dealerTab}' section completed`);
    }

    async getRejectionText(): Promise<string>{
        return await this.pwWrapper.dataReader.getInputFieldValueByXPath(this.Elements.rejectionOrResolvedReasonTxtareaXPath);
    }
}