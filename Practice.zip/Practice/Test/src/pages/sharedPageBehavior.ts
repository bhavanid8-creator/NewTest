/*eslint @typescript-eslint/no-unsafe-argument: "off" */
/*eslint @typescript-eslint/no-unsafe-assignment: "off" */
/*eslint @typescript-eslint/no-unsafe-call: "off" */
/*eslint @typescript-eslint/no-unsafe-member-access: "off" */
const { format } = require('date-fns');
import AccountDetails from "../helpers/util/test-data/dealer/accountDetails";
import GrowerDetails from "../helpers/util/test-data/grower/growerDetails";
import PageConstants from "./pageConstants";
import { fixture } from "../hooks/fixture";
import AccountDetailsForOrderModification from "../helpers/util/test-data/grower/accountDetailsForOrderModification";
import StringValidator from "../helpers/types/stringValidator";
import ProductInfo from "../helpers/util/test-data/product/productInfo";
import HtmlRoles from "../helpers/wrapper/htmlRoles";
import BasePage from "./basePage";
import AccountDetailsBasic from "../helpers/util/test-data/dealer/accountDetailsBasic";
import { expect, Locator } from "@playwright/test";
import DealerOrderAccountDetails from "../helpers/util/test-data/dealer/dealerOrderAccountDetails";
import AngularElements from "./angularElements";

type IndexedProductLineItem = [rowIndex: number, lineItem: ProductInfo];

export default class SharedPageBehavior  extends BasePage {

    replaceAccountNumber: string = "replace-account-number";
    replaceTableRowNumber: string = "replace-table-row";
    replaceTableCellNumber: string = "replace-table-cel";
    dateFormatInTheCalendar: string = 'MMMM d, yyyy';
    displayedButtonClickActionMsgLabelTxt: string;
    replaceErrorText: string = "replace-error-text";
    replaceProductItemNumber: string = "replace-prd-item-number";
    replaceBtnClassValue: string = "replace-btn-class-value";
    replaceSearchedText: string = "replace-searched-text";

    Elements = {
        progressElementXPath: "//div[@class='loaderWhite']",
        progressElementXPath1: "//div[@class='loaderWhiteOuter']",
        //progressElementXPath1: "//div[@class='loaderWhite']",
        lineItemCellXPath: `(((//tbody/tr)[${this.replaceTableRowNumber}])/td)[${this.replaceTableCellNumber}]`,
        nonSubscriberEmailName: 'accountEmail',
        calendarLabelName: 'Open calendar',
        chooseMonthYearLabel: 'Choose month and year',
        successfulButtonClickActionMsgId: 'toast-container',
        //successfulButtonClickActionMsgXPath: "//div[@role='alertdialog']",
        successfulButtonClickActionMsgXPath: "//div[@role='alert']",
        noItemsFoundXPath: `//div[text()='No items found']`,
        noRecordFoundXpath: `//tr/td[contains(text(),'No record Found.')]`,
        noItemsFoundXPath1: `//div[text()=' No data found for "${this.replaceSearchedText}" ']`,
        growerBusinessNameInputXPath: `//input[@id='txtbusinessName']`,
        growerFirstNameInputXPath: `//input[@id='txtFirstName']`,
        growerLastNameInputXPath: `//input[@id='txtLastName']`,
        availableGrower: `//p[@class='grower-name']`,
        revertAllErrorsBtnTxt: 'Revert All Errors',
        errorLineXPath: `//li[contains(text(),'${this.replaceErrorText}')]`,
        noRecordFoundXPath: `//*[contains(text(),'No record Found')]`,
        productLineItemSelectionByTestIDAttributeXPath: `//*[contains(@data-testid, '${this.replaceProductItemNumber}')]/ancestor::td/preceding-sibling::td//mat-checkbox`,
        productLineItemUnitsIncreaseDecreaseByTestIDAttributeXPath: `//*[contains(@data-testid, '${this.replaceProductItemNumber}')]/ancestor::td/following-sibling::td//button[contains(@class, '${this.replaceBtnClassValue}')]`,
        confirmationYesBtnTxt: 'Yes',
        confirmationNoBtnTxt: 'No',
    }

    /*eslint @typescript-eslint/require-await: "off" */
    async initialize(): Promise<boolean>{
        return true;
    }
    /*eslint @typescript-eslint/require-await: "off" */
    async isPageStable(): Promise<boolean> {
        return true;
    }
    
    async triggerOrderLevelActionByTooltip(toolTipText: string) {
        await this.pwWrapper.elementAction.clickElementByNameAndAttributeValue(HtmlRoles.LIST_ITEM, AngularElements.matTooltip, toolTipText);
        await this.pwWrapper.elementAction.waitAndClickButtonByRole(this.Elements.confirmationYesBtnTxt);
        while (await this.isOperationInProgress());
    }

    async clickOnConfirmationButton(isConfirmationYes: boolean = true){
        let confirmationBtnXPath = this.Elements.confirmationYesBtnTxt;
        if(!isConfirmationYes)
            confirmationBtnXPath = this.Elements.confirmationNoBtnTxt;
        
        await this.pwWrapper.elementAction.waitAndClickButtonByRole(confirmationBtnXPath);
        while (await this.isOperationInProgress());
    }

    async isOperationInProgress(spinnerXPath: string = ""): Promise<boolean>{
        await this.pwWrapper.common.delay(500); //it was observed that sometimes UI is not starting the spinner immediately; hence added this delay
        //let result = true;
        let count = 0;
        try{
            //await this.pwWrapper.pageElement.getVisibleElement(this.Elements.progressElementXPath, 3000);
            //count = await this.pwWrapper.pageElement.getAvailableElementCount(this.Elements.progressElementXPath);
            //if(count == 0)
            if (spinnerXPath.length == 0)
                spinnerXPath = this.Elements.progressElementXPath1;

            let maxRetryCount = 50;
            while (maxRetryCount > 0) {
                if (count !== 0) {
                    break;
                }
                //count = await this.pwWrapper.pageElement.getAvailableElementCount(spinnerXPath);
                count = await this.page.locator('[class^="loader"]').count();  // starts with loader
                //count = await this.page.locator('[class$="White"]').count();   // ends with White
                --maxRetryCount;
            }
        }
        catch(err){
            /*if(err.name === PageConstants.TIMEOUT_ERROR)
             {
                result = false;
             }*/
            fixture.logger.error(`failed to track spinner. Error - ${err}`);
            if(err.message.includes("has been closed")){
                //expected message: "Target page, context or browser has been closed"
                fixture.logger.error(`page/context/browser has been closed. Hence, exiting from the test`);
                expect(false).toBeTruthy(); //this is to fail the test case as we are not able to track spinner
            }
            return err;
         }
         //return result;
         await this.pwWrapper.common.delay(1000); //it was observed that sometimes UI is not showing data even after the spinner disappeared; hence added this delay
         return count > 0;
    }

    // async isOperationInProgress(spinnerXPath: string = ""): Promise<boolean>{
    //     let result = true;
    //     let retryCount = 0;
    //     try{
    //         result = await this.checkSpinnerPresence(spinnerXPath);
    //         if(result == false)
    //             fixture.logger.info(`operation is not in progress`);
    //         else
    //             fixture.logger.info(`operation is in progress`);
    //     }
    //     catch(err){
    //         fixture.logger.error(`err message is...${err.message}`);
    //         fixture.logger.error(`err stack is...${err.stack}`);
    //         if(err.name === PageConstants.TIMEOUT_ERROR)
    //          {
    //             result = false;
    //          }
    //      }
    //      return result;
    // }

    // async checkSpinnerPresence(spinnerXPath: string = ""): Promise<boolean>{
    //     await this.pwWrapper.common.delay(500); //it was observed that sometimes UI is not starting the spinner immediately; hence added this delay
    //     //let result = true;
    //     let count = 0;
    //     try{
    //         //await this.pwWrapper.pageElement.getVisibleElement(this.Elements.progressElementXPath, 3000);
    //         //count = await this.pwWrapper.pageElement.getAvailableElementCount(this.Elements.progressElementXPath);
    //         //if(count == 0)
    //         if (spinnerXPath.length == 0)
    //             spinnerXPath = this.Elements.progressElementXPath1;

    //         let maxRetryCount = 50;
    //         while (maxRetryCount > 0) {
    //             if (count !== 0) {
    //                 break;
    //             }
    //             //count = await this.pwWrapper.pageElement.getAvailableElementCount(spinnerXPath);
    //             count = await this.page.locator('[class^="loader"]').count();  // starts with loader
    //             //count = await this.page.locator('[class$="White"]').count();   // ends with White
    //             --maxRetryCount;
    //         }
    //     }
    //     catch(err){
    //         /*if(err.name === PageConstants.TIMEOUT_ERROR)
    //          {
    //             result = false;
    //          }*/
    //         fixture.logger.error(`failed to track spinner. Error - ${err}`);
    //         return err;
    //      }
    //      //return result;
    //      await this.pwWrapper.common.delay(1000); //it was observed that sometimes UI is not showing data even after the spinner disappeared; hence added this delay
    //      return count > 0;
    // }
    async isOperationInProgress_1(): Promise<boolean>{
        let result = true;

        try{
         await this.pwWrapper.pageElement.getVisibleElement(this.Elements.progressElementXPath);
        }
        catch(err){
            fixture.logger.error(`err message is...${err.message}`);
            fixture.logger.error(`err stack is...${err.stack}`);
            if(err.name === PageConstants.TIMEOUT_ERROR)
             {
                result = false;
             }
         }
        return result;
    }

    async isToastMsgVisible(): Promise<boolean>{
        let result = true;

        try{
            await this.pwWrapper.pageElement.getVisibleElementById(this.Elements.successfulButtonClickActionMsgId, 30000);
        }
        catch(err){
            if(err.name === PageConstants.TIMEOUT_ERROR)
             {
                result = false;
             }
         }
        return result;
    }

    async selectDealer(selectAccountDropdownText: string, accountName: string){
        await this.selectAngularDropdownOptionByPlaceholder(selectAccountDropdownText, accountName.trim());
    }
    buildAccountSelectionTextShort(accountDetails: AccountDetails | AccountDetailsForOrderModification | AccountDetailsBasic | DealerOrderAccountDetails): string{
        let result = accountDetails.name.trim() + " " + accountDetails.address.trim() + " ";
        
        fixture.logger.info("Account to be selected is : " + result.trim());
        return result.trim();
    }

    buildAccountSelectionText(accountDetails: AccountDetails | AccountDetailsForOrderModification | AccountDetailsBasic | DealerOrderAccountDetails): string{
        let result = accountDetails.name.trim() + " " + accountDetails.address.trim() + " ";
        
        if (StringValidator.isValidString(accountDetails.phone))
            result = result + accountDetails.phone.trim() + " ";

        result = result + " Account #: " + accountDetails.number.trim();

        fixture.logger.info("Account to be selected is : " + result.trim());
        return result.trim();
    }

    buildGrowerSelectionText(growerDetails: GrowerDetails): string{
        let result = growerDetails.name.trim() + " " + growerDetails.address.trim() + " ";

        if (StringValidator.isValidString(growerDetails.phone))
            result = result + growerDetails.phone.trim() + " ";

        if (StringValidator.isValidString(growerDetails.growerGMK))
            result = result + "Grower GMK: " + growerDetails.growerGMK.trim();

        if (StringValidator.isValidString(growerDetails.growerGLN)) {
            if (growerDetails.growerGMK.length > 0)
                result = result + " Grower GLN: " + growerDetails.growerGLN.trim();
            else
                result = result + "Grower GMK: Grower GLN: " + growerDetails.growerGLN.trim();
        }
        fixture.logger.info("Grower to be selected is : " + result);
        return result.trim();
    }

    async checkLabelPresence(labelName: string, performOperationInprogressCheck: boolean = true){
        if(performOperationInprogressCheck)
            while (await this.isOperationInProgress());

        return await this.pwWrapper.pageElement.isElementByLabelAvailable(labelName); 
    }

    async getOrderTopLineItemProductName(): Promise<string>{
        const rowXPath = this.Elements.lineItemCellXPath.replace(this.replaceTableRowNumber, "1");
        return await this.getProductLineItemCellContent(rowXPath, 2);
    }
    async selectProductTopOrderLineItem(){
        await this.pwWrapper.dataWriter.selectIndexedAngularCheckboxOption(1); //0 --> order-level selection checkbox; 1 --> first line item selection checkbox
        fixture.logger.info('top line item in the order has been selected');
    }
    async selectOrderProductLineItemsByItemNumber(producDetails: ProductInfo[]){
        fixture.logger.info(`selecting product line items started`);
        let atLeastOneItemSelected = false;
        for(let index=0; index< producDetails.length; index++){
            const finalXPath = this.Elements.productLineItemSelectionByTestIDAttributeXPath.replace(this.replaceProductItemNumber, producDetails[index].itemNumber);
            const foundCheckboxesCount = await this.pwWrapper.pageElement.getAvailableElementCount(finalXPath);

            if (foundCheckboxesCount == 0) {
                //we could not find any given product in the displayed line items
                fixture.logger.warn(`could not find any line item in the order matching the Item Number - ${producDetails[index].itemNumber}`);
                continue;
            }
            await this.pwWrapper.elementAction.clickIndexedElement(0, finalXPath); //there could be multiple rows with the same Item Number so we always click the first element
            atLeastOneItemSelected = true;
        }

        if(atLeastOneItemSelected)
            fixture.logger.info('specified line items in the order have been selected');
        else
            fixture.logger.info("ZERO line items in the order have been selected as there are no matching products found on the order page");
    }

    async selectOrderProductLineItems(producDetails: ProductInfo[]){
        fixture.logger.info(`selecting product line items started`);
        const lineItemDetails: IndexedProductLineItem[] = await this.getProductDetailsFromTableLineItems();

        fixture.logger.info(`producDetails length is...${producDetails.length}`);
        for(let i=0; i<producDetails.length; i++){
            fixture.logger.info(`producDetails${i} details is...${JSON.stringify(producDetails[i])}`);
        }
        const lineItemsToSelect: number[] = [];
        for(let index=0; index< producDetails.length; index++){
            const foundItems = lineItemDetails.filter(item => item[1].name == producDetails[index].name.trim());
            if(foundItems.length == 0)
                continue; //we could not find any given product in the displayed line items

            if (foundItems.length == 1) {
                lineItemsToSelect.push(foundItems[0][0]);
                continue; //we found exactly one product in the displayed line items
            }else{
                for(let foundItemIndex=0; foundItemIndex<foundItems.length; foundItemIndex++){
                    fixture.logger.info(`producDetails[${index}] is ${JSON.stringify(producDetails[index])}`);
                    fixture.logger.info(`foundItems[${foundItemIndex}][1] is ${JSON.stringify(foundItems[foundItemIndex][1])}`);
                    if( ((producDetails[index].packageSize == "Blank" && foundItems[foundItemIndex][1].packageSize == "") ||
                          producDetails[index].packageSize == foundItems[foundItemIndex][1].packageSize) &&
                        ((producDetails[index].seedSize == "Blank" && foundItems[foundItemIndex][1].seedSize == "") || 
                          producDetails[index].seedSize == foundItems[foundItemIndex][1].seedSize) &&
                        ((producDetails[index].technology == "Blank" && foundItems[foundItemIndex][1].technology == "") || 
                          producDetails[index].technology == foundItems[foundItemIndex][1].technology) &&
                        ((producDetails[index].treatment == "Blank" && foundItems[foundItemIndex][1].treatment == "") || 
                          producDetails[index].treatment == foundItems[foundItemIndex][1].treatment)){
                            lineItemsToSelect.push(foundItems[foundItemIndex][0]);
                            break;
                    }
                }
            }
        }

        for(let index=0; index < lineItemsToSelect.length; index++){
            const lineItemSelectElement = await this.pwWrapper.pageElement.getTableCellElement(lineItemsToSelect[index], 1);
            await lineItemSelectElement.click();
        }
        if(lineItemsToSelect.length > 0)
            fixture.logger.info('specified line items in the order have been selected');
        else
            fixture.logger.info("ZERO line items in the order have been selected as there are no matching products found on the order page");
    }

    private async getProductDetailsFromTableLineItems(): Promise<IndexedProductLineItem[]>{
        const result: IndexedProductLineItem[] = [];
        //line items start from row = 1 and each next row index is incremented by 2. So,
        //first line item row index = 1, second line item row index = 3, etc.,

        //product details start from cell = 2
        //product-name = 2; seed-size = 3; treatment = 4; package-size = 5; technology = 6; available-units = 7; long-short = 8; 

        const lineItemCount = await this.pwWrapper.pageElement.getTableRowCount();
        if(lineItemCount < 2)
            return result;

        for(let rowIndex=1; rowIndex<= lineItemCount; ){

            const rowXPath = this.Elements.lineItemCellXPath.replace(this.replaceTableRowNumber, rowIndex.toString());
            //fixture.logger.info(`rowXPath is...${rowXPath}`);
            const productInfo = new ProductInfo();

            let cellIndex = 2;
            productInfo.name = await this.getProductLineItemCellContent(rowXPath, cellIndex++);
            productInfo.seedSize = await this.getProductLineItemCellContent(rowXPath, cellIndex++);
            productInfo.treatment = await this.getProductLineItemCellContent(rowXPath, cellIndex++);
            productInfo.packageSize = await this.getProductLineItemCellContent(rowXPath, cellIndex++);
            productInfo.technology = await this.getProductLineItemCellContent(rowXPath, cellIndex++);

            result.push([rowIndex, productInfo]);

            rowIndex = rowIndex + 2;
        }
        return result;
    }

    private async getProductLineItemCellContent(rowXPath: string, cellIndex: number): Promise<string>{
        const cellXPath = rowXPath.replace(this.replaceTableCellNumber, cellIndex.toString());
        let result = (await this.pwWrapper.dataReader.getElementTextByXPath(cellXPath, false)).trim();
        if(result == "Blank")
            result = "";
        return result.trim();
    }

    async getExistingProductRowCountOnDealerOrGrowerOrder(): Promise<number>{
        const existingProductRowCount = await this.pwWrapper.pageElement.getAvailableElementCount(this.getUnitsDecreaseBtnXPath());
        fixture.logger.info(`existing product row count value is ${existingProductRowCount}`);
        return existingProductRowCount;
    }

    getUnitsDecreaseBtnXPath(): string{
        return this.getUnitsIncreaseDecreaseBtnXPath(' - ');
    } 
    getUnitsIncreaseBtnXPath(): string{
        return this.getUnitsIncreaseDecreaseBtnXPath(' + ');
    }

    private getUnitsIncreaseDecreaseBtnXPath(btnTxt: string): string{
        return `(//${HtmlRoles.BUTTON}[text()='${btnTxt}'])`;
    }

    async increaseOrDecreaseLineItemUnitsValue(itemNumber: string, shouldIncrease: boolean){
        let increaseDecreaseBtnClassName = shouldIncrease ? "plusBtn" : "minusBtn";
        let finalXPath = this.Elements.productLineItemUnitsIncreaseDecreaseByTestIDAttributeXPath.replace(this.replaceProductItemNumber, itemNumber);
        finalXPath = finalXPath.replace(this.replaceBtnClassValue, increaseDecreaseBtnClassName);
        await this.pwWrapper.elementAction.clickElement(finalXPath);
    }
    
    async fillNonSubscriberEmail(){
        const nonSubscriberEmail = 'qa-automation-user@qa.testing.com';
        const xpath = this.pwWrapper.common.getInputXPathWithId(this.Elements.nonSubscriberEmailName);
        const count = await this.pwWrapper.pageElement.getAvailableElementCount(xpath);
        //fixture.logger.info(`non-subscriber email element count is ${count}`);
        if(count == 0)
            return;
        else if(count == 1)
            await this.pwWrapper.dataWriter.enterValueIntoTextbox(this.Elements.nonSubscriberEmailName, nonSubscriberEmail, false);//this works for order page
        else
            await this.pwWrapper.dataWriter.enterValueIntoIndexedTextbox(1, this.Elements.nonSubscriberEmailName, nonSubscriberEmail, false); //this works for product transfer page
    
        fixture.logger.info("Filled non-subscriber email");
    }

    async fillDeliveryOrPickupDate(index: number, deliveryDateStr: string){
        fixture.logger.info(`selecting delivery/pickup date ..${deliveryDateStr}`);
        let calendarElement: Locator;
        
        if(index != -1)
            calendarElement = (await this.pwWrapper.pageElement.getElementByLabel(this.Elements.calendarLabelName)).nth(index);
        else
            calendarElement = (await this.pwWrapper.pageElement.getElementByLabel(this.Elements.calendarLabelName));

        await calendarElement.click();
        const today = new Date();
        let deliveryDate = new Date(deliveryDateStr);
        if(deliveryDate < today)
            deliveryDate = today; // if delivery date is in the past, make today as the delivery date

        await this.pwWrapper.elementAction.clickElementByLabel(this.Elements.chooseMonthYearLabel);
        //let formatted = format(today, this.dateFormatInTheCalendar);
        const formatted = format(deliveryDate, this.dateFormatInTheCalendar);
        const splits = formatted.split(" ");
        //await this.pwWrapper.elementAction.clickElementByLabel(splits[2], true); // selecting year
        await this.pwWrapper.elementAction.waitAndClickButtonByRole(splits[2]); // selecting year
        await this.pwWrapper.elementAction.clickElementByLabel(`${splits[0]} ${splits[2]}`); //selecting month & year
        await this.pwWrapper.elementAction.clickElementByLabel(formatted); //selecting day, month & year
        fixture.logger.info(`completed selecting delivery/pickup date`);
    }

    getCustomerPO(): string{
        const today = new Date();
        return "qaAuto" + format(today, 'ddMMMyyyyhhmmssSSS');
    }

    async clickButtonAndInspectSuccessMessage(operationName: string, buttonName: string, isExact: boolean = false): Promise<string>{
        fixture.logger.info(`${operationName} has started`);
        this.displayedButtonClickActionMsgLabelTxt = "";
        try {
            const allPromise = await Promise.all([
                this.pwWrapper.elementAction.waitAndClickButtonByRole(buttonName, 90000, isExact),
                this.pwWrapper.dataReader.getElementTextById(this.Elements.successfulButtonClickActionMsgId)  //toast success message on transfer successfully
            ]);
            let values = allPromise;
            this.displayedButtonClickActionMsgLabelTxt = values[1].trim();
            if(this.displayedButtonClickActionMsgLabelTxt == null || this.displayedButtonClickActionMsgLabelTxt.length == 0)//try once again
            {
                fixture.logger.info("could not retrieve toast message....trying again");
                const count = await this.pwWrapper.pageElement.getAvailableElementCountById(this.Elements.successfulButtonClickActionMsgId);
                fixture.logger.info(`toast message count is....${count}`);
                if(count > 0){
                    while(await this.isOperationInProgress());//sometimes UI is still showing the spinner and in such cases, clicking on the toast will fail so we will wait
                    this.displayedButtonClickActionMsgLabelTxt = await this.pwWrapper.dataReader.getElementTextById(this.Elements.successfulButtonClickActionMsgId);
                    //await this.pwWrapper.elementAction.clickElementById(this.Elements.successfulButtonClickActionMsgId);//it is observed sometimes it is failing to click the toast message; it could be  - by the time it is clicked, toast message disappears; hence disabled this step
                }
            }
            
            fixture.logger.info(`${operationName} has completed with the message - ${this.displayedButtonClickActionMsgLabelTxt}`);
        } catch (error) {
            const errMsg = `failed to resolve promises during ${operationName}...${error}`;
            this.logAndThrowError(errMsg);
        }
        return this.displayedButtonClickActionMsgLabelTxt;
    }

    async clickButtonByTestIdAndInspectSuccessMessage(operationName: string, buttonTestId: string): Promise<string>{
        fixture.logger.info(`${operationName} has started`);
        this.displayedButtonClickActionMsgLabelTxt = "";
        try {
            const allPromise = await Promise.all([
                this.pwWrapper.elementAction.clickElementByTestId(buttonTestId, 0),
                this.pwWrapper.dataReader.getElementTextById(this.Elements.successfulButtonClickActionMsgId)  //toast success message on transfer successfully
            ]);
            let values = allPromise;
            this.displayedButtonClickActionMsgLabelTxt = values[1].trim();
            if(this.displayedButtonClickActionMsgLabelTxt == null || this.displayedButtonClickActionMsgLabelTxt.length == 0)//try once again
            {
                fixture.logger.info("could not retrieve toast message....trying again");
                const count = await this.pwWrapper.pageElement.getAvailableElementCountById(this.Elements.successfulButtonClickActionMsgId);
                fixture.logger.info(`toast message count is....${count}`);
                if(count > 0){
                    while(await this.isOperationInProgress());//sometimes UI is still showing the spinner and in such cases, clicking on the toast will fail so we will wait
                    this.displayedButtonClickActionMsgLabelTxt = await this.pwWrapper.dataReader.getElementTextById(this.Elements.successfulButtonClickActionMsgId);
                    //await this.pwWrapper.elementAction.clickElementById(this.Elements.successfulButtonClickActionMsgId);//it is observed sometimes it is failing to click the toast message; it could be  - by the time it is clicked, toast message disappears; hence disabled this step
                }
            }
            
            fixture.logger.info(`${operationName} has completed with the message - ${this.displayedButtonClickActionMsgLabelTxt}`);
        } catch (error) {
            const errMsg = `failed to resolve promises during ${operationName}...${error}`;
            this.logAndThrowError(errMsg);
        }
        return this.displayedButtonClickActionMsgLabelTxt;
    }

    async clickButtonAndInspectSuccessMessageIndependently(operationName: string, buttonName: string, additionalBtnName: string = "", isExact: boolean = false, timeout: number = 3000): Promise<string>{
        fixture.logger.info(`${operationName} has started`);
        this.displayedButtonClickActionMsgLabelTxt = "";
        try {
            await this.pwWrapper.elementAction.waitAndClickButtonByRole(buttonName, timeout, isExact);
            /*
            if(additionalBtnName.length > 0){
                while(await this.isOperationInProgress());
                if(await this.pwWrapper.pageElement.isButtonDisplayed(additionalBtnName, timeout, isExact))
                    await this.pwWrapper.elementAction.waitAndClickButtonByRole(additionalBtnName, timeout, isExact);
            }
            while(await this.isOperationInProgress())
            {
                if(await this.pwWrapper.pageElement.getAvailableElementCount(this.Elements.successfulButtonClickActionMsgXPath) > 0)
                    this.displayedButtonClickActionMsgLabelTxt = await this.pwWrapper.dataReader.getElementTextById(this.Elements.successfulButtonClickActionMsgId);
            }
            */
            while(await this.isOperationInProgress())
            {
                if(await this.pwWrapper.pageElement.getAvailableElementCount(this.Elements.successfulButtonClickActionMsgXPath) > 0)
                    this.displayedButtonClickActionMsgLabelTxt = await this.pwWrapper.dataReader.getElementTextById(this.Elements.successfulButtonClickActionMsgId);
            }
            if(this.displayedButtonClickActionMsgLabelTxt.length > 0 //if we received this message then there is no need to check the additional button
                && additionalBtnName.length > 0)
            {
                if(await this.pwWrapper.pageElement.isButtonDisplayed(additionalBtnName, timeout, isExact))
                {
                    await this.pwWrapper.elementAction.waitAndClickButtonByRole(additionalBtnName, timeout, isExact);
                    while (await this.isOperationInProgress()) {
                        if (await this.pwWrapper.pageElement.getAvailableElementCount(this.Elements.successfulButtonClickActionMsgXPath) > 0)
                            this.displayedButtonClickActionMsgLabelTxt = await this.pwWrapper.dataReader.getElementTextById(this.Elements.successfulButtonClickActionMsgId);
                    }
                }
            }
            for (let i = 0; i < 5; i++) {
                if (this.displayedButtonClickActionMsgLabelTxt == null || this.displayedButtonClickActionMsgLabelTxt.length == 0)//try once again
                    this.displayedButtonClickActionMsgLabelTxt = await this.pwWrapper.dataReader.getElementTextById(this.Elements.successfulButtonClickActionMsgId);
                else
                    break;
            }
            fixture.logger.info(`${operationName} has completed with the message - ${this.displayedButtonClickActionMsgLabelTxt}`);
        } catch (error) {
            const errMsg = `failed to resolve promises during ${operationName}...${error}`;
            this.logAndThrowError(errMsg);
        }
        return this.displayedButtonClickActionMsgLabelTxt;
    }

    async clickButtonAndInspectSuccessMessageIndependentlyForOrderUpdate(operationName: string, buttonName: string, additionalBtnName: string = "", isExact: boolean = false, timeout: number = 30000): Promise<string>{
        fixture.logger.info(`${operationName} has started`);
        this.displayedButtonClickActionMsgLabelTxt = "";
        try {
            fixture.logger.info(`clicking the original button - '${buttonName}'`);
            //fixture.logger.info(`step 1`);
            await this.pwWrapper.elementAction.waitAndClickButtonByRole(buttonName, timeout, isExact);
            /*
            if(additionalBtnName.length > 0){
                while(await this.isOperationInProgress());
                if(await this.pwWrapper.pageElement.isButtonDisplayed(additionalBtnName, timeout, isExact))
                    await this.pwWrapper.elementAction.waitAndClickButtonByRole(additionalBtnName, timeout, isExact);
            }
            while(await this.isOperationInProgress())
            {
                if(await this.pwWrapper.pageElement.getAvailableElementCount(this.Elements.successfulButtonClickActionMsgXPath) > 0)
                    this.displayedButtonClickActionMsgLabelTxt = await this.pwWrapper.dataReader.getElementTextById(this.Elements.successfulButtonClickActionMsgId);
            }
            */
            //fixture.logger.info(`step 2`);
            //while(!await this.isOperationInProgress());//it may take some time to start the actual operation so we will wait until the operation starts; Note: operation start is indicated by the presence of the spinner
            await this.pwWrapper.common.delay(500);
            while(this.displayedButtonClickActionMsgLabelTxt.length == 0 && await this.isOperationInProgress())
            {
                //fixture.logger.info(`step 3`);
                if((await this.pwWrapper.pageElement.getAvailableElementCount(this.Elements.successfulButtonClickActionMsgXPath)) > 0)
                    {
                        //fixture.logger.info(`step 4`);
                        this.displayedButtonClickActionMsgLabelTxt = await this.pwWrapper.dataReader.getElementTextById(this.Elements.successfulButtonClickActionMsgId);
                    }
            }
            //fixture.logger.info(`step 5`);
            if(this.displayedButtonClickActionMsgLabelTxt.length == 0 //if we received this message then there is no need to check the additional button
                && additionalBtnName.length > 0)
            {
                //fixture.logger.info(`step 6`);
                fixture.logger.info(`we need to click additional button - '${additionalBtnName}' -; checking if it is present`);
                if(await this.pwWrapper.pageElement.isButtonDisplayed(additionalBtnName, timeout, isExact))
                {
                    //fixture.logger.info(`step 7`);
                    fixture.logger.info(`additional button - '${additionalBtnName}' - is displayed; clicking it`);
                    await this.pwWrapper.elementAction.waitAndClickButtonByRole(additionalBtnName, timeout, isExact);
                    await this.pwWrapper.common.delay(500);
                    //fixture.logger.info(`step 8`);
                    while (await this.isOperationInProgress()) {
                        //fixture.logger.info(`step 9`);
                        if ((await this.pwWrapper.pageElement.getAvailableElementCount(this.Elements.successfulButtonClickActionMsgXPath)) > 0)
                            {
                                //fixture.logger.info(`step 10`);
                                this.displayedButtonClickActionMsgLabelTxt = await this.pwWrapper.dataReader.getElementTextById(this.Elements.successfulButtonClickActionMsgId);
                            }
                    }
                }
            }
            for (let i = 0; i < 5; i++) {
                if (this.displayedButtonClickActionMsgLabelTxt == null || this.displayedButtonClickActionMsgLabelTxt.length == 0)//try once again
                    this.displayedButtonClickActionMsgLabelTxt = await this.pwWrapper.dataReader.getElementTextById(this.Elements.successfulButtonClickActionMsgId);
                else
                    break;
            }
            fixture.logger.info(`${operationName} has completed with the message - ${this.displayedButtonClickActionMsgLabelTxt}`);
        } catch (error) {
            const errMsg = `failed to resolve promises during ${operationName}...${error}`;
            this.logAndThrowError(errMsg);
        }
        return this.displayedButtonClickActionMsgLabelTxt;
    }
    async waitForPageNavigation(pageUri: string){
        const pageUrl = process.env.BASEURL + pageUri;
        await this.pwWrapper.waitForNavigation(pageUrl, 10000);
    }
    async clickOnTab(tabName: string, isExact: boolean = false, useHeadingAsRole: boolean = false){
        if(useHeadingAsRole)
            await (await this.pwWrapper.pageElement.getElementByRole(HtmlRoles.HEADING, tabName, isExact)).click();
        else
            await (await this.pwWrapper.pageElement.getElementByRole(HtmlRoles.TAB, tabName, isExact)).click();
        while(await this.isOperationInProgress());
    }
    /**
     * 
     * @param dropDownPlaceholderText 
     * @param dropdownOptionText will be used to filter items by searching
     * @param noSelectionXPath 
     * @param optionSearchText if this is empty, first search result will be used with the above filter; else specific text element will be clicked
     */
    async selectAngularDropdownOptionByPlaceholder(dropDownPlaceholderText: string, dropdownOptionText: string, noSelectionXPath:string = "", optionSearchText: string = "", selectOptionFromPanel: boolean = false){
        if(noSelectionXPath.length == 0)
            noSelectionXPath = this.Elements.noItemsFoundXPath;

        dropdownOptionText = dropdownOptionText.trim();
        if(selectOptionFromPanel){
            await this.pwWrapper.dataWriter.selectAngularDropdownOptionFromPanel(dropDownPlaceholderText, dropdownOptionText, optionSearchText);
        }else
        {
            await this.pwWrapper.dataWriter.selectAngularDropdownOption(dropDownPlaceholderText, dropdownOptionText, optionSearchText);
        }
        while(await this.isOperationInProgress());
        const count = await this.pwWrapper.pageElement.getAvailableElementCount(noSelectionXPath);
        if(count == 0)
            fixture.logger.info(`from - ${dropDownPlaceholderText} - the option - ${dropdownOptionText} - has been selected`);
        else {
            const errorMsg = `specified dropdown option - ${dropdownOptionText} - could not be selected from - ${dropDownPlaceholderText} - dropdown`;
            this.logAndThrowError(errorMsg);
        }
    }

    async selectDropdownOptionByPlaceholder(dropDownPlaceholderText: string, dropdownOptionText: string, noSelectionXPath:string = "", optionSearchText: string = "", selectOptionFromPanel: boolean = false){
        if(noSelectionXPath.length == 0)
            noSelectionXPath = this.Elements.noItemsFoundXPath;
            const noSelectionXPath1 = this.Elements.noItemsFoundXPath1.replace(this.replaceSearchedText, dropdownOptionText);

        dropdownOptionText = dropdownOptionText.trim();
        if(selectOptionFromPanel){
            await this.pwWrapper.dataWriter.selectAngularDropdownOptionFromPanel(dropDownPlaceholderText, dropdownOptionText, optionSearchText);
        }else
        {
            await this.pwWrapper.dataWriter.selectDropdownOptionByAngular(dropDownPlaceholderText, dropdownOptionText, optionSearchText);
        }
        while(await this.isOperationInProgress());
        const count = await this.pwWrapper.pageElement.getAvailableElementCount(noSelectionXPath);
        const count1 = await this.pwWrapper.pageElement.getAvailableElementCount(noSelectionXPath1);
        if(count == 0 && count1 == 0)
            fixture.logger.info(`from - ${dropDownPlaceholderText} - the option - ${dropdownOptionText} - has been selected`);
        else {
            const errorMsg = `specified dropdown option - ${dropdownOptionText} - could not be selected from - ${dropDownPlaceholderText} - dropdown`;
            this.logAndThrowError(errorMsg);
        }
    }

    async selectGrowerByAdvanceSearch(advanceSearchBtnXpath: string, firstName: string, lastName: string, searchBtnXpath: string, businessName: string) { 
        await this.pwWrapper.elementAction.clickElement(advanceSearchBtnXpath);
        if (businessName == null || businessName == undefined) {
            await this.pwWrapper.dataWriter.enterValueIntoTextboxByXPath(this.Elements.growerFirstNameInputXPath, firstName);
            await this.pwWrapper.dataWriter.enterValueIntoTextboxByXPath(this.Elements.growerLastNameInputXPath, lastName);
            await this.pwWrapper.elementAction.clickElement(searchBtnXpath);
        } else {
            await this.pwWrapper.dataWriter.enterValueIntoTextboxByXPath(this.Elements.growerBusinessNameInputXPath, businessName);
            await this.pwWrapper.elementAction.clickElement(searchBtnXpath);
        }
        // Wait for at least one grower to be visible; use the first match to avoid strict locator error when multiple results exist
        await this.pwWrapper.pageElement.waitUtilElementIsVisible(this.page.locator(this.Elements.availableGrower).first(), 10000);
        // click the first available grower (Playwright nth is zero-based).
        const availableGrowerCount = await this.pwWrapper.pageElement.getAvailableElementCount(this.Elements.availableGrower);
        if (availableGrowerCount > 0) {
            await this.pwWrapper.elementAction.clickIndexedElement(0, this.Elements.availableGrower);
        } else {
            const errorMsg = `No grower found for given first name - ${firstName}, last name - ${lastName}`;
            this.logAndThrowError(errorMsg);
        }
    }

    async selectAngularDropdownOptionByPlaceholderFromPanel(dropDownPlaceholderText: string, dropdownOptionText: string, noSelectionXPath:string = "", optionSearchText: string = ""){
        await this.selectAngularDropdownOptionByPlaceholder(dropDownPlaceholderText, dropdownOptionText, noSelectionXPath, optionSearchText, true);
    }
    throwErrorIfCountIsEmpty(count: number, errorMsg: string){
        if(count == 0){
            this.logAndThrowError(errorMsg);
        }
    }

    throwErrorIfCountIsNotEmpty(count: number, errorMsg: string){
        if(count > 0){
            this.logAndThrowError(errorMsg);
        }
    }

    logAndThrowError(errorMsg: string){
        fixture.logger.error(errorMsg);
        throw new Error(errorMsg);
    }

    async checkIfErrorExists(errorText:string){
        const finalXPath = this.Elements.errorLineXPath.replace(this.replaceErrorText, errorText);
        while(await this.isOperationInProgress());
        const count = await this.pwWrapper.pageElement.getAvailableElementCount(finalXPath);
        return count > 0;
    }

    async revertAllErrors(){
        await this.pwWrapper.elementAction.waitAndClickButtonByRole(this.Elements.revertAllErrorsBtnTxt);
    }

    async isNoDataAvailable(): Promise<boolean>{
        const existingProductRowCount = await this.pwWrapper.pageElement.getAvailableElementCount(this.Elements.noRecordFoundXPath);
        return existingProductRowCount > 0;
    }

    async incrementProductUnitsIfLineItemAvailable(finalXPath: string, itemNumber: string, unitsValue: string, isGrowerOrder: boolean = true): Promise<{orderContainsTheProduct: boolean, qtyIncremented: boolean}>{
        //lineItemWithTestIdAndUnitCssIdXPath: `//*[contains(@data-testid, '${this.replaceTestIdValue}')]/ancestor::td/following-sibling::td//input[@id='txtUnits']`,
        let orderContainsTheProduct: boolean = false;
        let qtyIncremented: boolean = false;

        const lineItemUnitsFieldCount = await this.pwWrapper.pageElement.getAvailableElementCount(finalXPath);
        if(lineItemUnitsFieldCount == 0){
            fixture.logger.warn(`could not find line item with the item number - ${itemNumber}`);
            return {orderContainsTheProduct, qtyIncremented};
        }
        
        orderContainsTheProduct = true;

        //there could be multiple line items with the same Item Number and we will increment the quantity for the first item
        const index = 0;
        const existingValTxt = await this.pwWrapper.dataReader.getIndexedInputFieldValueByXPath(finalXPath, index);
        const existingVal = parseInt(existingValTxt);
        const newQty = parseInt(unitsValue);
        const finalVal = isGrowerOrder ? existingVal + newQty //for grower order, we can give qty more than available
            : newQty; //for dealer order, we can not give qty more than available
        
        const unitsElement = this.page.locator(finalXPath).nth(index);
        qtyIncremented = true;

        const shouldFillUnits = isGrowerOrder ? true //for grower order, we always fill units
            : (existingVal < newQty); //for grower order, we fill units only if current qty is lesser than available qty (or new qty)
        
        if(shouldFillUnits)
            await this.fillUnits(unitsElement, finalVal.toString());
        else
            qtyIncremented = false;
        
        if(!isGrowerOrder)
            await this.pwWrapper.keyBoard.tabOutToNextElement();

        return {orderContainsTheProduct, qtyIncremented};;
    }

    async fillUnits(unitsElement: Locator, units: string){
        await unitsElement.click();
        await unitsElement.fill("");
        await unitsElement.fill(units);
        fixture.logger.info("Units filled");
    }
}