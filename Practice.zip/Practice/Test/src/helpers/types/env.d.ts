export { };

declare global {
    namespace NodeJS {
        interface ProcessEnv {
            BROWSER: "chrome" | "firefox" | "webkit",
            ENV: "QA1" | "QA2",
            TOKEN: "token",
            API_BASEURL: string,
            API_URI_PREFIX: string,
            CROP_YEAR: string,
            EXCLUDED_GROWERS_GMK_LIST: string,
            BASEURL: string,
            JDE_BASEURL: string,
            IS_LOCAL: "true" | "false",
            CUCUMBER_RETRY_COUNT: string,
            playwrightUser: string,
            playwrightPasswd: string,
            JDEReleaseFunctionsKey: string,
            DB_SERVER: string,
            DB_PORT: string,
            DB_DATABASE: string,
            DB_REQ_TIMEOUT: string,
            AUTHORIZATION_URL: string,
            HEAD: "true" | "false",
            SLOW_MOTION_IN_MS: string,
            LOG_LEVEL: "error" | "warn" | "info" | "http" | "verbose" | "debug" | "silly",
            DEFAULT_DATA_SOURCE_LOCATION: string,
            DEFAULT_CACHE_TIMEOUT_IN_SEC: string,
            EXTENDED_CACHE_TIMEOUT_IN_SEC: string,
            EXTEND_CACHE: string,
            DEALER_STOCK_TRANSFER_OPTION: string,
            DATA_REQUIREMENTS_COMMON: string,
            DATA_REQUIREMENTS_PRODUCTS: string,
            LOGIN_PAGE_CHECK_RETRY_COUNT: string,
            JDE_SALES_ORDER_ENQUIRY_DATA_SYNC_IN_MS: string,
            LOGIN_USER_DATA: string,
            ACCOUNT_CONTEXT_DATA: string,
            PRODUCT_CATALOG_DATA: string,
            PRODUCT_ORDER_DATA: string,
            CREATE_GROWER_ORDER_WITH_LINE_ITEM_PROPERTIES: string,
            CREATE_GROWER_ORDER_WITH_LINE_ITEM_PROPERTIES_EMULATION: string,
            CREATE_GROWER_ORDER_WITH_ORDER_PROPERTIES_EMULATION: string,
            CREATE_GROWER_ORDER_WITH_ORDER_PROPERTIES: string,
            GROWERORDERDATA: string,
            UPDATE_ORDER: string,
            UPDATE_ORDER_EMULATION: string,
            PRODUCT_TRANSFER_SAME_DEALER_NEW_ORDER: string,
            PRODUCT_TRANSFER_SAME_DEALER_OLD_ORDER: string,
            PRODUCT_TRANSFER_SAME_DEALER_NEW_ORDER_MULTI_AC_CONTEXT: string,
            PRODUCT_TRANSFER_SAME_DEALER_OLD_ORDER_MULTI_AC_CONTEXT: string,
            PRODUCT_TRANSFER_SAME_DEALER_NEW_ORDER_EMULATION: string,
            PRODUCT_TRANSFER_SAME_DEALER_OLD_ORDER_EMULATION: string,
            PRODUCT_TRANSFER_ANOTHER_DEALER_NEW_ORDER: string,
            PRODUCT_TRANSFER_ANOTHER_DEALER_OLD_ORDER: string,
            PRODUCT_TRANSFER_ANOTHER_DEALER_NEW_ORDER_MULTI_AC_CONTEXT: string,
            PRODUCT_TRANSFER_ANOTHER_DEALER_OLD_ORDER_MULTI_AC_CONTEXT: string,
            PRODUCT_TRANSFER_ANOTHER_DEALER_NEW_ORDER_EMULATION: string,
            PRODUCT_TRANSFER_ANOTHER_DEALER_OLD_ORDER_EMULATION: string,
            STOCK_TRANSFERS: string,
            DEALER_NEW_ORDER: string,
            DEALER_UPDATE_ORDER_EA: string,
            DEALER_NEW_ORDER_MULTI_AC_CONTEXT: string,
            DEALER_OLD_ORDER: string,
            DEALER_OLD_ORDER_MULTI_AC_CONTEXT: string
            DEALER_OLD_ORDER_MODIFY: string;
            DEALER_OLD_ORDER_MODIFY_MULTI_AC_CONTEXT: string;
            DEALER_OLD_ORDER_EMULATION: string;
            DEALER_PRODUCT_TRANSFER_NEW_ORDER: string;
            DEALER_PRODUCT_TRANSFER_OLD_ORDER: string;
            DEALER_PRODUCT_TRANSFER_OLD_ORDER_MULTI_AC_CONTEXT: string;
            DEALER_PRODUCT_TRANSFER_NEW_ORDER_MULTI_AC_CONTEXT: string;
            DEALER_PRODUCT_TRANSFER_OLD_ORDER_EMULATION: string;
            DEALER_PRODUCT_TRANSFER_NEW_ORDER_EMULATION: string;
            DEALER_PRODUCT_TRANSFER_OUTSIDE_TERRITORY: string;
            DEALER_PRODUCT_TRANSFER_OUTSIDE_TERRITORY_EMULATION: string;
            SEED_FULFILLMENT: string;
            SEED_FULFILLMENT_API_URL: string;
            USE_AZURE_CLI_FOR_DB: "true" | "false",
        }
    }
}