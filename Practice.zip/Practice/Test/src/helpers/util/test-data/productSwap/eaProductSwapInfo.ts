import ProductInfo from "../product/productInfo";

export default class EaProductSwapInfo{
    sourceProduct: ProductInfo;
    targetProduct: ProductInfo;
    units: string;
}