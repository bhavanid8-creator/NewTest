export default class EmulatedAccountSelectionToVerify{
    filterCategory:string;
    searchKey:string;
    attachedAccountNumberToSelect:string;
    attachedUserIdToSelect: string;
}