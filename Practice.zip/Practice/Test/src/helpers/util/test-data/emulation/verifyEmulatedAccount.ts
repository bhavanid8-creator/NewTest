import AccountDetails from "../dealer/accountDetails";
import EmulatedAccountSelectionToVerify from "./emulatedAccountSelectionToVerify"
export default class VerifyEmulatedAccount{
    selection: EmulatedAccountSelectionToVerify;
    expectedAccounts: AccountDetails[];
}