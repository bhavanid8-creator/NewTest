import GrowerDetails from "../grower/growerDetails";

export default class AccountDetails{
    name: string;
    address: string;
    phone: string;
    number: string;
    relatedGrowers: GrowerDetails[];
}