export default class FreightInstructions {
    driverAssistanceRequired: boolean;
    palletJackRequired: boolean;
    nonStockPallet: string;
    stockPallet: string;
    emptyCBox: string;
}