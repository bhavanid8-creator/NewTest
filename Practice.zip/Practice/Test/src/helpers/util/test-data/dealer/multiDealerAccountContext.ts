import DealerAccountContext from "./dealerAccountContext";

export default class MultiDealerAccountContext extends DealerAccountContext{
    selectAll: boolean;
    accountNumbersToSelect:  string[];

    copy(source: MultiDealerAccountContext){
        super.copy(source);
        this.accountNumbersToSelect = source.accountNumbersToSelect;
        this.selectAll = source.selectAll;
    }
}