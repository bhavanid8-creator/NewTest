import AccountDetails from "./accountDetails";

export default class DealerOrderAccountDetails extends AccountDetails {
    orderIdToUpdate: string;
}