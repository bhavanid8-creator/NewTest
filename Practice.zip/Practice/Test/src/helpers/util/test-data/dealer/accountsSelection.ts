export default class AccountsSelection{
    filterCategory:string;
    search:string;
    isMultiSelection:boolean;
    
    /**
     * If 'isMultiSelection' is true then 'accountNumbersToSelect' should have multiple values delimited by ##
     */
    accountNumbersToSelect:string;
}