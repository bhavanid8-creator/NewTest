export default class AccountsSelectionToVerify{
    filterCategory:string;
    searchKey:string;
    accountNumbersToSelect:string;
}