export default class AccountDetailsBasic{
    name: string;
    address: string;
    phone: string;
    number: string;
}