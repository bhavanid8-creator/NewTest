import DealerAccountContext from "./dealerAccountContext";

export default class SingleDealerAccountContext extends DealerAccountContext {
    accountNumberToSelect: string;
    copy(source: SingleDealerAccountContext){
        super.copy(source);
        this.accountNumberToSelect = source.accountNumberToSelect;
    }
}