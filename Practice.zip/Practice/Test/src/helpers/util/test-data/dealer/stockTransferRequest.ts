import ProductsSelection from "../product/productsSelection";
import AccountDetailsBasic from "./accountDetailsBasic";
import PickupOrDeliveryInfo from "./pickupOrDeliveryInfo";

type DeliveryOptionType = "ALREADY MOVED-TO ACCOUNT FREIGHT ALLOWANCE" | "ALREADY MOVED-FROM ACCOUNT FREIGHT ALLOWANCE" | "ALREADY MOVED-WFU EMPLOYEE" | "WFU ARRANGED";

export default class StockTransferRequest {
    sendingDealerAccount: AccountDetailsBasic;
    receivingDealerAccount: AccountDetailsBasic;
    deliveryOption: DeliveryOptionType;
    pickupInfo: PickupOrDeliveryInfo;
    productsToTransfer: ProductsSelection[];
    deliveryInfo: PickupOrDeliveryInfo;
}