export default class DealerAccountContext {
    filterCategory: string;
    searchKey: string;

    copy(source: DealerAccountContext){
        this.filterCategory = source.filterCategory;
        this.searchKey = source.searchKey;
    }
}