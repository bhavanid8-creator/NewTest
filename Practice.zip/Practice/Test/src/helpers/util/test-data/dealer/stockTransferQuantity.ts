export default class StockTransferQuantity{
    productId: string;
    qty: string;
}