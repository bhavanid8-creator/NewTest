import FreightInstructions from "./freightInstructions";

export default class PickupOrDeliveryInfo {
    desiredDate: string;
    contactName: string;
    contactNumber: string;
    isLocationDifferentThanDealerLocation: boolean;
    shippingInstructions: string;
    freightInstructions: FreightInstructions;
}