import AccountDetails from "./accountDetails";
import AccountsSelectionToVerify from "./accountsSelectionToVerify";

export default class VerifyAccounts{
    selections: AccountsSelectionToVerify[];
    expectedAccounts: AccountDetails[];
    static readonly accountNumbersToSelectDelimiter:string = " ## ";
}