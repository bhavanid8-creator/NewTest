const filterOptionsOnSeedReplantPage = 
[
    'Account Number',
    'Account Name',
    'Request Date',
    'Request Number',
    'Product Name',
    'Item Number',
    'Grower Name',
    'Grower GMK',
    'Customer PO',
    'Status',
];

const expectedColumnsOnDraftTab = [
  'Request Id',
  'Customer PO',
  'Account Name',
  'Account Number',
  'Draft Date',
  'Replant Products',
  'Units',
  'Delete Request',
];

const expectedColumnsOnActiveTab = [
  'Request Id',
  'Customer PO',
  'Account Name ',
  'Account Number',
  'Request Date',
  'Replant Products',
  'Units',
  'Status',
];

const seedReplantContants = {
    filterOptionsOnSeedReplantPage,
    expectedColumnsOnDraftTab,
    expectedColumnsOnActiveTab
};
export default seedReplantContants;