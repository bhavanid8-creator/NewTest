// import AccountDetailsForOrderModification from "./accountDetailsForOrderModification";
// import ProductToAddOrDeleteOrUpdate from "./productToAddOrDeleteOrUpdate";

// export default class ProductOrderLineItemAdd {
//     orderAccount: AccountDetailsForOrderModification;
//     productToAdd: ProductToAddOrDeleteOrUpdate;
// }