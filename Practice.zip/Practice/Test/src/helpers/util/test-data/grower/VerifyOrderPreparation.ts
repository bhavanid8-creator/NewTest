// import ProductOrderInfo from "./ProductOrderInfo";
// import ProductOrderLineItemInfo from "./productOrderLineItemInfo";

// export default class VerifyOrderPreparation{
//     productsToOrder: ProductOrderLineItemInfo[];
//     globalOrderInfo: ProductOrderInfo;
// }