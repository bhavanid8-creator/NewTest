// import AccountDetails from "./accountDetails";
// import DataSelection from "./dataSelection";
// import GrowerDetails from "./growerDetails";
// import ProductOrderLineItemInfo from "./productOrderLineItemInfo";

// export default class GrowerOrder{
//     dataSelection: DataSelection;
//     account: AccountDetails;
//     productsToOrder: ProductOrderLineItemInfo[];
// }