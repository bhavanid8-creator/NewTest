export default class GrowerDetails{
    name: string;
    address: string;
    phone: string;
    growerGMK: string;
    growerGLN: string;
}