import GrowerDetails from "./growerDetails";

export default class AccountDetailsForOrderModification{
    name: string;
    address: string;
    phone: string;
    number: string;
    relatedGrower: GrowerDetails;
    orderIdToUpdate: string;
}