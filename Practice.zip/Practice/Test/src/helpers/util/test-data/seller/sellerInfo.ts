export default class SellerInfo{
    name: string;
}