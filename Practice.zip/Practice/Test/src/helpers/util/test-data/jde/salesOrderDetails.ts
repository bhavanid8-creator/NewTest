export default class SalesOrderDetails {
    soldTo: string;
    shipTo: string;
    branch: string;
    qtyOrdered: string;
    itemNumber: string;
    orderNumber: string;
}