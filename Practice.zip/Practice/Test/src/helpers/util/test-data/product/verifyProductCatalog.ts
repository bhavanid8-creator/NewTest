import ProductInfo from "./productInfo";
import ProductFilter from "./productFilter";

export default class VerifyProductCatalog{
    filters: ProductFilter[];
    //expectedProducts: string[];
    expectedProducts: ProductInfo[];
    onlyShowProductWithAvailability: boolean;
    onlyShowProductOnDealerOrder: boolean;
}