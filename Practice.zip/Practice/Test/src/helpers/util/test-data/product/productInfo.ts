export default class ProductInfo{
    name: string;
    seedSize: string;
    treatment: string;
    packageSize: string;
    technology: string;
    itemNumber: string;
    existingCountOnTheOrder: number;
    conversionUnits: number;
    itemDescription: string;
}