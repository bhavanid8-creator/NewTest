import DealerOrderProductsSelectionBase from "./dealerOrderProductsSelectionBase";

export default class DealerOrderProductsSelection extends DealerOrderProductsSelectionBase {
    onlyShowProductWithAvailability: boolean;
}