import DealerOrderProductsSelectionBase from "./dealerOrderProductsSelectionBase";

export default class DealerOrderEAProductsSelection extends DealerOrderProductsSelectionBase {
    displayDealerOrderEarlyAdvantageUnits: boolean;
}