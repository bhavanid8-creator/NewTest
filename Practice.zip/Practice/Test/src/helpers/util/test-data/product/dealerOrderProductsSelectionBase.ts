import ProductFilter from "./productFilter";
import ProductInfo from "./productInfo";

export default class DealerOrderProductsSelectionBase {
    filters: ProductFilter[];
    expectedProducts: ProductInfo[];
}