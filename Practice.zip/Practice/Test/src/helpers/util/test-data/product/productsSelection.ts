import StockTransferQuantity from "../dealer/stockTransferQuantity";
import ProductFilter from "./productFilter";
import ProductInfo from "./productInfo";

export default class ProductsSelection {
    filters: ProductFilter[];
    expectedProducts: ProductInfo[];
    transferQuantities: StockTransferQuantity[];
}
export class ProductsSelection_Old{
    filterCategory:string;
    search:string;
    /*isMultiSelection:boolean;
    
    // /**
    //  * If 'isMultiSelection' is true then 'productNamesToSelect' should have multiple values delimited by ##
    //  /
    productNamesToSelect:string;*/
    productNameToSelect: string;
}

export class ProductSelectionFilters{
    static readonly productName: string = "Product Name";
    static readonly technology: string = "Technology";
    static readonly productLine: string = "Product Line";
    static readonly itemNumber: string = "Item Number";
}