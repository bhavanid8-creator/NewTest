export default class EAConfig {
    productLineId: string;
}