export default class ProductFilter{
    filterCategory: string;
    searchKey: string;
}