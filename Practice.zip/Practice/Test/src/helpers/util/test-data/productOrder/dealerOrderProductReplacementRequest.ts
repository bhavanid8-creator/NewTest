import DealerOrderAccountDetails from "../dealer/dealerOrderAccountDetails";
import MultiDealerAccountContext from "../dealer/multiDealerAccountContext";
import SingleDealerAccountContext from "../dealer/singleDealerAccountContext";
import DealerOrderProductModification from "./dealerOrderProductModification";

export default class DealerOrderProductReplacementRequest {
    dealerAccountContext: SingleDealerAccountContext | MultiDealerAccountContext;
    orderAccount: DealerOrderAccountDetails;
    productToModifyByPackageSize: DealerOrderProductModification;
    productToModifyBySeedSize: DealerOrderProductModification;
    productToModifyByTreatment: DealerOrderProductModification;
}