import DealerOrderAccountDetails from "../dealer/dealerOrderAccountDetails";
import MultiDealerAccountContext from "../dealer/multiDealerAccountContext";
import SingleDealerAccountContext from "../dealer/singleDealerAccountContext";
import EAConfig from "../product/eaConfig";
import EaProductSwapInfo from "../productSwap/eaProductSwapInfo";
import DealerOrderNewEAProduct from "./dealerOrderNewEAProduct";

export default class UpdateDealerOrderWithEARequest {
    dealerAccountContext: SingleDealerAccountContext | MultiDealerAccountContext;
    orderAccount: DealerOrderAccountDetails;
    eaConfig: EAConfig;
    productToAdd: DealerOrderNewEAProduct;
    productSwapping: EaProductSwapInfo; 
}