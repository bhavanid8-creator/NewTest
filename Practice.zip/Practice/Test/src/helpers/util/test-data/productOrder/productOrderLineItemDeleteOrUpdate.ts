import AccountDetailsForOrderModification from "../grower/accountDetailsForOrderModification";
import ProductToAddOrDeleteOrUpdate from "./productToAddOrDeleteOrUpdate";

export default class ProductOrderLineItemDeleteOrUpdate {
    orderAccount: AccountDetailsForOrderModification;
    productToAddIfOrderHasZeroLineItems: ProductToAddOrDeleteOrUpdate;
}