import VerifyProductCatalog from "../product/verifyProductCatalog";
import ProductOrderInfo from "./productOrderInfo";

export default class ProductToAddOrDeleteOrUpdate{
    productSelection: VerifyProductCatalog;
    productOrderInfo: ProductOrderInfo;
}