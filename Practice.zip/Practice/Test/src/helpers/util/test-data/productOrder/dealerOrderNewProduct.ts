import DealerOrderProductsSelection from "../product/dealerOrderProductsSelection";
import DealerOrderLineItemInfo from "./dealerOrderLineItemInfo";

export default class DealerOrderNewProduct {
    productSelection: DealerOrderProductsSelection;
    lineItemInfo: DealerOrderLineItemInfo;
}