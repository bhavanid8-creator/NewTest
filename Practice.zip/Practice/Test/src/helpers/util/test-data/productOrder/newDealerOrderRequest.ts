import DealerOrderNewProduct from "./dealerOrderNewProduct";
import DealerOrderAccountDetails from "../dealer/dealerOrderAccountDetails";
import MultiDealerAccountContext from "../dealer/multiDealerAccountContext";
import SingleDealerAccountContext from "../dealer/singleDealerAccountContext";

export default class NewDealerOrderRequest {
    dealerAccountContext: SingleDealerAccountContext | MultiDealerAccountContext;
    orderAccount: DealerOrderAccountDetails;
    productToAdd: DealerOrderNewProduct;
}