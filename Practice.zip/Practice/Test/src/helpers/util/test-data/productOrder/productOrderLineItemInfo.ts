import ProductOrderInfo from "./productOrderInfo";
import ProductInfo from "../product/productInfo";

export default class ProductOrderLineItemInfo{
    productInfo: ProductInfo;
    productOrderInfo: ProductOrderInfo;
}