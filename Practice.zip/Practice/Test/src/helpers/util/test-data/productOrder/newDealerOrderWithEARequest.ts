import DealerOrderAccountDetails from "../dealer/dealerOrderAccountDetails";
import MultiDealerAccountContext from "../dealer/multiDealerAccountContext";
import SingleDealerAccountContext from "../dealer/singleDealerAccountContext";
import EAConfig from "../product/eaConfig";
import DealerOrderNewEAProduct from "./dealerOrderNewEAProduct";

export default class NewDealerOrderWithEARequest {
    dealerAccountContext: SingleDealerAccountContext | MultiDealerAccountContext;
    orderAccount: DealerOrderAccountDetails;
    eaConfig: EAConfig;
    productToAdd: DealerOrderNewEAProduct;
}