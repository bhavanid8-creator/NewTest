import AccountsSelection from "../dealer/accountsSelection";
import ProductsSelection_Old from "../product/productsSelection";

export default class DataSelection{
    accounts: AccountsSelection;
    products: ProductsSelection_Old
}