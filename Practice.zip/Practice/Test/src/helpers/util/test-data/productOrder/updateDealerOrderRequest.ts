import ProductInfo from "../product/productInfo";
import DealerOrderProductModification from "./dealerOrderProductModification";
import NewDealerOrderRequest from "./newDealerOrderRequest";

export default class UpdateDealerOrderRequest extends NewDealerOrderRequest {
    productToModify: DealerOrderProductModification;
    productToDelete: ProductInfo;
}