export default class DealerOrderLineItemInfo {
    name: string;
    units: string;
}