import DealerOrderEAProductsSelection from "../product/dealerOrderEAProductsSelection";
import DealerOrderLineItemInfo from "./dealerOrderLineItemInfo";

export default class DealerOrderNewEAProduct {
    productSelection: DealerOrderEAProductsSelection;
    lineItemsInfo: DealerOrderLineItemInfo[];
}