export default class ProductOrderInfo{
    units: string;
    /**
     * @description expected format is MMMM DD, YYYY. E.g., October 31, 2023
     */
    deliveryDate: string;
    seller: string;
    customerPO: string;

    public toString(): string {
        return `Units: ${this.units} -- DeliveryDate: ${this.deliveryDate} -- Seller: ${this.seller} -- CustomerPO: ${this.customerPO} -- `;
    }
}