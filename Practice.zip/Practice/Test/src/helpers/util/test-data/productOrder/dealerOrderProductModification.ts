import ProductInfo from "../product/productInfo";
import DealerOrderLineItemInfo from "./dealerOrderLineItemInfo";

export default class DealerOrderProductModification {
    product: ProductInfo;
    lineItemInfo: DealerOrderLineItemInfo;
}