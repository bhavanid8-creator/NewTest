export default class JDEUser{
    userID: string;
    password: string;
}