import AccountDetailsForOrderModification from "../grower/accountDetailsForOrderModification";
import GrowerDetails from "../grower/growerDetails";
import ProductInfo from "../product/productInfo";
import ProductOrderInfo from "../productOrder/productOrderInfo";
import ProductToAddOrDeleteOrUpdate from "../productOrder/productToAddOrDeleteOrUpdate";
import SellerInfo from "../seller/sellerInfo";

export default class ProductTransferSameDealer{
    orderAccount: AccountDetailsForOrderModification;
    updatedSeller: SellerInfo;
    destinationGrower: GrowerDetails;
    destinationGrowerOrderId: string;
    productsToTransfer: ProductInfo[];
    transferModifications: ProductOrderInfo;
    productToAddIfOrderHasZeroLineItems: ProductToAddOrDeleteOrUpdate;
}