export default class InitializedGrower{
    gmk: string;
    newOrderNumber: string;
}