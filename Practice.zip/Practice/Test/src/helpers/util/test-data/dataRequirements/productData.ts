export default class ProductData {
    name: string;
    itemId: number;
}