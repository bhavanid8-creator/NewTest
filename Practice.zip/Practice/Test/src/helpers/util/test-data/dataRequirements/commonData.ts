export default class CommonData {
    cropYear: number;
    companyCode: string;
    defaultDealerProductQty: number;
    defaultGrowerProductQty: number;
}