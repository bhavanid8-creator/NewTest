export default class InitializedDealer{
    accountNumber: string;
    newOrderNumber: string;
}