import AccountDetailsBasic from "../dealer/accountDetailsBasic";
import OrderReleaseDeliveryInstructions from "./orderReleaseDeliveryInstructions";
import PalletDetails from "./palletDetails";
import ReleasedProduct from "./releasedProduct";

type FreightHandlingCodeType = "Customer Default" | "PREPAID FREIGHT" | "CUSTOMER ARRANGED" | "VENDOR MANAGED 3RD PARTY BILL" | "VENDOR ARRANGED (FOB BILLING)" | "SALES HISTORY CONV WF" | "BYPASS ROUTING AND RATING" | "VENDOR ARRANGED (DVT BILLING)" | "CONSIGNEE FREIGHT (WU ARRANGE)" | "CUSTOMER ARRANGED (FRT ALLWNC)" | "COMMON CARRIER (NON-OTM)" | "PREPAY AND ADD" | "PARCEL" | "CONSIGNEE FREIGHT (FRT ALW)" | "VENDOR MANAGED (OMNIUM PLANNED" | "VENDOR PICKUP/RETURN";
type InventoryComputeOptionsType = "Compute for all" | "Available to release" | "Do not compute";
type RequestType = "S9 order. No Print Pick Slip." | "S9 order. Auto Pick Slip" | "S9 cross doc." | "ST order. No Print Pick Slip." | "ST order. Auto Pick Slip" | "S6 order. No Print Pick Slip." | "S6 order. Auto Pick Slip" | "SD Order" | "S3 Order. No Print Pick Slip" | "Soft Commit Only" | "S3 order. Auto Pick Slip";

export default class SeedFulfillment {
    shipTo: AccountDetailsBasic;
    deliverTo: AccountDetailsBasic;
    branch: string;
    requestedDate: string;
    freightHandlingCode: FreightHandlingCodeType;
    inventoryComputeOptions: InventoryComputeOptionsType;
    requestType: RequestType;
    deliveryInstructions: OrderReleaseDeliveryInstructions;
    productsToRelease: ReleasedProduct[];
    palletDetailsToOverride: PalletDetails[];
}