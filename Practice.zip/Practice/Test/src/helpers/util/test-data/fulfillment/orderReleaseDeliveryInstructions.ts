
type ProductLineType = "Alfalfa" | "Spring Canola" | "Winter Canola" | "Corn" | "Cotton" | "Forage Sorghum" | "Grain Sorghum Packaged" | "Soybean" | "Soybean Bulk" | "Sunflower" | "Sunflower Non Traditional Packaged" | "Winter Wheat" | "Spring Wheat" | "All";
type ContactType = "Primary" | "Alternate 1" | "Alternate 2" | "Alternate 3" | "Alternate 4" | "Alternate 5" | "Alternate 6" | "Alternate 7" | "Alternate 8" | "Alternate 9" ;
type DeliveryInstructionType = "Ag Hopper Required for Bulk Soybeans (AGHOP)" | "Call Ahead (do not use on LTLs, if no answer the driver skips the stop) (CALL 1st)" | "Call 2 days ahead (CL 2 DAY AHD)" | "Call 1 day ahead (CL DAY AHD)" | "Delivery Appt needed (DLV APT)" | "Driver Required Assistance (DRA)" | "Pallet Jack Required (PJK)" | "Unmanned Location (UNMAN)";

export default class OrderReleaseDeliveryInstructions {
    productLine: ProductLineType;
    contactType: ContactType;
    firstName: string;
    lastName: string;
    phone: string;
    email: string;
    deliveryInstruction: DeliveryInstructionType[];
}