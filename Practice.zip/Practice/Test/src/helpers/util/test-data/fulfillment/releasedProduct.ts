export default class ReleasedProduct {
    name: string;
    quantity: string;
    seedWeight: string;
    inventory: string;
}