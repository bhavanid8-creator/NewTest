
type PalletType = "LOL PALLET STOCK 54INX42IN" | "FREIGHT CHARGE SEED" | "PALLET NON-STOCK" | "FS FORAGE SORG TRUCKLOAD PROG" | "FS FORAGE SORG HALF TRUCKLOAD" | "SRWW ZONE 1 FREIGHT CHARGE" | "SRWW ZONE 2 FREIGHT CHARGE" | "SRWW ZONE 3 FREIGHT CHARGE"| "PALLETS 48X40";

export default class PalletDetails {
    //palletType: PalletType;
    palletType: string;
    quantity: string;
    palletWeight: string;
}