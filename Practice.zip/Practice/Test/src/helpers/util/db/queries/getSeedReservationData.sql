;WITH ReservationLineCounts AS
(
    SELECT
        SRD.SeedReservationHeaderID,
        COUNT(1) AS LineItemCount
    FROM dbo.SeedReservationDetail AS SRD
    GROUP BY
        SRD.SeedReservationHeaderID
),
LatestEligibleReservation AS
(
    SELECT TOP (1)
        SRH.SeedReservationHeaderID,
        SRH.ShipToAccount,
        SRH.GMK AS GrowerGMK
    FROM dbo.SeedReservationHeader AS SRH
    INNER JOIN ReservationLineCounts AS RLC
        ON RLC.SeedReservationHeaderID = SRH.SeedReservationHeaderID
    WHERE
        RLC.LineItemCount > 1
    ORDER BY
        SRH.CreateTimeStamp DESC,
        SRH.SeedReservationHeaderID DESC
)
SELECT
    LER.ShipToAccount AS AccountNumber,
    LER.SeedReservationHeaderID AS ReservationID,
    LER.GrowerGMK,
    PLM.Description AS ProductLineName,
    MBM.Description AS MarketingBrandName,
    SRD.Units AS ReservationUnits
FROM LatestEligibleReservation AS LER
INNER JOIN dbo.SeedReservationDetail AS SRD
    ON SRD.SeedReservationHeaderID = LER.SeedReservationHeaderID
LEFT JOIN dbo.ProductLineMaster AS PLM
    ON PLM.ProductLineId = SRD.ProductLineID
LEFT JOIN dbo.MarketingBrandMaster AS MBM
    ON MBM.MarketingBrandId = SRD.MarketingBrandID
ORDER BY
    SRD.SeedReservationDetailID;