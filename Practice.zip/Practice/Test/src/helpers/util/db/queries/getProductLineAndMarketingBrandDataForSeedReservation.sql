DECLARE @Today date = CAST(GETDATE() AS date);
SELECT DISTINCT
    cfg.ProductLineID,
    pl.Description AS ProductLineName,
    cfg.MarketingBrandID,
    mb.Description AS MarketingBrandName,
    cfg.ConvAtItemLvl,
    cfg.ConvAtHybrPkgLvl
FROM dbo.SeedReservationProductLineMarketingBrandConfig AS cfg
INNER JOIN dbo.ProductLineMaster AS pl
    ON pl.ProductLineId = cfg.ProductLineID
INNER JOIN dbo.MarketingBrandMaster AS mb
    ON mb.MarketingBrandId = cfg.MarketingBrandID
INNER JOIN dbo.SeedReservationPeriodConfig AS pc
    ON pc.ProductLineId = cfg.ProductLineID
WHERE
    @Today >= CAST(pc.ReservationStartDate AS date)
    AND @Today <= CAST(pc.ReservationEndDate AS date)
ORDER BY
    pl.Description,
    mb.Description;