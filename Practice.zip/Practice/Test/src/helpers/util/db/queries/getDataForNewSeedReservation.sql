IF OBJECT_ID('tempdb..#ActiveAccounts') IS NOT NULL DROP TABLE #ActiveAccounts;

DECLARE @CropYear int =
(
    SELECT TOP (1) CYM.CropYear
    FROM dbo.CropYearMaster AS CYM
    WHERE CYM.Active = 1
    ORDER BY CYM.CropYear DESC
);

SELECT
    AccountNumber,
    AccountName
INTO #ActiveAccounts
FROM dbo.AccountMaster
WHERE Status = 'Y'
AND AccountType NOT LIKE 'X%';

CREATE UNIQUE CLUSTERED INDEX IX_ActiveAccounts
    ON #ActiveAccounts (AccountNumber);

;WITH Candidate AS
(
    SELECT TOP (1)
        AM.AccountNumber,
        GDR.GMK AS GrowerGMK
    FROM #ActiveAccounts AS AM
    INNER JOIN dbo.GrowerDealerRelationship AS GDR
        ON GDR.AccountNumber = AM.AccountNumber
    INNER JOIN dbo.GrowerMaster AS GM
        ON GM.GMK = GDR.GMK
    WHERE AM.AccountNumber NOT LIKE '601%'
    AND GM.Status = 1
    AND GM.BusinessName IS NOT NULL
    AND LTRIM(RTRIM(GM.BusinessName)) <> ''
    AND LTRIM(RTRIM(GM.BusinessName)) NOT LIKE 'My Dealer Bucket%'
    AND EXISTS
    (
        SELECT 1
        FROM dbo.SellerDealerRelationship AS SDR
        INNER JOIN #ActiveAccounts AS SellerAM
            ON SellerAM.AccountNumber = SDR.SellerAccountNumber
        WHERE SDR.ShipToAccountNumber = AM.AccountNumber
            AND SDR.IsActive = 1
            AND SDR.SellerAccountNumber <> AM.AccountNumber
    )
    AND NOT EXISTS
    (
        SELECT 1
        FROM dbo.SeedReservationHeader AS SRH
        WHERE SRH.ShipToAccount = AM.AccountNumber
            AND SRH.GMK = GDR.GMK
            AND SRH.CropYear = @CropYear
    )
    ORDER BY
        AM.AccountNumber,
        GDR.GMK
)
SELECT
    C.AccountNumber AS ShipToAccount,
    AM.AccountName AS ShipToAccountName,
    Seller.SellerAccountNumber,
    Seller.SellerAccountName,
    C.GrowerGMK,
    Grower.GrowerName
FROM Candidate AS C
INNER JOIN #ActiveAccounts AS AM
    ON AM.AccountNumber = C.AccountNumber
CROSS APPLY
(
    SELECT TOP (1)
        SDR.SellerAccountNumber,
        SellerAM.AccountName AS SellerAccountName
    FROM dbo.SellerDealerRelationship AS SDR
    INNER JOIN #ActiveAccounts AS SellerAM
        ON SellerAM.AccountNumber = SDR.SellerAccountNumber
    WHERE SDR.ShipToAccountNumber = C.AccountNumber
    AND SDR.IsActive = 1
    AND SDR.SellerAccountNumber <> C.AccountNumber
    ORDER BY SDR.SellerAccountNumber
) AS Seller
CROSS APPLY
(
    SELECT
        GM.BusinessName AS GrowerName
    FROM dbo.GrowerMaster AS GM
    WHERE GM.GMK = C.GrowerGMK
) AS Grower;

DROP TABLE #ActiveAccounts;