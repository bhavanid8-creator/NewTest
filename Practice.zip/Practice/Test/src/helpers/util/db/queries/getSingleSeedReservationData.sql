DECLARE @ReservationID INT;
DECLARE @Today date = CAST(GETDATE() AS date);
DECLARE @CropYear int =
(
    SELECT TOP (1) CYM.CropYear
    FROM dbo.CropYearMaster AS CYM
    WHERE CYM.Active = 1
    ORDER BY CYM.CropYear DESC
);

;WITH OneLineReservations AS
(
    SELECT
        SRH.SeedReservationHeaderID
    FROM dbo.SeedReservationHeader AS SRH
    INNER JOIN dbo.SeedReservationDetail AS SRD
        ON SRD.SeedReservationHeaderID = SRH.SeedReservationHeaderID
    WHERE SRH.CropYear = @CropYear
    GROUP BY
        SRH.SeedReservationHeaderID
    HAVING COUNT(*) = 1
)
SELECT TOP (1)
    @ReservationID = OLR.SeedReservationHeaderID
FROM OneLineReservations AS OLR
ORDER BY OLR.SeedReservationHeaderID;

SELECT
    SRH.ShipToAccount AS AccountNumber,
    SRH.SeedReservationHeaderID AS ReservationID,
    SRH.GMK AS GrowerGMK,
    PLM.Description AS ReservationProductLineName,
    MBM.Description AS ReservationMarketingBrandName,
    SRD.Units AS ReservationUnits,
    MissingCombo.ProductLineName AS MissingProductLineName,
    MissingCombo.MarketingBrandName AS MissingMarketingBrandName
FROM dbo.SeedReservationHeader AS SRH
INNER JOIN dbo.SeedReservationDetail AS SRD
    ON SRD.SeedReservationHeaderID = SRH.SeedReservationHeaderID
LEFT JOIN dbo.ProductLineMaster AS PLM
    ON PLM.ProductLineId = SRD.ProductLineID
LEFT JOIN dbo.MarketingBrandMaster AS MBM
    ON MBM.MarketingBrandId = SRD.MarketingBrandID
OUTER APPLY
(
    SELECT TOP (1)
        PLM2.Description AS ProductLineName,
        MBM2.Description AS MarketingBrandName
    FROM dbo.SeedReservationProductLineMarketingBrandConfig AS CFG
    INNER JOIN dbo.SeedReservationPeriodConfig AS pc
        ON pc.ProductLineId = CFG.ProductLineID
    LEFT JOIN dbo.ProductLineMaster AS PLM2
        ON PLM2.ProductLineId = CFG.ProductLineID
    LEFT JOIN dbo.MarketingBrandMaster AS MBM2
        ON MBM2.MarketingBrandId = CFG.MarketingBrandID
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM dbo.SeedReservationDetail AS D
        WHERE D.SeedReservationHeaderID = SRH.SeedReservationHeaderID
        AND D.ProductLineID = CFG.ProductLineID
        AND D.MarketingBrandID = CFG.MarketingBrandID
    )
    AND @Today >= CAST(pc.ReservationStartDate AS date)
    AND @Today <= CAST(pc.ReservationEndDate AS date)
    ORDER BY CFG.ProductLineID, CFG.MarketingBrandID
) AS MissingCombo
WHERE SRH.SeedReservationHeaderID = @ReservationID
ORDER BY SRD.SeedReservationDetailID;