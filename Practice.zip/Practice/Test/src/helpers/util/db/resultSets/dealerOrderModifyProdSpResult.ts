export class DealerOrderModifyProdSpResult{
    AccountNumber: number;
    DealerOrderNumber: string;
    DealerName: string;
    FromItemId: number;
    FromItemNumber: string;
    ToItemID: number;
    ToItemNumber: string;
    ToConv: number;
}