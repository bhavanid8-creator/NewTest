export default class GrowerOrderTransferProdSpResult{
    SrcAccountNumber: number;
    SrcGMK: number;
    SrcGrowerName: string;
    SrcGrowerOrderNumber: string;
    FromItemId: number;
    FromItemNumber: string;
    MinTransferrableQty: number;
    TrgtAccountNumber: number;
    TrgtGMK: number;
    TrgtGrowerName: string;
    TrgtGrowerOrderNumber: string;
}