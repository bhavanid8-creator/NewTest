import ProductLineAndMarketingBrand from "./productLineAndMarketingBrand";

export default class SingleSeedReservationDataQueryResult{
    ShipToAccountNumber: number;
    GrowerGMK: number;
    ReservationId: number;
    ProductLineAndMarketingBrandInfo: ProductLineAndMarketingBrand;
    MissingProductLineAndMarketingBrandInfo: ProductLineAndMarketingBrand;
}