
import HasLineItemsData from "./hasLineItemsData";
import LineItemInfo from "./lineItemInfo";

export default class CreateCppReturnRequestSpResult implements HasLineItemsData{
    ShipToAccountNumber: number;
    ShipToAccountName: string;
    SoldToAccountNumber: number;
    SoldToAccountName: string;
    PickupFromAccountNumber: number;
    IsPORequired: boolean = true; 
    HasDraftOrder: boolean;
    LineItemsData: LineItemInfo[];
}