import LineItemInfo from "./lineItemInfo";
import HasLineItemsData from "./hasLineItemsData";
export default class CreateCppOrderSpResult implements HasLineItemsData{
    ShipToAccountNumber: number;
    ShipToAccountName: string;
    SoldToAccountName: string;
    DeliverToAccountNumber: number; //can be null
    DeliverToAccountName: string; //can be null
    ItemId: number;
    ItemNumber: string;
    MinQty: number;
    ContactName: string; //can be null
    UOM: string;
    PackageSize: string;
    GallonsPerQty: number; //can be null
    HasDraftOrder: boolean;
    LineItemsData: LineItemInfo[]; //can be null for non SDM & non Bulk scenarios
    IsPORequired: boolean = true; //applicable only for Bulk scenarios
}