export default class DealerOrderTransferProdSpResult{
    SrcAccountNumber: number;
    SrcAccountName: string;
    SrcAccountOrderNumber: string;
    FromItemId: number;
    FromItemNumber: string;
    MinTransferrableQty: number;
    TrgtAccountNumber: number;
    TrgtAccountName: string;
    TrgtAccountOrderNumber: string;
}