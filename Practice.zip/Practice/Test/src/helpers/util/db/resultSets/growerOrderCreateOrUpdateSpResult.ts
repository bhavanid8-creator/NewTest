export default class GrowerOrderCreateOrUpdateSpResult{
    AccountNumber: number;
    AccountName: string;
    GMK: number;
    GrowerOrderNumber: string;
    GrowerName: string;
    ItemId: number;
    ItemNumber: string;
    MinQty: number;
}