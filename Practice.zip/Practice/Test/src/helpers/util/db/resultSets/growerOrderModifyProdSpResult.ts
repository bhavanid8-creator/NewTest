export default class GrowerOrderModifyProdSpResult {
    AccountNumber: number;
    GMK: number;
    GrowerOrderNumber: string;
    GrowerName: string;
    FromItemId: number;
    FromItemNumber: string;
    ToItemID: number;
    ToItemNumber: string;
    ToConv: number;
}