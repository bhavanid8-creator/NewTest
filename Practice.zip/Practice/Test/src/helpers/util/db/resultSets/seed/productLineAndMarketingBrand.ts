export default class ProductLineAndMarketingBrand{
    ProductLineName: string;
    MarketingBrandName: string;
    ReservationUnits?: number;
}