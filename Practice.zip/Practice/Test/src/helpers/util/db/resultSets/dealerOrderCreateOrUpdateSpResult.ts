export class DealerOrderCreateOrUpdateSpResult{
    AccountNumber: number;
    AccountName: string;
    DealerOrderNumber: string;
    ItemId: number;
    ItemNumber: string;
    MinQty: number;
    UpdatedEAUnits: number;
}