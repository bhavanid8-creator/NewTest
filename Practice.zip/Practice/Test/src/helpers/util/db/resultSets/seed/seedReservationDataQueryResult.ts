import ProductLineAndMarketingBrand from "./productLineAndMarketingBrand";

export default class SeedReservationDataQueryResult{
    ShipToAccountNumber: number;
    ShipToAccountName: string;
    SellerAccountNumber?: number;
    SellerAccountName?: string;
    GrowerGMK?: number;
    GrowerName?: string;
    ReservationId?: number;
    ProductLineAndMarketingBrandInfo?: ProductLineAndMarketingBrand[];
}