export default class DealerOrderSwapEAProdSpResult{
    AccountNumber: number;
    DealerOrderNumber: string;
    DealerName: string;
    FromItemId: number;
    FromItemNumber: string;
    ToItemID: number;
    ToItemNumber: string;
    ToConv: number;
    FinalFromEAUnits: number;
    FinalToEAUnits: number;
}