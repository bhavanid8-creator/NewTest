export class SeedReplantRequestActiveOrDraft {
    RequestId: number;
    RequestNumber: string;
    RequestDate: Date;
    AccountNumber: number;
    AccountName: string;
    GrowerGMK: number;
    CustomerPO: string;
    Status: string;
    TotalReplantProducts: number;
    TotalUnits: number;
}

export class SeedReplantRequestDetail {
    RequestId: number;
    RequestNumber: string;
    RequestDate: Date;
    AccountNumber: number;
    AccountName: string;
    GrowerGMK: number;
    CustomerPO: string;
    ProductItemId: number;
    ProductItemNumber: string;
    ProductDescription: string;
    LotNumber: string;
    Units: number;
    ProductType: string;
    Status: string;
}

export class SeedReplantRequestCreate {
    ShipToAccount: number;
    ShipToAccountName: string;
    SoldToAccount: number;
    SoldToAccountName: string;
    GrowerGMK: number;
    GrowerBusinessName: string;
    GrowerFirstName: string;
    GrowerLastName: string;
    GrowerHaveLicense: boolean | string;
    CreditToAccount: number;
    CreditToAccountName: string;
    FailedProductItemId: number;
    FailedProductItemNumber: number;
    FailedProductDescription: string;
    FailedProductLotNumber: string;
    ReplantProductItemId: number;
    ReplantProductItemNumber: number;
    ReplantProductDescription: string;
    HasDraftOrder: boolean;
}

export default class SeedReplantGetOrCreate {
    SeedReplantRequestActiveOrDraft: SeedReplantRequestActiveOrDraft | SeedReplantRequestActiveOrDraft[] | null;
    SeedReplantRequestDetail: SeedReplantRequestDetail | null;
    SeedReplantRequestCreate: SeedReplantRequestCreate | SeedReplantRequestCreate[] | null;
}