import { fixture } from "../../../../../hooks/fixture";

export default class ArrivalDateReasonChange{
    readonly B2BOrderPlaced = "B2B Order Placed";
    readonly ExpediteRequest = "Expedite Request";
    readonly VendorProgramChanged = "Vendor Program Date";
    readonly WinFieldUnitedProgramDate = "WinField United Program Date";

    getOptionCode(optionName: string): string{
        let optionCode = "";
        switch (optionName) {
            case this.B2BOrderPlaced:
                optionCode = "0";
                break;
            case this.ExpediteRequest:
                optionCode = "1";
                break;
            case this.VendorProgramChanged:
                optionCode = "2";
                break;
            case this.WinFieldUnitedProgramDate:
                optionCode = "3";
                break;
            default:
                {
                    let errMsg = `specified arrival date change reason - ${optionName} - is not supported`;
                    fixture.logger.error(errMsg);
                    throw new Error(errMsg);
                }

        }
        return optionCode;
    }
}