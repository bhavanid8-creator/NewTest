export default class LineItemInfo {
    /**
     * LineItemSeq starts with 1
     */
    LineItemSeq: number = 1;
    ItemNumber: string;
    MaxQty: number;
    MinQty: number;
    IsItemSDM: boolean;
    UOM: string;
    PackageSize: string;
    GallonsPerQty: number; //can be null
    /* FOR SDM SCENARIOS - BEGIN */
    //Structured Delivery Matrix (or arrival request) information; applicable only when IsItemSDM = true
    EarliestScheduledDeliveryDate: Date; // BLUE
    //NextEarliestScheduledDeliveryDate: Date; // YELLOW
    NextEarliestScheduledDeliveryDate: string; // YELLOW
    EarliestUnscheduledDeliveryDate: Date; //GRAY 
    NextEarliestUnScheduleDeliveryDate: Date; //GRAY 
    /* FOR SDM SCENARIOS - END */
    /* FOR BULK-PROPRIETARY SCENARIOS - BEGIN */
    PackageType: string = "bulk"; //for now it is bulk
    SupplierType: string = "proprietary"; //either Proprietary or Vendor; default is proprietary
    
    /* FOR BULK-PROPRIETARY SCENARIOS - END */

    /* FOR PACKAGED-VENDED-DIRECT_TO_SHIP SCENARIOS - BEGIN */
    SupplierNumber: string; //applicable only for Packaged-Vended-DirectToShip scenarios
    ItemVendorName: string; //applicable only for Packaged-Vended-DirectToShip scenarios
    /* FOR PACKAGED-VENDED-DIRECT_TO_SHIP SCENARIOS - END */

    /* FOR REQUESTED-ARRIVAL-DATE SCENARIOS - BEGIN */
    RequestDeliveryDate: string; //applicable only for Requested Arrival Date scenarios
    /* FOR REQUESTED-ARRIVAL-DATE SCENARIOS - END */

    /* FOR PRODUCT RETURNS SCENARIOS - BEGIN */
    /**
     * @reference ProductReturnType - AccountReturnable, AccountNonReturnable, ParentAccountReturnable, ParentAccountNonReturnable, ManualReturnable
     * @description ProductType is applicable only for Product Returns scenarios
     */
    ProductType: string;
    EligibleUnits: number;
    /* FOR PRODUCT RETURNS SCENARIOS - END */
}