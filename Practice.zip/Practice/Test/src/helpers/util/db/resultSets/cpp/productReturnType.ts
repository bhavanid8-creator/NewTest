export default class ProductReturnType {
 static readonly ACCOUNT_RETURNABLE: string = "AccountReturnable";
 static readonly ACCOUNT_NON_RETURNABLE: string = "AccountNonReturnable";
 static readonly PAREMT_ACCOUNT_RETURNABLE: string = "ParentAccountReturnable";
 static readonly PAREMT_ACCOUNT_NON_RETURNABLE: string = "ParentAccountNonReturnable";
 static readonly MANUAL_ACCOUNT_RETURNABLE: string = "ManualReturnable";
}