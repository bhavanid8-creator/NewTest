export class DealerStockTransferSpResult{
    SrcAccountNumber: number;
    SrcAccountName: string;
    ItemId: number;
    ItemNumber: string;
    MinTransferrableQty: number;
    TrgtAccountNumber: number;
    TrgtAccountName: string;
    LotNumber: string;
}