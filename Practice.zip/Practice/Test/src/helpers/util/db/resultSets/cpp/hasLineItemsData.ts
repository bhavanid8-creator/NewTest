import LineItemInfo from "./lineItemInfo";

export default interface HasLineItemsData {
    LineItemsData: LineItemInfo[] | null;
}
