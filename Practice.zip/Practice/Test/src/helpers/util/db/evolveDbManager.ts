import * as sql from 'mssql';
import { fixture } from "../../../hooks/fixture";
import DataBagKeys from "../../../tests/steps/dataBagKeys";
import DateHelper from "../../types/dateHelper";
import CommonData from "../test-data/dataRequirements/commonData";
import ProductData from "../test-data/dataRequirements/productData";
import ColumnDetails from "./columnDetails";
import DbManager, { DbConnectionMechanism } from "./dbManager";
import DbOperationResult from "./dbOperationResult";
import GrowerOrderModifyProdSpResult from "./resultSets/growerOrderModifyProdSpResult";
import GrowerOrderTransferProdSpResult from './resultSets/growerOrderTransferProdSpResult';
import DealerOrderTransferProdSpResult from './resultSets/dealerOrderTransferProdSpResult';
import { DealerOrderModifyProdSpResult } from './resultSets/dealerOrderModifyProdSpResult';
import { DealerStockTransferSpResult } from './resultSets/dealerStockTransferSpResult';
import { DealerOrderCreateOrUpdateSpResult } from './resultSets/dealerOrderCreateOrUpdateSpResult';
import GrowerOrderCreateOrUpdateSpResult from './resultSets/growerOrderCreateOrUpdateSpResult';
import DealerOrderSwapEAProdSpResult from './resultSets/dealerOrderSwapEAProdSpResult';
import CreateCppOrderSpResult from './resultSets/cpp/createCppOrderSpResult';
import LineItemInfo from './resultSets/cpp/lineItemInfo';
import HasLineItemsData from './resultSets/cpp/hasLineItemsData';
import CreateCppReturnRequestSpResult from './resultSets/cpp/createCppReturnRequestSpResult';
import { SkipScenarioError } from '../../util/errorHandler';
import SeedReplantGetOrCreate, { SeedReplantRequestActiveOrDraft, SeedReplantRequestCreate, SeedReplantRequestDetail } from './resultSets/seed/seedReplantGetOrCreateSpResult';
import SeedReservationDataQueryResult from './resultSets/seed/seedReservationDataQueryResult';
import ProductLineAndMarketingBrand from './resultSets/seed/productLineAndMarketingBrand';
import SingleSeedReservationDataQueryResult from './resultSets/seed/singleSeedReservationDataQueryResult';
import * as path from 'path';
import { Console } from 'console';

/**
 * COLUMN DATA TYPES
 */
const COL_TYPE_INT = 'INT';

/**
 * tables
 */
const TBL_USER_SECURITY = 'UserSecurity';
const TBL_GROWER_ORDER = 'GrowerOrder';
const TBL_GROWER_ORDER_ITEMS = 'GrowerOrderItems';
const TBL_GROWER_ORDER_MIGRATION_AUDIT = 'GrowerOrderMigrationAudit';
const TBL_GROWER_ORDER_ITEMS_AUDIT = 'GrowerOrderItemsAudit';
const TBL_GROWER_ORDER_AUDIT = 'GrowerOrderAudit';
const TBL_DEALER_ORDER = 'DealerOrder';
const TBL_DEALER_ORDER_ITEMS = 'DealerOrderItems';
const TBL_CROP_YEAR_MASTER = 'CropYearMaster';

/**
 * colums
 */
const COL_ROLE = 'Role';
const COL_USER_ID = 'UserId';
const COL_SHIP_TO_ACCOUNT = 'ShipToAccount';
const COL_DEALER_ORDER_ID = 'DealerOrderId';
const COL_GROWER_ORDER_ID = 'GrowerOrderID';
const COL_GROWER_GMK = 'GrowerGMK';
const COL_CROP_YEAR = 'CropYear';
const COL_COMPANY_CODE = 'CompanyCode';
const COL_ORDER_NUMBER = 'OrderNumber';
const COL_TRANSACTION_ORIGINATOR = 'TransactionOriginator';
const COL_EMULATING_USER_ID = 'EmulatingUserId';
const COL_CREATED_BY = 'CreatedBy';
const COL_CREATED_TIMESTAMP = 'CreatedTimestamp';
const COL_UPDATED_BY = 'UpdatedBy';
const COL_UPDATE_USER = 'UpdateUser';
const COL_UPDATED_TIMESTAMP = 'UpdatedTimestamp';
const COL_UPDATE_DATETIME = 'UpdateDateTime';
const COL_LINE_NUMBER = 'LineNumber';
const COL_ITEM_ID = 'ItemId';
const COL_QUANTITY = 'Quantity';
const COL_UOM = 'UOM';
const COL_SECONDARY_QUANTITY = 'SecondaryQuantity';
const COL_SECONDARY_UOM = 'SecondaryUOM';
const COL_CHANGE_TYPE = 'ChangeType';
const COL_ORDER_TYPE = 'OrderType';
const COL_ORDER_STATUS = 'OrderStatus';
const COL_TRANSACTION_QUANTITY = 'TransactionQuantity';
const COL_TRANSACTION_UOM = 'TransactionUOM';
const COL_PRIMARY_QUANTITY = 'PrimaryQuantity';
const COL_PRIMARY_UOM = 'PrimaryUOM';
const COL_DESIRED_DELIVERY_DATE = 'DesiredDeliveryDate';
const COL_SELLER_ID = 'SellerID';
const COL_STATUS = 'Status';
const COL_CUSTOMER_PO = 'CustomerPO';
const COL_ORDER_DATE_TIME = 'OrderDateTime';
const COL_CREATE_USER = 'CreateUser';
const COL_CREATE_TIMESTAMP = 'CreateTimeStamp';
const COL_UPDATE_TIMESTAMP = 'UpdateTimeStamp';
const COL_ACTIVE = 'Active'; 
const COL_END_DATE = 'EndDate'; 

/**
 * COLUMN VALUES
 */
const COL_VAL_SELLER_ID = 9901489;
const COL_VAL_CREATED_BY = 'qa-automation';
const COL_VAL_UPDATED_BY = 'qa-automation';
const COL_VAL_UPDATE_USER = 'qa-automation';
const COL_VAL_UOM = 'BG';
const COL_VAL_TRANSACTION_UOM = 'BG';
const COL_VAL_PRIMARY_UOM = 'BG';
const COL_VAL_CHANGE_TYPE_ADD = 'ADD';
const COL_VAL_ORDER_TYPE = 'WB';
const COL_VAL_ORDER_STATUS = 'A';
const COL_VAL_STATUS = 'A';
const COL_VAL_ACTIVE = 1;

export default class EvolveDbManager {
    readonly COL_VAL_USER_ROLE_ADMINISTRATOR = 'Administrator';
    private dbManager: DbManager;
    private pool: any = null;
    constructor(){
        this.dbManager = new DbManager();
    }

    private async initializeConnectionPool(){
        if(process.env.USE_AZURE_CLI_FOR_DB !== 'true')
            this.pool = await this.dbManager.connectToDatabase();
        else
            this.pool = await this.dbManager.connectToDatabase(DbConnectionMechanism.AzureCli);
    }

    private async releaseDbResources(){
        await this.dbManager.clearDbResources(this.pool);
    }

    async setUserRole(userId: string, role: string): Promise<DbOperationResult> {
        switch(role) {
            case this.COL_VAL_USER_ROLE_ADMINISTRATOR:
                return await this.setUserAsAdmin(userId);
            default:
                {
                    const errorMsg = `Role '${role}' is not supported for user role update.`;
                    fixture.logger.error(errorMsg);
                    throw new Error(errorMsg);
                }
        }
    }

    private async setUserAsAdmin(userId: string): Promise<DbOperationResult> {
        let dbOperationResult = new DbOperationResult();
        dbOperationResult.operationResult = false;
        
        try{
            await this.initializeConnectionPool();
            let result = await this.dbManager.updateData(this.pool, TBL_USER_SECURITY, 
                `${COL_ROLE} = '${this.COL_VAL_USER_ROLE_ADMINISTRATOR}'`, /* SET STATEMENT */
                `${COL_USER_ID} = '${userId}'`); /* WHERE CONDITION */
            dbOperationResult.operationResult = true;
            dbOperationResult.operationData = result.rowsAffected;
        }catch(err){
            //console.error("setUserAsAdmin DB ERROR:",err);
            console.error("DB ERROR:",JSON.stringify(err,null,2));
            fixture.logger.error(`error encountered while setting user role as Administrator - ${JSON.stringify(err)}`);
        }finally{
            await this.releaseDbResources();
        }
        return dbOperationResult;
    }

    async deleteGrowerOrders(dealerAccount: string, growerGMK: string){
        let dbOperationResult = new DbOperationResult();
        dbOperationResult.operationResult = false;
        
        try{
            await this.initializeConnectionPool();
            let result = await this.deleteGrowerOrdersData(dealerAccount, growerGMK);
            dbOperationResult.operationResult = true;
            dbOperationResult.operationData = result.rowsAffected;
        }catch(err){
            fixture.logger.error(`error encountered while deleting grower orders - ${JSON.stringify(err)}`);
        }finally{
            await this.releaseDbResources();
        }
        return dbOperationResult;
    }

    private async deleteGrowerOrdersData(dealerAccount: string, growerGMK: string): Promise<any>{
        let dealerAccountVal: number = parseInt(dealerAccount);
        let growerGMKVal: number = parseInt(growerGMK);
        
        let result = await this.dbManager.deleteData(this.pool, TBL_GROWER_ORDER_MIGRATION_AUDIT, this.getGrowerOrderMigrationAuditDeleteCondition(dealerAccountVal, growerGMKVal));
        fixture.logger.info(`Completed deleting data from ${TBL_GROWER_ORDER_MIGRATION_AUDIT} with the result - ${JSON.stringify(result)}`);
        
        result = await this.dbManager.deleteData(this.pool, TBL_GROWER_ORDER_ITEMS_AUDIT, this.getGrowerOrderItemsAuditDeleteCondition(dealerAccountVal, growerGMKVal));
        fixture.logger.info(`Completed deleting data from ${TBL_GROWER_ORDER_ITEMS_AUDIT} with the result - ${JSON.stringify(result)}`);

        result = await this.dbManager.deleteData(this.pool, TBL_GROWER_ORDER_AUDIT, this.getGrowerOrderAuditDeleteCondition(dealerAccountVal, growerGMKVal));
        fixture.logger.info(`Completed deleting data from ${TBL_GROWER_ORDER_AUDIT} with the result - ${JSON.stringify(result)}`);

        result = await this.dbManager.deleteData(this.pool, TBL_GROWER_ORDER_ITEMS, this.getGrowerOrderItemsDeleteCondition(dealerAccountVal, growerGMKVal));
        fixture.logger.info(`Completed deleting data from ${TBL_GROWER_ORDER_ITEMS} with the result - ${JSON.stringify(result)}`);
        
        result = await this.dbManager.deleteData(this.pool, TBL_GROWER_ORDER, this.getGrowerOrderDeleteCondition(dealerAccountVal, growerGMKVal));
        fixture.logger.info(`Completed deleting data from ${TBL_GROWER_ORDER} with the result - ${JSON.stringify(result)}`);

        return result;
    }

    async insertGrowerOrder(dealerAccount: string, growerGMK:string, itemIds:number[], quantities:number[], emulatingUserId:string, deleteExistingData: boolean){
        let dbOperationResult = new DbOperationResult();
        dbOperationResult.operationResult = false;
        
        try{
            await this.initializeConnectionPool();
            let result: any;
            
            if(deleteExistingData)
            {
                result = await this.deleteGrowerOrdersData(dealerAccount, growerGMK);
                fixture.logger.info(`completed deleting existing grower orders data`);
            }

            result = await this.insertGrowerOrdersData(dealerAccount, growerGMK, itemIds, quantities, emulatingUserId);
            dbOperationResult.operationResult = true;
            dbOperationResult.operationData = {};
            dbOperationResult.operationData.rowsAffected = result.dbResult.rowsAffected;
            dbOperationResult.operationData.newGrowerOrderId = result.newGrowerOrderId;
            dbOperationResult.operationData.newGrowerOrderNumber = result.newGrowerOrderNumber;
        }catch(err){
            fixture.logger.error(`error encountered while inserting grower orders - ${JSON.stringify(err)}`);
        }finally{
            await this.releaseDbResources();
        }
        return dbOperationResult;
    }
    async deleteDealerOrders(dealerAccount: string){
        let dbOperationResult = new DbOperationResult();
        dbOperationResult.operationResult = false;
        
        try{
            await this.initializeConnectionPool();
            let result = await this.deleteDealerOrdersData(dealerAccount);
            dbOperationResult.operationResult = true;
            dbOperationResult.operationData = result.rowsAffected;
        }catch(err){
            fixture.logger.error(`error encountered while deleting dealer orders - ${JSON.stringify(err)}`);
        }finally{
            await this.releaseDbResources();
        }
        return dbOperationResult;
    }
    
    async insertDealerOrder(dealerAccount: string, itemIds:number[], quantities:number[], emulatingUserId:string, deleteExistingData: boolean){
        let dbOperationResult = new DbOperationResult();
        dbOperationResult.operationResult = false;
        
        try{
            await this.initializeConnectionPool();
            let result: any;
            
            if(deleteExistingData)
            {
                result = await this.deleteDealerOrdersData(dealerAccount);
                fixture.logger.info(`completed deleting existing dealer orders data`);
            }

            result = await this.insertDealerOrdersData(dealerAccount, itemIds, quantities, emulatingUserId);
            dbOperationResult.operationResult = true;
            dbOperationResult.operationData = {};
            dbOperationResult.operationData.rowsAffected = result.dbResult.rowsAffected;
            dbOperationResult.operationData.newDealerOrderId = result.newDealerOrderId;
            dbOperationResult.operationData.newDealerOrderNumber = result.newDealerOrderNumber;

        }catch(err){
            fixture.logger.error(`error encountered while inserting dealer orders - ${JSON.stringify(err)}`);
        }finally{
            await this.releaseDbResources();
        }
        return dbOperationResult;
    }

    private async deleteDealerOrdersData(dealerAccount: string): Promise<any>{
        let dealerAccountVal: number = parseInt(dealerAccount);
        let result = await this.dbManager.deleteData(this.pool, TBL_DEALER_ORDER_ITEMS, this.getDealerOrderItemsDeleteCondition(dealerAccountVal));
        fixture.logger.info(`Completed deleting data from ${TBL_DEALER_ORDER_ITEMS} with the result - ${JSON.stringify(result)}`);
        result = await this.dbManager.deleteData(this.pool, TBL_DEALER_ORDER, this.getDealerOrderDeleteCondition(dealerAccountVal));
        fixture.logger.info(`Completed deleting data from ${TBL_DEALER_ORDER} with the result - ${JSON.stringify(result)}`);

        return result;
    }

    private async getNewOrderNumberFor(orderNumberFor: 'Dealer' | 'Grower' = 'Dealer'): Promise<string>{
        let tblName = TBL_DEALER_ORDER;
        let colName = COL_DEALER_ORDER_ID;

        if(orderNumberFor === "Grower"){
            tblName = TBL_GROWER_ORDER;
            colName = COL_GROWER_ORDER_ID;
        }
        let result = await this.dbManager.getColumnTopRecords(this.pool, 1, COL_ORDER_NUMBER, tblName, colName);
        let orderNumber = "";
        let newOrderNumber = "";
        if (result.recordset.length > 0) {
            let res = JSON.parse(JSON.stringify(result.recordset));
            orderNumber = res[0].OrderNumber;
            newOrderNumber = orderNumber.substring(0,8);
            let remainingNumber = orderNumber.substring(8);
            let remainingNumber_int = parseInt(remainingNumber) + 10; //by the time we insert a record, new records could have been inserted outside automation hence to avoid records with duplicate Ordernumber values, we increment latest value by 10
            if (remainingNumber.startsWith("0")) {
                newOrderNumber += "0" + remainingNumber_int.toString();
            }
            else {
                newOrderNumber += remainingNumber_int.toString();
            }
        } else {
            //we should never be here....
            newOrderNumber = Date.now().toString(); 
        }

        return newOrderNumber;
    }
    private getGrowerOrderIdFromTheDBResult(result: any): number{
        const newGrowerOrderIdStr = result.recordset[0][COL_GROWER_ORDER_ID];
        return parseInt(newGrowerOrderIdStr);
    }

    private async insertGrowerOrdersData(dealerAccount: string, growerGMK:string, itemIds:number[], quantities:number[], emulatingUserId:string = null): Promise<any>{
        // 2 step operation
        //Step 1: insert data into GrowerOrder
        //Step 2: insert data into GrowerOrderItems

        //Executing step 1: insert data into GrowerOrder
        let dealerAccountVal: number = parseInt(dealerAccount);
        let growerGMKVal: number = parseInt(growerGMK);
        let newOrderNumber = await this.getNewOrderNumberFor("Grower");

        let columns: string[]  = [];
        columns.push(COL_CROP_YEAR, COL_SHIP_TO_ACCOUNT, COL_COMPANY_CODE, COL_ORDER_NUMBER, COL_ORDER_DATE_TIME, 
            COL_TRANSACTION_ORIGINATOR, COL_EMULATING_USER_ID, COL_CREATE_USER, COL_CREATE_TIMESTAMP, COL_UPDATE_USER, 
            COL_UPDATE_TIMESTAMP, COL_GROWER_GMK, COL_ORDER_TYPE, COL_ORDER_STATUS);
        
        let colValues: any[] = [];
        
        let commonData:CommonData = this.getDataRequirementObject(DataBagKeys.DATA_REQ_COMMON);
        colValues.push(commonData.cropYear);
        colValues.push(dealerAccountVal);
        colValues.push(commonData.companyCode);
        colValues.push(newOrderNumber);
        let timeStamp = DateHelper.getTimeStamp();
        colValues.push(timeStamp);
        colValues.push(COL_VAL_CREATED_BY);
        colValues.push(emulatingUserId);
        colValues.push(COL_VAL_CREATED_BY);
        colValues.push(timeStamp);
        colValues.push(COL_VAL_UPDATED_BY);
        colValues.push(timeStamp);
        colValues.push(growerGMKVal);
        colValues.push(COL_VAL_ORDER_TYPE);
        colValues.push(COL_VAL_ORDER_STATUS);
        let columnDetailsToGetInsertedVals: ColumnDetails[] = [];

        let col= new ColumnDetails();
        col.name = COL_GROWER_ORDER_ID;
        col.type = COL_TYPE_INT;
        columnDetailsToGetInsertedVals.push(col);

        let result = await this.dbManager.insertDataWithColumnNames(this.pool, TBL_GROWER_ORDER, columns, colValues, columnDetailsToGetInsertedVals);
        fixture.logger.info(`Completed inserting data into ${TBL_GROWER_ORDER} with the result - ${JSON.stringify(result)}`);
        
        const newGrowerOrderId = this.getGrowerOrderIdFromTheDBResult(result);
        fixture.logger.info(`newly created grower order id is.... ${newGrowerOrderId}`)
        //Executing step 2: insert data into GrowerOrderItems

        columns = [];
        colValues = [];

        columns.push(COL_GROWER_ORDER_ID, COL_LINE_NUMBER, COL_ITEM_ID, COL_TRANSACTION_QUANTITY, COL_TRANSACTION_UOM,
                     COL_PRIMARY_QUANTITY, COL_PRIMARY_UOM, COL_DESIRED_DELIVERY_DATE, COL_UPDATE_DATETIME,
                     COL_SELLER_ID, COL_STATUS, COL_CUSTOMER_PO, COL_CHANGE_TYPE, COL_UPDATE_USER);//14 COLS

        let customerPO = "qa-automation-" + DateHelper.getUniqueNumberBasedOnDate();
        let desiredDeliveryDate = DateHelper.getDateTimeUTC(5);

        for(let i=0; i<itemIds.length; i++){
            colValues = [];
            colValues.push(newGrowerOrderId);
            colValues.push(i+1);
            colValues.push(itemIds[i]);
            colValues.push(quantities[i]);
            colValues.push(COL_VAL_UOM);
            colValues.push(quantities[i]);
            colValues.push(COL_VAL_UOM);
            colValues.push(desiredDeliveryDate);
            timeStamp = DateHelper.getTimeStamp();
            colValues.push(timeStamp);
            colValues.push(COL_VAL_SELLER_ID);
            colValues.push(COL_VAL_STATUS);
            colValues.push(customerPO);
            colValues.push(COL_VAL_CHANGE_TYPE_ADD);
            colValues.push(COL_VAL_CREATED_BY);

            result = await this.dbManager.insertDataWithColumnNames(this.pool, TBL_GROWER_ORDER_ITEMS, columns, colValues);
            fixture.logger.info(`Completed inserting a row into ${TBL_GROWER_ORDER_ITEMS} with the result - ${JSON.stringify(result)}`);
        }
        let finalResult: any = {};
        finalResult.dbResult = result;
        finalResult.newGrowerOrderId = newGrowerOrderId;
        finalResult.newGrowerOrderNumber = newOrderNumber;
        return finalResult;
    }
    
    private getDealerOrderIdFromTheDBResult(result: any): number{
        const newDealerOrderIdStr = result.recordset[0][COL_DEALER_ORDER_ID];
        return parseInt(newDealerOrderIdStr);
    }

    private async insertDealerOrdersData(dealerAccount: string, itemIds:number[], quantities:number[], emulatingUserId:string = null): Promise<any>{
        // 2 step operation
        //Step 1: insert data into DealerOrder
        //Step 2: insert data into DealerOrderItems

        //Executing step 1: insert data into DealerOrder
        let dealerAccountVal: number = parseInt(dealerAccount);
        let newOrderNumber = await this.getNewOrderNumberFor("Dealer");
        
        let columns: string[]  = [];
        columns.push(COL_CROP_YEAR, COL_SHIP_TO_ACCOUNT, COL_COMPANY_CODE, COL_ORDER_NUMBER, COL_TRANSACTION_ORIGINATOR, COL_EMULATING_USER_ID, COL_CREATED_BY, COL_CREATED_TIMESTAMP, COL_UPDATED_BY, COL_UPDATED_TIMESTAMP);
        
        let colValues: any[] = [];
        
        let commonData:CommonData = this.getDataRequirementObject(DataBagKeys.DATA_REQ_COMMON);
        colValues.push(commonData.cropYear);
        colValues.push(dealerAccountVal);
        colValues.push(commonData.companyCode);
        colValues.push(newOrderNumber);
        colValues.push(COL_VAL_CREATED_BY);
        colValues.push(emulatingUserId);
        colValues.push(COL_VAL_CREATED_BY);
        let timeStamp = DateHelper.getTimeStamp();
        colValues.push(timeStamp);
        colValues.push(COL_VAL_UPDATED_BY);
        colValues.push(timeStamp);
        
        let columnDetailsToGetInsertedVals: ColumnDetails[] = [];

        let col= new ColumnDetails();
        col.name = COL_DEALER_ORDER_ID;
        col.type = COL_TYPE_INT;
        columnDetailsToGetInsertedVals.push(col);

        let result = await this.dbManager.insertDataWithColumnNames(this.pool, TBL_DEALER_ORDER, columns, colValues, columnDetailsToGetInsertedVals);
        fixture.logger.info(`Completed inserting data into ${TBL_DEALER_ORDER} with the result - ${JSON.stringify(result)}`);
        
        const newDealerOrderId = this.getDealerOrderIdFromTheDBResult(result);
        fixture.logger.info(`newly created dealer order id is.... ${newDealerOrderId}`);
        //Executing step 2: insert data into DealerOrderItems

        columns = [];
        colValues = [];

        columns.push(COL_DEALER_ORDER_ID,COL_LINE_NUMBER,COL_ITEM_ID,COL_QUANTITY,COL_UOM,COL_SECONDARY_QUANTITY,COL_SECONDARY_UOM, COL_CREATED_BY, COL_CREATED_TIMESTAMP, COL_UPDATED_BY, COL_UPDATED_TIMESTAMP, COL_CHANGE_TYPE);

        for(let i=0; i<itemIds.length; i++){
            colValues = [];
            colValues.push(newDealerOrderId);
            colValues.push(i+1);
            colValues.push(itemIds[i]);
            colValues.push(quantities[i]);
            colValues.push(COL_VAL_UOM);
            colValues.push(quantities[i]);
            colValues.push(COL_VAL_UOM);
            colValues.push(COL_VAL_CREATED_BY);
            timeStamp = DateHelper.getTimeStamp();
            colValues.push(timeStamp);
            colValues.push(COL_VAL_CREATED_BY);
            colValues.push(timeStamp);
            colValues.push(COL_VAL_CHANGE_TYPE_ADD);

            result = await this.dbManager.insertDataWithColumnNames(this.pool, TBL_DEALER_ORDER_ITEMS, columns, colValues);
            fixture.logger.info(`Completed inserting a row into ${TBL_DEALER_ORDER_ITEMS} with the result - ${JSON.stringify(result)}`);
        }
        let finalResult: any = {};
        finalResult.dbResult = result;
        finalResult.newDealerOrderId = newDealerOrderId;
        finalResult.newDealerOrderNumber = newOrderNumber;
        return finalResult;
    }
    private getGrowerOrderMigrationAuditDeleteCondition(shipToAccount: number, growerGMK: number): string{
        return this.getGrowerOrderItemsDeleteCondition(shipToAccount, growerGMK);
    }
    private getGrowerOrderAuditDeleteCondition(shipToAccount: number, growerGMK: number): string{
        return this.getGrowerOrderItemsDeleteCondition(shipToAccount, growerGMK);
    }
    private getGrowerOrderItemsAuditDeleteCondition(shipToAccount: number, growerGMK: number): string{
        return this.getGrowerOrderItemsDeleteCondition(shipToAccount, growerGMK);
    }
    private getGrowerOrderItemsDeleteCondition(shipToAccount: number, growerGMK: number): string{
        return ` ${COL_GROWER_ORDER_ID} 
            IN (SELECT ${COL_GROWER_ORDER_ID} 
                FROM ${TBL_GROWER_ORDER} 
                WHERE ${this.getGrowerOrderDeleteCondition(shipToAccount, growerGMK)})`;
    }

    private getGrowerOrderDeleteCondition(shipToAccount: number, growerGMK: number): string{
        return `${COL_SHIP_TO_ACCOUNT} IN (${shipToAccount}) AND ${COL_GROWER_GMK} IN (${growerGMK})`;
    }

    private getDealerOrderItemsDeleteCondition(shipToAccount: number): string {
        return ` ${COL_DEALER_ORDER_ID} 
            IN (SELECT ${COL_DEALER_ORDER_ID} 
                FROM ${TBL_DEALER_ORDER} 
                WHERE ${this.getDealerOrderDeleteCondition(shipToAccount)})`;
    }

    private getDealerOrderDeleteCondition(shipToAccount: number): string{
        return `${COL_SHIP_TO_ACCOUNT} IN (${shipToAccount})`;
    }

    getDataRequirementObject(requirementType: string): any{
        switch(requirementType){
            case DataBagKeys.DATA_REQ_COMMON:
                return fixture.globalDataBag.getData(requirementType) as CommonData;
            case DataBagKeys.DATA_REQ_PRODUCTS:
                return fixture.globalDataBag.getData(requirementType) as ProductData[];
        }
    }

    async getActiveCropYearConfigData(): Promise<Date>{
        let tblName = TBL_CROP_YEAR_MASTER;
        let filterCondition = COL_ACTIVE + " = " + COL_VAL_ACTIVE;
        let colName = COL_END_DATE;

        const result = await this.getDataFromDBForSpecificCondition(colName, tblName, filterCondition);
        return new Date(result);
    }
    
    /*********************** STORED PROCEDURES **************************/
    async getDataForGrowerOrderProductModification(modificationType: string): Promise<DbOperationResult> {
        let dbOperationResult = new DbOperationResult();
        dbOperationResult.operationResult = false;
        const spName = 'proc_TA_GrowerOrder_ModifyProduct';

        modificationType = modificationType.replaceAll(" ",""); //SP does not accept spaces in the actionType

        const inputParams = [
            { name: 'ActionType', type: sql.VarChar, value: modificationType }
        ];

        try {
            fixture.logger.info(`executing the stored procedure - ${spName} - with the ActionType - ${modificationType}`);
            await this.initializeConnectionPool();
            const result = await this.dbManager.executeStoredProcedure<GrowerOrderModifyProdSpResult>(
                this.pool,
                spName,
                inputParams,
                (row) => {
                    let data = new GrowerOrderModifyProdSpResult();
                    data.AccountNumber = row.AccountNumber;
                    data.GMK = row.GMK;
                    data.GrowerOrderNumber = row.GrowerOrderNumber;
                    data.GrowerName = row.GrowerName;
                    data.FromItemId = row.FromItemId;
                    data.FromItemNumber = row.FromItemNumber;
                    data.ToItemID = row.ToItemID;
                    data.ToItemNumber = row.ToItemNumber;
                    data.ToConv = row.ToConv;
                    return data;
                }
            );
            fixture.logger.info(`stored procedure - ${spName} - returned - ${result.length} - row(s)`);
            if (result.length === 0) {
            throw new SkipScenarioError(`No data returned for ActionType: ${modificationType}`);
            }
            fixture.logger.info(`stored procedure - ${spName} - returned data is....`);
            result.forEach((row) => {
                fixture.logger.info(`${JSON.stringify(row)}`);
            });
            dbOperationResult.operationResult = true;
            dbOperationResult.operationData = result[0];
        } catch (err) {
            fixture.logger.error(`error encountered while executing the stored procedure - ${spName}. Error is - ${JSON.stringify(err)}`);
            // Rethrow if it's a SkipScenarioError so the caller can detect it
            if (err instanceof SkipScenarioError) {
                throw err;
            }
        } finally {
            await this.releaseDbResources();
        }
        return dbOperationResult;
    }

    async getDataForDealerOrderProductModification(modificationType: string): Promise<DbOperationResult> {
        let dbOperationResult = new DbOperationResult();
        dbOperationResult.operationResult = false;
        const spName = 'proc_TA_SeedOrder_ModifyProduct';

        modificationType = modificationType.replaceAll(" ",""); //SP does not accept spaces in the actionType

        const inputParams = [
            { name: 'ActionType', type: sql.VarChar, value: modificationType }
        ];

        try {
            fixture.logger.info(`executing the stored procedure - ${spName} - with the ActionType - ${modificationType}`);
            await this.initializeConnectionPool();
            const result = await this.dbManager.executeStoredProcedure<DealerOrderModifyProdSpResult>(
                this.pool,
                spName,
                inputParams,
                (row) => {
                    let data = new DealerOrderModifyProdSpResult();
                    data.AccountNumber = row.AccountNumber;
                    data.DealerOrderNumber = row.DealerOrderNumber;
                    data.DealerName = row.DealerName;
                    data.FromItemId = row.FromItemId;
                    data.FromItemNumber = row.FromItemNumber;
                    data.ToItemID = row.ToItemID;
                    data.ToItemNumber = row.ToItemNumber;
                    data.ToConv = row.ToMinModifiableQty;
                    return data;
                }
            );
            fixture.logger.info(`stored procedure - ${spName} - returned - ${result.length} - row(s)`);
            fixture.logger.info(`stored procedure - ${spName} - returned data is....`);
            result.forEach((row) => {
                fixture.logger.info(`${JSON.stringify(row)}`);
            });
            dbOperationResult.operationResult = true;
            dbOperationResult.operationData = result[0];
        } catch (err) {
            fixture.logger.error(`error encountered while executing the stored procedure - ${spName}. Error is - ${JSON.stringify(err)}`);
        } finally {
            await this.releaseDbResources();
        }
        return dbOperationResult;
    }

    async getDataForDealerOrderUpdation(updationType: string): Promise<DbOperationResult> {
        let dbOperationResult = new DbOperationResult();
        dbOperationResult.operationResult = false;
        const spName = 'proc_TA_DealerOrder_Update';

        updationType = updationType.replaceAll(" ",""); //SP does not accept spaces in the actionType

        const inputParams = [
            { name: 'ActionType', type: sql.VarChar, value: updationType }
        ];

        try {
            fixture.logger.info(`executing the stored procedure - ${spName} - with the ActionType - ${updationType}`);
            await this.initializeConnectionPool();
            const result = await this.dbManager.executeStoredProcedure<DealerOrderCreateOrUpdateSpResult>(
                this.pool,
                spName,
                inputParams,
                (row) => {
                    let data = new DealerOrderCreateOrUpdateSpResult();
                    data.AccountNumber = row.AccountNumber;
                    data.AccountName = row.AccountName;
                    data.DealerOrderNumber = row.DealerOrderNumber;
                    data.ItemId = row.ItemId;
                    data.ItemNumber = row.ItemNumber;
                    data.MinQty = row.MinimumTransferableUnit;
                    return data;
                }
            );
            fixture.logger.info(`stored procedure - ${spName} - returned - ${result.length} - row(s)`);
            fixture.logger.info(`stored procedure - ${spName} - returned data is....`);
            result.forEach((row) => {
                fixture.logger.info(`${JSON.stringify(row)}`);
            });
            dbOperationResult.operationResult = true;
            dbOperationResult.operationData = result[0];
        } catch (err) {
            fixture.logger.error(`error encountered while executing the stored procedure - ${spName}. Error is - ${JSON.stringify(err)}`);
        } finally {
            await this.releaseDbResources();
        }
        return dbOperationResult;
    }

    async getDataForGrowerOrderUpdation(updationType: string): Promise<DbOperationResult> {
        let dbOperationResult = new DbOperationResult();
        dbOperationResult.operationResult = false;
        const spName = 'proc_TA_GrowerOrder_Update';

        updationType = updationType.replaceAll(" ",""); //SP does not accept spaces in the actionType

        const inputParams = [
            { name: 'ActionType', type: sql.VarChar, value: updationType }
        ];

        try {
            fixture.logger.info(`executing the stored procedure - ${spName} - with the ActionType - ${updationType}`);
            await this.initializeConnectionPool();
            const result = await this.dbManager.executeStoredProcedure<GrowerOrderCreateOrUpdateSpResult>(
                this.pool,
                spName,
                inputParams,
                (row) => {
                    let data = new GrowerOrderCreateOrUpdateSpResult();
                    data.AccountNumber = row.AccountNumber;
                    data.AccountName = row.AccountName;
                    data.GMK = row.GrowerGMK;
                    data.GrowerOrderNumber = row.GrowerOrderNumber;
                    data.ItemId = row.ItemId;
                    data.ItemNumber = row.ItemNumber;
                    data.MinQty = row.MinimumTransferableUnit;
                    return data;
                }
            );
            fixture.logger.info(`stored procedure - ${spName} - returned - ${result.length} - row(s)`);
            fixture.logger.info(`stored procedure - ${spName} - returned data is....`);
            result.forEach((row) => {
                fixture.logger.info(`${JSON.stringify(row)}`);
            });
            dbOperationResult.operationResult = true;
            dbOperationResult.operationData = result[0];
        } catch (err) {
            fixture.logger.error(`error encountered while executing the stored procedure - ${spName}. Error is - ${JSON.stringify(err)}`);
        } finally {
            await this.releaseDbResources();
        }
        return dbOperationResult;
    }

    async getDataForGrowerOrderProductTransfer(isWithinDealerNetwork: boolean, needTargetGrowerOrder: boolean): Promise<DbOperationResult> {
        let dbOperationResult = new DbOperationResult();
        dbOperationResult.operationResult = false;
        
        const spName = 'proc_TA_GrowerOrder_TransferProduct';

        const actionType = isWithinDealerNetwork ? "SameDealer" : "DifferentDealer";
        const hasToGMKOrder = needTargetGrowerOrder ? 1 : 0;
        const inputParams = [
            { name: 'ActionType', type: sql.VarChar, value: actionType },
            { name: 'HasToGMKOrder', type: sql.Bit, value: hasToGMKOrder }
        ];

        try {
            fixture.logger.info(`executing the stored procedure - ${spName} - with the ActionType = ${actionType} and HasToGMKOrder = ${hasToGMKOrder}`);
            await this.initializeConnectionPool();
            fixture.logger.info(`stored procedure - ${spName} - returned data is....`);
            const result = await this.dbManager.executeStoredProcedure<GrowerOrderTransferProdSpResult>(
                this.pool,
                spName,
                inputParams,
                (row) => {
                    fixture.logger.info(`${JSON.stringify(row)}`);
                    let data = new GrowerOrderTransferProdSpResult();
                    data.SrcAccountNumber = row.FromAccountNumber;
                    data.SrcGMK = row.FromGMK;
                    data.SrcGrowerName = row.FromGrowerName;
                    data.SrcGrowerOrderNumber = row.FromGrowerOrderNumber;
                    data.FromItemId = row.FromItemId;
                    data.FromItemNumber = row.FromItemNumber;
                    data.MinTransferrableQty = row.MinimumTransferQuantity;
                    data.TrgtAccountNumber = row.ToAccountNumber;
                    data.TrgtGMK = row.ToGMK;
                    data.TrgtGrowerName = row.ToGrowerName;
                    data.TrgtGrowerOrderNumber = row.ToGrowerOrderNumber;
                    return data;
                }
            );
            /*fixture.logger.info(`stored procedure - ${spName} - returned - ${result.length} - row(s)`);
            fixture.logger.info(`stored procedure - ${spName} - returned data is....`);
            result.forEach((row) => {
                fixture.logger.info(`${JSON.stringify(row)}`);
            });*/
            dbOperationResult.operationResult = true;
            dbOperationResult.operationData = result[0];
        } catch (err) {
            fixture.logger.error(`error encountered while executing the stored procedure - ${spName}. Error is - ${JSON.stringify(err)}`);
        } finally {
            await this.releaseDbResources();
        }
            /*dbOperationResult.operationResult = true;
            dbOperationResult.operationData = this.getData(scenarioId);*/
            return dbOperationResult;
    }

    async getDataForDealerOrderProductTransfer(isWithinParentNetwork: boolean, needTargetDealererOrder: boolean): Promise<DbOperationResult> {
        let dbOperationResult = new DbOperationResult();
        dbOperationResult.operationResult = false;
        
        const spName = 'proc_TA_SeedOrder_TransferProduct';

        const actionType = isWithinParentNetwork ? "SameParent" : "DifferentParent";
        const hasToDealerOrder = needTargetDealererOrder ? 1 : 0;
        const inputParams = [
            { name: 'ActionType', type: sql.VarChar, value: actionType },
            { name: 'HasToDealerOrder', type: sql.Bit, value: hasToDealerOrder }
        ];

        try {
            fixture.logger.info(`executing the stored procedure - ${spName} - with the ActionType = ${actionType} and HasToDealerOrder = ${hasToDealerOrder}`);
            await this.initializeConnectionPool();
            fixture.logger.info(`stored procedure - ${spName} - returned data is....`);
            const result = await this.dbManager.executeStoredProcedure<DealerOrderTransferProdSpResult>(
                this.pool,
                spName,
                inputParams,
                (row) => {
                    fixture.logger.info(`${JSON.stringify(row)}`);
                    let data = new DealerOrderTransferProdSpResult();
                    data.SrcAccountNumber = row.FromAccountNumber;
                    data.SrcAccountName = row.FromAccountName;
                    data.SrcAccountOrderNumber = row.FromDealerOrderNumber;
                    data.FromItemId = row.FromItemId;
                    data.FromItemNumber = row.FromItemNumber;
                    data.MinTransferrableQty = row.MinimumTransferQuantity;
                    data.TrgtAccountNumber = row.ToAccountNumber;
                    data.TrgtAccountName = row.ToAccountName;
                    data.TrgtAccountOrderNumber = row.ToDealerOrderNumber;
                    return data;
                }
            );
            dbOperationResult.operationResult = true;
            dbOperationResult.operationData = result[0];
        } catch (err) {
            fixture.logger.error(`error encountered while executing the stored procedure - ${spName}. Error is - ${JSON.stringify(err)}`);
        } finally {
            await this.releaseDbResources();
        }
        return dbOperationResult;
    }

    async getDataForDealerStockTransfer(): Promise<DbOperationResult> {
        let dbOperationResult = new DbOperationResult();
        dbOperationResult.operationResult = false;
        
        const spName = 'proc_TA_StockTransfer';
        const inputParams = [];
        try {
            fixture.logger.info(`executing the stored procedure - ${spName}`);
            await this.initializeConnectionPool();
            fixture.logger.info(`stored procedure - ${spName} - returned data is....`);
            const result = await this.dbManager.executeStoredProcedure<DealerStockTransferSpResult>(
                this.pool,
                spName,
                inputParams,
                (row) => {
                    fixture.logger.info(`${JSON.stringify(row)}`);
                    let data = new DealerStockTransferSpResult();
                    data.SrcAccountNumber = row.FromAccountNumber;
                    data.SrcAccountName = row.FromAccountName;
                    data.ItemId = row.ItemId;
                    data.ItemNumber = row.ItemNumber;
                    data.MinTransferrableQty = row.MinimumTransferableUnit;
                    data.TrgtAccountNumber = row.ToAccountNumber;
                    data.TrgtAccountName = row.ToAccountName;
                    data.LotNumber = row.LotNumber;
                    return data;
                }
            );
            							
            dbOperationResult.operationResult = true;
            dbOperationResult.operationData = result[0];
        } catch (err) {
            fixture.logger.error(`error encountered while executing the stored procedure - ${spName}. Error is - ${JSON.stringify(err)}`);
        } finally {
            await this.releaseDbResources();
        }
        return dbOperationResult;
    }

    async getDataForNewDealerOrder(): Promise<DbOperationResult> {
        let dbOperationResult = new DbOperationResult();
        dbOperationResult.operationResult = false;
        
        const spName = 'proc_TA_DealerOrder_Create';
        const inputParams = [];
        try {
            fixture.logger.info(`executing the stored procedure - ${spName}`);
            await this.initializeConnectionPool();
            fixture.logger.info(`stored procedure - ${spName} - returned data is....`);
            const result = await this.dbManager.executeStoredProcedure<DealerOrderCreateOrUpdateSpResult>(
                this.pool,
                spName,
                inputParams,
                (row) => {
                    fixture.logger.info(`${JSON.stringify(row)}`);
                    let data = new DealerOrderCreateOrUpdateSpResult();
                    data.AccountNumber = row.AccountNumber;
                    data.AccountName = row.AccountName;
                    data.ItemId = row.ItemId;
                    data.ItemNumber = row.ItemNumber;
                    data.MinQty = row.MinimumTransferableUnit;
                    return data;
                }
            );
            									
            dbOperationResult.operationResult = true;
            dbOperationResult.operationData = result[0];
        } catch (err) {
            fixture.logger.error(`error encountered while executing the stored procedure - ${spName}. Error is - ${JSON.stringify(err)}`);
        } finally {
            await this.releaseDbResources();
        }
        return dbOperationResult;
    }

    async getDataForNewGrowerOrder(): Promise<DbOperationResult> {
        let dbOperationResult = new DbOperationResult();
        dbOperationResult.operationResult = false;
        
        const spName = 'proc_TA_GrowerOrder_Create';
        const inputParams = [];
        try {
            fixture.logger.info(`executing the stored procedure - ${spName}`);
            await this.initializeConnectionPool();
            fixture.logger.info(`stored procedure - ${spName} - returned data is....`);
            const result = await this.dbManager.executeStoredProcedure<GrowerOrderCreateOrUpdateSpResult>(
                this.pool,
                spName,
                inputParams,
                (row) => {
                    fixture.logger.info(`${JSON.stringify(row)}`);
                    let data = new GrowerOrderCreateOrUpdateSpResult();
                    data.AccountNumber = row.AccountNumber;
                    data.AccountName = row.AccountName;
                    data.GMK = row.GrowerGMK;
                    data.ItemId = row.ItemId;
                    data.ItemNumber = row.ItemNumber;
                    data.MinQty = row.MinimumTransferableUnit;
                    return data;
                }
            );
            									
            dbOperationResult.operationResult = true;
            dbOperationResult.operationData = result[0];
        } catch (err) {
            fixture.logger.error(`error encountered while executing the stored procedure - ${spName}. Error is - ${JSON.stringify(err)}`);
        } finally {
            await this.releaseDbResources();
        }
        return dbOperationResult;
    }

    async getDataForDealerOrderUpdateWithEAProduct(updationType: string): Promise<DbOperationResult> {
        let dbOperationResult = new DbOperationResult();
        dbOperationResult.operationResult = false;
        
        let spName = 'proc_TA_DealerOrder_EAModifyProduct';

        updationType = updationType.replaceAll(" ",""); //SP does not accept spaces in the actionType

        let inputParams = [
            { name: 'ActionType', type: sql.VarChar, value: updationType }
        ];

        if(updationType == "AddProduct"){
            spName = 'proc_TA_DealerOrder_EA_AddProduct';
            inputParams = [];
        }
        try {
            fixture.logger.info(`executing the stored procedure - ${spName}`);
            await this.initializeConnectionPool();
            fixture.logger.info(`stored procedure - ${spName} - returned data is....`);
            const result = await this.dbManager.executeStoredProcedure<DealerOrderCreateOrUpdateSpResult>(
                this.pool,
                spName,
                inputParams,
                (row) => {
                    fixture.logger.info(`${JSON.stringify(row)}`);
                    let data = new DealerOrderCreateOrUpdateSpResult();
                    data.AccountNumber = row.AccountNumber;
                    data.AccountName = row.AccountName;
                    data.DealerOrderNumber = row.DealerOrderNumber;
                    data.ItemId = row.ItemId;
                    data.ItemNumber = row.ItemNumber;
                    data.MinQty = row.MinimumTransferableUnit;
                    data.UpdatedEAUnits = row.EAUnits; //this EAUnits value represents post operation result
                    return data;
                }
            );
            									
            dbOperationResult.operationResult = true;
            dbOperationResult.operationData = result[0];
        } catch (err) {
            fixture.logger.error(`error encountered while executing the stored procedure - ${spName}. Error is - ${JSON.stringify(err)}`);
        } finally {
            await this.releaseDbResources();
        }
        return dbOperationResult;
    }

    async getDataForDealerOrderEAProductSwap(): Promise<DbOperationResult> {
        let dbOperationResult = new DbOperationResult();
        dbOperationResult.operationResult = false;
        const spName = 'proc_TA_DealerOrder_EA_SwapProduct';

        const inputParams = [];

        try {
            fixture.logger.info(`executing the stored procedure - ${spName}`);
            await this.initializeConnectionPool();
            const result = await this.dbManager.executeStoredProcedure<DealerOrderSwapEAProdSpResult>(
                this.pool,
                spName,
                inputParams,
                (row) => {
                    let data = new DealerOrderSwapEAProdSpResult();
                    data.AccountNumber = row.AccountNumber;
                    data.DealerOrderNumber = row.DealerOrderNumber;
                    data.DealerName = row.DealerName;
                    data.FromItemId = row.FromItemId;
                    data.FromItemNumber = row.FromItemNumber;
                    data.ToItemID = row.ToItemID;
                    data.ToItemNumber = row.ToItemNumber;
                    data.ToConv = row.MinimumTransferableUnit;
                    data.FinalFromEAUnits = row.EAUnits;
                    data.FinalToEAUnits = row.ToItemEAUnits;
                    return data;
                }
            );
            fixture.logger.info(`stored procedure - ${spName} - returned - ${result.length} - row(s)`);
            fixture.logger.info(`stored procedure - ${spName} - returned data is....`);
            result.forEach((row) => {
                fixture.logger.info(`${JSON.stringify(row)}`);
            });
            dbOperationResult.operationResult = true;
            dbOperationResult.operationData = result[0];
        } catch (err) {
            fixture.logger.error(`error encountered while executing the stored procedure - ${spName}. Error is - ${JSON.stringify(err)}`);
        } finally {
            await this.releaseDbResources();
        }
        return dbOperationResult;
    }
    /////// CPP ORDERS ///////
    static readonly CPP_PRODUCT_PACKAGE_TYPE = 'PACKAGED';

    async getDataForNewCppOrder(packageType: string): Promise<DbOperationResult> {
        let dbOperationResult = new DbOperationResult();
        dbOperationResult.operationResult = false;
        const spName = 'proc_TA_CPP_Order_Create';

        let inputParams = [
            { name: 'BulkPackaged', type: sql.VarChar, value: packageType }
        ];

        try {
            fixture.logger.info(`executing the stored procedure - ${spName}`);
            await this.initializeConnectionPool();
            const result = await this.dbManager.executeStoredProcedure<CreateCppOrderSpResult>(
                this.pool,
                spName,
                inputParams,
                (row) => {
                    let data = new CreateCppOrderSpResult();
                    data.ShipToAccountNumber = row.ShipToAccount;
                    data.ShipToAccountName = row.ShipToAccountName;
                    data.SoldToAccountName = row.SoldToAccountName;
                    data.DeliverToAccountNumber = row.DeliverToAccount;
                    data.DeliverToAccountName = row.DeliverToAccountName;
                    data.ItemId = row.ItemId;
                    data.ItemNumber = row.ItemNumber;
                    data.MinQty = row.MinOrderQty;
                    data.ContactName = row.ContactName;
                    data.UOM = row.UOM;
                    data.PackageSize = row.PackageSize;
                    data.GallonsPerQty = row.GallonsPerQty;
                    data.HasDraftOrder = row.HasDraftOrder;
                    return data;
                }
            );
            fixture.logger.info(`stored procedure - ${spName} - returned - ${result.length} - row(s)`);
            fixture.logger.info(`stored procedure - ${spName} - returned data is....`);
            result.forEach((row) => {
                fixture.logger.info(`${JSON.stringify(row)}`);
            });
            dbOperationResult.operationResult = true;
            dbOperationResult.operationData = result[0];
        } catch (err) {
            fixture.logger.error(`error encountered while executing the stored procedure - ${spName}. Error is - ${JSON.stringify(err)}`);
        } finally {
            await this.releaseDbResources();
        }
        return dbOperationResult;
    }

    async getDataForNewCppOrderWithSdm(): Promise<DbOperationResult> {
        let dbOperationResult = new DbOperationResult();
        dbOperationResult.operationResult = false;
        const spName = 'proc_TA_CPP_Order_Create_SDM'; 
        /* This SP is expected to return data as below:
         I) No of rows to return : 4
         II) 3 rows related to SDM products and 1 row related to non-SDM product
         III) All products are PACKAGED and not BULK
         IV) Each SDM product must have 3 delivery dates (scheduled-earliest, next-scheduled-earliest and unscheduled-earliest)
        */

        let inputParams = [];
        let lineItemSeqNumber = 1;
        try {
            fixture.logger.info(`executing the stored procedure - ${spName}`);
            await this.initializeConnectionPool();
            const result = await this.dbManager.executeStoredProcedure<CreateCppOrderSpResult>(
                this.pool,
                spName,
                inputParams,
                (row) => {
                    let data = new CreateCppOrderSpResult();
                    data.ShipToAccountNumber = row.ShipToAccount;
                    data.ShipToAccountName = row.ShipToAccountName;
                    data.SoldToAccountName = row.SoldToAccountName;
                    data.DeliverToAccountNumber = row.DeliverToAccount;
                    data.DeliverToAccountName = row.DeliverToAccountName;
                    data.LineItemsData = [];
                    let itemInfo = new LineItemInfo();
                    itemInfo.LineItemSeq = lineItemSeqNumber++; // Assign sequence number
                    itemInfo.ItemNumber = row.ItemNumber;
                    itemInfo.MinQty = row.MinOrderQty;
                    itemInfo.UOM = row.UOM;
                    itemInfo.PackageSize = row.PackageSize;
                    itemInfo.GallonsPerQty = row.GallonsPerQty;
                    itemInfo.IsItemSDM = row.IsItemSDM == "Y";
                    itemInfo.EarliestScheduledDeliveryDate = row.EarliestScheduleDeliveryDate;
                    itemInfo.NextEarliestScheduledDeliveryDate = row.NextEarliestScheduleDeliveryDate;
                    itemInfo.EarliestUnscheduledDeliveryDate = row.EarliestUnScheduleDeliveryDate;
                    itemInfo.NextEarliestUnScheduleDeliveryDate = row.NextEarliestUnScheduleDeliveryDate;
                    data.LineItemsData.push(itemInfo);
                    return data;
                }
            );
            
            fixture.logger.info(`stored procedure - ${spName} - returned - ${result.length} - row(s)`);
            fixture.logger.info(`stored procedure - ${spName} - returned data is....`);
            result.forEach((row) => {
                fixture.logger.info(`${JSON.stringify(row)}`);
            });
            dbOperationResult.operationResult = true;
            let finalData = this.mergeLineItems(result);
            fixture.logger.info(`finalData LineItemsData is - ${JSON.stringify(finalData.LineItemsData)}`);
            dbOperationResult.operationData = finalData;
        } catch (err) {
            fixture.logger.error(`error encountered while executing the stored procedure - ${spName}. Error is - ${JSON.stringify(err)}`);
        } finally {
            await this.releaseDbResources();
        }
        return dbOperationResult;
    }

    /**
     * @param packageType takes one of these values: PROPRIETARY
     * @param isCustomerPORequired takes one of these values: Y, N
     */
    async getDataForNewCppOrderWithBulkProduct(packageType: string = "PROPRIETARY", isCustomerPORequired: string = "Y"): Promise<DbOperationResult> {
        let dbOperationResult = new DbOperationResult();
        dbOperationResult.operationResult = false;
        const spName = 'proc_TA_CPP_Order_Create_Bulk'; 

        let inputParams = [
            { name: 'BulkProprietary', type: sql.VarChar, value: packageType },
            { name: 'IsCustomerPORequired', type: sql.VarChar, value: isCustomerPORequired }
        ];
        let lineItemSeqNumber = 1;
        try {
            fixture.logger.info(`executing the stored procedure - ${spName}`);
            await this.initializeConnectionPool();
            const result = await this.dbManager.executeStoredProcedure<CreateCppOrderSpResult>(
                this.pool,
                spName,
                inputParams,
                (row) => {
                    let data = new CreateCppOrderSpResult();
                    data.ShipToAccountNumber = row.ShipToAccount;
                    data.ShipToAccountName = row.ShipToAccountName;
                    data.SoldToAccountName = row.SoldToAccountName;
                    data.DeliverToAccountNumber = row.DeliverToAccount;
                    data.DeliverToAccountName = row.DeliverToAccountName;
                    data.LineItemsData = [];
                    data.IsPORequired = isCustomerPORequired == "Y";
                    data.ContactName = row.ContactName;
                    let itemInfo = new LineItemInfo();
                    itemInfo.LineItemSeq = lineItemSeqNumber++; // Assign sequence number
                    itemInfo.ItemNumber = row.ItemNumber;
                    itemInfo.MinQty = row.MinLineQty;
                    itemInfo.MaxQty = row.MaxLineQty;
                    itemInfo.UOM = row.OrderUOM;
                    itemInfo.PackageSize = row.PackageSize;
                    itemInfo.GallonsPerQty = row.GallonsPerQty;
                    data.LineItemsData.push(itemInfo);
                    return data;
                }
            );
            
            fixture.logger.info(`stored procedure - ${spName} - returned - ${result.length} - row(s)`);
            fixture.logger.info(`stored procedure - ${spName} - returned data is....`);
            result.forEach((row) => {
                fixture.logger.info(`${JSON.stringify(row)}`);
            });
            dbOperationResult.operationResult = true;
            let finalData = this.mergeLineItems(result);
            fixture.logger.info(`finalData LineItemsData is - ${JSON.stringify(finalData.LineItemsData)}`);
            dbOperationResult.operationData = finalData;
        } catch (err) {
            fixture.logger.error(`error encountered while executing the stored procedure - ${spName}. Error is - ${JSON.stringify(err)}`);
        } finally {
            await this.releaseDbResources();
        }
        return dbOperationResult;
    }

    /**
     * 
     * @returns multiple bulk products data for new CPP order
     */
    async getDataForNewCppOrderWithBulkProductsHavingDifferentDeliveryDates(): Promise<DbOperationResult> {
        let dbOperationResult = new DbOperationResult();
        dbOperationResult.operationResult = false;
        const spName = 'proc_TA_CPP_Order_Create_DeliveryDate_Bulk'; 

        /* This SP is expected to return data as below:
         I) No of rows to return : 6
         II) all the items must be Bulk
         III) 1 row related to one proudct and 5 rows related to another product
         IV) First two rows must have same delivery date and remaining four rows must have different delivery dates
        */

        let inputParams = [];
        let lineItemSeqNumber = 1;
        try {
            fixture.logger.info(`executing the stored procedure - ${spName}`);
            await this.initializeConnectionPool();
            const result = await this.dbManager.executeStoredProcedure<CreateCppOrderSpResult>(
                this.pool,
                spName,
                inputParams,
                (row) => {
                    let data = new CreateCppOrderSpResult();
                    data.ShipToAccountNumber = row.DealerShipToAccountNumber;
                    data.ShipToAccountName = row.DealerShipToAccountName;
                    data.SoldToAccountName = row.DealerSoldToAccountName;
                    data.DeliverToAccountNumber = row.DealerDeliverToAccountNumber;
                    data.DeliverToAccountName = row.DealerDeliverToAccountName;
                    data.LineItemsData = [];
                    data.IsPORequired = row.IsCustomerPORequired;
                    data.ContactName = row.ContactName;
                    let itemInfo = new LineItemInfo();
                    itemInfo.LineItemSeq = lineItemSeqNumber++; // Assign sequence number
                    itemInfo.ItemNumber = row.ProductItemNumber;
                    itemInfo.MinQty = row.MinQtyBulk;
                    //itemInfo.MaxQty = row.MaxLineQty;
                    itemInfo.UOM = row.OrderUOM;
                    itemInfo.PackageSize = row.PackageSize;
                    itemInfo.GallonsPerQty = row.GallonsPerQty;
                    itemInfo.RequestDeliveryDate = row.RequestDeliveryDate;
                    data.LineItemsData.push(itemInfo);
                    return data;
                }
            );
            
            fixture.logger.info(`stored procedure - ${spName} - returned - ${result.length} - row(s)`);
            fixture.logger.info(`stored procedure - ${spName} - returned data is....`);
            result.forEach((row) => {
                fixture.logger.info(`${JSON.stringify(row)}`);
            });
            dbOperationResult.operationResult = true;
            let finalData = this.mergeLineItems(result);
            fixture.logger.info(`finalData LineItemsData is - ${JSON.stringify(finalData.LineItemsData)}`);
            dbOperationResult.operationData = finalData;
        } catch (err) {
            fixture.logger.error(`error encountered while executing the stored procedure - ${spName}. Error is - ${JSON.stringify(err)}`);
        } finally {
            await this.releaseDbResources();
        }
        return dbOperationResult;
    }

    //Pacakeged - Vended - Direct-To-Ship
    async getDataForNewCppOrderWithPackVenDs(isCustomerPORequired: string): Promise<DbOperationResult> {
        let dbOperationResult = new DbOperationResult();
        dbOperationResult.operationResult = false;
        const spName = 'proc_TA_CPP_Order_Create_PackagedVended'; 
        /* This SP is expected to return data as below:
         I) No of rows to return : 3
         II) all the items must be Packaged, Vended and Direct-To-Ship
         III) 2 rows related to one vendor and 1 row related to another vendor
        */

         let inputParams = [
            { name: 'IsCustomerPORequired', type: sql.VarChar, value: isCustomerPORequired }
        ];
        let lineItemSeqNumber = 1;
        try {
            fixture.logger.info(`executing the stored procedure - ${spName}`);
            await this.initializeConnectionPool();
            const result = await this.dbManager.executeStoredProcedure<CreateCppOrderSpResult>(
                this.pool,
                spName,
                inputParams,
                (row) => {
                    let data = new CreateCppOrderSpResult();
                    data.ShipToAccountNumber = row.ShipToAccount;
                    data.ShipToAccountName = row.ShipToAccountName;
                    data.SoldToAccountName = row.SoldToAccountName;
                    data.DeliverToAccountNumber = row.DeliverToAccount;
                    data.DeliverToAccountName = row.DeliverToAccountName;
                    data.IsPORequired = row.IsCustomerPORequired;
                    
                    data.LineItemsData = [];
                    let itemInfo = new LineItemInfo();
                    itemInfo.LineItemSeq = lineItemSeqNumber++; // Assign sequence number
                    itemInfo.SupplierNumber = row.SupplierNumber.toString();
                    itemInfo.ItemNumber = row.ItemNumber;
                    itemInfo.ItemVendorName = row.ItemVendorName;
                    itemInfo.MinQty = row.MinOrderQty;
                    itemInfo.UOM = row.OrderUOM;
                    itemInfo.PackageSize = row.PackageSize;
                    itemInfo.GallonsPerQty = row.GallonsPerQty;
                    data.LineItemsData.push(itemInfo);
                    return data;
                }
            );
            
            fixture.logger.info(`stored procedure - ${spName} - returned - ${result.length} - row(s)`);
            fixture.logger.info(`stored procedure - ${spName} - returned data is....`);
            result.forEach((row) => {
                fixture.logger.info(`${JSON.stringify(row)}`);
            });
            dbOperationResult.operationResult = true;
            let finalData = this.mergeLineItems(result);
            fixture.logger.info(`finalData LineItemsData is - ${JSON.stringify(finalData.LineItemsData)}`);
            dbOperationResult.operationData = finalData;
        } catch (err) {
            fixture.logger.error(`error encountered while executing the stored procedure - ${spName}. Error is - ${JSON.stringify(err)}`);
        } finally {
            await this.releaseDbResources();
        }
        return dbOperationResult;
    }

    //Pacakeged - with arrival dates; DeliveryDateType takes either of the values: SAME, DIFFERENT
    async getDataForNewCppOrderWithPackArrivalDate(deliveryDateType: string): Promise<DbOperationResult> {
        let dbOperationResult = new DbOperationResult();
        dbOperationResult.operationResult = false;
        const spName = 'proc_TA_CPP_Order_Create_DeliveryDate'; 
        /* This SP is expected to return data as below:
         I) No of rows to return : 2
         II) all the items must be Packaged and from same vendor/supplier
         III) If DeliveryDateType = SAME then all the items must be from same supplier
         IV) If DeliveryDateType = DIFFERENT then all the items may be or may not be from the same supplier
        */

         let inputParams = [
            { name: 'DeliveryDateType', type: sql.VarChar, value: deliveryDateType }
        ];
        let lineItemSeqNumber = 1;
        try {
            fixture.logger.info(`executing the stored procedure - ${spName}`);
            await this.initializeConnectionPool();
            const result = await this.dbManager.executeStoredProcedure<CreateCppOrderSpResult>(
                this.pool,
                spName,
                inputParams,
                (row) => {
                    let data = new CreateCppOrderSpResult();
                    data.ShipToAccountNumber = row.ShipToAccount;
                    data.ShipToAccountName = row.ShipToAccountName;
                    data.SoldToAccountName = row.SoldToAccountName;
                    data.DeliverToAccountNumber = row.DeliverToAccount;
                    data.DeliverToAccountName = row.DeliverToAccountName;
                    data.IsPORequired = row.IsCustomerPORequired;
                    data.ContactName = row.ContactName;
                    
                    data.LineItemsData = [];
                    let itemInfo = new LineItemInfo();
                    itemInfo.LineItemSeq = lineItemSeqNumber++; // Assign sequence number
                    itemInfo.ItemNumber = row.ItemNumber;
                    itemInfo.MinQty = row.MinOrderQty;
                    itemInfo.UOM = row.UOM;
                    itemInfo.PackageSize = row.PackageSize;
                    itemInfo.GallonsPerQty = row.GallonsPerQty;
                    itemInfo.RequestDeliveryDate = row.RequestDeliveryDate;
                    data.LineItemsData.push(itemInfo);
                    return data;
                }
            );
            
            fixture.logger.info(`stored procedure - ${spName} - returned - ${result.length} - row(s)`);
            fixture.logger.info(`stored procedure - ${spName} - returned data is....`);
            result.forEach((row) => {
                fixture.logger.info(`${JSON.stringify(row)}`);
            });
            dbOperationResult.operationResult = true;
            let finalData = this.mergeLineItems(result);
            fixture.logger.info(`finalData LineItemsData is - ${JSON.stringify(finalData.LineItemsData)}`);
            dbOperationResult.operationData = finalData;
        } catch (err) {
            fixture.logger.error(`error encountered while executing the stored procedure - ${spName}. Error is - ${JSON.stringify(err)}`);
        } finally {
            await this.releaseDbResources();
        }
        return dbOperationResult;
    }

    //ReturnType takes either of the values: PRODUCT
    async getDataForNewCppReturnRequest(returnType: string): Promise<DbOperationResult> {
        let dbOperationResult = new DbOperationResult();
        dbOperationResult.operationResult = false;
        const spName = 'proc_TA_CPP_Returns_Product'; 
        /* This SP is expected to return data as below:
         I) No of rows to return : 5 (each row should have unique ItemNumber)
         II) 2 items from ShipToAccount (one item is returnable and another is not)
         III) 2 items from Parent of ShipToAccount (one item is returnable and another is not)
         IV) 1 item that can be maually returnable
        */
        let inputParams = [
            { name: 'ReturnType', type: sql.VarChar, value: returnType }
        ];
        let lineItemSeqNumber = 1;
        try {
            fixture.logger.info(`executing the stored procedure - ${spName}`);
            await this.initializeConnectionPool();
            const result = await this.dbManager.executeStoredProcedure<CreateCppReturnRequestSpResult>(
                this.pool,
                spName,
                inputParams,
                (row) => {
                    let data = new CreateCppReturnRequestSpResult();
                    data.ShipToAccountNumber = row.ShipToAccount;
                    data.ShipToAccountName = row.ShipToAccountName;
                    data.SoldToAccountNumber = row.SoldToAccount;
                    data.SoldToAccountName = row.SoldToAccountName;
                    data.PickupFromAccountNumber = row.PickupFromAccount;
                    data.IsPORequired = row.IsCustomerPORequired;
                    data.HasDraftOrder = row.HasDraftOrder;
                    
                    data.LineItemsData = [];
                    let itemInfo = new LineItemInfo();
                    itemInfo.LineItemSeq = lineItemSeqNumber++; // Assign sequence number
                    itemInfo.ItemNumber = row.ItemNumber;
                    itemInfo.ProductType = row.Producttype;
                    itemInfo.UOM = row.UOM;
                    itemInfo.EligibleUnits = row.EligibleUnits;
                    data.LineItemsData.push(itemInfo);
                    return data;
                }
            );
            
            fixture.logger.info(`stored procedure - ${spName} - returned - ${result.length} - row(s)`);
            fixture.logger.info(`stored procedure - ${spName} - returned data is....`);
            result.forEach((row) => {
                fixture.logger.info(`${JSON.stringify(row)}`);
            });
            dbOperationResult.operationResult = true;
            let finalData = this.mergeLineItems(result);
            fixture.logger.info(`finalData LineItemsData is - ${JSON.stringify(finalData.LineItemsData)}`);
            dbOperationResult.operationData = finalData;
        } catch (err) {
            fixture.logger.error(`error encountered while executing the stored procedure - ${spName}. Error is - ${JSON.stringify(err)}`);
        } finally {
            await this.releaseDbResources();
        }
        return dbOperationResult;
    }

    async getDataForNewCppInoculantsReturnRequest(): Promise<DbOperationResult> {
        let dbOperationResult = new DbOperationResult();
        dbOperationResult.operationResult = false;
        const spName = 'proc_TA_CPP_Returns_Inoculants'; 
        /* This SP is expected to return data as below:
         I) No of rows to return : 2 (each row should have unique ItemNumber)
         II) 1 item from ShipToAccount
         III) 1 item from Parent of ShipToAccount
        */
        let inputParams = [];
        let lineItemSeqNumber = 1;
        try {
            fixture.logger.info(`executing the stored procedure - ${spName}`);
            await this.initializeConnectionPool();
            const result = await this.dbManager.executeStoredProcedure<CreateCppReturnRequestSpResult>(
                this.pool,
                spName,
                inputParams,
                (row) => {
                    let data = new CreateCppReturnRequestSpResult();
                    data.ShipToAccountNumber = row.ShipToAccount;
                    data.ShipToAccountName = row.ShipToAccountName;
                    data.SoldToAccountNumber = row.SoldToAccount;
                    data.SoldToAccountName = row.SoldToAccountName;
                    data.PickupFromAccountNumber = row.PickupFromAccount;
                    data.IsPORequired = row.IsCustomerPORequired;
                    data.HasDraftOrder = row.HasDraftOrder;
                    
                    data.LineItemsData = [];
                    let itemInfo = new LineItemInfo();
                    itemInfo.LineItemSeq = lineItemSeqNumber++; // Assign sequence number
                    itemInfo.ItemNumber = row.ItemNumber;
                    itemInfo.ProductType = row.Producttype;
                    itemInfo.UOM = row.UOM;
                    itemInfo.EligibleUnits = row.EligibleUnits;
                    itemInfo.MaxQty = row.MaxReturnableUnits;
                    data.LineItemsData.push(itemInfo);
                    return data;
                }
            );
            
            fixture.logger.info(`stored procedure - ${spName} - returned - ${result.length} - row(s)`);
            fixture.logger.info(`stored procedure - ${spName} - returned data is....`);
            result.forEach((row) => {
                fixture.logger.info(`${JSON.stringify(row)}`);
            });
            dbOperationResult.operationResult = true;
            let finalData = this.mergeLineItems(result);
            fixture.logger.info(`finalData LineItemsData is - ${JSON.stringify(finalData.LineItemsData)}`);
            dbOperationResult.operationData = finalData;
        } catch (err) {
            fixture.logger.error(`error encountered while executing the stored procedure - ${spName}. Error is - ${JSON.stringify(err)}`);
        } finally {
            await this.releaseDbResources();
        }
        return dbOperationResult;
    }

    async getDataFromDBForSpecificCondition(columnName: string, tableName: string, condition: string): Promise<string> {
        let result = "";
        try {
            fixture.logger.info(`executing the select query to get the data based on input condition - columnName: ${columnName}, tableName: ${tableName}, condition: ${condition}`);
            await this.initializeConnectionPool();
            const queryResult = await this.dbManager.getColumnRecord(this.pool, columnName, tableName, condition);
            if (queryResult !== null && queryResult !== undefined) {
                result = String(queryResult).trim();
            } else {
                fixture.logger.warn(`no data returned from query - columnName: ${columnName}, tableName: ${tableName}, condition: ${condition}`);
            }
        } catch (err) {
            if (err instanceof Error) {
                fixture.logger.error(`error encountered while executing the query - ${err.name}: ${err.message}`);
                fixture.logger.error(`query execution stacktrace - ${err.stack}`);
            } else {
                fixture.logger.error(`error encountered while executing the query - ${String(err)}`);
            }
        } finally {
            await this.releaseDbResources();
        }
        return result;
    }

    async getDataForSeedReplantRequestGetOrCreate(requestType: string, userName: string, requestNumber?: string): Promise<DbOperationResult> {
        let dbOperationResult = new DbOperationResult();
        dbOperationResult.operationResult = false;
        const spName = 'proc_TA_SeedReplant_GetOrCreate';
        requestType = requestType.replaceAll(" ",""); //SP does not accept spaces in the actionType

        const inputParams = [
            { name: 'LoggedInUser', type: sql.VarChar, value: userName },
            { name: 'RequestType', type: sql.VarChar, value: requestType },
        ];

        try {
            fixture.logger.info(`executing the stored procedure - ${spName} - with the ActionType - ${requestType}`);
                await this.initializeConnectionPool();
                const result = await this.dbManager.executeStoredProcedure<SeedReplantGetOrCreate>(
                this.pool,
                spName,
                inputParams,
                (row) => {
                    let data = new SeedReplantGetOrCreate();
                    data.SeedReplantRequestActiveOrDraft = new SeedReplantRequestActiveOrDraft();
                    data.SeedReplantRequestCreate = new SeedReplantRequestCreate();
                    data.SeedReplantRequestActiveOrDraft.RequestId = row.RequestId;
                    data.SeedReplantRequestActiveOrDraft.RequestNumber = row.RequestNumber;
                    data.SeedReplantRequestActiveOrDraft.RequestDate = row.RequestDate;
                    data.SeedReplantRequestActiveOrDraft.AccountNumber = row.AccountNumber;
                    data.SeedReplantRequestActiveOrDraft.AccountName = row.AccountName;
                    data.SeedReplantRequestActiveOrDraft.GrowerGMK = row.GrowerGMK;
                    data.SeedReplantRequestActiveOrDraft.CustomerPO = row.CustomerPO;
                    data.SeedReplantRequestActiveOrDraft.Status = row.Status;
                    data.SeedReplantRequestActiveOrDraft.TotalReplantProducts = row.TotalReplantProducts;
                    data.SeedReplantRequestActiveOrDraft.TotalUnits = row.TotalUnits;
                    data.SeedReplantRequestCreate.ShipToAccount = row.ShipToAccount;
                    data.SeedReplantRequestCreate.ShipToAccountName = row.ShipToAccountName;
                    data.SeedReplantRequestCreate.SoldToAccount = row.SoldToAccount;
                    data.SeedReplantRequestCreate.SoldToAccountName = row.SoldToAccountName;
                    data.SeedReplantRequestCreate.GrowerGMK = row.GrowerGMK;
                    data.SeedReplantRequestCreate.GrowerBusinessName = row.GrowerBusinessName;
                    data.SeedReplantRequestCreate.GrowerFirstName = row.GrowerFirstName;
                    data.SeedReplantRequestCreate.GrowerLastName = row.GrowerLastName;
                    data.SeedReplantRequestCreate.GrowerHaveLicense = row.GrowerHaveLicense;
                    data.SeedReplantRequestCreate.CreditToAccount = row.CreditToAccount;
                    data.SeedReplantRequestCreate.CreditToAccountName = row.CreditToAccountName;
                    data.SeedReplantRequestCreate.FailedProductItemId = row.FailedProductItemId;
                    data.SeedReplantRequestCreate.FailedProductItemNumber = row.FailedProductItemNumber;
                    data.SeedReplantRequestCreate.FailedProductDescription = row.FailedProductDescription;
                    data.SeedReplantRequestCreate.FailedProductLotNumber = row.FailedProductLotNumber;
                    data.SeedReplantRequestCreate.ReplantProductItemId = row.ReplantProductItemId;
                    data.SeedReplantRequestCreate.ReplantProductItemNumber = row.ReplantProductItemNumber;
                    data.SeedReplantRequestCreate.ReplantProductDescription = row.ReplantProductDescription;
                    data.SeedReplantRequestCreate.HasDraftOrder = row.HasDraftOrder;
                    return data;
                }
                );
            fixture.logger.info(`stored procedure - ${spName} - returned - ${result.length} - row(s)`);
            if (result.length === 0) {
            throw new SkipScenarioError(`No data returned for ActionType: ${requestType}`);
            }
            fixture.logger.info(`stored procedure - ${spName} - returned data is....`);
            result.forEach((row) => {
                fixture.logger.info(`${JSON.stringify(row)}`);
            });
            dbOperationResult.operationResult = true;
            
            // For "Create" requestType with multiple rows, return all SeedReplantRequestCreate objects
            if (requestType === 'Create' && result.length > 1) {
                const response = new SeedReplantGetOrCreate();
                response.SeedReplantRequestCreate = result.map(r => r.SeedReplantRequestCreate as SeedReplantRequestCreate);
                dbOperationResult.operationData = response;
            } else if (requestType === 'Active' || requestType === 'Draft') {
                const response = new SeedReplantGetOrCreate();
                response.SeedReplantRequestActiveOrDraft = result.map(r => r.SeedReplantRequestActiveOrDraft as SeedReplantRequestActiveOrDraft);
                dbOperationResult.operationData = response;
            } else {
                dbOperationResult.operationData = result[0];
            }
        } catch (err) {
            fixture.logger.error(`error encountered while executing the stored procedure - ${spName}. Error is - ${JSON.stringify(err)}`);
            // Rethrow if it's a SkipScenarioError so the caller can detect it
            if (err instanceof SkipScenarioError) {
                throw err;
            }
        } finally {
            await this.releaseDbResources();
        }
        return dbOperationResult;
    }

    async getSeedReplantRequestDetail(requestType: string, requestNumber: number): Promise<DbOperationResult> {
        let dbOperationResult = new DbOperationResult();
        dbOperationResult.operationResult = false;
        const spName = 'proc_TA_SeedReplant_GetOrCreate';
        requestType = requestType.replaceAll(" ",""); //SP does not accept spaces in the actionType

        const inputParams = [
            { name: 'RequestType', type: sql.VarChar, value: requestType },
            { name: 'RequestNumber', type: sql.VarChar, value: requestNumber },
        ];

        try {
            fixture.logger.info(`executing the stored procedure - ${spName} - with the ActionType - ${requestType}`);
                await this.initializeConnectionPool();
                const result = await this.dbManager.executeStoredProcedure<SeedReplantGetOrCreate>(
                this.pool,
                spName,
                inputParams,
                (row) => {
                    let data = new SeedReplantGetOrCreate();
                    data.SeedReplantRequestDetail = new SeedReplantRequestDetail();
                    data.SeedReplantRequestDetail.RequestId = row.RequestId;
                    data.SeedReplantRequestDetail.RequestNumber = row.RequestNumber;
                    data.SeedReplantRequestDetail.RequestDate = row.RequestDate;
                    data.SeedReplantRequestDetail.AccountNumber = row.AccountNumber;
                    data.SeedReplantRequestDetail.AccountName = row.AccountName;
                    data.SeedReplantRequestDetail.GrowerGMK = row.GrowerGMK;
                    data.SeedReplantRequestDetail.CustomerPO = row.CustomerPO;
                    data.SeedReplantRequestDetail.ProductItemId = row.ProductItemId;
                    data.SeedReplantRequestDetail.ProductItemNumber = row.ProductItemNumber;
                    data.SeedReplantRequestDetail.ProductDescription = row.ProductDescription;
                    data.SeedReplantRequestDetail.LotNumber = row.LotNumber;
                    data.SeedReplantRequestDetail.Units = row.Units;
                    data.SeedReplantRequestDetail.ProductType = row.ProductType;
                    data.SeedReplantRequestDetail.Status = row.Status;
                    return data;
                }
                );
            fixture.logger.info(`stored procedure - ${spName} - returned - ${result.length} - row(s)`);
            if (result.length === 0) {
            throw new SkipScenarioError(`No data returned for ActionType: ${requestType}`);
            }
            fixture.logger.info(`stored procedure - ${spName} - returned data is....`);
            result.forEach((row) => {
                fixture.logger.info(`${JSON.stringify(row)}`);
            });
            dbOperationResult.operationResult = true;
            dbOperationResult.operationData = result[0];
        } catch (err) {
            fixture.logger.error(`error encountered while executing the stored procedure - ${spName}. Error is - ${JSON.stringify(err)}`);
            // Rethrow if it's a SkipScenarioError so the caller can detect it
            if (err instanceof SkipScenarioError) {
                throw err;
            }
        } finally {
            await this.releaseDbResources();
        }
        return dbOperationResult;
    }

    ///\\\ SEED RESERVATIONS \\\///
    
    /**
     * Fetches the product line and marketing brand data for seed reservations from the database.
     * @returns A promise that resolves to a DbOperationResult containing the fetched data.
     * Note: this data is not specific to any account
     */
    async getProductLineAndMarketingBrandDataForSeedReservation(): Promise<DbOperationResult> {
        let dbOperationResult = new DbOperationResult();
        dbOperationResult.operationResult = false;
        const fileName = 'getProductLineAndMarketingBrandDataForSeedReservation.sql';
        const filePath = path.join(__dirname, 'queries', fileName);
        try {
            fixture.logger.info(`running the getProductLineAndMarketingBrandDataForSeedReservation method`);
            await this.initializeConnectionPool();
            const result = await this.dbManager.executeQueryFromFile<ProductLineAndMarketingBrand>(
                this.pool,
                filePath,
                (row) => {
                    fixture.logger.info(`${JSON.stringify(row)}`);
                    let data = new ProductLineAndMarketingBrand();
                    data.ProductLineName = row.ProductLineName;
                    data.MarketingBrandName = row.MarketingBrandName;
                    return data;
                }
            );
            fixture.logger.info(`getProductLineAndMarketingBrandDataForSeedReservation method returned - ${result.length} - row(s)`);
            dbOperationResult.operationResult = true;
            dbOperationResult.operationData = result;
        } catch (err) {
            fixture.logger.error(`error encountered while running the getProductLineAndMarketingBrandDataForSeedReservation method. Error is - ${JSON.stringify(err)}`);
        } finally {
            await this.releaseDbResources();
        }
        return dbOperationResult;
    }

    /**
     * Fetches the data required for creating a new seed reservation from the database.
     * @returns A promise that resolves to a DbOperationResult containing the fetched data.
     */
    async getDataForNewSeedReservation(): Promise<DbOperationResult> {
        let dbOperationResult = new DbOperationResult();
        dbOperationResult.operationResult = false;
        /*
        Below query gets a ShipToAccount and GrowerGMK combination that does not have at least one seed reservation record in the SeedReservationHeader table. The query also ensures that the ShipToAccount is active and not of type 'X%'. Additionally, it checks that the GrowerGMK is active and has a valid business name. The query returns the ShipToAccount, ShipToAccountName, SellerAccountNumber, SellerAccountName, GrowerGMK, and GrowerName for the first matching combination found.
        */
        const fileName = 'getDataForNewSeedReservation.sql';
        const filePath = path.join(__dirname, 'queries', fileName);
        try {
            fixture.logger.info(`running the getDataForNewSeedReservation method`);
            await this.initializeConnectionPool();
            const result = await this.dbManager.executeQueryFromFile<SeedReservationDataQueryResult>(
                this.pool,
                filePath,
                (row) => {
                    fixture.logger.info(`${JSON.stringify(row)}`);
                    let data = new SeedReservationDataQueryResult();
                    data.ShipToAccountNumber = row.ShipToAccount;
                    data.ShipToAccountName = row.ShipToAccountName;
                    data.SellerAccountNumber = row.SellerAccountNumber;
                    data.SellerAccountName = row.SellerAccountName;
                    data.GrowerGMK = row.GrowerGMK;
                    data.GrowerName = row.GrowerName;
                    // not part of this query's result set
                    data.ReservationId = undefined;
                    data.ProductLineAndMarketingBrandInfo = undefined;
                    return data;
                }
            );
            fixture.logger.info(`getDataForNewSeedReservation method returned - ${result.length} - row(s)`);
            dbOperationResult.operationResult = true;
            dbOperationResult.operationData = result[0];
        } catch (err) {
            fixture.logger.error(`error encountered while running the getDataForNewSeedReservation method. Error is - ${JSON.stringify(err)}`);
        } finally {
            await this.releaseDbResources();
        }
        return dbOperationResult;
    }

    /**
     * Fetches seed reservation data
     * @param shouldContainOnlyOneLineItem Indicates whether the seed reservation should contain only one line item.
     * @returns A promise that resolves to a DbOperationResult containing the existing seed reservation data.
     */
    async getExistingSeedReservationData(shouldContainOnlyOneLineItem: boolean = false): Promise<DbOperationResult> {
        if (shouldContainOnlyOneLineItem)
            return await this.getSingleSeedReservationData();
        else
            return await this.getSeedReservationData();
    }

   /*
        Fetches the existing seed reservation data from the database, including account number, reservation ID, product line name, marketing brand name, and reservation units. The query retrieves the most recent seed reservation header and its associated details. If no existing seed reservation is found, a SkipScenarioError is thrown.
    */
    async getSeedReservationData(): Promise<DbOperationResult> {
        let dbOperationResult = new DbOperationResult();
        dbOperationResult.operationResult = false;
        const fileName = 'getSeedReservationData.sql';
        const filePath = path.join(__dirname, 'queries', fileName);
        try {
            fixture.logger.info(`running the getSeedReservationData method`);
            await this.initializeConnectionPool();
            // AccountNumber/ReservationID are identical across all line item rows for this reservation
            let accountNumber: number | undefined = undefined;
            let reservationId: number | undefined = undefined;
            let growerGMK: number | undefined = undefined;
            const lineItems = await this.dbManager.executeQueryFromFile<ProductLineAndMarketingBrand>(
                this.pool,
                filePath,
                (row) => {
                    fixture.logger.info(`${JSON.stringify(row)}`);
                    accountNumber = row.AccountNumber;
                    reservationId = row.ReservationID;
                    growerGMK = row.GrowerGMK;
                    let data = new ProductLineAndMarketingBrand();
                    data.ProductLineName = row.ProductLineName;
                    data.MarketingBrandName = row.MarketingBrandName;
                    data.ReservationUnits = row.ReservationUnits;
                    return data;
                }
            );
            fixture.logger.info(`getSeedReservationData method returned - ${lineItems.length} - line item row(s)`);
            if (lineItems.length === 0) {
                throw new SkipScenarioError(`No existing seed reservation found`);
            }
            let data = new SeedReservationDataQueryResult();
            data.ShipToAccountNumber = accountNumber!;
            data.ReservationId = reservationId;
            data.GrowerGMK = growerGMK;
            data.ProductLineAndMarketingBrandInfo = lineItems;
            dbOperationResult.operationResult = true;
            dbOperationResult.operationData = data;
        } catch (err) {
            fixture.logger.error(`error encountered while running the getSeedReservationData method. Error is - ${JSON.stringify(err)}`);
            if (err instanceof SkipScenarioError) {
                throw err;
            }
        } finally {
            await this.releaseDbResources();
        }
        return dbOperationResult;
    }

    /**
     * Fetches seed reservation data that contains only one line item from the database.
     * @returns A promise that resolves to a DbOperationResult containing the existing seed reservation data with a single line item.
     */
    async getSingleSeedReservationData(): Promise<DbOperationResult> {
        let dbOperationResult = new DbOperationResult();
        dbOperationResult.operationResult = false;
        const fileName = 'getSingleSeedReservationData.sql';
        const filePath = path.join(__dirname, 'queries', fileName);
        
        try {
            fixture.logger.info(`calling the getSingleSeedReservationData method`);
            await this.initializeConnectionPool();
            const lineItems = await this.dbManager.executeQueryFromFile<SingleSeedReservationDataQueryResult>(
                this.pool,
                filePath,
                (row) => {
                    fixture.logger.info(`${JSON.stringify(row)}`);
                    let seedReservationData = new SingleSeedReservationDataQueryResult();
                    seedReservationData.ShipToAccountNumber = row.AccountNumber;
                    seedReservationData.ReservationId = row.ReservationID;
                    seedReservationData.GrowerGMK = row.GrowerGMK;
                    seedReservationData.ProductLineAndMarketingBrandInfo = new ProductLineAndMarketingBrand();
                    seedReservationData.ProductLineAndMarketingBrandInfo.ProductLineName = row.ReservationProductLineName;
                    seedReservationData.ProductLineAndMarketingBrandInfo.MarketingBrandName = row.ReservationMarketingBrandName;
                    seedReservationData.ProductLineAndMarketingBrandInfo.ReservationUnits = row.ReservationUnits;
                    seedReservationData.MissingProductLineAndMarketingBrandInfo = new ProductLineAndMarketingBrand();
                    seedReservationData.MissingProductLineAndMarketingBrandInfo.ProductLineName = row.MissingProductLineName;
                    seedReservationData.MissingProductLineAndMarketingBrandInfo.MarketingBrandName = row.MissingMarketingBrandName;
                    return seedReservationData;
                }
            );
            fixture.logger.info(`getSingleSeedReservationData method returned - ${lineItems.length} - line item row(s)`);
            if (lineItems.length === 0) {
                throw new SkipScenarioError(`No existing seed reservation found`);
            }
            dbOperationResult.operationResult = true;
            dbOperationResult.operationData = lineItems[0];
        } catch (err) {
            fixture.logger.error(`error encountered while calling the getSingleSeedReservationData method. Error is - ${JSON.stringify(err)}`);
            if (err instanceof SkipScenarioError) {
                throw err;
            }
        } finally {
            await this.releaseDbResources();
        }
        return dbOperationResult;
    }
    ///\\\ SEED RESERVATIONS \\\///

    mergeLineItems<T extends HasLineItemsData>(results: T[]): T {
        if (results.length === 0) {
            const errMsg = `No results to merge`;
            fixture.logger.error(errMsg);
            throw new Error(errMsg);
        }
        
        // Use the first object as the base for non-array properties
        const base = results[0];
      
        // Merge all LineItemsData arrays, defaulting to an empty array if null
        const mergedLineItems = results.flatMap(result => result.LineItemsData || []);
      
        // Return a new object that combines the base properties with the merged array
        return {
          ...base,
          LineItemsData: mergedLineItems
        };
      }
}