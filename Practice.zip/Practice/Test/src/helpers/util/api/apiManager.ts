import { APIResponse } from "@playwright/test";
import { fixture } from "../../../hooks/fixture";
import DataBagKeys from "../../../tests/steps/dataBagKeys";
import ProductAvailabilityRequest from "./models/requests/productAvailabilityRequest";
import ProductAvailabilityResponse from "./models/responses/productAvailabilityResponse";
import ApiExecutor from "./apiExecutor";
import AvailableProductInfo from "./models/availableProductInfo";
import DealerAccountInfo from "./models/dealerAccountInfo";
import DealerGrowerInfo from "./models/dealerGrowerInfo";
import ProductChangeInfo from "./models/productChangeInfo";
import DealerSellerInfo from "./models/dealerSellerInfo";
import VerifyEmulatedAccount from "../test-data/emulation/verifyEmulatedAccount";
import EmulatedAccountSelectionToVerify from "../test-data/emulation/emulatedAccountSelectionToVerify";
import AccountDetails from "../test-data/dealer/accountDetails";
import DealerAccountContext from "../test-data/dealer/dealerAccountContext";
import DealerAccountInfoForEmulation from "./models/dealerAccountInfoForEmulation";
import EmulatedUserInfo from "./models/emulatedUserInfo";
import GrowerOrderItemInfo from "./models/growerOrderItemInfo";
import SeedFulfillmentInfo from "./models/seedFulfillmentInfo";

export default class ApiManager {
    private static readonly replace_AccNumber = "replace-acc-number";
    private static readonly replace_grower_orderId = "replace_grower_order_id";
    private static readonly replace_cropYear = "replace-crop-yr";
    private static readonly replace_itemId = "replace-item-id";
    private static readonly replace_action = "replace-action";

    private static readonly GROWER_PRODUCT_AVAILABILITY_URI = "GrowerOrder/product-availability";

    /**
     * gets all dealers; wfusB2BEnablement can be either No (no B2B) or Yes (with B2B)
     */
    private static readonly DEALERS_LSIT_URI = "GrowerOrder/account-list";

    /**
     * gets all growers with or without orders; order type can be either WB (no B2B) or KN (with B2B)
     */
    private static readonly DEALER_GROWERS_LIST_URI = `SeedReplant/grower-list-by-account?accountNumber=${ApiManager.replace_AccNumber}&cropYear=${ApiManager.replace_cropYear}`;

    /**
     * gets only those growers with orders; order type can be either WB (no B2B) or KN (with B2B)
     */
    private static readonly GROWERS_WITH_ORDERS_LIST_URI = `GrowerOrder/get-grower-detail?cropYear=${ApiManager.replace_cropYear}&shipToAccount=${ApiManager.replace_AccNumber}&gMk=0`;

    /**
     * gets replaceable/modifiable products
     */
    private static readonly PRODUCT_CHANGE_INFO_URI = `GrowerOrder/product-change-item?cropYear=${ApiManager.replace_cropYear}&itemId=${ApiManager.replace_itemId}&action=${ApiManager.replace_action}&accountNo=${ApiManager.replace_AccNumber}`;

    private static readonly DEALER_SELLERS_LIST_URI = `common/get-seller-list?accountNo=${ApiManager.replace_AccNumber}`;

    /**
     * gets list of dealer accounts that POSSIBLY have attached emulated users
     */
    private static readonly DEALER_EMULATION_LIST_URI = `Emulation/get-attached-account-data`;

    /**
     * gets list of attached emulated users for the specified dealer account
     */
    private static readonly DEALER_ATTACHED_USERS_LIST_URI = `Emulation/get-user-ids?account=${ApiManager.replace_AccNumber}`;

    /**
     * gets list of items included in the specified grower order id
     */
    private static readonly GROWER_ORDER_ITEMS_LIST_URI = `GrowerOrder/grower-order-items?growerOrderId=${ApiManager.replace_grower_orderId}&accountNo=${ApiManager.replace_AccNumber}&cropYear=${ApiManager.replace_cropYear}`;

    static async getAvailableProductsForTheAccount(request: ProductAvailabilityRequest): Promise<AvailableProductInfo[]> {
        const url = ApiManager.getEndpointUri(ApiManager.GROWER_PRODUCT_AVAILABILITY_URI);
        fixture.dataBag.saveData(DataBagKeys.REQUEST_BODY, request);

        let result = true;
        try {
            let response: APIResponse = await ApiExecutor.callPostMethod(url);
            const responseJson = await response.json();
            //fixture.logger.info(JSON.stringify(responseJson));
            const res = new ProductAvailabilityResponse(responseJson);
            return res.resultData;

        } catch (error) {
            result = false;
            fixture.logger.error("Failed to call the endpoint. Error: " + error);
        }
        return null;
    }

    static async getDealersWithZeroOrders(recordCountToReturn: number = 1, b2bEnabled: boolean = false): Promise<DealerAccountInfo[]> {
        const result = await ApiManager.getAvailableDealers(b2bEnabled);
        return result !== null ? result.filter(dealer => dealer.orderId === null || dealer.orderId === "").slice(0, recordCountToReturn) : null;
    }

    static async getDealersWithOrders(recordCountToReturn: number = 1, b2bEnabled: boolean = false): Promise<DealerAccountInfo[]> {
        const result = await ApiManager.getAvailableDealers(b2bEnabled);
        return result !== null ? result.filter(dealer => dealer.orderId !== null && dealer.orderId !== "" && dealer.orderId.length > 0).slice(0, recordCountToReturn) : null;
    }

    private static async getAvailableDealers(b2bEnabled: boolean): Promise<DealerAccountInfo[]> {
        const url = ApiManager.getEndpointUri(ApiManager.DEALERS_LSIT_URI);

        try {
            let response: APIResponse = await ApiExecutor.callGetMethod(url);
            const responseJson = await response.json();
            const res: DealerAccountInfo[] = responseJson.map((data: Partial<DealerAccountInfo>) => new DealerAccountInfo(data));

            if (res !== null && res.length > 0) {
                let wfusB2BEnablementComparisonValue = b2bEnabled ? "yes" : "no";
                return res.filter(dealer => dealer.wfusB2BEnablement.toLowerCase() == wfusB2BEnablementComparisonValue);
            } else {
                fixture.logger.error(`Dealers could not be retrieved from the endpoint`);
                return null;
            }

        } catch (error) {
            fixture.logger.error("Failed to call the endpoint. Error: " + error);
            return null;
        }
    }

    static async getGrowerCountOfTheDealer(accountNumber: number): Promise<number> {
        let url = ApiManager.DEALER_GROWERS_LIST_URI.replace(ApiManager.replace_AccNumber, accountNumber.toString());
        url = url.replace(ApiManager.replace_cropYear, process.env.CROP_YEAR);

        url = ApiManager.getEndpointUri(url);
        fixture.dataBag.saveData(DataBagKeys.REQUEST_BODY, {});
        try {
            let response: APIResponse = await ApiExecutor.callPostMethod(url);
            const responseJson = await response.json();

            const res: DealerGrowerInfo[] = responseJson.map((data: Partial<DealerGrowerInfo>) => new DealerGrowerInfo(data));
            if (res !== null && res.length > 0) {
                return res.length;
            } else {
                let errorMsg = `it appears the dealer with the account number -${accountNumber}- does not have any associated growers`;
                fixture.logger.warn(errorMsg);
                return 0;
            }
        } catch (error) {
            fixture.logger.error("Failed to call the endpoint. Error: " + error);
            return 0;
        }
    }

    // static async getGrowersWithZeroOrders(accountNumber: number, b2bEnabled: boolean = false, recordCountToReturn: number = 1): Promise<DealerGrowerInfo[]> {
    //     let url = ApiManager.DEALER_GROWERS_LIST_URI.replace(ApiManager.replace_AccNumber, accountNumber.toString());
    //     const result = await ApiManager.getAvailableGrowersOfTheDealer(url, b2bEnabled);
    //     return result !== null ? result.filter(grower => grower.orderID === null || grower.orderID === "").slice(0, recordCountToReturn) : null;
    // }

    // static async getGrowersWithOrders(b2bEnabled: boolean = false, recordCountToReturn: number = 1): Promise<DealerGrowerInfo[]> {
    //     const result = await ApiManager.getAvailableGrowersOfTheDealer(ApiManager.GROWERS_WITH_ORDERS_LIST_URI, b2bEnabled);
    //     return result !== null ? result.slice(0, recordCountToReturn) : null;
    // }

    static getExcludedData(dataType: string) {
        switch (dataType) {
            case "growers":
                return process.env.EXCLUDED_GROWERS_GMK_LIST.split(",").map(Number);
                break;
        }
    }

    static async getGrowersWithOrders(recordCountToReturn: number = 1, accountNumber: string = "0", b2bEnabled: boolean = false, includeGrowersFromDifferentDealers: boolean = false): Promise<DealerGrowerInfo[]> {
        let url = ApiManager.GROWERS_WITH_ORDERS_LIST_URI.replace(ApiManager.replace_cropYear, process.env.CROP_YEAR);
        url = url.replace(ApiManager.replace_AccNumber, accountNumber);

        url = ApiManager.getEndpointUri(url);

        try {
            let response: APIResponse = await ApiExecutor.callGetMethod(url);
            const responseJson = await response.json();

            const res: DealerGrowerInfo[] = responseJson.map((data: Partial<DealerGrowerInfo>) => new DealerGrowerInfo(data));
            if (res !== null && res.length > 0) {
                let wfusB2BEnablementComparisonValue = b2bEnabled ? "yes" : "no";
                const excludedGrowersGMKs = ApiManager.getExcludedData("growers");

                fixture.logger.info(`before filtering res length is...${res.length}`);
                let filteredData = res.filter(grower => grower.wfusB2BEnablement.toLowerCase() == wfusB2BEnablementComparisonValue
                    && !excludedGrowersGMKs.includes(grower.gmk));

                fixture.logger.info(`after filtering res length is...${filteredData.length}`);
                if(recordCountToReturn <= 1)
                    return filteredData.slice(0, recordCountToReturn);
                
                let uniqueDealerIds = [...new Set(filteredData.map(item => item.shipToAccount))];
                fixture.logger.info(`uniqueDealerIds count is...${uniqueDealerIds.length}`);

                if (uniqueDealerIds.length === 1)//if there is only one dealer, we will return all the records from this dealer only
                    return filteredData.slice(0, recordCountToReturn);

                let result: DealerGrowerInfo[] = [];
                if (includeGrowersFromDifferentDealers) {
                    fixture.logger.info(`growers would be from different dealers`);
                    // we will use only 2 dealer ids

                    let limit = recordCountToReturn / 2;
                    let dealer1Growers = filteredData.filter(item => item.shipToAccount == uniqueDealerIds[0]);
                    for (let index = 0; index < limit; index++) {
                        result.push(dealer1Growers[index]);
                        fixture.logger.info(`done with the first limit`);
                    }

                    let dealer2Growers = filteredData.filter(item => item.shipToAccount == uniqueDealerIds[1]);
                    limit = recordCountToReturn - limit;

                    for (let index = 0; index < limit; index++) {
                        result.push(dealer2Growers[index]);
                        fixture.logger.info(`done with the second limit`);
                    }
                } else { //this is getting growers from same dealer
                    fixture.logger.info(`growers would be from same dealer`);
                    // Create a frequency map: key = dealerId and value = grower count
                    //Note: we do this to finally decide from which dealer we need to find growers
                    //----- if we randomly decide a dealer, there is a possibility that the dealer might not have required number of growers
                    let frequencyMap: { [shipToAccount: number]: number } = {};

                    for (let grower of filteredData) {
                        if (frequencyMap[grower.shipToAccount]) {
                            frequencyMap[grower.shipToAccount]++;
                        } else {
                            frequencyMap[grower.shipToAccount] = 1;
                        }
                    }

                    // Find the dealerId with the maximum count
                    let maxCount = 0;
                    let dealerWithMaxGrowers;

                    for (let shipToAccount in frequencyMap) {
                        if (frequencyMap[shipToAccount] > maxCount) {
                            maxCount = frequencyMap[shipToAccount];
                            dealerWithMaxGrowers = shipToAccount;
                        }
                    }
                    result = filteredData.filter(item => item.shipToAccount == dealerWithMaxGrowers).slice(0, recordCountToReturn);
                }
                return result;
            } else {
                /*let errorMsg = `Growers with orders could not be retrieved from the endpoint`;
                if (accountNumber !== "0") {
                    errorMsg = errorMsg + ` for the dealer account ${accountNumber}`;
                }
                fixture.logger.error(errorMsg);*/
                return null;
            }
        } catch (error) {
            fixture.logger.error("Failed to call the endpoint. Error: " + error);
            return null;
        }
    }

    static async getModifiableProducts(accountNumber: number, itemId: number, action: string): Promise<ProductChangeInfo[]> {
        let url = ApiManager.PRODUCT_CHANGE_INFO_URI.replace(ApiManager.replace_cropYear, process.env.CROP_YEAR);
        url = url.replace(ApiManager.replace_itemId, itemId.toString());
        url = url.replace(ApiManager.replace_action, action);
        url = url.replace(ApiManager.replace_AccNumber, accountNumber.toString());

        url = ApiManager.getEndpointUri(url);

        try {
            let response: APIResponse = await ApiExecutor.callGetMethod(url);
            const responseJson = await response.json();

            const res: ProductChangeInfo[] = responseJson.map((data: Partial<ProductChangeInfo>) => new ProductChangeInfo(data));
            if (res !== null && res.length > 0) {
                return res.filter(product => product.seedAvailability > 0 && !product.isProductDeactivated);
            } else {
                let errorMsg = `Modifiable products could not be retrieved from the endpoint for the dealer account ${accountNumber} and for the item ${itemId} with the option ${action}`;
                fixture.logger.error(errorMsg);
                return [];
            }
        } catch (error) {
            fixture.logger.error("Failed to call the endpoint. Error: " + error);
            return [];
        }
    }

    static async getSellersForTheDealer(accountNumber: string): Promise<DealerSellerInfo[]> {
        let url = ApiManager.DEALER_SELLERS_LIST_URI.replace(ApiManager.replace_AccNumber, accountNumber);
        url = ApiManager.getEndpointUri(url);

        try {
            let response: APIResponse = await ApiExecutor.callGetMethod(url);
            const responseJson = await response.json();

            const res: DealerSellerInfo[] = responseJson.map((data: Partial<DealerSellerInfo>) => new DealerSellerInfo(data));
            if (res !== undefined && res !== null && res.length > 0) {
                return res;
            } else {
                let errorMsg = `Sellers could not be retrieved from the endpoint for the dealer account ${accountNumber}`;
                fixture.logger.error(errorMsg);
                return [];
            }
        } catch (error) {
            fixture.logger.error("Failed to call the endpoint. Error: " + error);
            //fixture.logger.error("Stack trace: " + error.stack);
            return [];
        }
    }

    static async getEmulationDetails(dealerAccountContext: DealerAccountContext, attachedUserRole: string = "WUSalesALL"): Promise<VerifyEmulatedAccount> {
        let url = ApiManager.getEndpointUri(ApiManager.DEALER_EMULATION_LIST_URI);
        let result: VerifyEmulatedAccount = null;
        try {
            let request: any = {};
            if (dealerAccountContext.filterCategory == "Account Name")
                request.accountName = dealerAccountContext.searchKey; //request takes several attributes but 'accountName' alone is sufficient
            else if (dealerAccountContext.filterCategory == "Account Number" || dealerAccountContext.filterCategory == "Account #")
                request.accountNo = dealerAccountContext.searchKey; //request takes several attributes but 'accountNo' alone is sufficient
            else {
                //we don't support any other filter category for now
                throw new Error(`filter category - ${dealerAccountContext.filterCategory} - is not supported in ApiManager::getEmulationDetails`);
            }
            fixture.dataBag.saveData(DataBagKeys.REQUEST_BODY, request);
            let response: APIResponse = await ApiExecutor.callPostMethod(url);
            const responseJson = await response.json();

            const accounts: DealerAccountInfoForEmulation[] = responseJson.map((data: Partial<DealerAccountInfoForEmulation>) => new DealerAccountInfoForEmulation(data));
            if (accounts !== undefined && accounts !== null && accounts.length > 0) {
                for (let index = 0; index < accounts.length; index++) {
                    let dealerAccountNumber = accounts[index].account.toString();
                    url = ApiManager.DEALER_ATTACHED_USERS_LIST_URI.replace(ApiManager.replace_AccNumber, dealerAccountNumber);
                    url = ApiManager.getEndpointUri(url);
                    let response1: APIResponse = await ApiExecutor.callGetMethod(url);
                    const responseJson1 = await response1.json();
                    if (responseJson1 === undefined || responseJson1 === null || responseJson1.length === 0)
                        continue;

                    const attachedUsers: EmulatedUserInfo[] = responseJson1.map((data: Partial<EmulatedUserInfo>) => new EmulatedUserInfo(data)).filter((user: EmulatedUserInfo) => user.data == attachedUserRole);

                    if (attachedUsers !== undefined && attachedUsers !== null && attachedUsers.length > 0) {
                        result = new VerifyEmulatedAccount();

                        result.selection = new EmulatedAccountSelectionToVerify();
                        result.selection.filterCategory = "Account #";
                        result.selection.searchKey = dealerAccountNumber;
                        result.selection.attachedAccountNumberToSelect = dealerAccountNumber;
                        result.selection.attachedUserIdToSelect = attachedUsers[0].id;

                        result.expectedAccounts = [];
                        const accountDetails = new AccountDetails();
                        accountDetails.number = dealerAccountNumber;
                        accountDetails.name = accounts[index].accountName;
                        result.expectedAccounts.push(accountDetails);

                        fixture.logger.info(`emulation details to be used are: ${JSON.stringify(result)}`);
                        break;
                    }
                }
            } else {
                let errorMsg = `For emulation setting, accounts details could not be retrieved from the endpoint for the account name search value - ${dealerAccountContext}`;
                fixture.logger.error(errorMsg);
                return null;
            }
        } catch (error) {
            fixture.logger.error("Failed to call the endpoint. Error: " + error);
            return null;
        }

        return result;
    }

    static async getGrowerOrderItems(accountNumber: string, growerOrderId: string, minGeuQty: number = 0): Promise<GrowerOrderItemInfo[]> {
        let url = ApiManager.GROWER_ORDER_ITEMS_LIST_URI.replace(ApiManager.replace_AccNumber, accountNumber);
        url = url.replace(ApiManager.replace_cropYear, process.env.CROP_YEAR);
        url = url.replace(ApiManager.replace_grower_orderId, growerOrderId);
        url = ApiManager.getEndpointUri(url);

        try {
            let response: APIResponse = await ApiExecutor.callGetMethod(url);
            const responseJson = await response.json();

            const res: GrowerOrderItemInfo[] = responseJson
                .map((data: Partial<GrowerOrderItemInfo>) => new GrowerOrderItemInfo(data))
                .filter((item: GrowerOrderItemInfo) => (item.lineErrors.id === undefined || item.lineErrors.id === null) && (item.geu >= minGeuQty));
            if (res !== undefined && res !== null && res.length > 0) {
                return res;
            } else {
                let errorMsg = `Grower order items could not be retrieved from the endpoint for the dealer account ${accountNumber} and grower order id ${growerOrderId} with product min geu quantity ${minGeuQty}`;
                fixture.logger.error(errorMsg);
                return [];
            }
        } catch (error) {
            fixture.logger.error("Failed to call the endpoint. Error: " + error);
            return [];
        }
    }

    /**
     * gets information needed for performing seed fulfillment operatons
     */
    //private static readonly SEED_FULFILLMENT_DATA_URI = `https://funcapp-evolve-pr.azurewebsites.net/api/TASeedFulfilmentAPI`;

    // static async getDataForSeedFulfillment(): Promise<SeedFulfillmentResponse> {
    //     //let url = ApiManager.SEED_FULFILLMENT_DATA_URI;
    //     let url = process.env.SEED_FULFILLMENT_API_URL;

    //     try {
    //         fixture.dataBag.saveData(DataBagKeys.AUTH_HEADERS, {}); //this API does not need any OAuth token
    //         const xFunctionsKey:Record<string, string> = {"x-functions-key": process.env.JDEReleaseFunctionsKey};
    //         const additionalHeaders: Record<string, string>[] = [xFunctionsKey];
    //         ApiExecutor.saveAdditionalHeaders(additionalHeaders);
    //         fixture.dataBag.saveData(DataBagKeys.REQUEST_BODY, {}); //this API does not take any payload
    //         let response: APIResponse = await ApiExecutor.callPostMethod(url);
    //         // Read body once
    //         const responseText = await response.text();

    //         // Non-2xx => put error into the response object
    //         if (!response.ok) {
    //             fixture.logger.error(`API returned status ${response.status}: ${responseText}`);

    //             return new SeedFulfillmentResponse({
    //                 Products: [],
    //                 Configuration: undefined as any,
    //                 Error: {
    //                     status: response.status,
    //                     code: `HTTP_${response.status}`,
    //                     message: `Seed fulfillment API failed`,
    //                     details: responseText
    //                 }
    //             });
    //         }

    //         // Empty body
    //         if (!responseText || responseText.trim() === '') {
    //             fixture.logger.error(`API returned empty response`);

    //             return new SeedFulfillmentResponse({
    //                 Products: [],
    //                 Configuration: undefined as any,
    //                 Error: {
    //                     code: "EMPTY_RESPONSE",
    //                     message: "Seed fulfillment API returned an empty body"
    //                 }
    //             });
    //         }

    //         // JSON parse
    //         let responseJson: any;
    //         try {
    //             responseJson = JSON.parse(responseText);
    //         } catch (e) {
    //             fixture.logger.error(`Failed to parse JSON. Body: ${responseText}`);

    //             return new SeedFulfillmentResponse({
    //                 Products: [],
    //                 Configuration: undefined as any,
    //                 Error: {
    //                     code: "INVALID_JSON",
    //                     message: "Seed fulfillment API returned invalid JSON",
    //                     details: e
    //                 }
    //             });
    //         }

    //         const res = new SeedFulfillmentResponse(responseJson);

    //         // To guarantee Error is not left unset:
    //         if (res == null) {
    //             return new SeedFulfillmentResponse({
    //                 Products: [],
    //                 Configuration: undefined as any,
    //                 Error: {
    //                     code: "NULL_RESPONSE_OBJECT",
    //                     message: "Seed fulfillment data could not be retrieved from the endpoint"
    //                 }
    //             });
    //         }

    //         fixture.logger.info(`Seed fulfillment API response is ${JSON.stringify(res)}`);
    //         return res;
    //     } catch (error) {
    //         fixture.logger.error("Failed to call the endpoint. Error: " + error);

    //         return new SeedFulfillmentResponse({
    //             Products: [],
    //             Configuration: undefined as any,
    //             Error: {
    //                 code: "REQUEST_FAILED",
    //                 message: "Failed to call the endpoint",
    //                 details: error
    //             }
    //         });
    //     }
    // }

    static async getDataForSeedFulfillment(): Promise<SeedFulfillmentInfo> {
        //let url = ApiManager.SEED_FULFILLMENT_DATA_URI;
        let url = process.env.SEED_FULFILLMENT_API_URL;

        try {
            fixture.dataBag.saveData(DataBagKeys.AUTH_HEADERS, {}); //this API does not need any OAuth token
            const xFunctionsKey:Record<string, string> = {"x-functions-key": process.env.JDEReleaseFunctionsKey};
            const additionalHeaders: Record<string, string>[] = [xFunctionsKey];
            ApiExecutor.saveAdditionalHeaders(additionalHeaders);
            fixture.dataBag.saveData(DataBagKeys.REQUEST_BODY, {}); //this API does not take any payload
            let response: APIResponse = await ApiExecutor.callPostMethod(url);
            
            // Check response status
            if (!response.ok) {
                const errorText = await response.text();
                fixture.logger.error(`API returned status ${response.status}: ${errorText}`);
                return null;
            }
            
            const responseText = await response.text();
            if (!responseText || responseText.trim() === '') {
                fixture.logger.error(`API returned empty response`);
                return null;
            }
            
            const responseJson = JSON.parse(responseText);
            const res = new SeedFulfillmentInfo(responseJson);
            if (res !== undefined && res !== null) {
                res.SeedWeightPerReleaseUnit = responseJson.SeedWeight;
                fixture.logger.info(`Seed fulfillment API response is ${JSON.stringify(res)}`);
                return res;
            } else {
                let errorMsg = `Seed fulfillment data could not be retrieved from the endpoint`;
                fixture.logger.error(errorMsg);
                return null;
            }
        } catch (error) {
            fixture.logger.error("Failed to call the endpoint. Error: " + error);
            return null;
        }
    }

    private static getEndpointUri(uriPart: string) {
        let uri = process.env.API_BASEURL;
        if (!uri.endsWith("/"))
            uri = uri + "/";

        uri = uri + process.env.API_URI_PREFIX;
        if (!uri.endsWith("/"))
            uri = uri + "/";

        return uri + uriPart;
    }
}