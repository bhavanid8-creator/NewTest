export default class EmulatedUserInfo{
    id: string; //this is ID
    value: string; //this is NAME
    data: string; //this is ROLE

    constructor(init?: Partial<EmulatedUserInfo>){
        Object.assign(this, init);
    }
}