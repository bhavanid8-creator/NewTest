// export default class SeedFulfillmentConfiguration{
//     BulkWeightLimit: number;
//     NonBulkWeightLimit: number;
//     constructor(init?: Partial<SeedFulfillmentConfiguration>) {
//         Object.assign(this, init);
//     }
// }