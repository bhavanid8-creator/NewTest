export default class LineErrorInfo{
    rowId: number;
    id: any | null;
    error: any | null;

    constructor(init?: Partial<LineErrorInfo>){
        Object.assign(this, init);
    }
}