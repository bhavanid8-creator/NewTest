export default class DealerGrowerInfo {
    growerOrderId: number;
    growerName: string;
    gln: string | null;
    gmk: number;
    growerAddress: string;
    orderID: string | null;
    unit: number;
    companyCode: string;
    cropYear: number;
    orderDate: string | null;
    lastUpdatedAt: string | null;
    orderType: string;
    address1: string;
    city: string;
    state: string;
    zip: string | null;
    shipToAccount: number;
    phoneNo: string | null;
    email: string | null;
    wfusB2BEnablement: string | null;
    dealerName: string;

    constructor(init?: Partial<DealerGrowerInfo>) {
        Object.assign(this, init);
    }
}