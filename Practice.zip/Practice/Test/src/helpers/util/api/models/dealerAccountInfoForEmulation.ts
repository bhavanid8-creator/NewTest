export default class DealerAccountInfoForEmulation {
    /* API response gives few other properties but are ignored here*/
    account: number;
    accountName: string;
    wfusB2BEnablement: string | null;
    parentNumber: number | null;

    constructor(init?: Partial<DealerAccountInfoForEmulation>){
        Object.assign(this, init);
    }
}