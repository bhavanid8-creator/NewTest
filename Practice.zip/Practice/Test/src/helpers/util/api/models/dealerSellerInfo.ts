export default class DealerSellerInfo{
    //there are many properties but are ignored...
    accountName: string;

    constructor(init?: Partial<DealerSellerInfo>){
        Object.assign(this, init);
    }
}