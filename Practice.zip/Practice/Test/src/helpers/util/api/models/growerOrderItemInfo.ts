import LineErrorInfo from "./lineErrorInfo";

export default class GrowerOrderItemInfo {
    /* contains several properties */
    productNameFilter: string;
    itemID: number;
    geu: number;
    marketingBrand: string;
    lineErrors: LineErrorInfo;
    itemDescription: string;
    seedSize: string;
    treatment: string;
    technology: string;
    packageSize: string;

    constructor(init?: Partial<GrowerOrderItemInfo>){
        Object.assign(this, init);
        if(init?.lineErrors !== undefined && init?.lineErrors !== null){
            this.lineErrors = new LineErrorInfo(init.lineErrors);
        }
    }
}