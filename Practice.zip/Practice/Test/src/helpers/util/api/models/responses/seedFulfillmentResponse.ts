// import SeedFulfillmentConfiguration from "../seedFulfillmentConfiguration";
// import SeedFulfillmentInfo from "../seedFulfillmentInfo";

// export default class SeedFulfillmentResponse{
//     Products: SeedFulfillmentInfo[];
//     Configuration: SeedFulfillmentConfiguration;
//     Error: any = null;

//     constructor(init?: Partial<SeedFulfillmentResponse>) {
//         Object.assign(this, init);
//         this.Products = init?.Products?.map(prodInfo => new SeedFulfillmentInfo(prodInfo)) || [];
//         this.Configuration = new SeedFulfillmentConfiguration(init?.Configuration);
//         this.Error = init?.Error ?? null;
//     }
//     getProductByType(productType: 'Bulk' | 'Non-Bulk' | 'CBOX'): SeedFulfillmentInfo {
//         return this.Products.find(product => product.ProductType === productType);
//     }
// }