export default class SeedFulfillmentInfo{
    AccountNumber: number;
    AccountName: string;
    DealerOrderId: number;
    DealerOrderNumber: string;
    BranchPlantId: string;
    ItemId: number;
    ItemNumber: string;
    UOM: string;
    ProductLine: string;
    AvailableToShip: number;
    SeedWeightPerReleaseUnit: number;
    //SeedWeight: number;
    PalletWeight: number;
    PalletQuantity: number;
    PalletType: string;
    Error: any;
    //ProductType: 'Bulk' | 'Non-Bulk' | 'CBOX';
    
    constructor(init?: Partial<SeedFulfillmentInfo>) {
        Object.assign(this, init);
    }
}