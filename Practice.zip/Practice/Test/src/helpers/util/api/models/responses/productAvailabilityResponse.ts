import AvailableProductInfo from "../availableProductInfo";

export default class ProductAvailabilityResponse{
    resultData: AvailableProductInfo[]

    constructor(init?: Partial<ProductAvailabilityResponse>) {
        Object.assign(this, init);
        this.resultData = init?.resultData?.map(prodInfo => new AvailableProductInfo(prodInfo)) || [];
    }
}