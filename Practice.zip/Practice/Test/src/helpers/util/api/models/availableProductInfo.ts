export default class AvailableProductInfo {

    brand: string;
    itemId: number;
    itemNumber: string;
    itemDescription: string;
    seedSize: number;
    treatment: string;
    maturity: string;
    technology: string;
    productLine: string;
    marketingBrand: string;
    packageSize: string;
    conv: number;
    seedAvailability: number;
    netGEU: number;
    netBEU: number;
    longShortPosition: number;
    myDealerBucketQty: number;
    softCommitUnits: number;
    plannedUnits: number;
    shippedUnits: number;
    highlightPackage: number;
    highlightTreatment: number;
    highlightTechnology: number;
    myDealerBucket: number;
    primaryUOM: string;
    secondaryUOM: string;
    dealerModifiableUnits: number;
    isProductDeactivated: boolean;
    deactivationType: string | null;
    stockTransferUnits: number;
    seedNonReturnable: boolean;
    
    constructor(init?: Partial<AvailableProductInfo>) {
        Object.assign(this, init);
    }
}