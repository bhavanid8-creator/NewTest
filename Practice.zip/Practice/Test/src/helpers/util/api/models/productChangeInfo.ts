export default class ProductChangeInfo{
    /*
    this class receives several properties from the API but only few are selected here
    */
    itemID: number;
    brand: string;
    itemNumber: string;
    itemDescription: string;
    conv: number;
    seedAvailability: number;
    isProductDeactivated: boolean;
    stockTransferUnits: number;

    constructor(init?: Partial<ProductChangeInfo>) {
        Object.assign(this, init);
    }
}