//import { faker } from '@faker-js/faker';
import { DateTime } from "luxon";

type MethodNames =
  | 'getTime'
  | 'convertDateToUTC'
  | 'getCurrentUtcDateTime'
  | 'getCurrentDateTimeInDesiredTimeZone'
  | 'getCustomStartDate'
  | 'getFormattedDate_MMMM_D_YYYY'
  | 'convertDateTime'
  | 'getDateDifference';

export class DateTimeUtility {

  startDate: Date = new Date('2000-01-01');

  endDate: Date = new Date();

  todayDate: Date = new Date();

  getTime(): string {
    return new Intl.DateTimeFormat('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
    }).format(this.endDate);
  }

  getDateDifference(startDate: string, endDate: string): string {
    const start: Date = new Date(startDate);
    const end: Date = new Date(endDate);
    if (isNaN(start.getTime()) || isNaN(end.getTime())) {
      throw new Error('Invalid date format');
    }
    if (end < start) {
      throw new Error('End date must be after start date');
    }
    let years: number = end.getFullYear() - start.getFullYear();
    let months: number = end.getMonth() - start.getMonth();
    let days: number = end.getDate() - start.getDate();
    if (days < 0) {
      months -= 1;
      const previousMonthDays = new Date(end.getFullYear(), end.getMonth(), 0).getDate();
      days += previousMonthDays;
    }
    if (months < 0) {
      years -= 1;
      months += 12;
    }
    const parts: string[] = [];
    if (years > 0) parts.push(`${years} years`);
    if (months > 0) parts.push(`${months} months`);
    if (days > 0) parts.push(`${days} days`);
    return parts.join(' ');
  }

  convertDateTime(inputDateTime: string, inputFormat: string, outputFormat: string): string {
    const dateTime: DateTime<true> | DateTime<false> = DateTime.fromFormat(inputDateTime, inputFormat);
    return dateTime.toFormat(outputFormat);
  }

  getFormattedDate_MMMM_D_YYYY(offsetDays: number = 0): string {
    const date = new Date();
    date.setDate(date.getDate() + offsetDays);

    const options: Intl.DateTimeFormatOptions = {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    };
    return date.toLocaleDateString('en-US', options); // e.g., July 2, 2025
   }

  getCustomStartDate(zoneId: string, requiredFormat: string): string {
    const currentDateTime: DateTime<true> | DateTime<false> = DateTime.now().setZone(zoneId);
    const startOfLastYearApril: DateTime<true> | DateTime<false> = currentDateTime
      .minus({ years: 1 })
      .set({ month: 4, day: 1, hour: 0, minute: 0, second: 0 });
    const formattedDateTime: string = startOfLastYearApril.toFormat(requiredFormat);
    console.log('getCustomStartDate: ' + formattedDateTime);
    return formattedDateTime;
  }

  getCurrentDateTimeInDesiredTimeZone(zoneId: string, format: string): string {
    const currentDateTime: DateTime<true> | DateTime<false> = DateTime.now().setZone(zoneId);
    const formattedDateTime: string = currentDateTime.toFormat(format);
    console.log('getCurrentDateTime: ' + formattedDateTime);
    return formattedDateTime;
  }

  getCurrentUtcDateTime(): number {
    const now = new Date(); // Get the current date and time
    const milliseconds = now.getTime(); // Convert to UTC ISO string
    return milliseconds;
  }

  convertDateToUTC(dateString: string, formattedDateTime: string, zoneId: string): string {
    const istDateTime: DateTime<true> | DateTime<false> = DateTime.fromFormat(dateString, formattedDateTime, {
      zone: zoneId,
    });
    const utcDateTime: DateTime<true> | DateTime<false> = istDateTime.toUTC();
    return utcDateTime.toFormat(formattedDateTime);
  }

formatDate(date: Date, format: string): string {
  const map: { [key: string]: string } = {
    'MM': String(date.getMonth() + 1).padStart(2, '0'),
    'DD': String(date.getDate()).padStart(2, '0'),
    'YYYY': String(date.getFullYear()),
    'YY': String(date.getFullYear()).slice(-2),
  };
  return format.replace(/MM|DD|YYYY|YY/g, matched => map[matched]);
}

  getFormattedDate(numberOfDayFromCurrentDate: number = 0): string {
  const date = new Date();
  date.setDate(date.getDate() + numberOfDayFromCurrentDate); // e.g. -7 for 7 days ago
  const day = String(date.getDate()).padStart(2, '0');
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const year = date.getFullYear();

  return `${day}/${month}/${year}`; // Adjust format as per your app
}

}
