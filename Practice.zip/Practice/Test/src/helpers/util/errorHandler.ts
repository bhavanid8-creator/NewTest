export class SkipScenarioError extends Error {
    constructor(message: string) {
        super(message);
        this.name = 'SkipScenarioError';
    }
}