import { expect, Locator, Page } from '@playwright/test';
import { get } from 'http';

export class ActionUtility {

constructor(private page: Page) { }

  async click(locator: Locator, timeout?: number): Promise<void> {
    await expect(locator).toBeVisible();
    await locator.click({ timeout : timeout });
  }

  async pressEnter(locator: Locator): Promise<void> {
    await expect(locator).toBeVisible();
    await locator.press('Enter');
  }

  async inputValue(locator: Locator, value: string): Promise<void> {
    await expect(locator).toBeVisible();
    await locator.fill(value);
  }

  async clear(locator: Locator): Promise<void> {
    await expect(locator).toBeVisible();
    await locator.clear();
  }

  async getAttributeValue(locator: Locator, attributeName: string): Promise<string | null> {
    await expect(locator).toBeVisible();
    return locator.getAttribute(attributeName);
  }

  async getPropertyAttributeValue(locator: Locator, propertyName: string): Promise<string> {
    await expect(locator).toBeVisible();
    const value = await locator.evaluate((element, propertyAttributeValue) => {
      const elementAsInput = element as HTMLInputElement;
      return (elementAsInput[propertyAttributeValue as keyof HTMLInputElement] as string) ??
        element.getAttribute(propertyAttributeValue) ??
        '';
    }, propertyName);
    return value;
  }

  async getInputValue(locator: Locator): Promise<string> {
    await expect(locator).toBeVisible();
    return locator.inputValue();
  }

  async selectDropdownValue(locator: Locator, dropDownValue: string): Promise<void> {
    await locator.selectOption(dropDownValue);
  }

  async selectDropdownOptionByTitle(locator: Locator, titleValue: string): Promise<void> {
    await locator.evaluate((select: HTMLSelectElement, title) => {
      const options = Array.from(select.options);
      const optionToSelect = options.find(option => option.title === title);
      if (optionToSelect) {
        select.value = optionToSelect.value;
        select.dispatchEvent(new Event('change', { bubbles: true }));
      }
    }, titleValue);
  }

  async selectDropdownValueByIndex(locator: Locator, index: number): Promise<void> {
    await locator.selectOption({ index: index });
  }

  async getSelectedDropdownOption(locator: Locator): Promise<string> {
    const selectedText: string = await locator.evaluate(select => {
      const selectedOption: HTMLOptionElement =  (select as HTMLSelectElement).options[(select as HTMLSelectElement).selectedIndex];
      return selectedOption.text;
    });
    return selectedText as string;
  }

  async normaliseTheText(actualText: string): Promise<string> {
    return actualText.replace(/\s+/g, ' ').trim();
  }

  async getSelectedDropdownValue(locator: Locator): Promise<string> {
    const selectedValue: string = await locator.evaluate(select => {
      const selectedOption: HTMLOptionElement =  (select as HTMLSelectElement).options[(select as HTMLSelectElement).selectedIndex];
      return selectedOption.value;
    });
    return selectedValue as string;
  }

  async getSelectedDropdownTitleValue(locator: Locator): Promise<string> {
    return locator.evaluate(select => {
      const selectedOption: HTMLOptionElement =  (select as HTMLSelectElement).options[(select as HTMLSelectElement).selectedIndex];
      return selectedOption.title;
    });
  }

  async getAllDropdownOptions(xpath: string): Promise<string[]> {
    const locator = this.page.locator(xpath);
    await expect(locator).toBeVisible();
    return locator.locator('option').allTextContents();
  }

  async getAllCustomDropdownOptions(xpath: string): Promise<string[]> {
    const locator = this.page.locator(xpath);
    await expect(locator).toBeVisible();

    const customOptions = locator.locator('.ng-option, [role="option"]');
    if (await customOptions.count() > 0) {
      return (await customOptions.allTextContents())
        .map(option => option.replace(/\s+/g, ' ').trim())
        .filter(option => option.length > 0);
    }

    return (await locator.allTextContents())
      .map(option => option.replace(/\s+/g, ' ').trim())
      .filter(option => option.length > 0);
  }

  async verifyArrayValues(expectedOptions: string[], actualOptions: string[]): Promise<void> {
    let expectedOption: string;
    for (expectedOption of expectedOptions) {
      expect(actualOptions).toContain(expectedOption);
    }
  }

  async getAllDropdownOptionTitles(locator: Locator): Promise<string[]> {
    return locator.evaluate((select: HTMLSelectElement) => {
      const options = Array.from(select.options);
      return options.map(option => option.title);
    });
  }

  async setCheckboxState(locator: Locator, check: boolean): Promise<void> {
    const isChecked: boolean = await locator.isChecked();
    if (check && !isChecked) {
      await locator.check();
    } else if (!check && isChecked) {
      await locator.uncheck();
    }
  }

  async getTextFromLocator(locator: Locator): Promise<string> {
    await locator.waitFor({ state: 'visible' });
    await expect(locator).toBeVisible();
    return await locator.textContent() || '';
  }

  async getTextByXpath(xpath: string): Promise<string> {
    const locator = this.page.locator(xpath);
    return await this.getTextFromLocator(locator);
  }

  async getInnerTextValue(locator: Locator): Promise<string> {
    await expect(locator).toBeVisible();
    return locator.innerText();
  }

  async hover(locator: Locator): Promise<void> {
    await expect(locator).toBeVisible();
    await locator.hover();
  }

  async getAllTextContent(locator: Locator): Promise<string[]> {
    return locator.allTextContents();
  }

  async getTotalLocatorCount(locator: Locator): Promise<number> {
    return locator.count();
  }

  async generateRandomNumber(): Promise<number> {
  const eightDigitNumber =  Math.floor(10000000 + Math.random() * 90000000);
  return eightDigitNumber;
}

  async acceptAlert(page: Page, alertMessage: string): Promise<void> {
    page.on('dialog', async (dialog) => {
      expect(dialog.message()).toBe(alertMessage);
      await dialog.accept();
    });
  }
}