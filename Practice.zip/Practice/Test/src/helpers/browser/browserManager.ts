import { LaunchOptions, chromium, firefox, webkit } from "@playwright/test";

const defaultOptions: LaunchOptions = {
    //headless: !true,
    headless: process.env.CI === 'true' || (process.env.IS_LOCAL !== 'true'),
    //args: ['--start-maximized'],
    args: ['--window-size=1920,1200', '--force-device-scale-factor=0.9'],
}
export const invokeBrowser = (options: LaunchOptions = null) => {
    if(options == null){
        options = defaultOptions;
    }
    //const browserType = process.env.npm_config_BROWSER || "chrome";
    const browserType = process.env.BROWSER || "chrome";
    switch (browserType) {
        case "chrome":
            return chromium.launch(options);
        case "firefox":
            return firefox.launch(options);
        case "webkit":
            return webkit.launch(options);
        default:
            throw new Error("Please set the proper browser!")
    }

}