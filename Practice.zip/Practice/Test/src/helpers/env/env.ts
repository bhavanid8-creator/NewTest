import { config } from 'dotenv'

export const getEnv = () => {
    const env = process.env.npm_config_ENV || process.env.ENV || 'QA2';

    config({
        override: true,
        path: `src/helpers/env/.env.${env}`
    })
}