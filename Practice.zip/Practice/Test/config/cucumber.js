const env = process.env.npm_config_ENV || process.env.ENV || 'QA2';

require('dotenv').config({ path: `src/helpers/env/.env.${env}` });


module.exports = {
    default: {
        tags: process.env.npm_config_TAGS || "",
        formatOptions: {
            snippetInterface: "async-await"
        },
        paths: [
            "src/tests/features/"
        ],
        dryRun: false,
        require: [
            "src/tests/steps/**/*.ts",
            "src/tests/steps/**/**/*.ts",
            "src/tests/steps/grower/orders/*.ts",
            "src/tests/steps/grower/orders/verification/*.ts",
            "src/tests/steps/grower/orders/adminMultipleAccount/*.ts",
            "src/tests/steps/grower/orders/adminSingleAccount/*.ts",
            "src/tests/steps/grower/orders/emulation/*.ts",
            "src/hooks/hooks.ts",
            "src/tests/steps/dealer/seed/*.ts",
            "src/tests/steps/dealer/seed/orders/*.ts",
            "src/tests/steps/seed/replant/*.ts",
            "src/tests/steps/seed/fulfillment/*.ts",
            "src/tests/steps/cpp/orders/*.ts",
            "src/tests/steps/cpp/common/*.ts",
            "src/tests/steps/cpp/returns/*.ts",
            "src/tests/steps/seed/reservations/*.ts",
        ],
        requireModule: [
            "ts-node/register"
        ],
        format: [
            "progress-bar",
            "summary",
            // "html:test-results/cucumber-report.html",
            // "json:test-results/cucumber-report.json",
            "rerun:@rerun.txt"
        ],
        parallel: 1,
        retry: (() => {
            const retryCount = parseInt(process.env.CUCUMBER_RETRY_COUNT, 10);
            return isNaN(retryCount) ? 0 : retryCount;
        })()
    },
    rerun: {
        formatOptions: {
            snippetInterface: "async-await"
        },
        dryRun: false,
        require: [
            "src/tests/steps/**/*.ts",
            "src/tests/steps/**/**/*.ts",
            "src/tests/steps/grower/orders/*.ts",
            "src/tests/steps/grower/orders/verification/*.ts",
            "src/tests/steps/grower/orders/adminMultipleAccount/*.ts",
            "src/tests/steps/grower/orders/adminSingleAccount/*.ts",
            "src/tests/steps/grower/orders/emulation/*.ts",
            "src/hooks/hooks.ts",
            "src/tests/steps/dealer/seed/*.ts",
            "src/tests/steps/dealer/seed/orders/*.ts",
            "src/tests/steps/seed/replant/*.ts",
            "src/tests/steps/seed/fulfillment/*.ts",
            "src/tests/steps/cpp/orders/*.ts",
            "src/tests/steps/cpp/common/*.ts",
            "src/tests/steps/cpp/returns/*.ts",
            "src/tests/steps/seed/reservations/*.ts",
        ],
        requireModule: [
            "ts-node/register"
        ],
        format: [
            "progress-bar",
            "summary",
            // "html:test-results/cucumber-report.html",
            // "json:test-results/cucumber-report.json",
        ],
        parallel: 1,
        retry: (() => {
            const retryCount = parseInt(process.env.CUCUMBER_RETRY_COUNT, 10);
            return isNaN(retryCount) ? 0 : retryCount;
        })()
    },
    order: {
        formatOptions: {
            snippetInterface: "async-await"
        },
        dryRun: false,
        require: [
            "src/tests/steps/**/*.ts",
            "src/tests/steps/**/**/*.ts",
            "src/tests/steps/grower/orders/*.ts",
            "src/tests/steps/grower/orders/verification/*.ts",
            "src/tests/steps/grower/orders/adminMultipleAccount/*.ts",
            "src/tests/steps/grower/orders/adminSingleAccount/*.ts",
            "src/tests/steps/grower/orders/emulation/*.ts",
            "src/hooks/hooks.ts",
            "src/tests/steps/dealer/seed/*.ts",
            "src/tests/steps/dealer/seed/orders/*.ts",
            "src/tests/steps/seed/replant/*.ts",
            "src/tests/steps/seed/fulfillment/*.ts",
            "src/tests/steps/cpp/orders/*.ts",
            "src/tests/steps/cpp/common/*.ts",
            "src/tests/steps/cpp/returns/*.ts",
            "src/tests/steps/seed/reservations/*.ts",
        ],
        requireModule: [
            "ts-node/register"
        ],
        format: [
            "progress-bar",
            "summary",
            // "html:test-results/cucumber-report.html",
            // "json:test-results/cucumber-report.json",
            "rerun:@rerun.txt"
        ],
        parallel: 1,
        retry: (() => {
            const retryCount = parseInt(process.env.CUCUMBER_RETRY_COUNT, 10);
            return isNaN(retryCount) ? 0 : retryCount;
        })()
    }
}